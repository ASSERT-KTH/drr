import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        dateAxis0.setAutoTickUnitSelection(false);
        java.awt.Paint paint9 = dateAxis0.getAxisLinePaint();
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange10, false, false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(dateRange10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth((double) 200);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str16 = categoryMarker15.getLabel();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot4, dataset18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        int int13 = categoryPlot4.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot4.getRangeAxisForDataset((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis19.getTickUnit();
        dateAxis19.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis19.setTickUnit(dateTickUnit24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer26);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint29, stroke30, (java.awt.Paint) color31, stroke32, 0.0f);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker34.setPaint(paint35);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot27.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        int int45 = categoryPlot44.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        categoryPlot44.setRangeAxisLocation((int) (short) 1, axisLocation47);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot44.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation39, plotOrientation49);
        categoryPlot4.setDomainAxisLocation(axisLocation39, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        dateAxis53.zoomRange((double) 10, (double) '#');
        java.awt.Shape shape57 = dateAxis53.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        double double59 = dateAxis58.getLowerBound();
        java.awt.Shape shape60 = dateAxis58.getLeftArrow();
        dateAxis53.setDownArrow(shape60);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis53);
        boolean boolean63 = dateAxis53.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot11.getSeriesRenderingOrder();
        xYPlot11.setNoDataMessage("");
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        categoryPlot8.setRangeCrosshairValue((double) '4');
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) categoryPlot8);
        java.awt.Image image15 = null;
        categoryPlot8.setBackgroundImage(image15);
        org.jfree.data.general.Dataset dataset17 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) image15, dataset17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        double double5 = dateAxis0.getLowerMargin();
        double double6 = dateAxis0.getFixedDimension();
        double double7 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color1 = java.awt.Color.magenta;
        boolean boolean2 = numberAxis0.equals((java.lang.Object) color1);
        numberAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) -1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        dateAxis2.configure();
        dateAxis2.setVerticalTickLabels(true);
        dateAxis2.setVisible(false);
        java.awt.Stroke stroke11 = dateAxis2.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-32513), paint1, stroke11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        dateAxis0.configure();
        java.awt.Shape shape5 = dateAxis0.getRightArrow();
        java.awt.Shape shape6 = dateAxis0.getUpArrow();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint16, stroke17, (java.awt.Paint) color18, stroke19, 0.0f);
        categoryPlot11.setDomainGridlineStroke(stroke19);
        categoryPlot11.clearRangeMarkers(9);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection26 = categoryPlot11.getRangeMarkers(layer25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = categoryPlot31.getOrientation();
        categoryPlot11.setOrientation(plotOrientation36);
        java.awt.Color color38 = java.awt.Color.darkGray;
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color38);
        dateAxis0.setTickMarkPaint((java.awt.Paint) color38);
        java.awt.Color color41 = color38.darker();
        java.awt.image.ColorModel colorModel42 = null;
        java.awt.Rectangle rectangle43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color41.createContext(colorModel42, rectangle43, rectangle2D44, affineTransform45, renderingHints46);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paintContext47);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        int int42 = day24.getMonth();
        long long43 = day24.getFirstMillisecond();
        java.util.Calendar calendar44 = null;
        try {
            long long45 = day24.getMiddleMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-57600000L) + "'", long43 == (-57600000L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        xYPlot11.mapDatasetToDomainAxis(12, (int) ' ');
        double double15 = xYPlot11.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis19.getTickUnit();
        dateAxis19.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis19.setTickUnit(dateTickUnit24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer26);
        java.awt.Paint paint28 = xYPlot27.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        int int30 = xYPlot27.indexOf(xYDataset29);
        xYPlot27.clearRangeMarkers(2);
        xYPlot27.setRangeZeroBaselineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        int int41 = categoryPlot40.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        categoryPlot40.setRangeAxisLocation((int) (short) 1, axisLocation43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = dateAxis46.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = dateAxis48.getTickUnit();
        dateAxis48.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = dateAxis52.getTickUnit();
        dateAxis48.setTickUnit(dateTickUnit53);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer55);
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint58, stroke59, (java.awt.Paint) color60, stroke61, 0.0f);
        java.awt.Paint paint64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker63.setPaint(paint64);
        xYPlot56.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker63);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str68 = lengthAdjustmentType67.toString();
        boolean boolean70 = lengthAdjustmentType67.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint73 = categoryAxis72.getAxisLinePaint();
        java.awt.Paint paint74 = categoryAxis72.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker76 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker76.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint80 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke81 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color82 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke83 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker85 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint80, stroke81, (java.awt.Paint) color82, stroke83, 0.0f);
        categoryMarker76.setOutlineStroke(stroke81);
        categoryAxis72.setTickMarkStroke(stroke81);
        boolean boolean88 = lengthAdjustmentType67.equals((java.lang.Object) categoryAxis72);
        categoryMarker63.setLabelOffsetType(lengthAdjustmentType67);
        categoryPlot40.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63);
        org.jfree.chart.util.Layer layer91 = null;
        boolean boolean93 = xYPlot27.removeDomainMarker(1, (org.jfree.chart.plot.Marker) categoryMarker63, layer91, false);
        java.awt.Stroke stroke94 = categoryMarker63.getStroke();
        xYPlot11.setDomainGridlineStroke(stroke94);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTickUnit47);
        org.junit.Assert.assertNotNull(dateTickUnit49);
        org.junit.Assert.assertNotNull(dateTickUnit53);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(lengthAdjustmentType67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "CONTRACT" + "'", str68.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(stroke94);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        categoryPlot4.setAnchorValue((double) 7, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        boolean boolean7 = dateAxis0.isNegativeArrowVisible();
        java.lang.Object obj8 = dateAxis0.clone();
        double double9 = dateAxis0.getUpperBound();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint5, stroke6, (java.awt.Paint) color7, stroke8, 0.0f);
        categoryMarker1.setOutlineStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryMarker1.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets12.createOutsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Paint paint7 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) numberTickUnit6);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        boolean boolean6 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint7 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot4.getDomainGridlinePosition();
        boolean boolean17 = categoryPlot4.isDomainGridlinesVisible();
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis15.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis17.setTickUnit(dateTickUnit22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer24);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint27, stroke28, (java.awt.Paint) color29, stroke30, 0.0f);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker32.setPaint(paint33);
        xYPlot25.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot25.getDomainAxisLocation(12);
        xYPlot11.setDomainAxisLocation(axisLocation37, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        xYPlot11.setRenderer(1, xYItemRenderer41);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot11.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset13);
        java.lang.Object obj15 = datasetChangeEvent14.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent14);
        boolean boolean17 = categoryPlot4.isSubplot();
        categoryPlot4.clearRangeMarkers((int) '#');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + false + "'", obj15.equals(false));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        float float10 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot4.removeRangeMarker(100, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation((int) (short) 1, axisLocation8);
        boolean boolean10 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double16 = categoryAxis15.getUpperMargin();
        categoryPlot5.setDomainAxis((int) ' ', categoryAxis15, false);
        categoryAxis15.setUpperMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis15, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryAxis15.getTickMarkStroke();
        float float25 = categoryAxis15.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace7, false);
        java.lang.String str10 = categoryPlot4.getPlotType();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        categoryPlot4.setWeight((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot4.getDomainAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis23.setTickUnit(dateTickUnit28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        dateAxis33.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range37 = dateAxis33.getDefaultAutoRange();
        double double38 = dateAxis33.getLowerMargin();
        boolean boolean39 = seriesRenderingOrder32.equals((java.lang.Object) dateAxis33);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { dateAxis33 };
        xYPlot31.setDomainAxes(valueAxisArray40);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot31.setDomainGridlinePaint(paint42);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder44);
        java.awt.geom.Point2D point2D46 = xYPlot31.getQuadrantOrigin();
        categoryPlot4.zoomDomainAxes(0.2d, (double) 1.0f, plotRenderingInfo19, point2D46);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        xYPlot11.drawAnnotations(graphics2D29, rectangle2D30, plotRenderingInfo31);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset13);
        java.lang.Object obj15 = datasetChangeEvent14.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent14);
        boolean boolean17 = categoryPlot4.isSubplot();
        categoryPlot4.setForegroundAlpha(0.8f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + false + "'", obj15.equals(false));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        double double7 = rectangleInsets2.calculateTopInset((double) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        java.lang.String str5 = categoryAxis1.getLabelToolTip();
        java.lang.Object obj6 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation((int) (short) 1, axisLocation9);
        categoryPlot6.configureRangeAxes();
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot20.addChangeListener(plotChangeListener24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        int int31 = categoryPlot30.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        categoryPlot30.setRangeAxisLocation((int) (short) 1, axisLocation33);
        categoryPlot30.configureRangeAxes();
        categoryPlot30.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot30.getRowRenderingOrder();
        categoryPlot20.setColumnRenderingOrder(sortOrder38);
        org.jfree.chart.plot.Plot plot40 = categoryPlot20.getParent();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets();
        double double45 = rectangleInsets43.calculateRightOutset((double) 10L);
        categoryMarker42.setLabelOffset(rectangleInsets43);
        double double47 = rectangleInsets43.getTop();
        categoryPlot20.setAxisOffset(rectangleInsets43);
        categoryPlot6.setInsets(rectangleInsets43);
        int int50 = objectList0.indexOf((java.lang.Object) rectangleInsets43);
        int int51 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Font font25 = categoryAxis23.getLabelFont();
        categoryPlot4.setDomainAxis(categoryAxis23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        java.awt.Font font4 = categoryAxis2.getTickLabelFont();
        java.awt.Paint paint5 = categoryAxis2.getTickLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        int int11 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint15, stroke16, (java.awt.Paint) color17, stroke18, 0.0f);
        categoryPlot10.setDomainGridlineStroke(stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 'a', paint5, stroke18);
        double double23 = valueMarker22.getValue();
        try {
            valueMarker22.setAlpha((float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 97.0d + "'", double23 == 97.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        categoryPlot4.setRangeGridlinesVisible(false);
        int int14 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str16 = datasetRenderingOrder15.toString();
        java.lang.String str17 = datasetRenderingOrder15.toString();
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str16.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str17.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean13 = categoryPlot4.equals((java.lang.Object) textAnchor12);
        boolean boolean14 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis16.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis18.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis18.setTickUnit(dateTickUnit23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer25);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightOutset((double) 10L);
        categoryMarker28.setLabelOffset(rectangleInsets29);
        boolean boolean33 = xYPlot26.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker28);
        xYPlot26.clearRangeMarkers((-246));
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets36);
        double double39 = rectangleInsets36.calculateTopOutset(198.0d);
        categoryPlot4.setInsets(rectangleInsets36);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint42, stroke43, (java.awt.Paint) color44, stroke45, 0.0f);
        categoryPlot4.setRangeGridlineStroke(stroke45);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        float float13 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot4.getIndexOf(categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot4.getRenderer();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth((double) (-1.0f));
        double double4 = rectangleInsets0.trimHeight((double) 64);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0d) + "'", double2 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 62.0d + "'", double4 == 62.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        java.awt.Color color3 = java.awt.Color.blue;
        dateAxis0.setLabelPaint((java.awt.Paint) color3);
        int int5 = color3.getRGB();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-16776961) + "'", int5 == (-16776961));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        boolean boolean8 = categoryPlot4.isRangeCrosshairLockedOnData();
        int int9 = categoryPlot4.getBackgroundImageAlignment();
        categoryPlot4.setRangeGridlinesVisible(false);
        categoryPlot4.clearDomainMarkers((-256));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-16776961), (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint10 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot4.getDomainAxis((-32513));
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent15);
        java.awt.Color color18 = java.awt.Color.magenta;
        int int19 = color18.getRGB();
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + false + "'", obj16.equals(false));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-65281) + "'", int19 == (-65281));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLowerBound();
        double double2 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.setAutoTickUnitSelection(false);
        dateAxis3.configure();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range12 = dateAxis8.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis17.setTickUnit(dateTickUnit22);
        java.util.Date date24 = dateAxis13.calculateHighestVisibleTickValue(dateTickUnit22);
        dateAxis8.setMaximumDate(date24);
        dateAxis3.setMinimumDate(date24);
        dateAxis0.setMinimumDate(date24);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24, timeZone28);
        int int31 = day30.getYear();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1969 + "'", int31 == 1969);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation13, false);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation((int) (short) 1, axisLocation9);
        categoryPlot6.configureRangeAxes();
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot20.addChangeListener(plotChangeListener24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        int int31 = categoryPlot30.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        categoryPlot30.setRangeAxisLocation((int) (short) 1, axisLocation33);
        categoryPlot30.configureRangeAxes();
        categoryPlot30.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot30.getRowRenderingOrder();
        categoryPlot20.setColumnRenderingOrder(sortOrder38);
        org.jfree.chart.plot.Plot plot40 = categoryPlot20.getParent();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets();
        double double45 = rectangleInsets43.calculateRightOutset((double) 10L);
        categoryMarker42.setLabelOffset(rectangleInsets43);
        double double47 = rectangleInsets43.getTop();
        categoryPlot20.setAxisOffset(rectangleInsets43);
        categoryPlot6.setInsets(rectangleInsets43);
        int int50 = objectList0.indexOf((java.lang.Object) rectangleInsets43);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis53, categoryItemRenderer54);
        java.awt.Stroke stroke56 = categoryPlot55.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint59 = categoryAxis58.getAxisLinePaint();
        java.awt.Paint paint61 = categoryAxis58.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean62 = categoryAxis58.isTickLabelsVisible();
        java.awt.Paint paint64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker69 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint64, stroke65, (java.awt.Paint) color66, stroke67, 0.0f);
        categoryAxis58.setTickLabelPaint(paint64);
        java.util.List list71 = categoryPlot55.getCategoriesForAxis(categoryAxis58);
        boolean boolean72 = objectList0.equals((java.lang.Object) list71);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(list71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        double double20 = categoryAxis16.getLowerMargin();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        categoryPlot28.setRangeAxisLocation((int) (short) 1, axisLocation31);
        categoryPlot28.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge((int) (byte) 0);
        try {
            double double36 = categoryAxis16.getCategoryEnd((int) (short) 1, (int) (byte) 1, rectangle2D23, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot11.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        float float18 = categoryAxis16.getTickMarkInsideLength();
        categoryAxis16.setLabel("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Paint paint22 = categoryAxis16.getTickLabelPaint((java.lang.Comparable) numberTickUnit21);
        try {
            xYPlot11.setQuadrantPaint(255, paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot11.drawAnnotations(graphics2D32, rectangle2D33, plotRenderingInfo34);
        xYPlot11.clearAnnotations();
        boolean boolean37 = xYPlot11.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        dateAxis0.resizeRange((double) 0L);
        java.awt.Color color5 = java.awt.Color.GRAY;
        int int6 = color5.getRed();
        dateAxis0.setLabelPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setInverted(true);
        dateAxis0.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis0.setRightArrow(shape12);
        java.util.Date date14 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis4.setAutoTickUnitSelection(false);
        dateAxis4.setNegativeArrowVisible(true);
        double double10 = dateAxis4.getAutoRangeMinimumSize();
        dateAxis4.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis13.getTickUnit();
        dateAxis13.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis13.setTickUnit(dateTickUnit18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range24 = dateAxis20.getDefaultAutoRange();
        dateAxis13.setRange(range24);
        dateAxis4.setRange(range24);
        dateAxis0.setRange(range24, true, true);
        dateAxis0.setRangeAboutValue((double) (byte) 100, (double) 0L);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot11.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint33 = categoryAxis32.getAxisLinePaint();
        java.awt.Font font34 = categoryAxis32.getLabelFont();
        double double35 = categoryAxis32.getFixedDimension();
        java.awt.Paint paint36 = categoryAxis32.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        java.awt.Stroke stroke42 = categoryPlot41.getRangeGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, paint36, stroke42);
        xYPlot11.setOutlineStroke(stroke42);
        xYPlot11.setDomainCrosshairVisible(false);
        int int47 = xYPlot11.getRangeAxisCount();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot11.getDomainAxisForDataset(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1969 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.removeChangeListener(markerChangeListener4);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryMarker1.notifyListeners(markerChangeEvent13);
        java.awt.Font font15 = categoryMarker1.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range20 = dateAxis16.getDefaultAutoRange();
        double double21 = dateAxis16.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis22.resizeRange((double) (-1.0f));
        dateAxis22.configure();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis27.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis27.setTickUnit(dateTickUnit32);
        dateAxis27.setLabelToolTip("CONTRACT");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis27.getTickUnit();
        dateAxis22.setTickUnit(dateTickUnit36, false, false);
        dateAxis16.setTickUnit(dateTickUnit36);
        categoryMarker1.setKey((java.lang.Comparable) dateTickUnit36);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(dateTickUnit36);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        dateAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        xYPlot11.mapDatasetToDomainAxis(11, (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation((int) (short) 1, axisLocation8);
        boolean boolean10 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double16 = categoryAxis15.getUpperMargin();
        categoryPlot5.setDomainAxis((int) ' ', categoryAxis15, false);
        categoryAxis15.setUpperMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis15, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryAxis15.getTickMarkStroke();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        int int31 = categoryPlot30.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.Range range33 = categoryPlot30.getDataRange(valueAxis32);
        categoryPlot30.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        categoryPlot30.setRenderer(categoryItemRenderer36, false);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        int int45 = categoryPlot44.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        categoryPlot44.setRangeAxisLocation((int) (short) 1, axisLocation47);
        categoryPlot44.configureRangeAxes();
        categoryPlot44.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot44.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace54 = categoryAxis15.reserveSpace(graphics2D25, (org.jfree.chart.plot.Plot) categoryPlot30, rectangle2D39, rectangleEdge52, axisSpace53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot11.zoomRangeAxes((double) 6, plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot11.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        xYPlot11.setRenderer(xYItemRenderer30);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(axisSpace29);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis4.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        dateAxis4.setTickUnit(dateTickUnit9);
        java.util.Date date11 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit9);
        dateAxis0.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis20.getTickUnit();
        dateAxis20.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis24.getTickUnit();
        dateAxis20.setTickUnit(dateTickUnit25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer27);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker30.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint34, stroke35, (java.awt.Paint) color36, stroke37, 0.0f);
        categoryMarker30.setOutlineStroke(stroke35);
        boolean boolean41 = xYPlot28.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font43 = dateAxis42.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition44 = dateAxis42.getTickMarkPosition();
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis42);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot28.getDomainAxisEdge(500);
        try {
            java.util.List list48 = dateAxis0.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(dateTickMarkPosition44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis0.setNumberFormatOverride(numberFormat5);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Shape shape9 = numberAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        java.lang.Object obj6 = dateAxis0.clone();
        dateAxis0.centerRange((double) (-256));
        dateAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis4.setMarkerBand(markerAxisBand7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis4.setNumberFormatOverride(numberFormat9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis11.setMarkerBand(markerAxisBand14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit16);
        numberAxis4.setTickUnit(numberTickUnit16);
        numberAxis1.setTickUnit(numberTickUnit16);
        boolean boolean20 = rectangleAnchor0.equals((java.lang.Object) numberTickUnit16);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        boolean boolean21 = xYPlot11.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot4.getDrawingSupplier();
        categoryPlot4.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double2 = categoryAxis1.getUpperMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 5);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation((int) (short) 1, axisLocation8);
        categoryPlot5.configureRangeAxes();
        categoryPlot5.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot5.getRangeAxisEdge();
        boolean boolean14 = rectangleAnchor0.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryPlot4.setRangeCrosshairValue(2.0d, false);
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot4.getDomainAxis(64);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertNull(categoryAxis26);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        int int42 = day24.getMonth();
        long long43 = day24.getFirstMillisecond();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis44.getTickUnit();
        dateAxis44.setAutoTickUnitSelection(false);
        dateAxis44.setNegativeArrowVisible(true);
        double double50 = dateAxis44.getAutoRangeMinimumSize();
        java.lang.String str51 = dateAxis44.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        dateAxis52.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range56 = dateAxis52.getDefaultAutoRange();
        dateAxis44.setRange(range56);
        boolean boolean58 = day24.equals((java.lang.Object) range56);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-57600000L) + "'", long43 == (-57600000L));
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str16 = categoryMarker15.getLabel();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot4, dataset18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot4.render(graphics2D20, rectangle2D21, (int) (byte) 1, plotRenderingInfo23);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit5);
        boolean boolean7 = numberAxis0.getAutoRangeIncludesZero();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot18.setRangeAxisLocation((int) (short) 1, axisLocation21);
        categoryPlot18.configureRangeAxes();
        categoryPlot18.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot18.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            org.jfree.chart.axis.AxisState axisState28 = numberAxis0.draw(graphics2D10, (double) 255, rectangle2D12, rectangle2D13, rectangleEdge26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis34.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition38 = dateAxis34.getTickMarkPosition();
        dateAxis25.setTickMarkPosition(dateTickMarkPosition38);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(dateTickMarkPosition38);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        int int31 = xYPlot11.getIndexOf(xYItemRenderer30);
        double double32 = xYPlot11.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range38 = dateAxis34.getDefaultAutoRange();
        double double39 = dateAxis34.getAutoRangeMinimumSize();
        xYPlot11.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot8.setRangeAxisLocation((int) (short) 1, axisLocation11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot8.addDomainMarker(categoryMarker14);
        java.awt.Stroke stroke16 = categoryMarker14.getOutlineStroke();
        dateAxis0.setTickMarkStroke(stroke16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        int int23 = categoryPlot22.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        categoryPlot22.setRangeAxisLocation((int) (short) 1, axisLocation25);
        categoryPlot22.clearRangeMarkers();
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        java.awt.Stroke stroke14 = xYPlot11.getDomainGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleAnchor17, jFreeChart18, chartChangeEventType19);
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) chartChangeEventType19);
        xYPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        java.awt.Paint paint23 = defaultDrawingSupplier15.getNextFillPaint();
        java.awt.Paint paint24 = defaultDrawingSupplier15.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot4.addDomainMarker(categoryMarker10);
        java.awt.Stroke stroke12 = categoryMarker10.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setTickMarkInsideLength((float) (short) 10);
        java.awt.Paint paint16 = dateAxis13.getTickLabelPaint();
        boolean boolean17 = categoryMarker10.equals((java.lang.Object) dateAxis13);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        int int27 = categoryPlot26.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot26.getDataRange(valueAxis28);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint31, stroke32, (java.awt.Paint) color33, stroke34, 0.0f);
        categoryPlot26.setDomainGridlineStroke(stroke34);
        java.awt.Stroke stroke38 = categoryPlot26.getRangeCrosshairStroke();
        categoryPlot26.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        int int46 = categoryPlot45.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation48 = null;
        categoryPlot45.setRangeAxisLocation((int) (short) 1, axisLocation48);
        categoryPlot45.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot45.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot45.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation54 = axisLocation53.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation55 = axisLocation53.getOpposite();
        categoryPlot26.setDomainAxisLocation(axisLocation55, false);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        int int63 = categoryPlot62.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation65 = null;
        categoryPlot62.setRangeAxisLocation((int) (short) 1, axisLocation65);
        categoryPlot62.configureRangeAxes();
        categoryPlot62.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation70 = categoryPlot62.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation55, plotOrientation70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        try {
            org.jfree.chart.axis.AxisState axisState73 = dateAxis13.draw(graphics2D18, (double) 8, rectangle2D20, rectangle2D21, rectangleEdge71, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(plotOrientation70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker1, jFreeChart4, chartChangeEventType5);
        org.jfree.chart.JFreeChart jFreeChart7 = chartChangeEvent6.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-65281), 0.0d, (double) (-655360));
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str16 = categoryMarker15.getLabel();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        java.awt.Stroke stroke18 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis29.getTickUnit();
        dateAxis25.setTickUnit(dateTickUnit30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer32);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range39 = dateAxis35.getDefaultAutoRange();
        double double40 = dateAxis35.getLowerMargin();
        boolean boolean41 = seriesRenderingOrder34.equals((java.lang.Object) dateAxis35);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] { dateAxis35 };
        xYPlot33.setDomainAxes(valueAxisArray42);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot33.setDomainGridlinePaint(paint44);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder46 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot33.setDatasetRenderingOrder(datasetRenderingOrder46);
        java.awt.geom.Point2D point2D48 = xYPlot33.getQuadrantOrigin();
        categoryPlot4.zoomDomainAxes((double) 0.5f, 3.0d, plotRenderingInfo21, point2D48);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(datasetRenderingOrder46);
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot4.getIndexOf(categoryItemRenderer20);
        boolean boolean22 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis28.getTickUnit();
        dateAxis28.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis32.getTickUnit();
        dateAxis28.setTickUnit(dateTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer35);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder37 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        dateAxis38.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range42 = dateAxis38.getDefaultAutoRange();
        double double43 = dateAxis38.getLowerMargin();
        boolean boolean44 = seriesRenderingOrder37.equals((java.lang.Object) dateAxis38);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { dateAxis38 };
        xYPlot36.setDomainAxes(valueAxisArray45);
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot36.setDomainGridlinePaint(paint47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot36.setDatasetRenderingOrder(datasetRenderingOrder49);
        java.awt.geom.Point2D point2D51 = xYPlot36.getQuadrantOrigin();
        categoryPlot4.zoomRangeAxes(256.0d, plotRenderingInfo24, point2D51);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder37);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        categoryMarker2.setKey((java.lang.Comparable) (short) -1);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = categoryMarker2.getLabelOffsetType();
        boolean boolean6 = sortOrder0.equals((java.lang.Object) lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        java.awt.Stroke stroke37 = categoryPlot35.getOutlineStroke();
        xYPlot11.setRangeCrosshairStroke(stroke37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        xYPlot11.addChangeListener(plotChangeListener39);
        org.jfree.data.xy.XYDataset xYDataset42 = xYPlot11.getDataset((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = xYPlot11.getLegendItems();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset42);
        org.junit.Assert.assertNotNull(legendItemCollection43);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint7 = categoryAxis6.getAxisLinePaint();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        categoryPlot4.setNoDataMessageFont(font8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot17.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot17.setFixedLegendItems(legendItemCollection23);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double28 = categoryAxis27.getUpperMargin();
        categoryPlot17.setDomainAxis((int) ' ', categoryAxis27, false);
        java.awt.Paint paint31 = categoryAxis27.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryAxis27.getTickLabelInsets();
        categoryPlot4.setDomainAxis(7, categoryAxis27);
        java.awt.Color color34 = java.awt.Color.GREEN;
        categoryAxis27.setLabelPaint((java.awt.Paint) color34);
        float[] floatArray38 = new float[] { 10.0f, 7 };
        try {
            float[] floatArray39 = color34.getRGBColorComponents(floatArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        java.util.Date date26 = day24.getStart();
        long long27 = day24.getSerialIndex();
        int int28 = day24.getYear();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        java.lang.Object obj4 = intervalMarker2.clone();
        double double5 = intervalMarker2.getStartValue();
        intervalMarker2.setStartValue((double) ' ');
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean5 = categoryAxis1.isTickLabelsVisible();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        categoryAxis1.setTickLabelPaint(paint7);
        java.awt.Paint paint14 = categoryAxis1.getLabelPaint();
        categoryAxis1.setTickMarkOutsideLength((float) (byte) 10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot4.getIndexOf(categoryItemRenderer20);
        boolean boolean22 = categoryPlot4.isRangeCrosshairLockedOnData();
        try {
            categoryPlot4.zoom((double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot11.getSeriesRenderingOrder();
        boolean boolean23 = xYPlot11.isRangeZoomable();
        java.awt.Paint paint24 = xYPlot11.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        double double5 = dateAxis0.getUpperMargin();
        dateAxis0.setAutoRangeMinimumSize(34.0d);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot4.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker16, layer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint21 = categoryAxis20.getAxisLinePaint();
        java.awt.Font font22 = categoryAxis20.getTickLabelFont();
        java.awt.Paint paint23 = categoryAxis20.getTickLabelPaint();
        java.lang.String str24 = categoryAxis20.getLabelToolTip();
        java.awt.Font font25 = categoryAxis20.getTickLabelFont();
        intervalMarker16.setLabelFont(font25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis28.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis30.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis30.setTickUnit(dateTickUnit35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer37);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYPlot38.rendererChanged(rendererChangeEvent39);
        java.awt.Stroke stroke41 = xYPlot38.getDomainGridlineStroke();
        intervalMarker16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot38);
        double double43 = intervalMarker16.getStartValue();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        int int42 = day24.getMonth();
        long long43 = day24.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day24.next();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-57600000L) + "'", long43 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        java.awt.Paint paint25 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot11.getDomainAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot11.setRenderer(10, xYItemRenderer29);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis27);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 0, (double) 10.0f, (double) (-256));
        double double25 = rectangleInsets23.trimWidth(0.0d);
        categoryMarker13.setLabelOffset(rectangleInsets23);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 256.0d + "'", double25 == 256.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        categoryPlot4.setForegroundAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(axisSpace20);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Image image23 = xYPlot11.getBackgroundImage();
        xYPlot11.configureDomainAxes();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = xYPlot11.render(graphics2D25, rectangle2D26, 128, plotRenderingInfo28, crosshairState29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot11.getRangeAxisLocation((-1));
        java.util.List list33 = xYPlot11.getAnnotations();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot4.getDomainAxis(500);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        double double10 = categoryPlot4.getRangeCrosshairValue();
        categoryPlot4.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.setTickMarkInsideLength((float) 3);
        categoryAxis7.clearCategoryLabelToolTips();
        categoryAxis7.setTickMarkOutsideLength((float) 6);
        float float26 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 1 + "'", obj2.equals((byte) 1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        xYPlot11.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        java.awt.Stroke stroke37 = categoryPlot35.getOutlineStroke();
        xYPlot11.setRangeCrosshairStroke(stroke37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot11.getAxisOffset();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = dateAxis41.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = dateAxis43.getTickUnit();
        dateAxis43.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = dateAxis47.getTickUnit();
        dateAxis43.setTickUnit(dateTickUnit48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer50);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        xYPlot51.rendererChanged(rendererChangeEvent52);
        java.awt.Stroke stroke54 = xYPlot51.getDomainGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke56 = defaultDrawingSupplier55.getNextOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart58 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType59 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent60 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleAnchor57, jFreeChart58, chartChangeEventType59);
        boolean boolean61 = defaultDrawingSupplier55.equals((java.lang.Object) chartChangeEventType59);
        xYPlot51.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier55);
        java.awt.Paint paint63 = defaultDrawingSupplier55.getNextFillPaint();
        xYPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier55);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(dateTickUnit42);
        org.junit.Assert.assertNotNull(dateTickUnit44);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(chartChangeEventType59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 0, (double) 10.0f, (double) (-256));
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateTopOutset((double) 'a');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        double double35 = dateAxis34.getLowerBound();
        java.awt.Shape shape36 = dateAxis34.getLeftArrow();
        dateAxis25.setRightArrow(shape36);
        java.lang.String str38 = dateAxis25.getLabelToolTip();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        int int44 = categoryPlot43.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        categoryPlot43.setRangeAxisLocation((int) (short) 1, axisLocation46);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot43.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot43.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        int int51 = categoryPlot43.getIndexOf(categoryItemRenderer50);
        dateAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot43);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNull(legendItemCollection49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        float float17 = xYPlot11.getForegroundAlpha();
        java.awt.Color color19 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 2, (java.awt.Paint) color19, stroke27);
        xYPlot11.setDomainTickBandPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis15.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis17.setTickUnit(dateTickUnit22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer24);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint27, stroke28, (java.awt.Paint) color29, stroke30, 0.0f);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker32.setPaint(paint33);
        xYPlot25.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot25.getDomainAxisLocation(12);
        xYPlot11.setDomainAxisLocation(axisLocation37, false);
        java.util.List list40 = xYPlot11.getAnnotations();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        java.lang.Object obj4 = null;
        boolean boolean5 = intervalMarker2.equals(obj4);
        java.awt.Font font6 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        xYPlot11.setRangeZeroBaselineVisible(true);
        xYPlot11.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = xYPlot11.getOrientation();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(plotOrientation21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace7, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets11.createOutsetRectangle(rectangle2D12, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Font font25 = categoryAxis23.getLabelFont();
        categoryPlot4.setDomainAxis(categoryAxis23);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint29, stroke30, (java.awt.Paint) color31, stroke32, 0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        int int40 = categoryPlot39.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot39.setRangeAxisLocation((int) (short) 1, axisLocation42);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot39.getOrientation();
        boolean boolean45 = categoryPlot39.isSubplot();
        boolean boolean46 = categoryMarker34.equals((java.lang.Object) boolean45);
        categoryMarker34.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer49 = null;
        try {
            categoryPlot4.addDomainMarker(0, categoryMarker34, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.data.Range range5 = dateAxis0.getRange();
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation((int) (short) 1, axisLocation9);
        categoryPlot6.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot6.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot6.setDataset(categoryDataset15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        int int24 = categoryPlot23.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot23.setRangeAxisLocation((int) (short) 1, axisLocation26);
        boolean boolean28 = categoryPlot23.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        categoryPlot23.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double34 = categoryAxis33.getUpperMargin();
        categoryPlot23.setDomainAxis((int) ' ', categoryAxis33, false);
        categoryAxis33.setUpperMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis33, valueAxis39, categoryItemRenderer40);
        java.awt.Stroke stroke42 = categoryAxis33.getTickMarkStroke();
        categoryPlot6.setDomainAxis((int) '4', categoryAxis33, false);
        objectList0.set((int) (byte) 10, (java.lang.Object) false);
        java.lang.Object obj46 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint5 = categoryAxis4.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis4.getLabelFont();
        double double7 = categoryAxis4.getFixedDimension();
        java.awt.Paint paint8 = categoryAxis4.getTickMarkPaint();
        boolean boolean9 = numberAxis0.equals((java.lang.Object) paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        int int11 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot10.setRangeAxisLocation((int) (short) 1, axisLocation13);
        boolean boolean15 = categoryPlot10.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot10.setDomainGridlinePosition(categoryAnchor16);
        java.lang.String str18 = categoryAnchor16.toString();
        java.lang.String str19 = categoryAnchor16.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        int int28 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint32, stroke33, (java.awt.Paint) color34, stroke35, 0.0f);
        categoryPlot27.setDomainGridlineStroke(stroke35);
        java.awt.Stroke stroke39 = categoryPlot27.getRangeCrosshairStroke();
        categoryPlot27.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        int int47 = categoryPlot46.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot46.setRangeAxisLocation((int) (short) 1, axisLocation49);
        categoryPlot46.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot46.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot46.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation55 = axisLocation54.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation56 = axisLocation54.getOpposite();
        categoryPlot27.setDomainAxisLocation(axisLocation56, false);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, valueAxis61, categoryItemRenderer62);
        int int64 = categoryPlot63.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation66 = null;
        categoryPlot63.setRangeAxisLocation((int) (short) 1, axisLocation66);
        categoryPlot63.configureRangeAxes();
        categoryPlot63.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = categoryPlot63.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation56, plotOrientation71);
        try {
            double double73 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor16, (int) (short) 100, 500, rectangle2D22, rectangleEdge72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryAnchor.END" + "'", str18.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "CategoryAnchor.END" + "'", str19.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(plotOrientation71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection19 = categoryPlot4.getRangeMarkers(layer18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        int int25 = categoryPlot24.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        categoryPlot24.setRangeAxisLocation((int) (short) 1, axisLocation27);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = categoryPlot24.getOrientation();
        categoryPlot4.setOrientation(plotOrientation29);
        java.awt.Color color31 = java.awt.Color.darkGray;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot4.getDomainAxis((int) ' ');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(categoryAxis34);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        boolean boolean8 = categoryPlot4.isRangeCrosshairLockedOnData();
        categoryPlot4.setBackgroundAlpha((float) 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint5, stroke6, (java.awt.Paint) color7, stroke8, 0.0f);
        categoryMarker1.setOutlineStroke(stroke6);
        java.awt.Color color12 = java.awt.Color.yellow;
        int int13 = color12.getRed();
        categoryMarker1.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double26 = rectangleInsets24.calculateRightOutset((double) 10L);
        categoryMarker23.setLabelOffset(rectangleInsets24);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot19.addDomainMarker((int) (short) -1, categoryMarker23, layer28, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot19.zoomDomainAxes((double) 3, plotRenderingInfo32, point2D33);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot19);
        org.jfree.chart.text.TextAnchor textAnchor36 = categoryMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNotNull(textAnchor36);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        float float4 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10);
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange(0.0d, (double) 1L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis23.setTickUnit(dateTickUnit28);
        java.util.Date date30 = dateAxis19.calculateHighestVisibleTickValue(dateTickUnit28);
        dateAxis5.setTickUnit(dateTickUnit28, true, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        int int31 = xYPlot11.getIndexOf(xYItemRenderer30);
        double double32 = xYPlot11.getDomainCrosshairValue();
        java.awt.Paint paint33 = xYPlot11.getRangeCrosshairPaint();
        boolean boolean34 = xYPlot11.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str16 = categoryMarker15.getLabel();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        java.awt.Stroke stroke18 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean19 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation((int) (short) 1, axisLocation19);
        categoryPlot16.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot16.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot16.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation25 = axisLocation24.getOpposite();
        categoryPlot4.setRangeAxisLocation((int) (byte) 0, axisLocation24, false);
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(sortOrder28);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot4.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker16, layer17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = intervalMarker16.getGradientPaintTransformer();
        intervalMarker16.setStartValue((double) 10.0f);
        java.awt.Paint paint22 = intervalMarker16.getPaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis0.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = null;
        numberAxis7.setMarkerBand(markerAxisBand10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit12);
        numberAxis0.setTickUnit(numberTickUnit12);
        boolean boolean15 = numberAxis0.getAutoRangeStickyZero();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        int int23 = categoryPlot22.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        categoryPlot22.setRangeAxisLocation((int) (short) 1, axisLocation25);
        boolean boolean27 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot22.setDomainGridlinePosition(categoryAnchor28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot22.setRenderer(5, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint35 = categoryAxis34.getAxisLinePaint();
        java.awt.Font font36 = categoryAxis34.getLabelFont();
        int int37 = categoryPlot22.getDomainAxisIndex(categoryAxis34);
        java.awt.Paint paint38 = categoryPlot22.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot22.getRangeAxisEdge((int) (short) 1);
        try {
            double double41 = numberAxis0.java2DToValue(0.05d, rectangle2D17, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis9.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis13.getTickUnit();
        dateAxis9.setTickUnit(dateTickUnit14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range20 = dateAxis16.getDefaultAutoRange();
        dateAxis9.setRange(range20);
        dateAxis0.setRange(range20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.setAutoTickUnitSelection(false);
        dateAxis23.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis23.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource28);
        org.jfree.data.Range range30 = dateAxis0.getRange();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        categoryPlot4.setRangeGridlinesVisible(false);
        int int14 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot4.getInsets();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("UnitType.ABSOLUTE");
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.setAutoTickUnitSelection(false);
        dateAxis17.setNegativeArrowVisible(true);
        int int23 = xYPlot11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.CENTER" + "'", str2.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Paint paint7 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) numberTickUnit6);
        float float8 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        double double5 = categoryAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets2.createOutsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        boolean boolean29 = xYPlot11.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup30 = xYPlot11.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        categoryMarker32.setKey((java.lang.Comparable) (short) -1);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(datasetGroup30);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        float float4 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10);
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange(0.0d, (double) 1L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer17);
        boolean boolean19 = dateAxis5.isVisible();
        boolean boolean20 = dateAxis5.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint23, stroke24, (java.awt.Paint) color25, stroke26, 0.0f);
        categoryPlot18.setDomainGridlineStroke(stroke26);
        xYPlot11.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis31.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis35.getTickUnit();
        dateAxis35.setAutoTickUnitSelection(false);
        dateAxis35.setNegativeArrowVisible(true);
        double double41 = dateAxis35.getAutoRangeMinimumSize();
        dateAxis35.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis44.getTickUnit();
        dateAxis44.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = dateAxis48.getTickUnit();
        dateAxis44.setTickUnit(dateTickUnit49);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        dateAxis51.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range55 = dateAxis51.getDefaultAutoRange();
        dateAxis44.setRange(range55);
        dateAxis35.setRange(range55);
        dateAxis31.setRange(range55, true, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = dateAxis31.getTickLabelInsets();
        boolean boolean62 = dateAxis31.isInverted();
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertNotNull(dateTickUnit49);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        categoryMarker1.setKey((java.lang.Comparable) (short) -1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis21.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis21.setTickUnit(dateTickUnit26);
        dateAxis21.setInverted(true);
        dateAxis21.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis21.setRightArrow(shape33);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        int int41 = categoryPlot40.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        categoryPlot40.setRangeAxisLocation((int) (short) 1, axisLocation43);
        categoryPlot40.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot40.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot40.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation49 = axisLocation48.getOpposite();
        categoryPlot4.setDomainAxisLocation(axisLocation48, true);
        org.jfree.chart.axis.ValueAxis valueAxis53 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis53);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        categoryPlot20.setRangeAxisLocation((int) (short) 1, axisLocation23);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot20.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot20.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation29 = axisLocation28.getOpposite();
        xYPlot11.setDomainAxisLocation((int) '4', axisLocation29, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot4.getDataset((-256));
        categoryPlot4.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLowerBound();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis4.setAutoTickUnitSelection(false);
        dateAxis4.configure();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range13 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis18.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis18.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis14.calculateHighestVisibleTickValue(dateTickUnit23);
        dateAxis9.setMaximumDate(date25);
        dateAxis4.setMinimumDate(date25);
        dateAxis1.setMinimumDate(date25);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date25, timeZone29);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        int int38 = categoryPlot37.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot37.setRangeAxisLocation((int) (short) 1, axisLocation40);
        boolean boolean42 = categoryPlot37.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot37.setDomainGridlinePosition(categoryAnchor43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        categoryPlot37.setRenderer(5, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint50 = categoryAxis49.getAxisLinePaint();
        java.awt.Font font51 = categoryAxis49.getLabelFont();
        int int52 = categoryPlot37.getDomainAxisIndex(categoryAxis49);
        java.awt.Paint paint53 = categoryPlot37.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot37.getRangeAxisEdge((int) (short) 1);
        try {
            double double56 = dateAxis0.dateToJava2D(date25, rectangle2D32, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint9 = categoryAxis8.getAxisLinePaint();
        java.awt.Font font10 = categoryAxis8.getLabelFont();
        dateAxis0.setLabelFont(font10);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        int int13 = categoryPlot4.getWeight();
        categoryPlot4.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        int int20 = categoryPlot19.getDomainAxisCount();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        java.awt.Font font23 = categoryPlot19.getNoDataMessageFont();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.calculateRightOutset((double) 10L);
        categoryMarker25.setLabelOffset(rectangleInsets26);
        double double31 = rectangleInsets26.calculateRightOutset((double) 2.0f);
        categoryPlot19.setInsets(rectangleInsets26);
        categoryPlot4.setInsets(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        double double18 = dateAxis13.getLowerMargin();
        boolean boolean19 = seriesRenderingOrder12.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        xYPlot11.setDomainAxes(valueAxisArray20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot11.setDomainGridlinePaint(paint22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder24);
        java.lang.String str26 = datasetRenderingOrder24.toString();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str26.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = dateAxis7.equals((java.lang.Object) rectangleAnchor8);
        int int10 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint16 = categoryAxis15.getAxisLinePaint();
        java.awt.Paint paint17 = categoryAxis15.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker19.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint23, stroke24, (java.awt.Paint) color25, stroke26, 0.0f);
        categoryMarker19.setOutlineStroke(stroke24);
        categoryAxis15.setTickMarkStroke(stroke24);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer32);
        org.jfree.chart.axis.Timeline timeline34 = dateAxis31.getTimeline();
        dateAxis7.setTimeline(timeline34);
        org.jfree.data.Range range36 = dateAxis7.getRange();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(timeline34);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        int int18 = categoryPlot4.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        int int25 = categoryPlot24.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        categoryPlot24.setRangeAxisLocation((int) (short) 1, axisLocation27);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot24.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot24.getDomainAxisLocation();
        categoryPlot4.setDomainAxisLocation(7, axisLocation32, false);
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot4.getRangeAxis(1);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        int int46 = categoryPlot45.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.Range range48 = categoryPlot45.getDataRange(valueAxis47);
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint50, stroke51, (java.awt.Paint) color52, stroke53, 0.0f);
        categoryPlot45.setDomainGridlineStroke(stroke53);
        categoryPlot45.clearRangeMarkers(9);
        int int59 = categoryPlot45.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis63, categoryItemRenderer64);
        int int66 = categoryPlot65.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation68 = null;
        categoryPlot65.setRangeAxisLocation((int) (short) 1, axisLocation68);
        categoryPlot65.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot65.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation73 = categoryPlot65.getDomainAxisLocation();
        categoryPlot45.setDomainAxisLocation(7, axisLocation73, false);
        try {
            categoryPlot4.setRangeAxisLocation((-655360), axisLocation73, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(axisLocation73);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot4.notifyListeners(plotChangeEvent12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot4.getRangeAxisLocation(89);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 0, (double) 10.0f, (double) (-256));
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateLeftInset((double) 255);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setDomainAxisLocation((int) (byte) 1, axisLocation14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot4.setDataset(categoryDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes(0.0d, (double) (byte) 0, plotRenderingInfo17, point2D18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis24.getTickUnit();
        dateAxis24.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis28.getTickUnit();
        dateAxis24.setTickUnit(dateTickUnit29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer31);
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker34.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint38, stroke39, (java.awt.Paint) color40, stroke41, 0.0f);
        categoryMarker34.setOutlineStroke(stroke39);
        boolean boolean45 = xYPlot32.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        xYPlot32.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = dateAxis47.getTickUnit();
        dateAxis47.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis51.getTickUnit();
        dateAxis47.setTickUnit(dateTickUnit52);
        xYPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot32.getRangeAxisLocation();
        categoryPlot4.setDomainAxisLocation((int) (short) 100, axisLocation55, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        dateAxis1.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis1.setTickUnit(dateTickUnit6);
        dateAxis0.setTickUnit(dateTickUnit6, false, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        java.awt.Color color7 = java.awt.Color.lightGray;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis12.getTickUnit();
        dateAxis12.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis16.getTickUnit();
        dateAxis12.setTickUnit(dateTickUnit17);
        java.util.Date date19 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit17);
        boolean boolean20 = color7.equals((java.lang.Object) date19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLowerBound();
        double double23 = dateAxis21.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis24.getTickUnit();
        dateAxis24.setAutoTickUnitSelection(false);
        dateAxis24.configure();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range33 = dateAxis29.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis38.getTickUnit();
        dateAxis38.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = dateAxis42.getTickUnit();
        dateAxis38.setTickUnit(dateTickUnit43);
        java.util.Date date45 = dateAxis34.calculateHighestVisibleTickValue(dateTickUnit43);
        dateAxis29.setMaximumDate(date45);
        dateAxis24.setMinimumDate(date45);
        dateAxis21.setMinimumDate(date45);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date45, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date19, timeZone49);
        dateAxis0.setTimeZone(timeZone49);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(tickUnitSource50);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot11.getDataset(100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot11.rendererChanged(rendererChangeEvent15);
        java.awt.Paint paint17 = xYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range23 = dateAxis19.getDefaultAutoRange();
        double double24 = dateAxis19.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.resizeRange((double) (-1.0f));
        dateAxis25.configure();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis30.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis30.setTickUnit(dateTickUnit35);
        dateAxis30.setLabelToolTip("CONTRACT");
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis30.getTickUnit();
        dateAxis25.setTickUnit(dateTickUnit39, false, false);
        dateAxis19.setTickUnit(dateTickUnit39);
        xYPlot11.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis19, true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(dateTickUnit39);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        double double20 = categoryAxis16.getLowerMargin();
        java.awt.Paint paint21 = categoryAxis16.getTickLabelPaint();
        java.lang.Comparable comparable22 = null;
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        try {
            categoryAxis16.setTickLabelPaint(comparable22, paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        java.awt.Stroke stroke37 = categoryPlot35.getOutlineStroke();
        xYPlot11.setRangeCrosshairStroke(stroke37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot11.setRangeAxis(valueAxis39);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot18.addChangeListener(plotChangeListener22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        categoryPlot28.setRangeAxisLocation((int) (short) 1, axisLocation31);
        categoryPlot28.configureRangeAxes();
        categoryPlot28.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot28.getRowRenderingOrder();
        categoryPlot18.setColumnRenderingOrder(sortOrder36);
        org.jfree.chart.plot.Plot plot38 = categoryPlot18.getParent();
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets();
        double double43 = rectangleInsets41.calculateRightOutset((double) 10L);
        categoryMarker40.setLabelOffset(rectangleInsets41);
        double double45 = rectangleInsets41.getTop();
        categoryPlot18.setAxisOffset(rectangleInsets41);
        categoryPlot4.setInsets(rectangleInsets41);
        org.jfree.chart.util.SortOrder sortOrder48 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(sortOrder48);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot11.drawAnnotations(graphics2D32, rectangle2D33, plotRenderingInfo34);
        boolean boolean36 = xYPlot11.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        xYPlot11.mapDatasetToDomainAxis(12, (int) ' ');
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot11.getDomainAxisForDataset(0);
        xYPlot11.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        int int24 = categoryPlot23.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot23.setRangeAxisLocation((int) (short) 1, axisLocation26);
        boolean boolean28 = categoryPlot23.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        categoryPlot23.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double34 = categoryAxis33.getUpperMargin();
        categoryPlot23.setDomainAxis((int) ' ', categoryAxis33, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot23.zoomRangeAxes((double) (short) 10, plotRenderingInfo38, point2D39);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range45 = dateAxis41.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        dateAxis46.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = dateAxis50.getTickUnit();
        dateAxis50.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis54.getTickUnit();
        dateAxis50.setTickUnit(dateTickUnit55);
        java.util.Date date57 = dateAxis46.calculateHighestVisibleTickValue(dateTickUnit55);
        dateAxis41.setMaximumDate(date57);
        java.lang.Object obj59 = dateAxis41.clone();
        categoryPlot23.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        java.util.Date date62 = day61.getStart();
        dateAxis41.setMaximumDate(date62);
        xYPlot11.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) dateAxis41, true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(dateTickUnit51);
        org.junit.Assert.assertNotNull(dateTickUnit55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(date62);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getRed();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color2 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE", 8);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot4.getIndexOf(categoryItemRenderer20);
        boolean boolean22 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot4.getDatasetGroup();
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot4.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        xYPlot11.axisChanged(axisChangeEvent15);
        xYPlot11.clearDomainMarkers();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset((double) 10L);
        double double3 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day24.next();
        java.util.Date date43 = regularTimePeriod42.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.GENERAL", timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date43, timeZone45);
        int int48 = day47.getYear();
        int int49 = day47.getYear();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1970 + "'", int48 == 1970);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1970 + "'", int49 == 1970);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint23, stroke24, (java.awt.Paint) color25, stroke26, 0.0f);
        categoryPlot18.setDomainGridlineStroke(stroke26);
        xYPlot11.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font32 = dateAxis31.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis31.getTickMarkPosition();
        int int34 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.awt.Stroke stroke35 = xYPlot11.getRangeCrosshairStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset13);
        java.lang.Object obj15 = datasetChangeEvent14.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent14);
        boolean boolean17 = categoryPlot4.isSubplot();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot4.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + false + "'", obj15.equals(false));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        java.awt.Stroke stroke22 = xYPlot11.getRangeGridlineStroke();
        double double23 = xYPlot11.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        java.awt.Font font8 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot11.getDataset(100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot11.rendererChanged(rendererChangeEvent15);
        java.awt.Paint paint17 = xYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker19.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener22 = null;
        categoryMarker19.removeChangeListener(markerChangeListener22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        categoryPlot28.setRangeAxisLocation((int) (short) 1, axisLocation31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot28.setRenderer(5, categoryItemRenderer34);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker38.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener41 = null;
        categoryMarker38.removeChangeListener(markerChangeListener41);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint44, stroke45, (java.awt.Paint) color46, stroke47, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker49);
        categoryMarker38.notifyListeners(markerChangeEvent50);
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker(4, categoryMarker38, layer52, true);
        xYPlot11.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker19, layer52);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(layer52);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker36.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        int int44 = categoryPlot43.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        categoryPlot43.setRangeAxisLocation((int) (short) 1, axisLocation46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot43.setRenderer(5, categoryItemRenderer49);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = null;
        categoryPlot43.notifyListeners(plotChangeEvent51);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = categoryPlot43.getDomainMarkers(layer53);
        boolean boolean56 = xYPlot11.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker36, layer53, true);
        java.lang.String str57 = layer53.toString();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Layer.FOREGROUND" + "'", str57.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color2 = java.awt.Color.magenta;
        boolean boolean3 = numberAxis1.equals((java.lang.Object) color2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot8.setRangeAxisLocation((int) (short) 1, axisLocation11);
        boolean boolean13 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot8.zoomDomainAxes((double) 1, plotRenderingInfo15, point2D16, true);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis20.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis22.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis22.setTickUnit(dateTickUnit27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer29);
        java.awt.Paint paint31 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot30.getDataset();
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot30.setDomainCrosshairStroke(stroke33);
        categoryPlot8.setRangeGridlineStroke(stroke33);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint38 = categoryAxis37.getAxisLinePaint();
        java.awt.Font font39 = categoryAxis37.getTickLabelFont();
        java.awt.Paint paint40 = categoryAxis37.getTickLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = dateAxis42.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis44.getTickUnit();
        dateAxis44.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = dateAxis48.getTickUnit();
        dateAxis44.setTickUnit(dateTickUnit49);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer51);
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker54.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint58, stroke59, (java.awt.Paint) color60, stroke61, 0.0f);
        categoryMarker54.setOutlineStroke(stroke59);
        boolean boolean65 = xYPlot52.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker54);
        xYPlot52.clearDomainAxes();
        boolean boolean67 = xYPlot52.isDomainCrosshairLockedOnData();
        java.awt.Color color68 = java.awt.Color.gray;
        xYPlot52.setDomainGridlinePaint((java.awt.Paint) color68);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot52.setRangeGridlineStroke(stroke70);
        org.jfree.data.xy.XYDataset xYDataset72 = xYPlot52.getDataset();
        java.awt.Color color73 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot52.setRangeCrosshairPaint((java.awt.Paint) color73);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder75 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        dateAxis76.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range80 = dateAxis76.getDefaultAutoRange();
        double double81 = dateAxis76.getLowerMargin();
        boolean boolean82 = seriesRenderingOrder75.equals((java.lang.Object) dateAxis76);
        int int83 = xYPlot52.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis76);
        xYPlot52.setRangeCrosshairValue((double) 0L, false);
        java.awt.Stroke stroke87 = xYPlot52.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker89 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0f, (java.awt.Paint) color2, stroke33, paint40, stroke87, 0.0f);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertNotNull(dateTickUnit49);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNull(xYDataset72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(seriesRenderingOrder75);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.05d + "'", double81 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        xYPlot11.setRangeZeroBaselineVisible(true);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis23.setTickUnit(dateTickUnit28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        dateAxis33.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range37 = dateAxis33.getDefaultAutoRange();
        double double38 = dateAxis33.getLowerMargin();
        boolean boolean39 = seriesRenderingOrder32.equals((java.lang.Object) dateAxis33);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { dateAxis33 };
        xYPlot31.setDomainAxes(valueAxisArray40);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot31.setDomainGridlinePaint(paint42);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis45.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = dateAxis47.getTickUnit();
        dateAxis47.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis51.getTickUnit();
        dateAxis47.setTickUnit(dateTickUnit52);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) dateAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer54);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        xYPlot55.rendererChanged(rendererChangeEvent56);
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit60 = dateAxis59.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit62 = dateAxis61.getTickUnit();
        dateAxis61.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = dateAxis65.getTickUnit();
        dateAxis61.setTickUnit(dateTickUnit66);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset58, (org.jfree.chart.axis.ValueAxis) dateAxis59, (org.jfree.chart.axis.ValueAxis) dateAxis61, xYItemRenderer68);
        java.awt.Paint paint71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color73 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker76 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint71, stroke72, (java.awt.Paint) color73, stroke74, 0.0f);
        java.awt.Paint paint77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker76.setPaint(paint77);
        xYPlot69.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker76);
        org.jfree.chart.axis.AxisLocation axisLocation81 = xYPlot69.getDomainAxisLocation(12);
        xYPlot55.setDomainAxisLocation(axisLocation81, false);
        xYPlot31.setRangeAxisLocation(axisLocation81, false);
        try {
            xYPlot11.setDomainAxisLocation((-16776961), axisLocation81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(dateTickUnit60);
        org.junit.Assert.assertNotNull(dateTickUnit62);
        org.junit.Assert.assertNotNull(dateTickUnit66);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(axisLocation81);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setLabel("");
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font9 = dateAxis8.getLabelFont();
        categoryAxis1.setLabelFont(font9);
        categoryAxis1.setFixedDimension((double) 200);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        categoryAxis16.configure();
        categoryAxis16.setTickMarkOutsideLength((float) '4');
        java.lang.Object obj23 = categoryAxis16.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        categoryPlot4.setWeight((-1));
        boolean boolean19 = categoryPlot4.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation((int) (short) 1, axisLocation9);
        categoryPlot6.configureRangeAxes();
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot20.addChangeListener(plotChangeListener24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        int int31 = categoryPlot30.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        categoryPlot30.setRangeAxisLocation((int) (short) 1, axisLocation33);
        categoryPlot30.configureRangeAxes();
        categoryPlot30.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot30.getRowRenderingOrder();
        categoryPlot20.setColumnRenderingOrder(sortOrder38);
        org.jfree.chart.plot.Plot plot40 = categoryPlot20.getParent();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets();
        double double45 = rectangleInsets43.calculateRightOutset((double) 10L);
        categoryMarker42.setLabelOffset(rectangleInsets43);
        double double47 = rectangleInsets43.getTop();
        categoryPlot20.setAxisOffset(rectangleInsets43);
        categoryPlot6.setInsets(rectangleInsets43);
        int int50 = objectList0.indexOf((java.lang.Object) rectangleInsets43);
        java.lang.Object obj52 = objectList0.get(6);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, valueAxis55, categoryItemRenderer56);
        int int58 = categoryPlot57.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation60 = null;
        categoryPlot57.setRangeAxisLocation((int) (short) 1, axisLocation60);
        org.jfree.chart.plot.PlotOrientation plotOrientation62 = categoryPlot57.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection63 = categoryPlot57.getFixedLegendItems();
        boolean boolean64 = objectList0.equals((java.lang.Object) categoryPlot57);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(plotOrientation62);
        org.junit.Assert.assertNull(legendItemCollection63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.clearRangeMarkers();
        categoryPlot4.clearDomainMarkers(100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot4.notifyListeners(plotChangeEvent12);
        boolean boolean14 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis15.getTickUnit();
        dateAxis15.resizeRange((double) (-1.0f));
        dateAxis15.configure();
        java.awt.Shape shape20 = dateAxis15.getRightArrow();
        java.awt.Shape shape21 = dateAxis15.getUpArrow();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        int int27 = categoryPlot26.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot26.getDataRange(valueAxis28);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint31, stroke32, (java.awt.Paint) color33, stroke34, 0.0f);
        categoryPlot26.setDomainGridlineStroke(stroke34);
        categoryPlot26.clearRangeMarkers(9);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection41 = categoryPlot26.getRangeMarkers(layer40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        int int47 = categoryPlot46.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot46.setRangeAxisLocation((int) (short) 1, axisLocation49);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot46.getOrientation();
        categoryPlot26.setOrientation(plotOrientation51);
        java.awt.Color color53 = java.awt.Color.darkGray;
        categoryPlot26.setNoDataMessagePaint((java.awt.Paint) color53);
        dateAxis15.setTickMarkPaint((java.awt.Paint) color53);
        int int56 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot4.getIndexOf(categoryItemRenderer20);
        boolean boolean22 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot4.getRangeAxis((int) ' ');
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range26 = dateAxis22.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis31.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis35.getTickUnit();
        dateAxis31.setTickUnit(dateTickUnit36);
        java.util.Date date38 = dateAxis27.calculateHighestVisibleTickValue(dateTickUnit36);
        dateAxis22.setMaximumDate(date38);
        java.lang.Object obj40 = dateAxis22.clone();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        dateAxis22.setFixedAutoRange((double) 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint20, stroke21, (java.awt.Paint) color22, stroke23, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker25);
        java.awt.Color color27 = java.awt.Color.WHITE;
        categoryMarker25.setLabelPaint((java.awt.Paint) color27);
        categoryMarker25.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean32 = categoryPlot4.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker25, layer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean34 = categoryMarker25.equals((java.lang.Object) color33);
        int int35 = color33.getAlpha();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot4.getRootPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint11 = categoryAxis10.getAxisLinePaint();
        categoryPlot4.setOutlinePaint(paint11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot4.getDatasetRenderingOrder();
        try {
            categoryPlot4.setBackgroundImageAlpha((float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(0.0d);
        double double4 = rectangleInsets0.calculateRightOutset((double) (-57600000L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot4.getDrawingSupplier();
        categoryPlot4.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setUpperMargin((double) (byte) -1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace7, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        boolean boolean12 = categoryPlot4.isRangeCrosshairVisible();
        int int13 = categoryPlot4.getWeight();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        double double5 = dateAxis0.getLowerMargin();
        float float6 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.configure();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint12 = categoryAxis11.getAxisLinePaint();
        java.awt.Font font13 = categoryAxis11.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        categoryPlot18.setRangeCrosshairValue((double) '4');
        boolean boolean24 = categoryAxis11.equals((java.lang.Object) categoryPlot18);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot18.getDomainAxisEdge(0);
        try {
            double double27 = dateAxis0.java2DToValue((double) (short) 100, rectangle2D9, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        categoryPlot4.setWeight((-1));
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        categoryPlot4.setOutlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace32, false);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot11.getFixedLegendItems();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNull(legendItemCollection35);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker6);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryMarker6.setLabelPaint((java.awt.Paint) color8);
        categoryMarker6.setKey((java.lang.Comparable) "");
        java.awt.Paint paint12 = categoryMarker6.getPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean13 = categoryPlot4.equals((java.lang.Object) textAnchor12);
        boolean boolean14 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis16.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis18.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis18.setTickUnit(dateTickUnit23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer25);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightOutset((double) 10L);
        categoryMarker28.setLabelOffset(rectangleInsets29);
        boolean boolean33 = xYPlot26.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker28);
        xYPlot26.clearRangeMarkers((-246));
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets36);
        double double39 = rectangleInsets36.calculateTopOutset(198.0d);
        categoryPlot4.setInsets(rectangleInsets36);
        categoryPlot4.setWeight((-256));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot4.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker16, layer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint21 = categoryAxis20.getAxisLinePaint();
        java.awt.Font font22 = categoryAxis20.getTickLabelFont();
        java.awt.Paint paint23 = categoryAxis20.getTickLabelPaint();
        java.lang.String str24 = categoryAxis20.getLabelToolTip();
        java.awt.Font font25 = categoryAxis20.getTickLabelFont();
        intervalMarker16.setLabelFont(font25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis28.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis30.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis30.setTickUnit(dateTickUnit35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer37);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYPlot38.rendererChanged(rendererChangeEvent39);
        java.awt.Stroke stroke41 = xYPlot38.getDomainGridlineStroke();
        intervalMarker16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot38);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot38.getRenderer(6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(xYItemRenderer44);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (-3.0d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint18 = categoryAxis17.getAxisLinePaint();
        java.awt.Font font19 = categoryAxis17.getLabelFont();
        double double20 = categoryAxis17.getFixedDimension();
        java.awt.Paint paint21 = categoryAxis17.getTickMarkPaint();
        categoryMarker13.setOutlinePaint(paint21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        int int28 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        categoryPlot27.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot27.setRenderer(categoryItemRenderer33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean41 = categoryPlot27.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker39, layer40);
        boolean boolean43 = categoryPlot4.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker13, layer40, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        boolean boolean46 = layer40.equals((java.lang.Object) categoryAxis45);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis53, categoryItemRenderer54);
        int int56 = categoryPlot55.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation58 = null;
        categoryPlot55.setRangeAxisLocation((int) (short) 1, axisLocation58);
        categoryPlot55.configureRangeAxes();
        categoryPlot55.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot55.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            org.jfree.chart.axis.AxisState axisState65 = categoryAxis45.draw(graphics2D47, (double) (short) 0, rectangle2D49, rectangle2D50, rectangleEdge63, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        dateAxis0.setAutoRangeMinimumSize((double) 100);
        dateAxis0.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint21, stroke22, (java.awt.Paint) color23, stroke24, 0.0f);
        categoryPlot16.setDomainGridlineStroke(stroke24);
        java.awt.Stroke stroke28 = categoryPlot16.getRangeCrosshairStroke();
        categoryPlot4.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint33 = categoryAxis32.getAxisLinePaint();
        java.awt.Font font34 = categoryAxis32.getTickLabelFont();
        categoryPlot4.setDomainAxis((int) (byte) 100, categoryAxis32);
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 0);
        double double38 = categoryAxis32.getLowerMargin();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.axis.AxisState axisState40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        int int47 = categoryPlot46.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.data.Range range49 = categoryPlot46.getDataRange(valueAxis48);
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint51, stroke52, (java.awt.Paint) color53, stroke54, 0.0f);
        categoryPlot46.setDomainGridlineStroke(stroke54);
        java.awt.Stroke stroke58 = categoryPlot46.getRangeCrosshairStroke();
        categoryPlot46.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis63, categoryItemRenderer64);
        int int66 = categoryPlot65.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation68 = null;
        categoryPlot65.setRangeAxisLocation((int) (short) 1, axisLocation68);
        categoryPlot65.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot65.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation73 = categoryPlot65.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation74 = axisLocation73.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation75 = axisLocation73.getOpposite();
        categoryPlot46.setDomainAxisLocation(axisLocation75, false);
        org.jfree.data.category.CategoryDataset categoryDataset78 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = null;
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer81 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot(categoryDataset78, categoryAxis79, valueAxis80, categoryItemRenderer81);
        int int83 = categoryPlot82.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation85 = null;
        categoryPlot82.setRangeAxisLocation((int) (short) 1, axisLocation85);
        categoryPlot82.configureRangeAxes();
        categoryPlot82.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation90 = categoryPlot82.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation75, plotOrientation90);
        try {
            java.util.List list92 = categoryAxis32.refreshTicks(graphics2D39, axisState40, rectangle2D41, rectangleEdge91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(axisLocation73);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(plotOrientation90);
        org.junit.Assert.assertNotNull(rectangleEdge91);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        dateAxis0.configure();
        java.awt.Shape shape5 = dateAxis0.getRightArrow();
        java.awt.Shape shape6 = dateAxis0.getUpArrow();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint16, stroke17, (java.awt.Paint) color18, stroke19, 0.0f);
        categoryPlot11.setDomainGridlineStroke(stroke19);
        categoryPlot11.clearRangeMarkers(9);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection26 = categoryPlot11.getRangeMarkers(layer25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = categoryPlot31.getOrientation();
        categoryPlot11.setOrientation(plotOrientation36);
        java.awt.Color color38 = java.awt.Color.darkGray;
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color38);
        dateAxis0.setTickMarkPaint((java.awt.Paint) color38);
        java.awt.Color color41 = color38.darker();
        java.awt.Color color42 = java.awt.Color.blue;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray44 = null;
        float[] floatArray45 = color43.getColorComponents(floatArray44);
        float[] floatArray46 = color42.getColorComponents(floatArray44);
        float[] floatArray47 = color38.getColorComponents(floatArray44);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        boolean boolean34 = dateAxis25.isVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint5 = categoryAxis4.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis4.getLabelFont();
        double double7 = categoryAxis4.getFixedDimension();
        java.awt.Paint paint8 = categoryAxis4.getTickMarkPaint();
        boolean boolean9 = numberAxis0.equals((java.lang.Object) paint8);
        java.lang.String str10 = numberAxis0.getLabel();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis15.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis17.setTickUnit(dateTickUnit22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer24);
        java.awt.Paint paint26 = xYPlot25.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = xYPlot25.getAxisOffset();
        boolean boolean28 = xYPlot25.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot25.getDomainAxisEdge();
        try {
            java.util.List list30 = numberAxis0.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10);
        java.util.Date date12 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit10);
        boolean boolean13 = color0.equals((java.lang.Object) date12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerBound();
        double double16 = dateAxis14.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.setAutoTickUnitSelection(false);
        dateAxis17.configure();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range26 = dateAxis22.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis31.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis35.getTickUnit();
        dateAxis31.setTickUnit(dateTickUnit36);
        java.util.Date date38 = dateAxis27.calculateHighestVisibleTickValue(dateTickUnit36);
        dateAxis22.setMaximumDate(date38);
        dateAxis17.setMinimumDate(date38);
        dateAxis14.setMinimumDate(date38);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date38, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date12, timeZone42);
        int int46 = day45.getMonth();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = color0.brighter();
        int int2 = color0.getGreen();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getColorComponents(floatArray6);
        try {
            float[] floatArray8 = color0.getComponents(colorSpace4, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font26 = dateAxis25.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition27 = dateAxis25.getTickMarkPosition();
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone29);
        dateAxis25.setStandardTickUnits(tickUnitSource30);
        java.util.TimeZone timeZone32 = dateAxis25.getTimeZone();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(dateTickMarkPosition27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertNotNull(timeZone32);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset(0.0d);
        double double5 = rectangleInsets0.trimHeight((double) 8);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot4.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker16, layer17);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        java.util.List list27 = numberAxis20.refreshTicks(graphics2D23, axisState24, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.setTickMarkInsideLength((float) (short) 10);
        dateAxis28.resizeRange((double) 0L);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        dateAxis28.setTickMarkPaint((java.awt.Paint) color33);
        int int35 = color33.getTransparency();
        numberAxis20.setAxisLinePaint((java.awt.Paint) color33);
        int int37 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot4.setRenderer(categoryItemRenderer18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit5);
        boolean boolean7 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.data.RangeType rangeType8 = numberAxis0.getRangeType();
        numberAxis0.setFixedDimension((double) 3);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rangeType8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        int int16 = xYPlot11.getRangeAxisIndex(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.trimWidth((double) 200);
        xYPlot11.setAxisOffset(rectangleInsets17);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 198.0d + "'", double19 == 198.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        dateAxis0.resizeRange((double) 0L);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color5);
        double double7 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint21, stroke22, (java.awt.Paint) color23, stroke24, 0.0f);
        categoryPlot16.setDomainGridlineStroke(stroke24);
        java.awt.Stroke stroke28 = categoryPlot16.getRangeCrosshairStroke();
        categoryPlot4.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint33 = categoryAxis32.getAxisLinePaint();
        java.awt.Font font34 = categoryAxis32.getTickLabelFont();
        categoryPlot4.setDomainAxis((int) (byte) 100, categoryAxis32);
        boolean boolean36 = categoryAxis32.isVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        float float13 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot14 = categoryPlot4.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(5, categoryDataset16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot4.removeChangeListener(plotChangeListener18);
        try {
            categoryPlot4.setBackgroundImageAlpha((float) (-32513));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        double double2 = dateAxis0.getUpperBound();
        dateAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Font font25 = categoryAxis23.getLabelFont();
        categoryPlot4.setDomainAxis(categoryAxis23);
        java.awt.Paint paint27 = categoryAxis23.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.removeChangeListener(markerChangeListener4);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryMarker1.notifyListeners(markerChangeEvent13);
        java.awt.Font font15 = categoryMarker1.getLabelFont();
        boolean boolean16 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateRightOutset((double) 10L);
        categoryMarker8.setLabelOffset(rectangleInsets9);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot4.addDomainMarker((int) (short) -1, categoryMarker8, layer13, false);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot4.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        double double5 = dateAxis0.getUpperMargin();
        java.util.Date date6 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot11.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation26 = null;
        try {
            xYPlot11.addAnnotation(xYAnnotation26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day24.next();
        java.util.Date date43 = regularTimePeriod42.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.GENERAL", timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date43, timeZone45);
        int int48 = day47.getYear();
        org.jfree.data.time.SerialDate serialDate49 = day47.getSerialDate();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1970 + "'", int48 == 1970);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot11.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint33 = categoryAxis32.getAxisLinePaint();
        java.awt.Font font34 = categoryAxis32.getLabelFont();
        double double35 = categoryAxis32.getFixedDimension();
        java.awt.Paint paint36 = categoryAxis32.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        java.awt.Stroke stroke42 = categoryPlot41.getRangeGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, paint36, stroke42);
        xYPlot11.setOutlineStroke(stroke42);
        xYPlot11.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = dateAxis48.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = dateAxis50.getTickUnit();
        dateAxis50.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis54.getTickUnit();
        dateAxis50.setTickUnit(dateTickUnit55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer57);
        java.awt.Paint paint59 = xYPlot58.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset60 = xYPlot58.getDataset();
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot58.setDomainCrosshairStroke(stroke61);
        xYPlot11.setRangeZeroBaselineStroke(stroke61);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(dateTickUnit49);
        org.junit.Assert.assertNotNull(dateTickUnit51);
        org.junit.Assert.assertNotNull(dateTickUnit55);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(xYDataset60);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        int int31 = categoryPlot30.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        categoryPlot30.setRangeAxisLocation((int) (short) 1, axisLocation33);
        boolean boolean35 = categoryPlot30.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = null;
        categoryPlot30.setFixedLegendItems(legendItemCollection36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double41 = categoryAxis40.getUpperMargin();
        categoryPlot30.setDomainAxis((int) ' ', categoryAxis40, false);
        java.awt.Paint paint44 = categoryAxis40.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryAxis40.getTickLabelInsets();
        double double46 = rectangleInsets45.getLeft();
        xYPlot11.setInsets(rectangleInsets45, false);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot11.getRangeAxis((-256));
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertNull(valueAxis50);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        java.awt.Shape shape7 = dateAxis0.getLeftArrow();
        dateAxis0.setFixedAutoRange((-1.6777224E7d));
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        dateAxis1.zoomRange((double) 1.0f, (double) 2);
        double double15 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setLabelToolTip("CONTRACT");
        dateAxis0.setAutoRangeMinimumSize(4.0d, true);
        dateAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day24.next();
        java.util.Date date43 = regularTimePeriod42.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.GENERAL", timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date43, timeZone45);
        long long48 = day47.getSerialIndex();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 25569L + "'", long48 == 25569L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot4.notifyListeners(plotChangeEvent12);
        boolean boolean14 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Image image15 = null;
        categoryPlot4.setBackgroundImage(image15);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets21.calculateRightOutset((double) 10L);
        categoryMarker20.setLabelOffset(rectangleInsets21);
        double double26 = rectangleInsets21.extendWidth((double) ' ');
        categoryPlot4.setInsets(rectangleInsets21);
        categoryPlot4.mapDatasetToRangeAxis(64, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 34.0d + "'", double26 == 34.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj8 = categoryPlot4.clone();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot4.setColumnRenderingOrder(sortOrder9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis12.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer21);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint24, stroke25, (java.awt.Paint) color26, stroke27, 0.0f);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker29.setPaint(paint30);
        xYPlot22.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot22.getDomainAxisLocation(12);
        categoryPlot4.setDomainAxisLocation(axisLocation34, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        long long26 = day24.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-14400001L) + "'", long26 == (-14400001L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        dateAxis0.resizeRange((double) 0L);
        dateAxis0.setInverted(false);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = dateAxis0.draw(graphics2D7, (double) ' ', rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot11.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot11.setRenderer(128, xYItemRenderer21, true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.data.Range range31 = categoryPlot28.getDataRange(valueAxis30);
        categoryPlot28.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint34 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot28.getDomainAxis((-32513));
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset38);
        java.lang.Object obj40 = datasetChangeEvent39.getSource();
        categoryPlot28.datasetChanged(datasetChangeEvent39);
        xYPlot11.datasetChanged(datasetChangeEvent39);
        java.awt.Paint paint43 = xYPlot11.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + obj40 + "' != '" + false + "'", obj40.equals(false));
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        xYPlot11.mapDatasetToDomainAxis(12, (int) ' ');
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot11.getDomainAxisForDataset(0);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double26 = rectangleInsets24.calculateRightOutset((double) 10L);
        categoryMarker23.setLabelOffset(rectangleInsets24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = categoryMarker23.getLabelAnchor();
        boolean boolean29 = intervalMarker21.equals((java.lang.Object) categoryMarker23);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        int int35 = categoryPlot34.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot34.setRangeAxisLocation((int) (short) 1, axisLocation37);
        categoryPlot34.configureRangeAxes();
        categoryPlot34.clearRangeMarkers(0);
        categoryPlot34.mapDatasetToDomainAxis((int) '#', (int) (short) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        categoryMarker47.setKey((java.lang.Comparable) (short) -1);
        java.awt.Paint paint50 = null;
        categoryMarker47.setOutlinePaint(paint50);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis54, categoryItemRenderer55);
        int int57 = categoryPlot56.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        int int63 = categoryPlot62.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.data.Range range65 = categoryPlot62.getDataRange(valueAxis64);
        java.awt.Paint paint67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint67, stroke68, (java.awt.Paint) color69, stroke70, 0.0f);
        categoryPlot62.setDomainGridlineStroke(stroke70);
        java.awt.Paint paint76 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke79 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker81 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint76, stroke77, (java.awt.Paint) color78, stroke79, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent82 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker81);
        java.awt.Color color83 = java.awt.Color.WHITE;
        categoryMarker81.setLabelPaint((java.awt.Paint) color83);
        categoryMarker81.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot62.addRangeMarker(500, (org.jfree.chart.plot.Marker) categoryMarker81, layer87);
        java.util.Collection collection89 = categoryPlot56.getRangeMarkers(layer87);
        boolean boolean90 = categoryPlot34.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) categoryMarker47, layer87);
        boolean boolean92 = xYPlot11.removeDomainMarker(100, (org.jfree.chart.plot.Marker) categoryMarker23, layer87, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNull(range65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertNotNull(collection89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextPaint();
        xYPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        xYPlot11.setRangeZeroBaselineVisible(true);
        xYPlot11.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets21.calculateRightOutset((double) 10L);
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double23, dataset24);
        xYPlot11.datasetChanged(datasetChangeEvent25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range31 = dateAxis27.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        dateAxis36.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = dateAxis40.getTickUnit();
        dateAxis36.setTickUnit(dateTickUnit41);
        java.util.Date date43 = dateAxis32.calculateHighestVisibleTickValue(dateTickUnit41);
        dateAxis27.setMaximumDate(date43);
        java.lang.Object obj45 = dateAxis27.clone();
        java.awt.Color color49 = java.awt.Color.getHSBColor((float) 9, (float) (-256), (float) 2);
        dateAxis27.setTickMarkPaint((java.awt.Paint) color49);
        java.lang.String str51 = color49.toString();
        xYPlot11.setRangeGridlinePaint((java.awt.Paint) color49);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(dateTickUnit41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "java.awt.Color[r=255,g=255,b=254]" + "'", str51.equals("java.awt.Color[r=255,g=255,b=254]"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setTickMarkInsideLength((float) (short) 10);
        dateAxis8.resizeRange((double) 0L);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color13);
        int int15 = color13.getTransparency();
        numberAxis0.setAxisLinePaint((java.awt.Paint) color13);
        int int17 = color13.getRed();
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        float float13 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot14 = categoryPlot4.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(5, categoryDataset16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot4.removeChangeListener(plotChangeListener18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot4.getLegendItems();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis0.setNumberFormatOverride(numberFormat5);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation((int) (short) 1, axisLocation19);
        categoryPlot16.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot16.getRangeAxisEdge((int) (byte) 0);
        try {
            java.util.List list24 = numberAxis0.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        java.awt.Paint paint25 = xYPlot11.getRangeZeroBaselinePaint();
        float float26 = xYPlot11.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        boolean boolean8 = dateAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range39 = dateAxis35.getDefaultAutoRange();
        double double40 = dateAxis35.getLowerMargin();
        boolean boolean41 = seriesRenderingOrder34.equals((java.lang.Object) dateAxis35);
        int int42 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.ChartColor chartColor46 = new org.jfree.chart.ChartColor(0, 10, 9);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) chartColor46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = xYPlot11.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNull(axisSpace48);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        xYPlot11.axisChanged(axisChangeEvent15);
        boolean boolean17 = xYPlot11.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot11.drawAnnotations(graphics2D32, rectangle2D33, plotRenderingInfo34);
        java.awt.geom.Point2D point2D36 = xYPlot11.getQuadrantOrigin();
        java.lang.Object obj37 = null;
        boolean boolean38 = xYPlot11.equals(obj37);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation39 = null;
        try {
            xYPlot11.addAnnotation(xYAnnotation39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        dateAxis0.resizeRange((double) 0L);
        dateAxis0.setNegativeArrowVisible(false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font2 = dateAxis1.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.zoomRange((double) 10, (double) '#');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis10.getTickUnit();
        dateAxis10.setAutoTickUnitSelection(false);
        dateAxis10.setNegativeArrowVisible(true);
        double double16 = dateAxis10.getAutoRangeMinimumSize();
        java.awt.Shape shape17 = dateAxis10.getLeftArrow();
        java.util.Date date18 = dateAxis10.getMinimumDate();
        dateAxis4.setMaximumDate(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker6);
        org.jfree.chart.JFreeChart jFreeChart9 = markerChangeEvent8.getChart();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(jFreeChart9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot4.addDomainMarker(categoryMarker10);
        java.awt.Stroke stroke12 = categoryMarker10.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setTickMarkInsideLength((float) (short) 10);
        java.awt.Paint paint16 = dateAxis13.getTickLabelPaint();
        boolean boolean17 = categoryMarker10.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = categoryMarker10.getLabelAnchor();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getLeftArrow();
        dateAxis0.resizeRange((double) 12);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot11.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot11.setRenderer(128, xYItemRenderer21, true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.data.Range range31 = categoryPlot28.getDataRange(valueAxis30);
        categoryPlot28.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint34 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot28.getDomainAxis((-32513));
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset38);
        java.lang.Object obj40 = datasetChangeEvent39.getSource();
        categoryPlot28.datasetChanged(datasetChangeEvent39);
        xYPlot11.datasetChanged(datasetChangeEvent39);
        java.awt.Paint paint43 = xYPlot11.getBackgroundPaint();
        xYPlot11.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + obj40 + "' != '" + false + "'", obj40.equals(false));
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis9.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis13.getTickUnit();
        dateAxis9.setTickUnit(dateTickUnit14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range20 = dateAxis16.getDefaultAutoRange();
        dateAxis9.setRange(range20);
        dateAxis0.setRange(range20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.setAutoTickUnitSelection(false);
        dateAxis23.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis23.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        int int35 = categoryPlot34.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot34.setRangeAxisLocation((int) (short) 1, axisLocation37);
        boolean boolean39 = categoryPlot34.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = null;
        categoryPlot34.setFixedLegendItems(legendItemCollection40);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double45 = categoryAxis44.getUpperMargin();
        categoryPlot34.setDomainAxis((int) ' ', categoryAxis44, false);
        java.awt.Paint paint48 = categoryAxis44.getLabelPaint();
        dateAxis0.setTickMarkPaint(paint48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(dateTickUnit50);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot11.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint33 = categoryAxis32.getAxisLinePaint();
        java.awt.Font font34 = categoryAxis32.getLabelFont();
        double double35 = categoryAxis32.getFixedDimension();
        java.awt.Paint paint36 = categoryAxis32.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        java.awt.Stroke stroke42 = categoryPlot41.getRangeGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, paint36, stroke42);
        xYPlot11.setOutlineStroke(stroke42);
        xYPlot11.setDomainCrosshairVisible(false);
        int int47 = xYPlot11.getRangeAxisCount();
        java.awt.Color color49 = java.awt.Color.black;
        xYPlot11.setQuadrantPaint(0, (java.awt.Paint) color49);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(color49);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        java.awt.Stroke stroke14 = xYPlot11.getDomainGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleAnchor17, jFreeChart18, chartChangeEventType19);
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) chartChangeEventType19);
        xYPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        boolean boolean23 = xYPlot11.isOutlineVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setTickMarkInsideLength((float) (short) 10);
        dateAxis10.resizeRange((double) 0L);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot21.setRangeAxisLocation((int) (short) 1, axisLocation24);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot21.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot21.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot21.getDataset((-256));
        java.awt.Stroke stroke32 = categoryPlot21.getOutlineStroke();
        numberAxis1.setTickMarkStroke(stroke32);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.lang.Object obj27 = xYPlot11.clone();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot11.indexOf(xYDataset28);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        boolean boolean8 = categoryPlot4.isRangeCrosshairLockedOnData();
        categoryPlot4.setRangeCrosshairValue(1.0E-8d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        java.awt.Stroke stroke14 = xYPlot11.getDomainGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        categoryPlot20.setRangeAxisLocation((int) (short) 1, axisLocation23);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot20.addDomainMarker(categoryMarker26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis29.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis31.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis35.getTickUnit();
        dateAxis31.setTickUnit(dateTickUnit36);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer38);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker41.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint45, stroke46, (java.awt.Paint) color47, stroke48, 0.0f);
        categoryMarker41.setOutlineStroke(stroke46);
        boolean boolean52 = xYPlot39.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker41);
        xYPlot39.clearDomainAxes();
        boolean boolean54 = xYPlot39.isDomainCrosshairLockedOnData();
        java.awt.Color color55 = java.awt.Color.gray;
        xYPlot39.setDomainGridlinePaint((java.awt.Paint) color55);
        java.awt.Stroke stroke57 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot39.setRangeGridlineStroke(stroke57);
        org.jfree.data.xy.XYDataset xYDataset59 = xYPlot39.getDataset();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot39.setRangeCrosshairPaint((java.awt.Paint) color60);
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection63 = xYPlot39.getDomainMarkers(layer62);
        boolean boolean64 = xYPlot11.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) categoryMarker26, layer62);
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot11.getDomainAxis(10);
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, categoryAxis69, valueAxis70, categoryItemRenderer71);
        int int73 = categoryPlot72.getDomainAxisCount();
        boolean boolean74 = categoryPlot72.getDrawSharedDomainAxis();
        java.awt.Paint paint75 = categoryPlot72.getOutlinePaint();
        categoryPlot72.setRangeCrosshairLockedOnData(false);
        boolean boolean78 = categoryPlot72.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation80 = categoryPlot72.getDomainAxisLocation((-256));
        xYPlot11.setRangeAxisLocation(9, axisLocation80);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNull(xYDataset59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(valueAxis66);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(axisLocation80);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation((int) (short) 1, axisLocation14);
        boolean boolean16 = categoryPlot11.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = null;
        categoryPlot11.setFixedLegendItems(legendItemCollection17);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double22 = categoryAxis21.getUpperMargin();
        categoryPlot11.setDomainAxis((int) ' ', categoryAxis21, false);
        categoryAxis21.setUpperMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis21, valueAxis27, categoryItemRenderer28);
        categoryPlot29.clearRangeMarkers();
        boolean boolean31 = dateAxis0.hasListener((java.util.EventListener) categoryPlot29);
        double double32 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder15);
        java.awt.Paint paint17 = xYPlot11.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        xYPlot11.setDomainCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D19 = xYPlot11.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(categoryDataset10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 8, plotRenderingInfo13, point2D14, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot4.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker16, layer17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = intervalMarker16.getGradientPaintTransformer();
        intervalMarker16.setStartValue((double) 10.0f);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint23, stroke24, (java.awt.Paint) color25, stroke26, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker28);
        intervalMarker16.notifyListeners(markerChangeEvent29);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot4.getDrawingSupplier();
        categoryPlot4.setRangeCrosshairValue(0.0d, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        int int20 = categoryPlot19.getDomainAxisCount();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        java.awt.Font font23 = categoryPlot19.getNoDataMessageFont();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.calculateRightOutset((double) 10L);
        categoryMarker25.setLabelOffset(rectangleInsets26);
        double double31 = rectangleInsets26.calculateRightOutset((double) 2.0f);
        categoryPlot19.setInsets(rectangleInsets26);
        categoryPlot4.setAxisOffset(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot11.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot11.setRenderer(128, xYItemRenderer21, true);
        xYPlot11.clearDomainMarkers(0);
        java.awt.Stroke stroke26 = xYPlot11.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = color0.darker();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getColorComponents(floatArray5);
        float[] floatArray7 = color3.getComponents(floatArray5);
        float[] floatArray8 = color2.getRGBComponents(floatArray5);
        float[] floatArray9 = color1.getComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup19 = categoryPlot4.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNull(datasetGroup19);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        java.awt.Paint paint25 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearRangeMarkers();
        boolean boolean27 = xYPlot11.isDomainZoomable();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        xYPlot11.addChangeListener(plotChangeListener28);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot11.setRenderer((int) (byte) 0, xYItemRenderer14, true);
        double double17 = xYPlot11.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot11.getDataset();
        boolean boolean15 = xYPlot11.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        java.awt.Color color6 = java.awt.Color.cyan;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getColorComponents(floatArray8);
        float[] floatArray10 = color6.getRGBColorComponents(floatArray8);
        dateAxis0.setTickMarkPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = xYPlot11.getDomainMarkers(layer34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot11.setRangeZeroBaselineStroke(stroke36);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        numberAxis0.setUpperBound((double) '4');
        numberAxis0.configure();
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint18 = categoryAxis14.getLabelPaint();
        float float19 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        java.lang.Comparable comparable20 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker22.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        categoryMarker22.removeChangeListener(markerChangeListener25);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint28, stroke29, (java.awt.Paint) color30, stroke31, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker33);
        categoryMarker22.notifyListeners(markerChangeEvent34);
        java.awt.Font font36 = categoryMarker22.getLabelFont();
        try {
            categoryAxis14.setTickLabelFont(comparable20, font36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.addChangeListener(plotChangeListener8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation17);
        categoryPlot14.configureRangeAxes();
        categoryPlot14.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot14.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot4.getParent();
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker26.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener29 = null;
        categoryMarker26.removeChangeListener(markerChangeListener29);
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint32, stroke33, (java.awt.Paint) color34, stroke35, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker37);
        categoryMarker26.notifyListeners(markerChangeEvent38);
        boolean boolean40 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit5);
        boolean boolean7 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.data.Range range15 = categoryPlot12.getDataRange(valueAxis14);
        categoryPlot12.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot12.setRenderer(categoryItemRenderer18, false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint28 = categoryAxis27.getAxisLinePaint();
        java.awt.Font font29 = categoryAxis27.getLabelFont();
        categoryPlot25.setNoDataMessageFont(font29);
        categoryPlot12.setNoDataMessageFont(font29);
        boolean boolean32 = categoryPlot12.getDrawSharedDomainAxis();
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot12);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        xYPlot11.setBackgroundImageAlpha(0.8f);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        double double23 = xYPlot11.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot11.setDataset(89, xYDataset25);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setFixedDimension(0.0d);
        double double4 = dateAxis0.getFixedAutoRange();
        dateAxis0.setRangeAboutValue((double) (short) 1, (double) (byte) 0);
        java.awt.Shape shape8 = dateAxis0.getUpArrow();
        dateAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis0.setNumberFormatOverride(numberFormat5);
        numberAxis0.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis21.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis21.setTickUnit(dateTickUnit26);
        dateAxis21.setInverted(true);
        dateAxis21.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis21.setRightArrow(shape33);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        int int41 = categoryPlot40.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        categoryPlot40.setRangeAxisLocation((int) (short) 1, axisLocation43);
        boolean boolean45 = categoryPlot40.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot40.setDomainGridlinePosition(categoryAnchor46);
        categoryPlot4.setDomainGridlinePosition(categoryAnchor46);
        java.lang.String str49 = categoryAnchor46.toString();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(categoryAnchor46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "CategoryAnchor.END" + "'", str49.equals("CategoryAnchor.END"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        dateAxis0.setRange((-3.0d), 3.0d);
        double double9 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Color color12 = java.awt.Color.BLUE;
        dateAxis3.setTickMarkPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setTickMarkInsideLength((float) (short) 10);
        dateAxis10.resizeRange((double) 0L);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer15);
        xYPlot16.setForegroundAlpha((float) (byte) 100);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.awt.Paint paint5 = null;
        try {
            numberAxis0.setTickLabelPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis0.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = null;
        numberAxis7.setMarkerBand(markerAxisBand10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit12);
        numberAxis0.setTickUnit(numberTickUnit12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis15.setMarkerBand(markerAxisBand18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit20);
        org.jfree.data.RangeType rangeType22 = numberAxis15.getRangeType();
        numberAxis0.setRangeType(rangeType22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis28.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis30.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis30.setTickUnit(dateTickUnit35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer37);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint40, stroke41, (java.awt.Paint) color42, stroke43, 0.0f);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker45.setPaint(paint46);
        xYPlot38.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker45);
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot38.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis53, categoryItemRenderer54);
        int int56 = categoryPlot55.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation58 = null;
        categoryPlot55.setRangeAxisLocation((int) (short) 1, axisLocation58);
        categoryPlot55.configureRangeAxes();
        categoryPlot55.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = categoryPlot55.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation50, plotOrientation63);
        try {
            java.util.List list65 = numberAxis0.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(rangeType22);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        categoryAxis16.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        categoryPlot4.mapDatasetToRangeAxis(10, 0);
        float float18 = categoryPlot4.getForegroundAlpha();
        categoryPlot4.setNoDataMessage("CONTRACT");
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        int int26 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot25.setRangeAxisLocation((int) (short) 1, axisLocation28);
        boolean boolean30 = categoryPlot25.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot25.setDomainGridlinePosition(categoryAnchor31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot25.setRenderer(5, categoryItemRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint38 = categoryAxis37.getAxisLinePaint();
        java.awt.Font font39 = categoryAxis37.getLabelFont();
        int int40 = categoryPlot25.getDomainAxisIndex(categoryAxis37);
        org.jfree.data.general.DatasetGroup datasetGroup41 = categoryPlot25.getDatasetGroup();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.plot.Plot plot43 = plotChangeEvent42.getPlot();
        org.jfree.chart.JFreeChart jFreeChart44 = null;
        plotChangeEvent42.setChart(jFreeChart44);
        categoryPlot4.notifyListeners(plotChangeEvent42);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNull(datasetGroup41);
        org.junit.Assert.assertNotNull(plot43);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.GENERAL", timeZone1);
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot11.getDataset((-246));
        boolean boolean19 = xYPlot11.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        categoryPlot24.clearRangeAxes();
        boolean boolean26 = xYPlot11.equals((java.lang.Object) categoryPlot24);
        xYPlot11.configureRangeAxes();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot11.getDomainAxisLocation(2);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis0.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = null;
        numberAxis7.setMarkerBand(markerAxisBand10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit12);
        numberAxis0.setTickUnit(numberTickUnit12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis15.setMarkerBand(markerAxisBand18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit20);
        org.jfree.data.RangeType rangeType22 = numberAxis15.getRangeType();
        numberAxis0.setRangeType(rangeType22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis28.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis30.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis30.setTickUnit(dateTickUnit35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer37);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker40.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint44, stroke45, (java.awt.Paint) color46, stroke47, 0.0f);
        categoryMarker40.setOutlineStroke(stroke45);
        boolean boolean51 = xYPlot38.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker40);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font53 = dateAxis52.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition54 = dateAxis52.getTickMarkPosition();
        xYPlot38.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = xYPlot38.getDomainAxisEdge(500);
        try {
            java.util.List list58 = numberAxis0.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(rangeType22);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(dateTickMarkPosition54);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        double double23 = xYPlot11.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis27.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis27.setTickUnit(dateTickUnit32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer34);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        double double40 = rectangleInsets38.calculateRightOutset((double) 10L);
        categoryMarker37.setLabelOffset(rectangleInsets38);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker37);
        xYPlot35.clearRangeMarkers((-246));
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint52 = categoryAxis51.getAxisLinePaint();
        java.awt.Font font53 = categoryAxis51.getLabelFont();
        categoryPlot49.setNoDataMessageFont(font53);
        org.jfree.chart.axis.AxisLocation axisLocation56 = categoryPlot49.getRangeAxisLocation(0);
        xYPlot35.setRangeAxisLocation(axisLocation56);
        xYPlot11.setRangeAxisLocation(axisLocation56, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(axisLocation56);
    }
}

