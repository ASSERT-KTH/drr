import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.ChartColor chartColor4 = new org.jfree.chart.ChartColor(0, (int) 'a', 0);
        java.awt.Stroke stroke5 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1, (java.awt.Paint) chartColor4, stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, (double) 0.0f, (double) (short) -1, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (-1.0d), (double) 10, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) -1, (double) (short) -1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        try {
            categoryPlot4.zoom((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot4.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Font font8 = null;
        try {
            categoryPlot4.setNoDataMessageFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        try {
            categoryPlot4.zoom((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth((double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0d) + "'", double2 == (-3.0d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        boolean boolean6 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint7 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 3, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets2.createInsetRectangle(rectangle2D6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        boolean boolean6 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint7 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            categoryPlot4.setRangeAxisLocation(axisLocation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        try {
            categoryPlot4.setRenderer((-1), categoryItemRenderer13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint6 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot4.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            categoryPlot4.setRangeAxisLocation(axisLocation11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation((int) (short) 1, axisLocation14);
        categoryPlot11.configureRangeAxes();
        categoryPlot11.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge();
        try {
            double double20 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 0L, (java.lang.Comparable) (short) -1, categoryDataset4, (double) 10, rectangle2D6, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder11 = null;
        try {
            categoryPlot4.setRowRenderingOrder(sortOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot12.setRangeAxisLocation((int) (short) 1, axisLocation15);
        categoryPlot12.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot12.getRangeAxisEdge((int) (byte) 0);
        try {
            java.util.List list20 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { 100.0f, 10.0f };
        try {
            float[] floatArray5 = color0.getComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo17, point2D18, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = null;
        try {
            dateAxis0.setDownArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint20, stroke21, (java.awt.Paint) color22, stroke23, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker25);
        java.awt.Color color27 = java.awt.Color.WHITE;
        categoryMarker25.setLabelPaint((java.awt.Paint) color27);
        categoryMarker25.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean32 = categoryPlot4.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker25, layer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot4.zoomDomainAxes((double) (short) 100, plotRenderingInfo34, point2D35, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.removeChangeListener(markerChangeListener4);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryMarker1.notifyListeners(markerChangeEvent13);
        java.lang.String str15 = markerChangeEvent13.toString();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation((int) (short) 1, axisLocation10);
        categoryPlot7.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot7.getRangeAxisEdge((int) (byte) 0);
        try {
            double double15 = dateAxis0.dateToJava2D(date1, rectangle2D2, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        categoryPlot4.mapDatasetToRangeAxis(10, 0);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            categoryPlot4.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        double double6 = rectangleInsets2.getTop();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str9 = lengthAdjustmentType8.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets2.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CONTRACT" + "'", str9.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot4.getAxisOffset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), (float) 8, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getColorComponents(floatArray1);
        java.lang.String str3 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean3 = unitType0.equals((java.lang.Object) unitType2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=128]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 10, 10.0d, (double) 1.0f, (double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint18, stroke19, (java.awt.Paint) color20, stroke21, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker23);
        java.awt.Color color25 = java.awt.Color.WHITE;
        categoryMarker23.setLabelPaint((java.awt.Paint) color25);
        categoryMarker23.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot4.addRangeMarker(500, (org.jfree.chart.plot.Marker) categoryMarker23, layer29);
        try {
            categoryPlot4.zoom((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(layer29);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryMarker5.setOutlineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (byte) 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getLabelFont();
        java.util.Date date2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot8.setRangeAxisLocation((int) (short) 1, axisLocation11);
        categoryPlot8.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot8.getRangeAxisEdge((int) (byte) 0);
        try {
            double double16 = dateAxis0.dateToJava2D(date2, rectangle2D3, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        double double7 = rectangleInsets2.calculateRightInset((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets2.createOutsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot4.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            categoryPlot4.setAxisOffset(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setInverted(true);
        dateAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) rectangleAnchor1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot7.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot7.notifyListeners(plotChangeEvent15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection18 = categoryPlot7.getDomainMarkers(layer17);
        boolean boolean19 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        double double15 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker1, jFreeChart4, chartChangeEventType5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent6.getType();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartChangeEvent6, jFreeChart8, chartChangeEventType9);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        java.lang.String str12 = categoryAnchor10.toString();
        java.lang.Object obj13 = null;
        boolean boolean14 = categoryAnchor10.equals(obj13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.END" + "'", str12.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        categoryPlot4.setWeight((-1));
        boolean boolean19 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean22 = categoryPlot4.removeAnnotation(categoryAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis1.draw(graphics2D7, (double) ' ', rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint18 = categoryAxis14.getLabelPaint();
        categoryAxis14.setAxisLineVisible(true);
        java.lang.String str21 = categoryAxis14.getLabelURL();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier8);
        java.awt.Paint paint10 = categoryPlot4.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint18, stroke19, (java.awt.Paint) color20, stroke21, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker23);
        java.awt.Color color25 = java.awt.Color.WHITE;
        categoryMarker23.setLabelPaint((java.awt.Paint) color25);
        categoryMarker23.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot4.addRangeMarker(500, (org.jfree.chart.plot.Marker) categoryMarker23, layer29);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(layer29);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateRightOutset((double) 10L);
        categoryMarker14.setLabelOffset(rectangleInsets15);
        double double20 = rectangleInsets15.extendWidth((double) ' ');
        categoryPlot4.setAxisOffset(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 34.0d + "'", double20 == 34.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        double double6 = rectangleInsets2.getRight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis2.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker6.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint10, stroke11, (java.awt.Paint) color12, stroke13, 0.0f);
        categoryMarker6.setOutlineStroke(stroke11);
        categoryAxis2.setTickMarkStroke(stroke11);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer19);
        try {
            dateAxis18.setRangeWithMargins(100.0d, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        dateAxis0.setAutoRangeMinimumSize((double) 100);
        dateAxis0.setLowerBound((double) '4');
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot4.addRangeMarker((-16777216), marker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(layer23);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint21, stroke22, (java.awt.Paint) color23, stroke24, 0.0f);
        categoryPlot16.setDomainGridlineStroke(stroke24);
        java.awt.Stroke stroke28 = categoryPlot16.getRangeCrosshairStroke();
        categoryPlot4.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint33 = categoryAxis32.getAxisLinePaint();
        java.awt.Font font34 = categoryAxis32.getTickLabelFont();
        categoryPlot4.setDomainAxis((int) (byte) 100, categoryAxis32);
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 0);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryAxis32.setTickMarkStroke(stroke38);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setLabel("");
        float float8 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setFixedDimension(0.0d);
        double double4 = dateAxis0.getFixedAutoRange();
        java.util.Date date5 = null;
        java.util.Date date6 = null;
        try {
            dateAxis0.setRange(date5, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-256) + "'", int2 == (-256));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32513) + "'", int1 == (-32513));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomRangeAxes((double) 7, plotRenderingInfo11, point2D12, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation((int) (short) 1, axisLocation14);
        categoryPlot11.configureRangeAxes();
        categoryPlot11.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge();
        try {
            double double20 = categoryAxis1.getCategoryStart(9, (-256), rectangle2D6, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        try {
            dateAxis0.setRangeWithMargins((double) 2, (-3.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (-3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int3 = java.awt.Color.HSBtoRGB(10.0f, (float) 10, 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-246) + "'", int3 == (-246));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation((int) (short) 1, axisLocation8);
        boolean boolean10 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double16 = categoryAxis15.getUpperMargin();
        categoryPlot5.setDomainAxis((int) ' ', categoryAxis15, false);
        categoryAxis15.setUpperMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis15, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            boolean boolean26 = categoryPlot23.removeAnnotation(categoryAnnotation24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateRightOutset((double) 10L);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        categoryMarker1.setKey((java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint16, stroke17, (java.awt.Paint) color18, stroke19, 0.0f);
        categoryPlot11.setDomainGridlineStroke(stroke19);
        categoryPlot11.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot11.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot11.getDrawingSupplier();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        int int33 = categoryPlot32.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot32.setRangeAxisLocation((int) (short) 1, axisLocation35);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.clearRangeMarkers(0);
        categoryPlot32.mapDatasetToDomainAxis((int) '#', (int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot32.getRangeAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace46 = dateAxis0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D27, rectangleEdge44, axisSpace45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        try {
            dateAxis0.zoomRange((double) '4', (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean3 = dateAxis1.equals((java.lang.Object) rectangleAnchor2);
        boolean boolean4 = rectangleAnchor0.equals((java.lang.Object) rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        categoryPlot4.mapDatasetToRangeAxis(10, 0);
        float float18 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        int int13 = categoryPlot4.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot4.getRangeAxisForDataset((int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) '#', 10.0d, plotRenderingInfo18, point2D19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot4.getRangeAxis(0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        float float13 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot14 = categoryPlot4.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(5, categoryDataset16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot4.getRenderer(100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        dateAxis0.configure();
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        boolean boolean9 = categoryMarker6.equals((java.lang.Object) textAnchor7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str8.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        double double5 = dateAxis0.getLowerMargin();
        dateAxis0.setLabelURL("hi!");
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot4.getRenderer();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean2 = dateAxis0.equals((java.lang.Object) rectangleAnchor1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean4 = rectangleAnchor1.equals((java.lang.Object) rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryPlot4.markerChanged(markerChangeEvent13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("CONTRACT", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double2 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis21.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis21.setTickUnit(dateTickUnit26);
        dateAxis21.setInverted(true);
        dateAxis21.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis21.setRightArrow(shape33);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot4.getDataset((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(categoryDataset37);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        java.awt.geom.Point2D point2D19 = null;
        try {
            xYPlot11.setQuadrantOrigin(point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryPlot4.markerChanged(markerChangeEvent13);
        boolean boolean15 = categoryPlot4.isRangeCrosshairVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        boolean boolean20 = categoryPlot4.render(graphics2D16, rectangle2D17, (int) (short) 1, plotRenderingInfo19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot4.notifyListeners(plotChangeEvent21);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        java.awt.Paint paint20 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot4.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint23 = categoryPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.BOTTOM_CENTER", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryMarker6.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot4.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint26 = categoryAxis25.getAxisLinePaint();
        java.awt.Font font27 = categoryAxis25.getLabelFont();
        double double28 = categoryAxis25.getFixedDimension();
        java.awt.Paint paint29 = categoryAxis25.getTickMarkPaint();
        categoryAxis25.setLabel("");
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis25.setLabelPaint((java.awt.Paint) color32);
        try {
            xYPlot11.setQuadrantPaint((int) (short) 10, (java.awt.Paint) color32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint21, stroke22, (java.awt.Paint) color23, stroke24, 0.0f);
        categoryPlot16.setDomainGridlineStroke(stroke24);
        java.awt.Stroke stroke28 = categoryPlot16.getRangeCrosshairStroke();
        categoryPlot4.setRangeGridlineStroke(stroke28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        double double34 = rectangleInsets32.calculateRightOutset((double) 10L);
        categoryMarker31.setLabelOffset(rectangleInsets32);
        double double36 = rectangleInsets32.getTop();
        categoryPlot4.setInsets(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean5 = categoryAxis1.isTickLabelsVisible();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        categoryAxis1.setTickLabelPaint(paint7);
        boolean boolean14 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint11, stroke12, (java.awt.Paint) color13, stroke14, 0.0f);
        categoryPlot6.setDomainGridlineStroke(stroke14);
        java.awt.Stroke stroke18 = categoryPlot6.getRangeCrosshairStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint23 = categoryAxis22.getAxisLinePaint();
        java.awt.Font font24 = categoryAxis22.getTickLabelFont();
        java.awt.Paint paint25 = categoryAxis22.getTickLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        int int31 = categoryPlot30.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.Range range33 = categoryPlot30.getDataRange(valueAxis32);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint35, stroke36, (java.awt.Paint) color37, stroke38, 0.0f);
        categoryPlot30.setDomainGridlineStroke(stroke38);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 'a', paint25, stroke38);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1), (java.awt.Paint) color1, stroke18, (java.awt.Paint) color19, stroke38, (float) (-256));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation((int) (short) 1, axisLocation14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot11.getOrientation();
        boolean boolean17 = categoryPlot11.isSubplot();
        boolean boolean18 = categoryMarker6.equals((java.lang.Object) boolean17);
        categoryMarker6.setAlpha((float) 1L);
        java.lang.String str21 = categoryMarker6.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double2 = categoryAxis1.getUpperMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 5);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        int int11 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        categoryPlot10.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint16 = categoryPlot10.getOutlinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot10.axisChanged(axisChangeEvent17);
        java.lang.String str19 = categoryPlot10.getNoDataMessage();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        int int26 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot25.setRangeAxisLocation((int) (short) 1, axisLocation28);
        categoryPlot25.configureRangeAxes();
        categoryPlot25.clearRangeMarkers(0);
        categoryPlot25.mapDatasetToDomainAxis((int) '#', (int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot25.getRangeAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace39 = categoryAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot10, rectangle2D20, rectangleEdge37, axisSpace38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        int int30 = categoryPlot29.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 1, axisLocation32);
        categoryPlot29.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot29.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot29.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation38 = axisLocation37.getOpposite();
        try {
            xYPlot11.setRangeAxisLocation((int) (short) -1, axisLocation38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot11.setRenderer((int) (byte) 0, xYItemRenderer14, true);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot11.indexOf(xYDataset17);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-32513));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleAnchor0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.CENTER" + "'", str4.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            xYPlot11.draw(graphics2D15, rectangle2D16, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot11.setAxisOffset(rectangleInsets21);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            boolean boolean27 = xYPlot11.removeRangeMarker((int) (short) -1, marker24, layer25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(layer25);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(500, 2, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot4.getDataset((-256));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint18 = categoryAxis14.getLabelPaint();
        categoryAxis14.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Font font25 = categoryAxis23.getTickLabelFont();
        java.awt.Paint paint26 = categoryAxis23.getTickLabelPaint();
        java.lang.String str27 = categoryAxis23.getLabelToolTip();
        java.awt.Font font28 = categoryAxis23.getTickLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 11, font28);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str16 = categoryMarker15.getLabel();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot4, dataset18);
        java.lang.String str20 = datasetChangeEvent19.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        boolean boolean29 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        try {
            xYPlot11.zoomRangeAxes((double) '4', plotRenderingInfo31, point2D32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        float float4 = intervalMarker2.getAlpha();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLowerBound();
        double double2 = dateAxis0.getFixedAutoRange();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation((int) (short) 1, axisLocation14);
        categoryPlot11.configureRangeAxes();
        categoryPlot11.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = dateAxis0.draw(graphics2D3, (double) (byte) 10, rectangle2D5, rectangle2D6, rectangleEdge19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double2 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint10 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot4.axisChanged(axisChangeEvent11);
        categoryPlot4.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range39 = dateAxis35.getDefaultAutoRange();
        double double40 = dateAxis35.getLowerMargin();
        boolean boolean41 = seriesRenderingOrder34.equals((java.lang.Object) dateAxis35);
        int int42 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        java.awt.geom.Point2D point2D43 = null;
        try {
            xYPlot11.setQuadrantOrigin(point2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot12.setRangeAxisLocation((int) (short) 1, axisLocation15);
        categoryPlot12.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot12.getRangeAxisEdge((int) (byte) 0);
        try {
            double double20 = dateAxis0.lengthToJava2D((double) (byte) 0, rectangle2D7, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth((double) (-1.0f));
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0d) + "'", double2 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot11.getRangeAxis(0);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(valueAxis32);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.addChangeListener(plotChangeListener8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation17);
        categoryPlot14.configureRangeAxes();
        categoryPlot14.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot14.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder22);
        float float24 = categoryPlot4.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        java.awt.Stroke stroke14 = xYPlot11.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint25, stroke26, (java.awt.Paint) color27, stroke28, 0.0f);
        categoryPlot20.setDomainGridlineStroke(stroke28);
        categoryPlot20.clearRangeMarkers(9);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = categoryPlot20.getRangeMarkers(layer34);
        try {
            boolean boolean36 = xYPlot11.removeRangeMarker(marker15, layer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot11.getFixedLegendItems();
        boolean boolean28 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        try {
            xYPlot11.zoomRangeAxes((double) '#', (double) (-32513), plotRenderingInfo31, point2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (-32513.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        boolean boolean18 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot4.getDataset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryDataset19);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { 0L, 1, 10, (short) 1, 2.0f, 11 };
        try {
            float[] floatArray9 = color0.getComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        try {
            dateAxis3.setLowerMargin((double) (-32513));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32513.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        int int11 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint15, stroke16, (java.awt.Paint) color17, stroke18, 0.0f);
        categoryPlot10.setDomainGridlineStroke(stroke18);
        java.awt.Stroke stroke22 = categoryPlot10.getRangeCrosshairStroke();
        categoryPlot10.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        int int30 = categoryPlot29.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 1, axisLocation32);
        categoryPlot29.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot29.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot29.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation38 = axisLocation37.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation37.getOpposite();
        categoryPlot10.setDomainAxisLocation(axisLocation39, false);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        int int47 = categoryPlot46.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot46.setRangeAxisLocation((int) (short) 1, axisLocation49);
        categoryPlot46.configureRangeAxes();
        categoryPlot46.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = categoryPlot46.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation39, plotOrientation54);
        try {
            double double56 = categoryAxis1.getCategoryEnd((int) 'a', 8, rectangle2D5, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(plotOrientation54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        categoryPlot4.mapDatasetToDomainAxis((int) '#', (int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge((int) '#');
        categoryPlot4.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace15, false);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            xYPlot11.drawOutline(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot4.setRenderer(categoryItemRenderer14);
        java.lang.String str16 = categoryPlot4.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.trimWidth((double) (-1.0f));
        double double21 = rectangleInsets17.trimHeight((double) (-1.0f));
        categoryPlot4.setInsets(rectangleInsets17, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0d) + "'", double19 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.0d) + "'", double21 == (-3.0d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setLabel("");
        java.awt.Font font8 = null;
        try {
            categoryAxis1.setLabelFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearDomainMarkers(10);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        categoryPlot8.setRangeCrosshairValue((double) '4');
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) categoryPlot8);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        categoryPlot20.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot20.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = categoryPlot20.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker32, layer33);
        java.util.Collection collection35 = categoryPlot8.getRangeMarkers(0, layer33);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        categoryPlot4.mapDatasetToRangeAxis(10, 0);
        float float18 = categoryPlot4.getForegroundAlpha();
        categoryPlot4.setNoDataMessage("CONTRACT");
        categoryPlot4.setAnchorValue((double) '4');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation((int) (short) 1, axisLocation14);
        categoryPlot11.configureRangeAxes();
        categoryPlot11.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = numberAxis0.draw(graphics2D3, (double) '#', rectangle2D5, rectangle2D6, rectangleEdge19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker36.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        int int44 = categoryPlot43.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        categoryPlot43.setRangeAxisLocation((int) (short) 1, axisLocation46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot43.setRenderer(5, categoryItemRenderer49);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = null;
        categoryPlot43.notifyListeners(plotChangeEvent51);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = categoryPlot43.getDomainMarkers(layer53);
        boolean boolean56 = xYPlot11.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker36, layer53, true);
        org.jfree.chart.plot.Marker marker57 = null;
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        int int63 = categoryPlot62.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation65 = null;
        categoryPlot62.setRangeAxisLocation((int) (short) 1, axisLocation65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        categoryPlot62.setRenderer(5, categoryItemRenderer68);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent70 = null;
        categoryPlot62.notifyListeners(plotChangeEvent70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection73 = categoryPlot62.getDomainMarkers(layer72);
        try {
            xYPlot11.addRangeMarker(marker57, layer72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNull(collection73);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        dateAxis0.resizeRange((double) 0L);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.setTickMarkInsideLength((float) 3);
        categoryAxis7.setCategoryMargin((double) 1.0f);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = dateAxis7.equals((java.lang.Object) rectangleAnchor8);
        int int10 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis16.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis18.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis18.setTickUnit(dateTickUnit23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer25);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker28.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint32, stroke33, (java.awt.Paint) color34, stroke35, 0.0f);
        categoryMarker28.setOutlineStroke(stroke33);
        boolean boolean39 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker28);
        xYPlot26.clearDomainAxes();
        boolean boolean41 = xYPlot26.isDomainCrosshairLockedOnData();
        java.awt.Color color42 = java.awt.Color.gray;
        xYPlot26.setDomainGridlinePaint((java.awt.Paint) color42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot26.setRangeGridlineStroke(stroke44);
        org.jfree.data.xy.XYDataset xYDataset46 = xYPlot26.getDataset();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        xYPlot26.drawAnnotations(graphics2D47, rectangle2D48, plotRenderingInfo49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = xYPlot26.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            org.jfree.chart.axis.AxisState axisState54 = dateAxis7.draw(graphics2D11, 34.0d, rectangle2D13, rectangle2D14, rectangleEdge52, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        dateAxis0.configure();
        java.awt.Shape shape5 = dateAxis0.getRightArrow();
        java.awt.Shape shape6 = dateAxis0.getUpArrow();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        int int14 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot13.setRangeAxisLocation((int) (short) 1, axisLocation16);
        categoryPlot13.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot13.getRangeAxisEdge((int) (byte) 0);
        try {
            double double21 = dateAxis0.valueToJava2D((double) (byte) 1, rectangle2D8, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        categoryMarker6.setLabelTextAnchor(textAnchor8);
        categoryMarker6.setLabel("");
        java.lang.Object obj12 = categoryMarker6.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation25 = null;
        try {
            xYPlot11.addAnnotation(xYAnnotation25, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        java.awt.Paint paint19 = xYPlot11.getRangeZeroBaselinePaint();
        int int20 = xYPlot11.getRangeAxisCount();
        boolean boolean21 = xYPlot11.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = categoryPlot17.getDataRange(valueAxis19);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint22, stroke23, (java.awt.Paint) color24, stroke25, 0.0f);
        categoryPlot17.setDomainGridlineStroke(stroke25);
        java.awt.Stroke stroke29 = categoryPlot17.getRangeCrosshairStroke();
        categoryPlot17.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        int int37 = categoryPlot36.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        categoryPlot36.setRangeAxisLocation((int) (short) 1, axisLocation39);
        categoryPlot36.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot36.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot36.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation45 = axisLocation44.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation46 = axisLocation44.getOpposite();
        categoryPlot17.setDomainAxisLocation(axisLocation46, false);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, categoryItemRenderer52);
        int int54 = categoryPlot53.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation56 = null;
        categoryPlot53.setRangeAxisLocation((int) (short) 1, axisLocation56);
        categoryPlot53.configureRangeAxes();
        categoryPlot53.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = categoryPlot53.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation46, plotOrientation61);
        try {
            java.util.List list63 = numberAxis0.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setFixedDimension(0.0d);
        java.lang.String str4 = dateAxis0.getLabel();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Font font25 = categoryAxis23.getLabelFont();
        categoryPlot4.setDomainAxis(categoryAxis23);
        double double27 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryPlot4.markerChanged(markerChangeEvent13);
        boolean boolean15 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        dateAxis0.setAutoRange(true);
        java.util.Date date5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis10.getTickUnit();
        dateAxis10.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis10.setTickUnit(dateTickUnit15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer17);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint20, stroke21, (java.awt.Paint) color22, stroke23, 0.0f);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker25.setPaint(paint26);
        xYPlot18.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot18.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot35.setRangeAxisLocation((int) (short) 1, axisLocation38);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = categoryPlot35.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation40);
        try {
            double double42 = dateAxis0.dateToJava2D(date5, rectangle2D6, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint21, stroke22, (java.awt.Paint) color23, stroke24, 0.0f);
        categoryPlot16.setDomainGridlineStroke(stroke24);
        java.awt.Stroke stroke28 = categoryPlot16.getRangeCrosshairStroke();
        categoryPlot16.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot35.setRangeAxisLocation((int) (short) 1, axisLocation38);
        categoryPlot35.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot35.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation44 = axisLocation43.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation45 = axisLocation43.getOpposite();
        categoryPlot16.setDomainAxisLocation(axisLocation45, false);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        int int53 = categoryPlot52.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation55 = null;
        categoryPlot52.setRangeAxisLocation((int) (short) 1, axisLocation55);
        categoryPlot52.configureRangeAxes();
        categoryPlot52.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = categoryPlot52.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation45, plotOrientation60);
        try {
            categoryPlot4.setDomainAxisLocation((-246), axisLocation45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        categoryPlot8.setRangeCrosshairValue((double) '4');
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) categoryPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot8.getDomainAxisLocation((int) (short) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getColorComponents(floatArray2);
        float[] floatArray4 = color0.getRGBColorComponents(floatArray2);
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color0.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(paintContext10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryMarker5.setOutlineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        java.lang.Object obj17 = null;
        boolean boolean18 = categoryAxis1.equals(obj17);
        boolean boolean20 = categoryAxis1.equals((java.lang.Object) (-65281));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.END");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = dateAxis7.equals((java.lang.Object) rectangleAnchor8);
        int int10 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean12 = categoryPlot4.removeAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        double double20 = categoryAxis16.getLowerMargin();
        double double21 = categoryAxis16.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent4.getChart();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent4.getChart();
        boolean boolean7 = dateAxis0.equals((java.lang.Object) jFreeChart6);
        java.awt.Shape shape8 = dateAxis0.getRightArrow();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertNull(jFreeChart6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        int int16 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot15.setRangeAxisLocation((int) (short) 1, axisLocation18);
        categoryPlot15.configureRangeAxes();
        categoryPlot15.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = categoryAxis1.draw(graphics2D7, (double) 8, rectangle2D9, rectangle2D10, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryMarker5.setOutlineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        int int26 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot25.getDataRange(valueAxis27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = null;
        categoryPlot25.setDrawingSupplier(drawingSupplier29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot25.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            org.jfree.chart.axis.AxisState axisState33 = categoryAxis1.draw(graphics2D17, 97.0d, rectangle2D19, rectangle2D20, rectangleEdge31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setAutoRangeMinimumSize((double) 1, true);
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = intervalMarker29.getGradientPaintTransformer();
        java.lang.Object obj31 = intervalMarker29.clone();
        xYPlot11.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker29);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range39 = dateAxis35.getDefaultAutoRange();
        double double40 = dateAxis35.getLowerMargin();
        boolean boolean41 = seriesRenderingOrder34.equals((java.lang.Object) dateAxis35);
        int int42 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        xYPlot11.setRangeCrosshairValue((double) 0L, false);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace46);
        org.jfree.data.xy.XYDataset xYDataset49 = xYPlot11.getDataset((-32513));
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNull(xYDataset49);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Shape shape7 = dateAxis0.getLeftArrow();
        java.text.DateFormat dateFormat8 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(dateFormat8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker1, jFreeChart4, chartChangeEventType5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent6.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent6.getType();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) sortOrder9);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint6 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot4.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D9);
        java.awt.Image image11 = null;
        categoryPlot4.setBackgroundImage(image11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        dateAxis0.resizeRange((double) 3, 0.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot14.getDataRange(valueAxis16);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint19, stroke20, (java.awt.Paint) color21, stroke22, 0.0f);
        categoryPlot14.setDomainGridlineStroke(stroke22);
        java.awt.Stroke stroke26 = categoryPlot14.getRangeCrosshairStroke();
        categoryPlot14.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        int int34 = categoryPlot33.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        categoryPlot33.setRangeAxisLocation((int) (short) 1, axisLocation36);
        categoryPlot33.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot33.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot33.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation42 = axisLocation41.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation43 = axisLocation41.getOpposite();
        categoryPlot14.setDomainAxisLocation(axisLocation43, false);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, categoryItemRenderer49);
        int int51 = categoryPlot50.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation53 = null;
        categoryPlot50.setRangeAxisLocation((int) (short) 1, axisLocation53);
        categoryPlot50.configureRangeAxes();
        categoryPlot50.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = categoryPlot50.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation43, plotOrientation58);
        try {
            double double60 = dateAxis0.lengthToJava2D((double) 9, rectangle2D9, rectangleEdge59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = categoryAxis1.draw(graphics2D4, (double) 9, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = xYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        xYPlot11.setRenderer(xYItemRenderer32);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int3 = java.awt.Color.HSBtoRGB((float) '4', (float) 1, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-655360) + "'", int3 == (-655360));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setTickMarksVisible(true);
        boolean boolean7 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis4.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        dateAxis4.setTickUnit(dateTickUnit9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker14.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint18, stroke19, (java.awt.Paint) color20, stroke21, 0.0f);
        categoryMarker14.setOutlineStroke(stroke19);
        boolean boolean25 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker14);
        xYPlot12.clearDomainAxes();
        boolean boolean27 = xYPlot12.isDomainCrosshairLockedOnData();
        java.awt.Color color28 = java.awt.Color.gray;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot12.setRangeGridlineStroke(stroke30);
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot12.getDataset();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot12.setRangeCrosshairPaint((java.awt.Paint) color33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range40 = dateAxis36.getDefaultAutoRange();
        double double41 = dateAxis36.getLowerMargin();
        boolean boolean42 = seriesRenderingOrder35.equals((java.lang.Object) dateAxis36);
        int int43 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis36);
        boolean boolean44 = textAnchor0.equals((java.lang.Object) int43);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        categoryPlot4.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLowerBound();
        boolean boolean2 = dateAxis0.isInverted();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setInverted(true);
        dateAxis0.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis0.setRightArrow(shape12);
        boolean boolean15 = dateAxis0.isHiddenValue((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot11.setRenderer((int) (short) 1, xYItemRenderer22, true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setInverted(true);
        dateAxis0.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis0.setRightArrow(shape12);
        java.lang.Object obj14 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.addChangeListener(plotChangeListener8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation17);
        categoryPlot14.configureRangeAxes();
        categoryPlot14.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot14.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder22);
        categoryPlot4.clearRangeMarkers((-246));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(sortOrder22);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setLabelToolTip("CONTRACT");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis0.getTickLabelInsets();
        dateAxis0.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        java.lang.String str7 = dateAxis0.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range12 = dateAxis8.getDefaultAutoRange();
        dateAxis0.setRange(range12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis20.getTickUnit();
        dateAxis20.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis24.getTickUnit();
        dateAxis20.setTickUnit(dateTickUnit25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer27);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker30.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint34, stroke35, (java.awt.Paint) color36, stroke37, 0.0f);
        categoryMarker30.setOutlineStroke(stroke35);
        boolean boolean41 = xYPlot28.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        xYPlot28.clearDomainAxes();
        boolean boolean43 = xYPlot28.isDomainCrosshairLockedOnData();
        java.awt.Color color44 = java.awt.Color.gray;
        xYPlot28.setDomainGridlinePaint((java.awt.Paint) color44);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot28.setRangeGridlineStroke(stroke46);
        org.jfree.data.xy.XYDataset xYDataset48 = xYPlot28.getDataset();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        xYPlot28.drawAnnotations(graphics2D49, rectangle2D50, plotRenderingInfo51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot28.getRangeAxisEdge(0);
        try {
            java.util.List list55 = dateAxis0.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(xYDataset48);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isSubplot();
        categoryPlot4.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        java.awt.Stroke stroke19 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Stroke stroke20 = xYPlot11.getRangeGridlineStroke();
        java.awt.Stroke stroke21 = xYPlot11.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace32, false);
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot11.getFixedDomainAxisSpace();
        xYPlot11.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int3 = java.awt.Color.HSBtoRGB((float) 3, (float) 255, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        java.awt.Paint paint25 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.zoomRange((double) 10, (double) '#');
        java.awt.Shape shape32 = dateAxis28.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getLowerBound();
        java.awt.Shape shape35 = dateAxis33.getLeftArrow();
        dateAxis28.setDownArrow(shape35);
        try {
            xYPlot11.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis) dateAxis28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis26.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit31);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        dateAxis26.setAutoRangeMinimumSize((double) 11, true);
        java.awt.Shape shape37 = null;
        try {
            dateAxis26.setUpArrow(shape37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker6);
        org.jfree.chart.plot.Marker marker8 = markerChangeEvent7.getMarker();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(marker8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot18.setRangeAxisLocation((int) (short) 1, axisLocation21);
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot18.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = numberAxis0.draw(graphics2D10, (double) 100.0f, rectangle2D12, rectangle2D13, rectangleEdge25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation17 = null;
        try {
            xYPlot11.addAnnotation(xYAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis26.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit31);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.data.time.DateRange dateRange34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setRangeWithMargins((org.jfree.data.Range) dateRange34, true, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateRange34);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateRightOutset((double) 10L);
        categoryMarker8.setLabelOffset(rectangleInsets9);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot4.addDomainMarker((int) (short) -1, categoryMarker8, layer13, false);
        boolean boolean16 = categoryMarker8.getDrawAsLine();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis2.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker6.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint10, stroke11, (java.awt.Paint) color12, stroke13, 0.0f);
        categoryMarker6.setOutlineStroke(stroke11);
        categoryAxis2.setTickMarkStroke(stroke11);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot20.getRangeAxisLocation(10);
        boolean boolean23 = categoryPlot20.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = categoryPlot5.getDataRange(valueAxis7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot5.addChangeListener(plotChangeListener9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        int int16 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot15.setRangeAxisLocation((int) (short) 1, axisLocation18);
        categoryPlot15.configureRangeAxes();
        categoryPlot15.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot15.getRowRenderingOrder();
        categoryPlot5.setColumnRenderingOrder(sortOrder23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint27 = categoryAxis26.getAxisLinePaint();
        java.awt.Font font28 = categoryAxis26.getTickLabelFont();
        java.awt.Paint paint29 = categoryAxis26.getTickLabelPaint();
        java.lang.String str30 = categoryAxis26.getLabelToolTip();
        boolean boolean31 = sortOrder23.equals((java.lang.Object) categoryAxis26);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        java.awt.Color color33 = color32.darker();
        categoryAxis26.setTickLabelPaint((java.awt.Paint) color33);
        java.awt.Color color35 = java.awt.Color.getColor("", color33);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        boolean boolean6 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint7 = categoryPlot4.getOutlinePaint();
        java.util.List list8 = categoryPlot4.getCategories();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot4.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLowerBound();
        java.awt.Shape shape3 = dateAxis1.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font5 = dateAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        java.text.DateFormat dateFormat7 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(dateFormat7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        java.util.Date date5 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setCategoryMargin((double) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        boolean boolean7 = dateAxis0.isNegativeArrowVisible();
        java.lang.String str8 = dateAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        double double6 = dateAxis1.getLowerMargin();
        boolean boolean7 = seriesRenderingOrder0.equals((java.lang.Object) dateAxis1);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.zoomRange((double) 10, (double) '#');
        java.awt.Shape shape12 = dateAxis8.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis13.getTickUnit();
        dateAxis13.resizeRange((double) (-1.0f));
        dateAxis13.configure();
        java.awt.Shape shape18 = dateAxis13.getRightArrow();
        java.awt.Shape shape19 = dateAxis13.getUpArrow();
        dateAxis8.setRightArrow(shape19);
        dateAxis1.setDownArrow(shape19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder15);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint18, stroke19, (java.awt.Paint) color20, stroke21, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker23);
        java.awt.Color color25 = java.awt.Color.WHITE;
        categoryMarker23.setLabelPaint((java.awt.Paint) color25);
        categoryMarker23.setKey((java.lang.Comparable) "");
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis32.getTickUnit();
        dateAxis32.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        dateAxis32.setTickUnit(dateTickUnit37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer39);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint42, stroke43, (java.awt.Paint) color44, stroke45, 0.0f);
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker47.setPaint(paint48);
        xYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker47);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot40.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis53 = xYPlot40.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis54.getTickUnit();
        dateAxis54.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource58 = null;
        dateAxis54.setStandardTickUnits(tickUnitSource58);
        dateAxis54.setAutoRangeMinimumSize((double) 100);
        xYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker65.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, categoryAxis69, valueAxis70, categoryItemRenderer71);
        int int73 = categoryPlot72.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation75 = null;
        categoryPlot72.setRangeAxisLocation((int) (short) 1, axisLocation75);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        categoryPlot72.setRenderer(5, categoryItemRenderer78);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent80 = null;
        categoryPlot72.notifyListeners(plotChangeEvent80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection83 = categoryPlot72.getDomainMarkers(layer82);
        boolean boolean85 = xYPlot40.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker65, layer82, true);
        boolean boolean86 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer82);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(valueAxis53);
        org.junit.Assert.assertNotNull(dateTickUnit55);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNull(collection83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset13);
        java.lang.Object obj15 = datasetChangeEvent14.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot4.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot4.setRangeAxis((int) (short) 1, valueAxis19, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + false + "'", obj15.equals(false));
        org.junit.Assert.assertNull(categoryDataset17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getAlpha();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = dateAxis7.equals((java.lang.Object) rectangleAnchor8);
        int int10 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setRange((org.jfree.data.Range) dateRange11);
        dateAxis7.setLabelToolTip("CONTRACT");
        java.text.DateFormat dateFormat15 = null;
        dateAxis7.setDateFormatOverride(dateFormat15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateRange11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint18 = categoryAxis14.getLabelPaint();
        categoryAxis14.setAxisLineVisible(true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis27.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis31.getTickUnit();
        dateAxis27.setTickUnit(dateTickUnit32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer34);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker37.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint41, stroke42, (java.awt.Paint) color43, stroke44, 0.0f);
        categoryMarker37.setOutlineStroke(stroke42);
        boolean boolean48 = xYPlot35.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker37);
        xYPlot35.clearDomainAxes();
        boolean boolean50 = xYPlot35.isDomainCrosshairLockedOnData();
        java.awt.Color color51 = java.awt.Color.gray;
        xYPlot35.setDomainGridlinePaint((java.awt.Paint) color51);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot35.setRangeGridlineStroke(stroke53);
        org.jfree.data.xy.XYDataset xYDataset55 = xYPlot35.getDataset();
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        xYPlot35.drawAnnotations(graphics2D56, rectangle2D57, plotRenderingInfo58);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot35.getRangeAxisEdge(0);
        try {
            java.util.List list62 = categoryAxis14.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(xYDataset55);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        java.lang.Object obj4 = categoryMarker1.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        java.awt.Stroke stroke37 = categoryPlot35.getOutlineStroke();
        xYPlot11.setRangeCrosshairStroke(stroke37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot11.setDataset(xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        xYPlot11.setRangeAxis(valueAxis41);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str16 = categoryMarker15.getLabel();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot4, dataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot4.getDataset((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(categoryDataset21);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        java.lang.Object obj6 = dateAxis0.clone();
        org.jfree.data.Range range7 = null;
        try {
            dateAxis0.setRangeWithMargins(range7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        double double5 = dateAxis0.getLowerMargin();
        try {
            dateAxis0.setRangeWithMargins((double) 100.0f, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (97.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setLabelToolTip("CONTRACT");
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis0.getTickUnit();
        java.awt.Shape shape10 = dateAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setLabelToolTip("CONTRACT");
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis0.getTickUnit();
        try {
            dateAxis0.setRange((double) (short) 100, (double) (-32513));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint18 = categoryAxis17.getAxisLinePaint();
        java.awt.Font font19 = categoryAxis17.getLabelFont();
        double double20 = categoryAxis17.getFixedDimension();
        java.awt.Paint paint21 = categoryAxis17.getTickMarkPaint();
        categoryMarker13.setOutlinePaint(paint21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        int int28 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        categoryPlot27.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot27.setRenderer(categoryItemRenderer33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean41 = categoryPlot27.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker39, layer40);
        boolean boolean43 = categoryPlot4.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker13, layer40, true);
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(sortOrder44);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation((int) (short) 1, axisLocation8);
        boolean boolean10 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double16 = categoryAxis15.getUpperMargin();
        categoryPlot5.setDomainAxis((int) ' ', categoryAxis15, false);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint21, stroke22, (java.awt.Paint) color23, stroke24, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker26);
        java.awt.Color color28 = java.awt.Color.WHITE;
        categoryMarker26.setLabelPaint((java.awt.Paint) color28);
        categoryMarker26.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean33 = categoryPlot5.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker26, layer32);
        boolean boolean34 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot4.axisChanged(axisChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font16 = dateAxis15.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = dateAxis15.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.zoomRange((double) 10, (double) '#');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint5, stroke6, (java.awt.Paint) color7, stroke8, 0.0f);
        categoryMarker1.setOutlineStroke(stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Paint paint25 = categoryAxis23.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker27.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint31, stroke32, (java.awt.Paint) color33, stroke34, 0.0f);
        categoryMarker27.setOutlineStroke(stroke32);
        categoryAxis23.setTickMarkStroke(stroke32);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer40);
        boolean boolean42 = xYPlot11.equals((java.lang.Object) categoryPlot41);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        try {
            categoryPlot41.setDataset((-1), categoryDataset44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot4.getRendererForDataset(categoryDataset5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        int int13 = categoryPlot4.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot4.getRangeAxisForDataset((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis19.getTickUnit();
        dateAxis19.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis19.setTickUnit(dateTickUnit24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer26);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint29, stroke30, (java.awt.Paint) color31, stroke32, 0.0f);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker34.setPaint(paint35);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot27.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        int int45 = categoryPlot44.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        categoryPlot44.setRangeAxisLocation((int) (short) 1, axisLocation47);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot44.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation39, plotOrientation49);
        categoryPlot4.setDomainAxisLocation(axisLocation39, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        dateAxis53.zoomRange((double) 10, (double) '#');
        java.awt.Shape shape57 = dateAxis53.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        double double59 = dateAxis58.getLowerBound();
        java.awt.Shape shape60 = dateAxis58.getLeftArrow();
        dateAxis53.setDownArrow(shape60);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis53);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit64 = dateAxis63.getTickUnit();
        dateAxis63.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit68 = dateAxis67.getTickUnit();
        dateAxis63.setTickUnit(dateTickUnit68);
        dateAxis63.setLabelToolTip("CONTRACT");
        org.jfree.chart.axis.DateTickUnit dateTickUnit72 = dateAxis63.getTickUnit();
        java.util.Date date73 = dateAxis53.calculateHighestVisibleTickValue(dateTickUnit72);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(dateTickUnit64);
        org.junit.Assert.assertNotNull(dateTickUnit68);
        org.junit.Assert.assertNotNull(dateTickUnit72);
        org.junit.Assert.assertNotNull(date73);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range11 = dateAxis7.getDefaultAutoRange();
        dateAxis0.setRange(range11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis16.getTickUnit();
        dateAxis16.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis20.getTickUnit();
        dateAxis16.setTickUnit(dateTickUnit21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer23);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker26.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint30, stroke31, (java.awt.Paint) color32, stroke33, 0.0f);
        categoryMarker26.setOutlineStroke(stroke31);
        boolean boolean37 = xYPlot24.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker26);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font39 = dateAxis38.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition40 = dateAxis38.getTickMarkPosition();
        xYPlot24.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis38);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot24);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(dateTickMarkPosition40);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation((int) (short) 1, axisLocation19);
        categoryPlot16.configureRangeAxes();
        categoryPlot16.clearRangeMarkers(0);
        categoryPlot16.mapDatasetToDomainAxis((int) '#', (int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot16.getRangeAxisEdge((int) '#');
        try {
            double double29 = numberAxis0.java2DToValue((double) ' ', rectangle2D11, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        java.awt.Paint paint3 = dateAxis0.getTickLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener8 = null;
        categoryMarker5.removeChangeListener(markerChangeListener8);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint11, stroke12, (java.awt.Paint) color13, stroke14, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker16);
        categoryMarker5.notifyListeners(markerChangeEvent17);
        java.awt.Font font19 = categoryMarker5.getLabelFont();
        dateAxis0.setLabelFont(font19);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation17);
        boolean boolean19 = categoryPlot14.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot14.setDomainGridlinePosition(categoryAnchor20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot14.setRenderer(5, categoryItemRenderer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint27 = categoryAxis26.getAxisLinePaint();
        java.awt.Font font28 = categoryAxis26.getLabelFont();
        int int29 = categoryPlot14.getDomainAxisIndex(categoryAxis26);
        java.awt.Paint paint30 = categoryPlot14.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot14.getRangeAxisEdge((int) (short) 1);
        try {
            double double33 = categoryAxis1.getCategoryEnd(500, (int) (byte) 0, rectangle2D9, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            xYPlot11.handleClick(0, (-256), plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint5, stroke6, (java.awt.Paint) color7, stroke8, 0.0f);
        categoryMarker1.setOutlineStroke(stroke6);
        java.awt.Color color12 = java.awt.Color.yellow;
        int int13 = color12.getRed();
        categoryMarker1.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double26 = rectangleInsets24.calculateRightOutset((double) 10L);
        categoryMarker23.setLabelOffset(rectangleInsets24);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot19.addDomainMarker((int) (short) -1, categoryMarker23, layer28, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot19.zoomDomainAxes((double) 3, plotRenderingInfo32, point2D33);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot19);
        int int36 = categoryPlot19.getWeight();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot4.setDomainAxisLocation(11, axisLocation14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomDomainAxes(10.0d, 0.0d, plotRenderingInfo19, point2D20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            categoryPlot4.drawOutline(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(sortOrder9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset((double) 10L);
        double double3 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets0.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.setTickMarkInsideLength((float) 3);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint26 = categoryAxis25.getAxisLinePaint();
        java.awt.Font font27 = categoryAxis25.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        int int33 = categoryPlot32.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.Range range35 = categoryPlot32.getDataRange(valueAxis34);
        categoryPlot32.setRangeCrosshairValue((double) '4');
        boolean boolean38 = categoryAxis25.equals((java.lang.Object) categoryPlot32);
        java.awt.Image image39 = null;
        categoryPlot32.setBackgroundImage(image39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = dateAxis43.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis45.getTickUnit();
        dateAxis45.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = dateAxis49.getTickUnit();
        dateAxis45.setTickUnit(dateTickUnit50);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer52);
        java.awt.Paint paint55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint55, stroke56, (java.awt.Paint) color57, stroke58, 0.0f);
        java.awt.Paint paint61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker60.setPaint(paint61);
        xYPlot53.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.chart.axis.AxisLocation axisLocation65 = xYPlot53.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, valueAxis68, categoryItemRenderer69);
        int int71 = categoryPlot70.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation73 = null;
        categoryPlot70.setRangeAxisLocation((int) (short) 1, axisLocation73);
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = categoryPlot70.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation65, plotOrientation75);
        org.jfree.chart.axis.AxisSpace axisSpace77 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace78 = categoryAxis7.reserveSpace(graphics2D23, (org.jfree.chart.plot.Plot) categoryPlot32, rectangle2D41, rectangleEdge76, axisSpace77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTickUnit44);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(dateTickUnit50);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean2 = dateAxis0.equals((java.lang.Object) rectangleAnchor1);
        boolean boolean3 = dateAxis0.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis4.setAutoTickUnitSelection(false);
        dateAxis4.setNegativeArrowVisible(true);
        double double10 = dateAxis4.getAutoRangeMinimumSize();
        java.lang.String str11 = dateAxis4.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range16 = dateAxis12.getDefaultAutoRange();
        dateAxis4.setRange(range16);
        dateAxis0.setRange(range16);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5);
        dateAxis0.setLabelToolTip("CONTRACT");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets9.createInsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.data.Range range5 = dateAxis0.getRange();
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        float float13 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot14 = categoryPlot4.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(5, categoryDataset16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot4.getRendererForDataset(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot11.getDataset();
        xYPlot11.configureDomainAxes();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNull(xYDataset14);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean5 = categoryAxis1.isTickLabelsVisible();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        categoryAxis1.setTickLabelPaint(paint7);
        java.awt.Paint paint14 = categoryAxis1.getLabelPaint();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        int int21 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        categoryPlot20.setRangeAxisLocation((int) (short) 1, axisLocation23);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot20.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.Dataset dataset29 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset29);
        java.lang.Object obj31 = datasetChangeEvent30.getSource();
        categoryPlot20.datasetChanged(datasetChangeEvent30);
        boolean boolean33 = categoryPlot20.isSubplot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot20.getDomainAxisLocation(2);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        int int42 = categoryPlot41.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot41.setRangeAxisLocation((int) (short) 1, axisLocation44);
        boolean boolean46 = categoryPlot41.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot41.setDomainGridlinePosition(categoryAnchor47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot41.setRenderer(5, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint54 = categoryAxis53.getAxisLinePaint();
        java.awt.Font font55 = categoryAxis53.getLabelFont();
        int int56 = categoryPlot41.getDomainAxisIndex(categoryAxis53);
        java.awt.Paint paint57 = categoryPlot41.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot41.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace61 = categoryAxis1.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot20, rectangle2D36, rectangleEdge59, axisSpace60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + obj31 + "' != '" + false + "'", obj31.equals(false));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo19, point2D20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        categoryPlot4.notifyListeners(plotChangeEvent22);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) textAnchor1);
        java.lang.Object obj3 = null;
        boolean boolean4 = lengthAdjustmentType0.equals(obj3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint6 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxis((-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean13 = categoryPlot4.equals((java.lang.Object) textAnchor12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            categoryPlot4.drawOutline(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker1, jFreeChart4, chartChangeEventType5);
        java.lang.String str7 = chartChangeEvent6.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        java.awt.Stroke stroke14 = xYPlot11.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleAnchor15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        boolean boolean20 = chartChangeEventType17.equals((java.lang.Object) stroke19);
        xYPlot11.setRangeZeroBaselineStroke(stroke19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        try {
            xYPlot11.zoomRangeAxes(97.0d, plotRenderingInfo23, point2D24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot4.getFixedRangeAxisSpace();
        java.awt.Paint paint8 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        try {
            categoryPlot4.setDomainGridlinePosition(categoryAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryMarker5.setOutlineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        java.lang.Object obj17 = null;
        boolean boolean18 = categoryAxis1.equals(obj17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        java.awt.Paint paint31 = xYPlot11.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Paint paint7 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) numberTickUnit6);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = xYPlot11.getDomainMarkers(layer34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        int int41 = categoryPlot40.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.data.Range range43 = categoryPlot40.getDataRange(valueAxis42);
        categoryPlot40.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        categoryPlot40.setRenderer(categoryItemRenderer46, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean54 = categoryPlot40.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker52, layer53);
        java.util.Collection collection55 = xYPlot11.getRangeMarkers(layer53);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setFixedDimension(0.0d);
        double double4 = dateAxis0.getFixedAutoRange();
        dateAxis0.setRangeAboutValue((double) (short) 1, (double) (byte) 0);
        dateAxis0.setFixedDimension((double) (-1L));
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        boolean boolean6 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation19 = null;
        try {
            xYPlot11.addAnnotation(xYAnnotation19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint18 = categoryAxis14.getLabelPaint();
        float float19 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        java.awt.Paint paint20 = categoryAxis14.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        boolean boolean18 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot4.getRenderer(500);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLowerBound();
        double double2 = dateAxis0.getFixedAutoRange();
        dateAxis0.resizeRange(3.0d, (double) 0.8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace32, false);
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot11.getRangeAxis();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(valueAxis36);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Stroke stroke8 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint14 = categoryAxis13.getAxisLinePaint();
        java.awt.Font font15 = categoryAxis13.getLabelFont();
        double double16 = categoryAxis13.getFixedDimension();
        java.awt.Paint paint17 = categoryAxis13.getTickMarkPaint();
        categoryAxis13.setLabel("");
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis13.setLabelPaint((java.awt.Paint) color20);
        java.awt.Font font22 = categoryAxis13.getLabelFont();
        dateAxis3.setLabelFont(font22);
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis3.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(dateTickUnit24);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot4.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker16, layer17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = intervalMarker16.getGradientPaintTransformer();
        intervalMarker16.setStartValue((double) 10.0f);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = intervalMarker16.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer19);
        org.junit.Assert.assertNull(gradientPaintTransformer22);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis26.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit31);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        dateAxis26.setAutoRangeMinimumSize((double) 11, true);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = dateAxis37.getTickUnit();
        java.util.Date date39 = dateAxis26.calculateLowestVisibleTickValue(dateTickUnit38);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint18 = categoryAxis17.getAxisLinePaint();
        java.awt.Font font19 = categoryAxis17.getLabelFont();
        double double20 = categoryAxis17.getFixedDimension();
        java.awt.Paint paint21 = categoryAxis17.getTickMarkPaint();
        categoryMarker13.setOutlinePaint(paint21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        int int28 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        categoryPlot27.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot27.setRenderer(categoryItemRenderer33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean41 = categoryPlot27.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker39, layer40);
        boolean boolean43 = categoryPlot4.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker13, layer40, true);
        java.lang.String str44 = layer40.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.BACKGROUND" + "'", str44.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateRightOutset((double) 10L);
        categoryMarker8.setLabelOffset(rectangleInsets9);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot4.addDomainMarker((int) (short) -1, categoryMarker8, layer13, false);
        int int16 = categoryPlot4.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        java.awt.Shape shape34 = dateAxis25.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range39 = dateAxis35.getDefaultAutoRange();
        double double40 = dateAxis35.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = dateAxis41.getTickUnit();
        dateAxis41.resizeRange((double) (-1.0f));
        dateAxis41.configure();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = dateAxis46.getTickUnit();
        dateAxis46.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = dateAxis50.getTickUnit();
        dateAxis46.setTickUnit(dateTickUnit51);
        dateAxis46.setLabelToolTip("CONTRACT");
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis46.getTickUnit();
        dateAxis41.setTickUnit(dateTickUnit55, false, false);
        dateAxis35.setTickUnit(dateTickUnit55);
        dateAxis25.setTickUnit(dateTickUnit55);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit42);
        org.junit.Assert.assertNotNull(dateTickUnit47);
        org.junit.Assert.assertNotNull(dateTickUnit51);
        org.junit.Assert.assertNotNull(dateTickUnit55);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        categoryPlot4.setRangeGridlinesVisible(false);
        int int14 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint20, stroke21, (java.awt.Paint) color22, stroke23, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker25);
        java.awt.Color color27 = java.awt.Color.WHITE;
        categoryMarker25.setLabelPaint((java.awt.Paint) color27);
        categoryMarker25.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean32 = categoryPlot4.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker25, layer31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint36 = categoryAxis35.getAxisLinePaint();
        java.awt.Font font37 = categoryAxis35.getLabelFont();
        java.awt.Paint paint38 = categoryAxis35.getTickLabelPaint();
        categoryAxis35.setTickMarksVisible(true);
        int int41 = categoryPlot4.getDomainAxisIndex(categoryAxis35);
        boolean boolean42 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(axisSpace33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 10, (double) '#');
        java.awt.Shape shape4 = dateAxis0.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerBound();
        java.awt.Shape shape7 = dateAxis5.getLeftArrow();
        dateAxis0.setDownArrow(shape7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        dateAxis0.addChangeListener(axisChangeListener10);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double15 = categoryAxis14.getUpperMargin();
        categoryPlot4.setDomainAxis((int) ' ', categoryAxis14, false);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint20, stroke21, (java.awt.Paint) color22, stroke23, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker25);
        java.awt.Color color27 = java.awt.Color.WHITE;
        categoryMarker25.setLabelPaint((java.awt.Paint) color27);
        categoryMarker25.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean32 = categoryPlot4.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker25, layer31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        int int40 = categoryPlot39.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot39.setRangeAxisLocation((int) (short) 1, axisLocation42);
        categoryPlot39.configureRangeAxes();
        categoryPlot39.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot39.setRenderer(categoryItemRenderer47);
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str51 = categoryMarker50.getLabel();
        categoryPlot39.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker50);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis54.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis56.getTickUnit();
        dateAxis56.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = dateAxis60.getTickUnit();
        dateAxis56.setTickUnit(dateTickUnit61);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis56, xYItemRenderer63);
        org.jfree.chart.plot.CategoryMarker categoryMarker66 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker66.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke73 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker75 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint70, stroke71, (java.awt.Paint) color72, stroke73, 0.0f);
        categoryMarker66.setOutlineStroke(stroke71);
        boolean boolean77 = xYPlot64.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker66);
        xYPlot64.clearDomainAxes();
        boolean boolean79 = xYPlot64.isDomainCrosshairLockedOnData();
        java.awt.Color color80 = java.awt.Color.gray;
        xYPlot64.setDomainGridlinePaint((java.awt.Paint) color80);
        java.awt.Stroke stroke82 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot64.setRangeGridlineStroke(stroke82);
        org.jfree.data.xy.XYDataset xYDataset84 = xYPlot64.getDataset();
        java.awt.Color color85 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot64.setRangeCrosshairPaint((java.awt.Paint) color85);
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection88 = xYPlot64.getDomainMarkers(layer87);
        boolean boolean90 = categoryPlot4.removeDomainMarker((-16777216), (org.jfree.chart.plot.Marker) categoryMarker50, layer87, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(axisSpace33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(dateTickUnit55);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(dateTickUnit61);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNull(xYDataset84);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertNull(collection88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot4.addDomainMarker(categoryMarker10);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot4.getColumnRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 1, axisLocation20);
        categoryPlot17.configureRangeAxes();
        categoryPlot17.clearRangeMarkers(0);
        categoryPlot17.mapDatasetToDomainAxis((int) '#', (int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot17.getRangeAxisEdge((int) '#');
        boolean boolean30 = sortOrder12.equals((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.setVisible(false);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone9);
        dateAxis0.setTimeZone(timeZone9);
        dateAxis0.setLabelToolTip("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = color0.darker();
        int int2 = color1.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis26.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit31);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = dateAxis37.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = dateAxis39.getTickUnit();
        dateAxis39.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = dateAxis43.getTickUnit();
        dateAxis39.setTickUnit(dateTickUnit44);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer46);
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker49.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint53, stroke54, (java.awt.Paint) color55, stroke56, 0.0f);
        categoryMarker49.setOutlineStroke(stroke54);
        boolean boolean60 = xYPlot47.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker49);
        xYPlot47.clearDomainAxes();
        boolean boolean62 = xYPlot47.isDomainCrosshairLockedOnData();
        java.awt.Color color63 = java.awt.Color.gray;
        xYPlot47.setDomainGridlinePaint((java.awt.Paint) color63);
        java.awt.Stroke stroke65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot47.setRangeGridlineStroke(stroke65);
        org.jfree.data.xy.XYDataset xYDataset67 = xYPlot47.getDataset();
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        xYPlot47.drawAnnotations(graphics2D68, rectangle2D69, plotRenderingInfo70);
        java.awt.geom.Point2D point2D72 = xYPlot47.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        try {
            xYPlot11.draw(graphics2D34, rectangle2D35, point2D72, plotState73, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(dateTickUnit44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNull(xYDataset67);
        org.junit.Assert.assertNotNull(point2D72);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        java.util.Date date26 = day24.getStart();
        int int27 = day24.getMonth();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(categoryAxis13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        categoryMarker6.setLabelTextAnchor(textAnchor8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation17);
        categoryPlot14.configureRangeAxes();
        categoryPlot14.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot14.setRenderer(categoryItemRenderer22);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str26 = categoryMarker25.getLabel();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.data.general.Dataset dataset28 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot14, dataset28);
        java.lang.Object obj30 = datasetChangeEvent29.getSource();
        boolean boolean31 = textAnchor8.equals(obj30);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(97.0d, (double) ' ');
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis20.getTickUnit();
        dateAxis20.resizeRange((double) (-1.0f));
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        categoryPlot28.setRangeAxisLocation((int) (short) 1, axisLocation31);
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot28.addDomainMarker(categoryMarker34);
        java.awt.Stroke stroke36 = categoryMarker34.getOutlineStroke();
        dateAxis20.setTickMarkStroke(stroke36);
        categoryPlot4.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        try {
            categoryPlot4.setRangeAxisLocation((int) (short) -1, axisLocation40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean5 = categoryAxis1.isTickLabelsVisible();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        categoryAxis1.setTickLabelPaint(paint7);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint16 = categoryAxis15.getAxisLinePaint();
        java.awt.Font font17 = categoryAxis15.getLabelFont();
        categoryAxis1.setTickLabelFont(font17);
        float float19 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        java.awt.Paint paint25 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot11.getDomainAxis();
        org.jfree.data.Range range28 = null;
        try {
            valueAxis27.setRange(range28, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis27);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double2 = categoryAxis1.getUpperMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 5);
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 100.0d);
        categoryAxis1.setMaximumCategoryLabelLines(1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        categoryAxis1.setLowerMargin((double) 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        int int29 = xYPlot11.getDatasetCount();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        java.lang.String str7 = dateAxis0.getLabelURL();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.data.Range range15 = categoryPlot12.getDataRange(valueAxis14);
        categoryPlot12.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot12.setRenderer(categoryItemRenderer18, false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint28 = categoryAxis27.getAxisLinePaint();
        java.awt.Font font29 = categoryAxis27.getLabelFont();
        categoryPlot25.setNoDataMessageFont(font29);
        categoryPlot12.setNoDataMessageFont(font29);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        int int40 = categoryPlot39.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot39.setRangeAxisLocation((int) (short) 1, axisLocation42);
        categoryPlot39.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot39.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot39.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation48 = axisLocation47.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation49 = axisLocation47.getOpposite();
        xYPlot11.setDomainAxisLocation(5, axisLocation49);
        java.awt.Paint paint51 = xYPlot11.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean5 = categoryAxis1.isTickLabelsVisible();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        categoryAxis1.setTickLabelPaint(paint7);
        java.awt.Stroke stroke14 = categoryAxis1.getTickMarkStroke();
        float float15 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Stroke stroke16 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        boolean boolean29 = xYPlot11.isDomainGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot11.getRenderer((int) '#');
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(xYItemRenderer31);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        boolean boolean13 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        double double6 = dateAxis1.getLowerMargin();
        boolean boolean7 = seriesRenderingOrder0.equals((java.lang.Object) dateAxis1);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        dateAxis8.setAutoTickUnitSelection(false);
        dateAxis8.setNegativeArrowVisible(true);
        double double14 = dateAxis8.getAutoRangeMinimumSize();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis17.setTickUnit(dateTickUnit22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range28 = dateAxis24.getDefaultAutoRange();
        dateAxis17.setRange(range28);
        dateAxis8.setRange(range28);
        dateAxis1.setRange(range28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            categoryPlot4.drawOutline(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getRangeAxisEdge();
        float float13 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.plot.Plot plot14 = categoryPlot4.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(5, categoryDataset16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        int int23 = categoryPlot22.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.Range range25 = categoryPlot22.getDataRange(valueAxis24);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint27, stroke28, (java.awt.Paint) color29, stroke30, 0.0f);
        categoryPlot22.setDomainGridlineStroke(stroke30);
        categoryPlot22.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot22.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = categoryPlot22.getDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis38.getTickUnit();
        dateAxis38.resizeRange((double) (-1.0f));
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        int int47 = categoryPlot46.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        categoryPlot46.setRangeAxisLocation((int) (short) 1, axisLocation49);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot46.addDomainMarker(categoryMarker52);
        java.awt.Stroke stroke54 = categoryMarker52.getOutlineStroke();
        dateAxis38.setTickMarkStroke(stroke54);
        categoryPlot22.setRangeCrosshairStroke(stroke54);
        categoryPlot4.setRangeGridlineStroke(stroke54);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            xYPlot11.setRangeAxisLocation(axisLocation21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getRangeAxisLocation(1);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis12.getTickUnit();
        dateAxis12.setAutoTickUnitSelection(false);
        dateAxis12.setNegativeArrowVisible(true);
        double double18 = dateAxis12.getAutoRangeMinimumSize();
        dateAxis12.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis21.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis21.setTickUnit(dateTickUnit26);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range32 = dateAxis28.getDefaultAutoRange();
        dateAxis21.setRange(range32);
        dateAxis12.setRange(range32);
        int int35 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint20 = categoryAxis19.getAxisLinePaint();
        java.awt.Font font21 = categoryAxis19.getLabelFont();
        categoryPlot17.setNoDataMessageFont(font21);
        categoryPlot4.setNoDataMessageFont(font21);
        boolean boolean24 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot4.getRangeAxis(8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation28);
        boolean boolean30 = xYPlot11.isRangeZoomable();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        java.lang.Class<?> wildcardClass7 = categoryMarker6.getClass();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setFixedDimension(0.0d);
        double double4 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.setAutoTickUnitSelection(false);
        dateAxis5.setNegativeArrowVisible(true);
        double double11 = dateAxis5.getAutoRangeMinimumSize();
        dateAxis5.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range25 = dateAxis21.getDefaultAutoRange();
        dateAxis14.setRange(range25);
        dateAxis5.setRange(range25);
        dateAxis0.setRange(range25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        dateAxis0.setTickLabelInsets(rectangleInsets29);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint23, stroke24, (java.awt.Paint) color25, stroke26, 0.0f);
        categoryPlot18.setDomainGridlineStroke(stroke26);
        xYPlot11.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font32 = dateAxis31.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis31.getTickMarkPosition();
        int int34 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray36 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer35 };
        xYPlot11.setRenderers(xYItemRendererArray36);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererArray36);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis7.setAutoTickUnitSelection(false);
        dateAxis7.setNegativeArrowVisible(true);
        double double13 = dateAxis7.getAutoRangeMinimumSize();
        java.awt.Shape shape14 = dateAxis7.getLeftArrow();
        java.util.Date date15 = dateAxis7.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot21.getDataRange(valueAxis23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        categoryPlot21.setDrawingSupplier(drawingSupplier25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot21.getRangeAxisEdge();
        try {
            double double28 = dateAxis0.dateToJava2D(date15, rectangle2D16, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        dateAxis23.setTickUnit(dateTickUnit28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker33.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint37, stroke38, (java.awt.Paint) color39, stroke40, 0.0f);
        categoryMarker33.setOutlineStroke(stroke38);
        boolean boolean44 = xYPlot31.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker33);
        xYPlot31.clearDomainAxes();
        boolean boolean46 = xYPlot31.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot31.setRangeAxisLocation((int) (byte) 100, axisLocation48);
        categoryPlot4.setRangeAxisLocation(axisLocation48, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font2 = dateAxis1.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.zoomRange((double) 10, (double) '#');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Stroke stroke17 = categoryPlot16.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets21.calculateRightOutset((double) 10L);
        categoryMarker20.setLabelOffset(rectangleInsets21);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot16.addDomainMarker((int) (short) -1, categoryMarker20, layer25, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis32.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis34.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis38.getTickUnit();
        dateAxis34.setTickUnit(dateTickUnit39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer41);
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker44.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint48, stroke49, (java.awt.Paint) color50, stroke51, 0.0f);
        categoryMarker44.setOutlineStroke(stroke49);
        boolean boolean55 = xYPlot42.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker44);
        xYPlot42.clearDomainAxes();
        boolean boolean57 = xYPlot42.isDomainCrosshairLockedOnData();
        java.awt.Color color58 = java.awt.Color.gray;
        xYPlot42.setDomainGridlinePaint((java.awt.Paint) color58);
        java.awt.Stroke stroke60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot42.setRangeGridlineStroke(stroke60);
        org.jfree.data.xy.XYDataset xYDataset62 = xYPlot42.getDataset();
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot42.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        java.awt.geom.Point2D point2D67 = xYPlot42.getQuadrantOrigin();
        categoryPlot16.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo30, point2D67);
        org.jfree.chart.plot.PlotState plotState69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        try {
            xYPlot9.draw(graphics2D10, rectangle2D11, point2D67, plotState69, plotRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(xYDataset62);
        org.junit.Assert.assertNotNull(point2D67);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint7 = categoryAxis6.getAxisLinePaint();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        categoryPlot4.setNoDataMessageFont(font8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot17.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot17.setFixedLegendItems(legendItemCollection23);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double28 = categoryAxis27.getUpperMargin();
        categoryPlot17.setDomainAxis((int) ' ', categoryAxis27, false);
        java.awt.Paint paint31 = categoryAxis27.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryAxis27.getTickLabelInsets();
        categoryPlot4.setDomainAxis(7, categoryAxis27);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint39 = categoryAxis38.getAxisLinePaint();
        java.awt.Font font40 = categoryAxis38.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        int int46 = categoryPlot45.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.Range range48 = categoryPlot45.getDataRange(valueAxis47);
        categoryPlot45.setRangeCrosshairValue((double) '4');
        boolean boolean51 = categoryAxis38.equals((java.lang.Object) categoryPlot45);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot45.getDomainAxisEdge(0);
        try {
            double double54 = categoryAxis27.getCategoryMiddle(89, (int) (byte) 10, rectangle2D36, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomRangeAxes((double) 255, plotRenderingInfo9, point2D10);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.setForegroundAlpha((float) '4');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        int int13 = categoryPlot4.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot4.getRangeAxisForDataset((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis19.getTickUnit();
        dateAxis19.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis19.setTickUnit(dateTickUnit24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer26);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint29, stroke30, (java.awt.Paint) color31, stroke32, 0.0f);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker34.setPaint(paint35);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot27.getDomainAxisLocation(12);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        int int45 = categoryPlot44.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        categoryPlot44.setRangeAxisLocation((int) (short) 1, axisLocation47);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot44.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation39, plotOrientation49);
        categoryPlot4.setDomainAxisLocation(axisLocation39, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        dateAxis53.zoomRange((double) 10, (double) '#');
        java.awt.Shape shape57 = dateAxis53.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        double double59 = dateAxis58.getLowerBound();
        java.awt.Shape shape60 = dateAxis58.getLeftArrow();
        dateAxis53.setDownArrow(shape60);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis53);
        boolean boolean63 = categoryPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis26.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit31);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        dateAxis26.setAutoRangeMinimumSize((double) 11, true);
        java.util.Date date37 = null;
        try {
            dateAxis26.setMinimumDate(date37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot11.setDomainCrosshairStroke(stroke14);
        java.awt.Paint paint16 = xYPlot11.getRangeTickBandPaint();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot11.render(graphics2D17, rectangle2D18, 6, plotRenderingInfo20, crosshairState21);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Image image23 = xYPlot11.getBackgroundImage();
        xYPlot11.configureDomainAxes();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = xYPlot11.render(graphics2D25, rectangle2D26, 128, plotRenderingInfo28, crosshairState29);
        xYPlot11.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint5, stroke6, (java.awt.Paint) color7, stroke8, 0.0f);
        categoryMarker1.setOutlineStroke(stroke6);
        java.awt.Color color12 = java.awt.Color.yellow;
        int int13 = color12.getRed();
        categoryMarker1.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double26 = rectangleInsets24.calculateRightOutset((double) 10L);
        categoryMarker23.setLabelOffset(rectangleInsets24);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot19.addDomainMarker((int) (short) -1, categoryMarker23, layer28, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot19.zoomDomainAxes((double) 3, plotRenderingInfo32, point2D33);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot19);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double38 = categoryAxis37.getUpperMargin();
        categoryPlot19.setDomainAxis(categoryAxis37);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot19.getDomainAxis(15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNull(categoryAxis41);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange((double) 10, (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        dateAxis5.setMaximumDate(date21);
        dateAxis0.setMinimumDate(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = categoryPlot31.getNoDataMessagePaint();
        boolean boolean40 = seriesRenderingOrder26.equals((java.lang.Object) paint39);
        int int41 = day24.compareTo((java.lang.Object) boolean40);
        int int42 = day24.getMonth();
        java.util.Calendar calendar43 = null;
        try {
            day24.peg(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint24 = categoryAxis23.getAxisLinePaint();
        java.awt.Paint paint25 = categoryAxis23.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker27.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint31, stroke32, (java.awt.Paint) color33, stroke34, 0.0f);
        categoryMarker27.setOutlineStroke(stroke32);
        categoryAxis23.setTickMarkStroke(stroke32);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer40);
        boolean boolean42 = xYPlot11.equals((java.lang.Object) categoryPlot41);
        xYPlot11.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint9 = categoryAxis8.getAxisLinePaint();
        java.awt.Font font10 = categoryAxis8.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        int int16 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot15.getDataRange(valueAxis17);
        categoryPlot15.setRangeCrosshairValue((double) '4');
        boolean boolean21 = categoryAxis8.equals((java.lang.Object) categoryPlot15);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot15.getDomainAxisEdge(0);
        try {
            double double24 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D6, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis34.getTickUnit();
        dateAxis34.resizeRange((double) (-1.0f));
        dateAxis34.configure();
        java.awt.Shape shape39 = dateAxis34.getRightArrow();
        dateAxis25.setDownArrow(shape39);
        boolean boolean42 = dateAxis25.isHiddenValue((long) 2);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setCategoryMargin((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        int int11 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint15, stroke16, (java.awt.Paint) color17, stroke18, 0.0f);
        categoryPlot10.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot10.getDomainGridlinePosition();
        java.lang.String str23 = categoryAnchor22.toString();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint29 = categoryAxis28.getAxisLinePaint();
        java.awt.Font font30 = categoryAxis28.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.data.Range range38 = categoryPlot35.getDataRange(valueAxis37);
        categoryPlot35.setRangeCrosshairValue((double) '4');
        boolean boolean41 = categoryAxis28.equals((java.lang.Object) categoryPlot35);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot35.getDomainAxisEdge(0);
        try {
            double double44 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor22, (int) ' ', 1, rectangle2D26, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str23.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1.0d, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker5, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = chartChangeEvent10.getType();
        chartChangeEvent3.setType(chartChangeEventType11);
        java.lang.String str13 = chartChangeEventType11.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str13.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        java.lang.Object obj6 = dateAxis0.clone();
        dateAxis0.centerRange((double) (-256));
        org.jfree.data.Range range9 = dateAxis0.getRange();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint1, stroke2, (java.awt.Paint) color3, stroke4, 0.0f);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        categoryMarker6.setLabelTextAnchor(textAnchor8);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener10 = null;
        categoryMarker6.removeChangeListener(markerChangeListener10);
        float float12 = categoryMarker6.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset13);
        java.lang.Object obj15 = datasetChangeEvent14.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot4.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint20 = categoryAxis19.getAxisLinePaint();
        java.awt.Font font21 = categoryAxis19.getLabelFont();
        double double22 = categoryAxis19.getFixedDimension();
        java.awt.Paint paint23 = categoryAxis19.getTickMarkPaint();
        int int24 = categoryPlot4.getDomainAxisIndex(categoryAxis19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + false + "'", obj15.equals(false));
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range39 = dateAxis35.getDefaultAutoRange();
        double double40 = dateAxis35.getLowerMargin();
        boolean boolean41 = seriesRenderingOrder34.equals((java.lang.Object) dateAxis35);
        int int42 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        xYPlot11.setRangeCrosshairValue((double) 0L, false);
        java.awt.Stroke stroke46 = xYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace47);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        boolean boolean10 = categoryPlot4.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint18 = categoryAxis17.getAxisLinePaint();
        java.awt.Font font19 = categoryAxis17.getLabelFont();
        double double20 = categoryAxis17.getFixedDimension();
        java.awt.Paint paint21 = categoryAxis17.getTickMarkPaint();
        categoryMarker13.setOutlinePaint(paint21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        int int28 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        categoryPlot27.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot27.setRenderer(categoryItemRenderer33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean41 = categoryPlot27.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker39, layer40);
        boolean boolean43 = categoryPlot4.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker13, layer40, true);
        java.lang.Comparable comparable44 = categoryMarker13.getKey();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + "hi!" + "'", comparable44.equals("hi!"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setTickMarkInsideLength((float) 15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot11.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        dateAxis25.setAutoRangeMinimumSize((double) 100);
        xYPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker36.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        int int44 = categoryPlot43.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        categoryPlot43.setRangeAxisLocation((int) (short) 1, axisLocation46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot43.setRenderer(5, categoryItemRenderer49);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = null;
        categoryPlot43.notifyListeners(plotChangeEvent51);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = categoryPlot43.getDomainMarkers(layer53);
        boolean boolean56 = xYPlot11.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker36, layer53, true);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit58 = dateAxis57.getTickUnit();
        dateAxis57.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource61 = null;
        dateAxis57.setStandardTickUnits(tickUnitSource61);
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTickUnit58);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        double double18 = dateAxis13.getLowerMargin();
        boolean boolean19 = seriesRenderingOrder12.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        xYPlot11.setDomainAxes(valueAxisArray20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot11.getRenderer();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker1.setKey((java.lang.Comparable) "hi!");
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.removeChangeListener(markerChangeListener4);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint7, stroke8, (java.awt.Paint) color9, stroke10, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryMarker1.notifyListeners(markerChangeEvent13);
        java.awt.Font font15 = categoryMarker1.getLabelFont();
        java.lang.Object obj16 = null;
        boolean boolean17 = categoryMarker1.equals(obj16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int19 = color18.getAlpha();
        java.awt.Color color20 = color18.darker();
        categoryMarker1.setPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        int int31 = xYPlot11.getIndexOf(xYItemRenderer30);
        double double32 = xYPlot11.getDomainCrosshairValue();
        xYPlot11.mapDatasetToRangeAxis(6, 9);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        double double18 = dateAxis13.getLowerMargin();
        boolean boolean19 = seriesRenderingOrder12.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        xYPlot11.setDomainAxes(valueAxisArray20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot11.setDomainGridlinePaint(paint22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis25.setMarkerBand(markerAxisBand28);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis25.setTickUnit(numberTickUnit30);
        boolean boolean32 = numberAxis25.getAutoRangeIncludesZero();
        xYPlot11.setDomainAxis(3, (org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot11.getDataset();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(xYDataset34);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        dateAxis0.setTimeZone(timeZone3);
        java.awt.Font font6 = dateAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker5.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryMarker5.setOutlineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        java.lang.Comparable comparable19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.data.Range range31 = categoryPlot28.getDataRange(valueAxis30);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint33, stroke34, (java.awt.Paint) color35, stroke36, 0.0f);
        categoryPlot28.setDomainGridlineStroke(stroke36);
        java.awt.Stroke stroke40 = categoryPlot28.getRangeCrosshairStroke();
        categoryPlot28.setWeight((-1));
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        int int48 = categoryPlot47.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot47.setRangeAxisLocation((int) (short) 1, axisLocation50);
        categoryPlot47.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot47.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot47.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation56 = axisLocation55.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation57 = axisLocation55.getOpposite();
        categoryPlot28.setDomainAxisLocation(axisLocation57, false);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, categoryItemRenderer63);
        int int65 = categoryPlot64.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation67 = null;
        categoryPlot64.setRangeAxisLocation((int) (short) 1, axisLocation67);
        categoryPlot64.configureRangeAxes();
        categoryPlot64.clearRangeMarkers(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = categoryPlot64.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation57, plotOrientation72);
        try {
            double double74 = categoryAxis1.getCategorySeriesMiddle(comparable19, (java.lang.Comparable) (short) 10, categoryDataset21, (-1.0d), rectangle2D23, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = xYPlot11.getSeriesRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        int int37 = categoryPlot36.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        categoryPlot36.setRangeAxisLocation((int) (short) 1, axisLocation39);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
        categoryPlot36.addDomainMarker(categoryMarker42);
        java.awt.Stroke stroke44 = categoryMarker42.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setTickMarkInsideLength((float) (short) 10);
        java.awt.Paint paint48 = dateAxis45.getTickLabelPaint();
        boolean boolean49 = categoryMarker42.equals((java.lang.Object) dateAxis45);
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        int int55 = categoryPlot54.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.data.Range range57 = categoryPlot54.getDataRange(valueAxis56);
        categoryPlot54.setRangeCrosshairValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        categoryPlot54.setRenderer(categoryItemRenderer60, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.util.Layer layer67 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean68 = categoryPlot54.removeDomainMarker((-246), (org.jfree.chart.plot.Marker) intervalMarker66, layer67);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker42, layer67);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(layer67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot4.notifyListeners(plotChangeEvent12);
        boolean boolean14 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Image image15 = null;
        categoryPlot4.setBackgroundImage(image15);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets21.calculateRightOutset((double) 10L);
        categoryMarker20.setLabelOffset(rectangleInsets21);
        double double26 = rectangleInsets21.extendWidth((double) ' ');
        categoryPlot4.setInsets(rectangleInsets21);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace28);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 34.0d + "'", double26 == 34.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis9.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis13.getTickUnit();
        dateAxis9.setTickUnit(dateTickUnit14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer16);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint19, stroke20, (java.awt.Paint) color21, stroke22, 0.0f);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker24.setPaint(paint25);
        xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker24);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        int int34 = categoryPlot33.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        categoryPlot33.setRangeAxisLocation((int) (short) 1, axisLocation36);
        categoryPlot33.configureRangeAxes();
        categoryPlot33.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot33.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace43 = categoryAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) xYPlot17, rectangle2D28, rectangleEdge41, axisSpace42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = xYPlot11.getDomainMarkers(layer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.data.Range range37 = xYPlot11.getDataRange(valueAxis36);
        try {
            xYPlot11.setBackgroundImageAlpha((float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot11.removeChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(axisLocation34, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Color color27 = java.awt.Color.gray;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setRangeGridlineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot11.getDataset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = xYPlot11.getDomainMarkers(layer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.data.Range range37 = xYPlot11.getDataRange(valueAxis36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = dateAxis42.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis44.getTickUnit();
        dateAxis44.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = dateAxis48.getTickUnit();
        dateAxis44.setTickUnit(dateTickUnit49);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer51);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder53 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        dateAxis54.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range58 = dateAxis54.getDefaultAutoRange();
        double double59 = dateAxis54.getLowerMargin();
        boolean boolean60 = seriesRenderingOrder53.equals((java.lang.Object) dateAxis54);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] { dateAxis54 };
        xYPlot52.setDomainAxes(valueAxisArray61);
        java.awt.Paint paint63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot52.setDomainGridlinePaint(paint63);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder65 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot52.setDatasetRenderingOrder(datasetRenderingOrder65);
        java.awt.geom.Point2D point2D67 = xYPlot52.getQuadrantOrigin();
        try {
            xYPlot11.zoomRangeAxes((double) 2.0f, (double) (byte) 1, plotRenderingInfo40, point2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertNotNull(dateTickUnit49);
        org.junit.Assert.assertNotNull(seriesRenderingOrder53);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(datasetRenderingOrder65);
        org.junit.Assert.assertNotNull(point2D67);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis9.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis13.getTickUnit();
        dateAxis9.setTickUnit(dateTickUnit14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range20 = dateAxis16.getDefaultAutoRange();
        dateAxis9.setRange(range20);
        dateAxis0.setRange(range20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        dateAxis23.setAutoTickUnitSelection(false);
        dateAxis23.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis23.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource28);
        java.text.DateFormat dateFormat30 = null;
        dateAxis0.setDateFormatOverride(dateFormat30);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(tickUnitSource28);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        numberAxis0.setUpperBound((double) '4');
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(numberTickUnit10);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        java.lang.Comparable comparable21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis27.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis29.getTickUnit();
        dateAxis29.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis33.getTickUnit();
        dateAxis29.setTickUnit(dateTickUnit34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer36);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker39.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint43, stroke44, (java.awt.Paint) color45, stroke46, 0.0f);
        categoryMarker39.setOutlineStroke(stroke44);
        boolean boolean50 = xYPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker39);
        xYPlot37.clearDomainAxes();
        boolean boolean52 = xYPlot37.isDomainCrosshairLockedOnData();
        java.awt.Color color53 = java.awt.Color.gray;
        xYPlot37.setDomainGridlinePaint((java.awt.Paint) color53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot37.setRangeGridlineStroke(stroke55);
        org.jfree.data.xy.XYDataset xYDataset57 = xYPlot37.getDataset();
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        xYPlot37.drawAnnotations(graphics2D58, rectangle2D59, plotRenderingInfo60);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = xYPlot37.getRangeAxisEdge(0);
        try {
            double double64 = categoryAxis7.getCategorySeriesMiddle(comparable21, (java.lang.Comparable) "TextAnchor.BOTTOM_CENTER", categoryDataset23, (double) 2, rectangle2D25, rectangleEdge63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(xYDataset57);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot4.getIndexOf(categoryItemRenderer11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = categoryPlot17.getOrientation();
        categoryPlot4.setOrientation(plotOrientation22);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0E-8d);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightOutset((double) 10L);
        categoryMarker28.setLabelOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = categoryMarker28.getLabelAnchor();
        boolean boolean34 = intervalMarker26.equals((java.lang.Object) categoryMarker28);
        boolean boolean35 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker28);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot11.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot11.setRenderer(128, xYItemRenderer21, true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        int int29 = categoryPlot28.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.data.Range range31 = categoryPlot28.getDataRange(valueAxis30);
        categoryPlot28.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint34 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot28.getDomainAxis((-32513));
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset38);
        java.lang.Object obj40 = datasetChangeEvent39.getSource();
        categoryPlot28.datasetChanged(datasetChangeEvent39);
        xYPlot11.datasetChanged(datasetChangeEvent39);
        double double43 = xYPlot11.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + obj40 + "' != '" + false + "'", obj40.equals(false));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Color color1 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke9 = defaultDrawingSupplier8.getNextStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 2, (java.awt.Paint) color1, stroke9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis12.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer21);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker24.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint28, stroke29, (java.awt.Paint) color30, stroke31, 0.0f);
        categoryMarker24.setOutlineStroke(stroke29);
        boolean boolean35 = xYPlot22.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker24);
        xYPlot22.clearDomainAxes();
        boolean boolean37 = xYPlot22.isDomainCrosshairLockedOnData();
        java.awt.Color color38 = java.awt.Color.gray;
        xYPlot22.setDomainGridlinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot22.setRangeGridlineStroke(stroke40);
        org.jfree.data.xy.XYDataset xYDataset42 = xYPlot22.getDataset();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot22.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        dateAxis46.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range50 = dateAxis46.getDefaultAutoRange();
        double double51 = dateAxis46.getLowerMargin();
        boolean boolean52 = seriesRenderingOrder45.equals((java.lang.Object) dateAxis46);
        int int53 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis46);
        xYPlot22.setRangeCrosshairValue((double) 0L, false);
        java.awt.Stroke stroke57 = xYPlot22.getDomainZeroBaselineStroke();
        valueMarker10.setStroke(stroke57);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(xYDataset42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.setTickMarkInsideLength((float) 3);
        categoryAxis7.setFixedDimension((double) 255);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation((int) (short) 1, axisLocation8);
        boolean boolean10 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        double double16 = categoryAxis15.getUpperMargin();
        categoryPlot5.setDomainAxis((int) ' ', categoryAxis15, false);
        categoryAxis15.setUpperMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis15, valueAxis21, categoryItemRenderer22);
        categoryPlot23.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot23.getRangeAxis((-32513));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        java.awt.Paint paint19 = xYPlot11.getRangeZeroBaselinePaint();
        int int20 = xYPlot11.getRangeAxisCount();
        java.awt.Paint paint21 = xYPlot11.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        float float15 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot4.getAxisOffset();
        double double18 = rectangleInsets16.trimWidth((double) (-16777216));
        java.lang.String str19 = rectangleInsets16.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.6777224E7d) + "'", double18 == (-1.6777224E7d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        boolean boolean8 = categoryPlot4.isRangeCrosshairLockedOnData();
        int int9 = categoryPlot4.getBackgroundImageAlignment();
        categoryPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        org.jfree.data.Range range5 = dateAxis0.getRange();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearDomainAxes();
        boolean boolean26 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        int int31 = xYPlot11.getIndexOf(xYItemRenderer30);
        double double32 = xYPlot11.getDomainCrosshairValue();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot11.getDomainMarkers(layer33);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(collection34);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo11, point2D12, true);
        float float15 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot4.getIndexOf(categoryItemRenderer16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        float float4 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10);
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange(0.0d, (double) 1L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot18.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.setRangeCrosshairValue((double) '4');
        java.awt.Paint paint10 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot4.axisChanged(axisChangeEvent11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 1, axisLocation20);
        categoryPlot17.configureRangeAxes();
        categoryPlot17.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot17.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder25);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(sortOrder25);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation(12);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection25 = xYPlot11.getRangeMarkers(layer24);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getDomainAxisLocation();
        int int13 = categoryPlot4.getWeight();
        categoryPlot4.clearDomainAxes();
        java.awt.Image image15 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint18 = categoryAxis17.getAxisLinePaint();
        java.awt.Paint paint20 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) 7);
        java.util.List list21 = categoryPlot4.getCategoriesForAxis(categoryAxis17);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint23, stroke24, (java.awt.Paint) color25, stroke26, 0.0f);
        categoryPlot18.setDomainGridlineStroke(stroke26);
        xYPlot11.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font32 = dateAxis31.getLabelFont();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis31.getTickMarkPosition();
        int int34 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis31);
        double double35 = dateAxis31.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setTickMarkInsideLength((float) (short) 10);
        dateAxis36.resizeRange((double) 0L);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        dateAxis36.setTickMarkPaint((java.awt.Paint) color41);
        java.util.Date date43 = dateAxis36.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        int int50 = categoryPlot49.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation52 = null;
        categoryPlot49.setRangeAxisLocation((int) (short) 1, axisLocation52);
        categoryPlot49.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot49.getRangeAxisEdge((int) (byte) 0);
        try {
            double double57 = dateAxis31.dateToJava2D(date43, rectangle2D44, rectangleEdge56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis9.setAutoTickUnitSelection(false);
        dateAxis9.setNegativeArrowVisible(true);
        double double15 = dateAxis9.getAutoRangeMinimumSize();
        dateAxis9.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis18.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis22.getTickUnit();
        dateAxis18.setTickUnit(dateTickUnit23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range29 = dateAxis25.getDefaultAutoRange();
        dateAxis18.setRange(range29);
        dateAxis9.setRange(range29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis32.getTickUnit();
        dateAxis32.setAutoTickUnitSelection(false);
        dateAxis32.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = dateAxis32.getStandardTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource37);
        dateAxis0.setStandardTickUnits(tickUnitSource37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = dateAxis40.getTickUnit();
        dateAxis40.resizeRange((double) (-1.0f));
        dateAxis40.configure();
        java.awt.Shape shape45 = dateAxis40.getRightArrow();
        dateAxis0.setLeftArrow(shape45);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(tickUnitSource37);
        org.junit.Assert.assertNotNull(dateTickUnit41);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker13.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint17, stroke18, (java.awt.Paint) color19, stroke20, 0.0f);
        categoryMarker13.setOutlineStroke(stroke18);
        boolean boolean24 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot11.getDomainAxis(89);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis21.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis21.setTickUnit(dateTickUnit26);
        dateAxis21.setInverted(true);
        dateAxis21.resizeRange(0.0d, (double) 1L);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis21.setRightArrow(shape33);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        int int41 = categoryPlot40.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        categoryPlot40.setRangeAxisLocation((int) (short) 1, axisLocation43);
        categoryPlot40.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot40.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot40.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation49 = axisLocation48.getOpposite();
        categoryPlot4.setDomainAxisLocation(axisLocation48, true);
        java.lang.String str52 = categoryPlot4.getPlotType();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        boolean boolean15 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint8 = categoryAxis7.getAxisLinePaint();
        java.awt.Paint paint10 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) 7);
        boolean boolean11 = categoryAxis7.isTickLabelsVisible();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        categoryAxis7.setTickLabelPaint(paint13);
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.setTickMarkInsideLength((float) 3);
        double double23 = categoryAxis7.getLowerMargin();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        xYPlot11.setRangeZeroBaselineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        int int25 = categoryPlot24.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        categoryPlot24.setRangeAxisLocation((int) (short) 1, axisLocation27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis32.getTickUnit();
        dateAxis32.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        dateAxis32.setTickUnit(dateTickUnit37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer39);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint42, stroke43, (java.awt.Paint) color44, stroke45, 0.0f);
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker47.setPaint(paint48);
        xYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str52 = lengthAdjustmentType51.toString();
        boolean boolean54 = lengthAdjustmentType51.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint57 = categoryAxis56.getAxisLinePaint();
        java.awt.Paint paint58 = categoryAxis56.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker60.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker69 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint64, stroke65, (java.awt.Paint) color66, stroke67, 0.0f);
        categoryMarker60.setOutlineStroke(stroke65);
        categoryAxis56.setTickMarkStroke(stroke65);
        boolean boolean72 = lengthAdjustmentType51.equals((java.lang.Object) categoryAxis56);
        categoryMarker47.setLabelOffsetType(lengthAdjustmentType51);
        categoryPlot24.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker47);
        org.jfree.chart.util.Layer layer75 = null;
        boolean boolean77 = xYPlot11.removeDomainMarker(1, (org.jfree.chart.plot.Marker) categoryMarker47, layer75, false);
        boolean boolean78 = xYPlot11.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(lengthAdjustmentType51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "CONTRACT" + "'", str52.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        double double18 = dateAxis13.getLowerMargin();
        boolean boolean19 = seriesRenderingOrder12.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        xYPlot11.setDomainAxes(valueAxisArray20);
        java.awt.Color color23 = java.awt.Color.YELLOW;
        java.awt.Color color24 = color23.darker();
        try {
            xYPlot11.setQuadrantPaint((-655360), (java.awt.Paint) color23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-655360) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarkInsideLength((float) (short) 10);
        java.awt.Color color3 = java.awt.Color.blue;
        dateAxis0.setLabelPaint((java.awt.Paint) color3);
        dateAxis0.setFixedAutoRange((double) 5);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        double double18 = dateAxis13.getLowerMargin();
        boolean boolean19 = seriesRenderingOrder12.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        xYPlot11.setDomainAxes(valueAxisArray20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot11.setDomainGridlinePaint(paint22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis25.setMarkerBand(markerAxisBand28);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis25.setTickUnit(numberTickUnit30);
        boolean boolean32 = numberAxis25.getAutoRangeIncludesZero();
        xYPlot11.setDomainAxis(3, (org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis25.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(numberTickUnit34);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        xYPlot11.clearRangeMarkers(2);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot11.getDataset((-246));
        float float19 = xYPlot11.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis23.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis25.getTickUnit();
        dateAxis25.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis29.getTickUnit();
        dateAxis25.setTickUnit(dateTickUnit30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer32);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker35.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint39, stroke40, (java.awt.Paint) color41, stroke42, 0.0f);
        categoryMarker35.setOutlineStroke(stroke40);
        boolean boolean46 = xYPlot33.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker35);
        xYPlot33.clearDomainAxes();
        boolean boolean48 = xYPlot33.isDomainCrosshairLockedOnData();
        java.awt.Color color49 = java.awt.Color.gray;
        xYPlot33.setDomainGridlinePaint((java.awt.Paint) color49);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot33.setRangeGridlineStroke(stroke51);
        org.jfree.data.xy.XYDataset xYDataset53 = xYPlot33.getDataset();
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        xYPlot33.drawAnnotations(graphics2D54, rectangle2D55, plotRenderingInfo56);
        java.awt.geom.Point2D point2D58 = xYPlot33.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        try {
            xYPlot11.draw(graphics2D20, rectangle2D21, point2D58, plotState59, plotRenderingInfo60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(xYDataset53);
        org.junit.Assert.assertNotNull(point2D58);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(5, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        int int19 = categoryPlot4.getDomainAxisIndex(categoryAxis16);
        java.awt.Stroke stroke20 = categoryPlot4.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        java.awt.Image image12 = categoryPlot4.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = categoryPlot17.getDataRange(valueAxis19);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint22, stroke23, (java.awt.Paint) color24, stroke25, 0.0f);
        categoryPlot17.setDomainGridlineStroke(stroke25);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint31, stroke32, (java.awt.Paint) color33, stroke34, 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker36);
        java.awt.Color color38 = java.awt.Color.WHITE;
        categoryMarker36.setLabelPaint((java.awt.Paint) color38);
        categoryMarker36.setKey((java.lang.Comparable) "");
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot17.addRangeMarker(500, (org.jfree.chart.plot.Marker) categoryMarker36, layer42);
        boolean boolean44 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker36);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(image12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleAnchor2, jFreeChart3, chartChangeEventType4);
        boolean boolean6 = defaultDrawingSupplier0.equals((java.lang.Object) chartChangeEventType4);
        java.lang.String str7 = chartChangeEventType4.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str7.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setNegativeArrowVisible(true);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Shape shape7 = dateAxis0.getLeftArrow();
        double double8 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot4.getRowRenderingOrder();
        boolean boolean13 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot4.getDomainAxisForDataset(0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        java.awt.Image image23 = xYPlot11.getBackgroundImage();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation24 = null;
        try {
            boolean boolean26 = xYPlot11.removeAnnotation(xYAnnotation24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(image23);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot4.axisChanged(axisChangeEvent12);
        java.awt.Paint paint14 = null;
        categoryPlot4.setBackgroundPaint(paint14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setFixedDimension(0.0d);
        double double4 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.setAutoTickUnitSelection(false);
        dateAxis5.setNegativeArrowVisible(true);
        double double11 = dateAxis5.getAutoRangeMinimumSize();
        dateAxis5.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis14.getTickUnit();
        dateAxis14.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.zoomRange((double) 10, (double) '#');
        org.jfree.data.Range range25 = dateAxis21.getDefaultAutoRange();
        dateAxis14.setRange(range25);
        dateAxis5.setRange(range25);
        dateAxis0.setRange(range25);
        double double29 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint3 = categoryAxis2.getAxisLinePaint();
        float float4 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis5.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis9.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10);
        dateAxis5.setInverted(true);
        dateAxis5.resizeRange(0.0d, (double) 1L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer17);
        boolean boolean19 = dateAxis5.isVisible();
        dateAxis5.setAutoRangeMinimumSize((double) 11, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis15.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis17.getTickUnit();
        dateAxis17.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis21.getTickUnit();
        dateAxis17.setTickUnit(dateTickUnit22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer24);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint27, stroke28, (java.awt.Paint) color29, stroke30, 0.0f);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker32.setPaint(paint33);
        xYPlot25.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot25.getDomainAxisLocation(12);
        xYPlot11.setDomainAxisLocation(axisLocation37, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = xYPlot11.getOrientation();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(plotOrientation40);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot11.setDomainCrosshairStroke(stroke14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot11.getDataset();
        java.awt.Paint paint17 = xYPlot11.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        dateAxis0.setTickMarkOutsideLength((float) (-16777216));
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint13, stroke14, (java.awt.Paint) color15, stroke16, 0.0f);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker18.setPaint(paint19);
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        boolean boolean22 = xYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets();
        double double35 = rectangleInsets33.calculateRightOutset((double) 10L);
        categoryMarker32.setLabelOffset(rectangleInsets33);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot28.addDomainMarker((int) (short) -1, categoryMarker32, layer37, false);
        java.util.Collection collection40 = xYPlot11.getRangeMarkers(2, layer37);
        xYPlot11.mapDatasetToDomainAxis(255, (-1));
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNull(collection40);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        int int14 = xYPlot11.indexOf(xYDataset13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace15, false);
        boolean boolean18 = xYPlot11.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke19 = xYPlot11.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        java.awt.Font font8 = categoryPlot4.getNoDataMessageFont();
        java.awt.Stroke stroke9 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        double double4 = categoryAxis1.getFixedDimension();
        float float5 = categoryAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        java.awt.Paint paint12 = xYPlot11.getRangeCrosshairPaint();
        java.awt.Paint paint13 = xYPlot11.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis3.getTickUnit();
        dateAxis3.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis3.setTickUnit(dateTickUnit8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateRightOutset((double) 10L);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        boolean boolean18 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        xYPlot11.clearRangeMarkers((-246));
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot11.setAxisOffset(rectangleInsets21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis24.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        dateAxis26.resizeRange((double) (-1.0f));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis30.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer33);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        categoryMarker36.setKey((java.lang.Comparable) "hi!");
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint40, stroke41, (java.awt.Paint) color42, stroke43, 0.0f);
        categoryMarker36.setOutlineStroke(stroke41);
        boolean boolean47 = xYPlot34.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker36);
        xYPlot34.clearDomainAxes();
        boolean boolean49 = xYPlot34.isDomainCrosshairLockedOnData();
        java.awt.Color color50 = java.awt.Color.gray;
        xYPlot34.setDomainGridlinePaint((java.awt.Paint) color50);
        java.awt.Stroke stroke52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot34.setRangeGridlineStroke(stroke52);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder54 = xYPlot34.getSeriesRenderingOrder();
        xYPlot11.setSeriesRenderingOrder(seriesRenderingOrder54);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = xYPlot11.getOrientation();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(seriesRenderingOrder54);
        org.junit.Assert.assertNotNull(plotOrientation56);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation7);
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor10);
        categoryPlot4.setRangeGridlinesVisible(false);
        int int14 = categoryPlot4.getDomainAxisCount();
        try {
            categoryPlot4.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, paint9, stroke10, (java.awt.Paint) color11, stroke12, 0.0f);
        categoryPlot4.setDomainGridlineStroke(stroke12);
        categoryPlot4.clearRangeMarkers(9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot4.getIndexOf(categoryItemRenderer20);
        boolean boolean22 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        int int28 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        categoryPlot27.setRangeAxisLocation((int) (short) 1, axisLocation30);
        categoryPlot27.configureRangeAxes();
        categoryPlot27.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot27.setRenderer(categoryItemRenderer35);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0);
        java.lang.String str39 = categoryMarker38.getLabel();
        categoryPlot27.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker38);
        org.jfree.data.general.Dataset dataset41 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot27, dataset41);
        java.lang.Object obj43 = datasetChangeEvent42.getSource();
        categoryPlot4.datasetChanged(datasetChangeEvent42);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(obj43);
    }
}

