import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int6 = timePeriodValues5.getMinEndIndex();
        java.lang.String str7 = timePeriodValues5.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long11 = simpleTimePeriod10.getStartMillis();
        long long12 = simpleTimePeriod10.getStartMillis();
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (java.lang.Number) 10L);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int20 = timePeriodValues19.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass23 = seriesException22.getClass();
        java.lang.Class<?> wildcardClass24 = seriesException22.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long28 = simpleTimePeriod27.getStartMillis();
        java.util.Date date29 = simpleTimePeriod27.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long35 = simpleTimePeriod34.getStartMillis();
        java.util.Date date36 = simpleTimePeriod34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date29, date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year38, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.next();
        boolean boolean42 = simpleTimePeriod10.equals((java.lang.Object) regularTimePeriod41);
        boolean boolean43 = day0.equals((java.lang.Object) regularTimePeriod41);
        boolean boolean45 = day0.equals((java.lang.Object) 100.0f);
        java.util.Date date46 = day0.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) (short) 1);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValue10.equals(obj11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test03");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int3 = day0.compareTo((java.lang.Object) (-1));
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getMiddleMillisecond();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        int int26 = year22.compareTo((java.lang.Object) 10L);
        long long27 = year22.getFirstMillisecond();
        java.lang.String str28 = year22.toString();
        long long29 = year22.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int34 = timePeriodValues33.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass37 = seriesException36.getClass();
        java.lang.Class<?> wildcardClass38 = seriesException36.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long42 = simpleTimePeriod41.getStartMillis();
        java.util.Date date43 = simpleTimePeriod41.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long49 = simpleTimePeriod48.getStartMillis();
        java.util.Date date50 = simpleTimePeriod48.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date43, date50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year52, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year52.next();
        boolean boolean57 = year52.equals((java.lang.Object) 35L);
        int int58 = year52.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year52, (double) 100.0f);
        int int61 = year22.compareTo((java.lang.Object) 100.0f);
        java.util.Date date62 = year22.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1969" + "'", str28.equals("1969"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1969L + "'", long29 == 1969L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 35L + "'", long49 == 35L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1969 + "'", int58 == 1969);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(date62);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(43629L, 1560409200000L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, 12.0d);
        java.lang.String str32 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long36 = simpleTimePeriod35.getStartMillis();
        long long37 = simpleTimePeriod35.getStartMillis();
        java.util.Date date38 = simpleTimePeriod35.getEnd();
        java.util.Date date39 = simpleTimePeriod35.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int44 = timePeriodValues43.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException46 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass47 = seriesException46.getClass();
        java.lang.Class<?> wildcardClass48 = seriesException46.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long52 = simpleTimePeriod51.getStartMillis();
        java.util.Date date53 = simpleTimePeriod51.getEnd();
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date53, timeZone54);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long59 = simpleTimePeriod58.getStartMillis();
        java.util.Date date60 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date53, date60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date60);
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year62, (double) 5);
        long long65 = year62.getSerialIndex();
        int int66 = simpleTimePeriod35.compareTo((java.lang.Object) year62);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod35, (double) 12);
        java.lang.Number number69 = timePeriodValue68.getValue();
        java.lang.Number number70 = timePeriodValue68.getValue();
        java.lang.String str71 = timePeriodValue68.toString();
        java.lang.Object obj72 = timePeriodValue68.clone();
        java.lang.Number number73 = timePeriodValue68.getValue();
        timePeriodValues3.add(timePeriodValue68);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str32.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 35L + "'", long52 == 35L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 35L + "'", long59 == 35L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1969L + "'", long65 == 1969L);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 12.0d + "'", number69.equals(12.0d));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 12.0d + "'", number70.equals(12.0d));
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 12.0d + "'", number73.equals(12.0d));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((-1), (int) (byte) -1);
        int int10 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long9 = simpleTimePeriod8.getStartMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 10L);
        java.util.Date date14 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        java.lang.String str18 = day17.toString();
        java.lang.Class<?> wildcardClass19 = day17.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-1969" + "'", str18.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long29 = simpleTimePeriod28.getStartMillis();
        long long30 = simpleTimePeriod28.getStartMillis();
        java.util.Date date31 = simpleTimePeriod28.getEnd();
        java.util.Date date32 = simpleTimePeriod28.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int37 = timePeriodValues36.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass40 = seriesException39.getClass();
        java.lang.Class<?> wildcardClass41 = seriesException39.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long45 = simpleTimePeriod44.getStartMillis();
        java.util.Date date46 = simpleTimePeriod44.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date46, timeZone47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long52 = simpleTimePeriod51.getStartMillis();
        java.util.Date date53 = simpleTimePeriod51.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date46, date53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date53);
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year55, (double) 5);
        long long58 = year55.getSerialIndex();
        int int59 = simpleTimePeriod28.compareTo((java.lang.Object) year55);
        org.jfree.data.time.TimePeriodValue timePeriodValue61 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (double) 12);
        java.lang.Number number62 = timePeriodValue61.getValue();
        java.lang.Object obj63 = timePeriodValue61.clone();
        boolean boolean64 = year22.equals((java.lang.Object) timePeriodValue61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year22.previous();
        long long66 = year22.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 35L + "'", long52 == 35L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1969L + "'", long58 == 1969L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 12.0d + "'", number62.equals(12.0d));
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-15739200001L) + "'", long66 == (-15739200001L));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int11 = timePeriodValues10.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass14 = seriesException13.getClass();
        java.lang.Class<?> wildcardClass15 = seriesException13.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long26 = simpleTimePeriod25.getStartMillis();
        java.util.Date date27 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year29, (double) 5);
        long long32 = year29.getSerialIndex();
        int int33 = simpleTimePeriod2.compareTo((java.lang.Object) year29);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 12);
        java.lang.String str36 = timePeriodValue35.toString();
        org.jfree.data.time.TimePeriod timePeriod37 = timePeriodValue35.getPeriod();
        java.lang.String str38 = timePeriodValue35.toString();
        java.lang.Number number39 = timePeriodValue35.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(timePeriod37);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 12.0d + "'", number39.equals(12.0d));
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test12");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        long long4 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        java.util.Date date6 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int11 = timePeriodValues10.getMinEndIndex();
//        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass14 = seriesException13.getClass();
//        java.lang.Class<?> wildcardClass15 = seriesException13.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long19 = simpleTimePeriod18.getStartMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long26 = simpleTimePeriod25.getStartMillis();
//        java.util.Date date27 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year29, (double) 5);
//        long long32 = year29.getSerialIndex();
//        int int33 = simpleTimePeriod2.compareTo((java.lang.Object) year29);
//        java.util.Date date34 = year29.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getLastMillisecond();
//        int int38 = day35.compareTo((java.lang.Object) (-1));
//        long long39 = day35.getLastMillisecond();
//        long long40 = day35.getMiddleMillisecond();
//        long long41 = day35.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day35.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day35.previous();
//        org.jfree.data.time.SerialDate serialDate44 = day35.getSerialDate();
//        boolean boolean45 = year29.equals((java.lang.Object) day35);
//        int int46 = day35.getMonth();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560495599999L + "'", long36 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560452399999L + "'", long40 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43629L + "'", long41 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int4 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
//        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long12 = simpleTimePeriod11.getStartMillis();
//        java.util.Date date13 = simpleTimePeriod11.getEnd();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long19 = simpleTimePeriod18.getStartMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int30 = timePeriodValues29.getMinEndIndex();
//        java.lang.String str31 = timePeriodValues29.getRangeDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long35 = simpleTimePeriod34.getStartMillis();
//        long long36 = simpleTimePeriod34.getStartMillis();
//        java.util.Date date37 = simpleTimePeriod34.getEnd();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (java.lang.Number) 10L);
//        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass42 = seriesException41.getClass();
//        java.lang.String str43 = seriesException41.toString();
//        boolean boolean44 = timePeriodValues29.equals((java.lang.Object) str43);
//        timePeriodValues29.setDescription("13-June-2019");
//        int int47 = timePeriodValues29.getMaxEndIndex();
//        int int48 = timePeriodValues29.getMaxEndIndex();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        boolean boolean51 = day49.equals((java.lang.Object) 1.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day49.next();
//        long long53 = day49.getSerialIndex();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day49, (java.lang.Number) 1560409200000L);
//        int int56 = year22.compareTo((java.lang.Object) timePeriodValues29);
//        try {
//            java.lang.Object obj57 = timePeriodValues29.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str31.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 43629L + "'", long53 == 43629L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setNotify(false);
        int int10 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((-1), (int) (byte) -1);
        int int10 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        timePeriodValues3.setDomainDescription("");
        boolean boolean15 = timePeriodValues3.isEmpty();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int3 = day0.compareTo((java.lang.Object) (-1));
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getMiddleMillisecond();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        long long9 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int14 = timePeriodValues13.getMinEndIndex();
//        java.lang.String str15 = timePeriodValues13.getRangeDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long19 = simpleTimePeriod18.getStartMillis();
//        long long20 = simpleTimePeriod18.getStartMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) 10L);
//        timePeriodValues13.update(0, (java.lang.Number) 3);
//        boolean boolean27 = day0.equals((java.lang.Object) 3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str15.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int3 = day0.compareTo((java.lang.Object) (-1));
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getMiddleMillisecond();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int12 = timePeriodValues11.getMinEndIndex();
//        java.lang.String str13 = timePeriodValues11.getRangeDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long17 = simpleTimePeriod16.getStartMillis();
//        long long18 = simpleTimePeriod16.getStartMillis();
//        java.util.Date date19 = simpleTimePeriod16.getEnd();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 10L);
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass24 = seriesException23.getClass();
//        java.lang.String str25 = seriesException23.toString();
//        boolean boolean26 = timePeriodValues11.equals((java.lang.Object) str25);
//        timePeriodValues11.setDescription("13-June-2019");
//        boolean boolean29 = day0.equals((java.lang.Object) "13-June-2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int34 = timePeriodValues33.getMinEndIndex();
//        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass37 = seriesException36.getClass();
//        java.lang.Class<?> wildcardClass38 = seriesException36.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long42 = simpleTimePeriod41.getStartMillis();
//        java.util.Date date43 = simpleTimePeriod41.getEnd();
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone44);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long49 = simpleTimePeriod48.getStartMillis();
//        java.util.Date date50 = simpleTimePeriod48.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date43, date50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50);
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year52, (double) 5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year52.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long59 = simpleTimePeriod58.getStartMillis();
//        long long60 = simpleTimePeriod58.getStartMillis();
//        java.util.Date date61 = simpleTimePeriod58.getEnd();
//        java.util.Date date62 = simpleTimePeriod58.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int67 = timePeriodValues66.getMinEndIndex();
//        org.jfree.data.general.SeriesException seriesException69 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass70 = seriesException69.getClass();
//        java.lang.Class<?> wildcardClass71 = seriesException69.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long75 = simpleTimePeriod74.getStartMillis();
//        java.util.Date date76 = simpleTimePeriod74.getEnd();
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date76, timeZone77);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long82 = simpleTimePeriod81.getStartMillis();
//        java.util.Date date83 = simpleTimePeriod81.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date76, date83);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date83);
//        timePeriodValues66.add((org.jfree.data.time.TimePeriod) year85, (double) 5);
//        long long88 = year85.getSerialIndex();
//        int int89 = simpleTimePeriod58.compareTo((java.lang.Object) year85);
//        org.jfree.data.time.TimePeriodValue timePeriodValue91 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (double) 12);
//        java.lang.Number number92 = timePeriodValue91.getValue();
//        java.lang.Object obj93 = timePeriodValue91.clone();
//        boolean boolean94 = year52.equals((java.lang.Object) timePeriodValue91);
//        int int95 = day0.compareTo((java.lang.Object) timePeriodValue91);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str25.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 35L + "'", long49 == 35L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 35L + "'", long59 == 35L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 35L + "'", long60 == 35L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 35L + "'", long75 == 35L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 35L + "'", long82 == 35L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1969L + "'", long88 == 1969L);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
//        org.junit.Assert.assertTrue("'" + number92 + "' != '" + 12.0d + "'", number92.equals(12.0d));
//        org.junit.Assert.assertNotNull(obj93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int11 = timePeriodValues10.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass14 = seriesException13.getClass();
        java.lang.Class<?> wildcardClass15 = seriesException13.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long26 = simpleTimePeriod25.getStartMillis();
        java.util.Date date27 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year29, (double) 5);
        long long32 = year29.getSerialIndex();
        int int33 = simpleTimePeriod2.compareTo((java.lang.Object) year29);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 12);
        java.lang.Number number36 = timePeriodValue35.getValue();
        java.lang.Object obj37 = timePeriodValue35.clone();
        java.lang.String str38 = timePeriodValue35.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 12.0d + "'", number36.equals(12.0d));
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        java.lang.Class<?> wildcardClass3 = seriesException1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.Date date8 = simpleTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.util.Date date12 = year11.getStart();
        int int13 = year11.getYear();
        long long14 = year11.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-15739200001L) + "'", long14 == (-15739200001L));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long9 = simpleTimePeriod8.getStartMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass16 = seriesException15.getClass();
        java.lang.String str17 = seriesException15.toString();
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) str17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener19);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue22 = timePeriodValues3.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int11 = timePeriodValues10.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass14 = seriesException13.getClass();
        java.lang.Class<?> wildcardClass15 = seriesException13.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long26 = simpleTimePeriod25.getStartMillis();
        java.util.Date date27 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year29, (double) 5);
        long long32 = year29.getSerialIndex();
        int int33 = simpleTimePeriod2.compareTo((java.lang.Object) year29);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 12);
        java.lang.Number number36 = timePeriodValue35.getValue();
        java.lang.Number number37 = timePeriodValue35.getValue();
        java.lang.String str38 = timePeriodValue35.toString();
        timePeriodValue35.setValue((java.lang.Number) (short) 0);
        timePeriodValue35.setValue((java.lang.Number) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 12.0d + "'", number36.equals(12.0d));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 12.0d + "'", number37.equals(12.0d));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        int int26 = year22.compareTo((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.next();
        java.util.Calendar calendar28 = null;
        try {
            year22.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long9 = simpleTimePeriod8.getStartMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 10L);
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        int int16 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((-1), (int) (byte) -1);
        timePeriodValues9.setDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        int int25 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        int int27 = timePeriodValues3.getMaxStartIndex();
        int int28 = timePeriodValues3.getMinEndIndex();
        java.lang.Comparable comparable29 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int39 = timePeriodValues38.getMinEndIndex();
        java.lang.String str40 = timePeriodValues38.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long44 = simpleTimePeriod43.getStartMillis();
        long long45 = simpleTimePeriod43.getStartMillis();
        java.util.Date date46 = simpleTimePeriod43.getEnd();
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod43, (java.lang.Number) 10L);
        timePeriodValues38.update(0, (java.lang.Number) 3);
        timePeriodValues38.delete((int) (byte) 1, (-1));
        boolean boolean55 = timePeriodValues38.isEmpty();
        int int56 = timePeriodValues38.getMinEndIndex();
        int int57 = timePeriodValues38.getMaxMiddleIndex();
        java.lang.Number number59 = timePeriodValues38.getValue((int) (short) 0);
        java.lang.String str60 = timePeriodValues38.getRangeDescription();
        java.lang.String str61 = timePeriodValues38.getRangeDescription();
        java.lang.String str62 = timePeriodValues38.getDescription();
        boolean boolean63 = simpleTimePeriod32.equals((java.lang.Object) timePeriodValues38);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 10L + "'", comparable29.equals(10L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str40.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35L + "'", long44 == 35L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 3 + "'", number59.equals(3));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str60.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str61.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) 0);
        long long9 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        int int26 = year22.compareTo((java.lang.Object) 10L);
        long long27 = year22.getFirstMillisecond();
        java.lang.Object obj28 = null;
        int int29 = year22.compareTo(obj28);
        long long30 = year22.getLastMillisecond();
        java.util.Date date31 = year22.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]");
        java.lang.String str4 = timePeriodValues3.getRangeDescription();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: ]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        int int25 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setNotify(false);
        int int28 = timePeriodValues3.getMinEndIndex();
        int int29 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass32 = seriesException31.getClass();
        java.lang.Class<?> wildcardClass33 = seriesException31.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long37 = simpleTimePeriod36.getStartMillis();
        java.util.Date date38 = simpleTimePeriod36.getEnd();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date38, timeZone39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long44 = simpleTimePeriod43.getStartMillis();
        java.util.Date date45 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date38, date45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date45);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45);
        long long49 = year48.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 4);
        timePeriodValues3.add(timePeriodValue51);
        java.lang.String str53 = timePeriodValue51.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35L + "'", long44 == 35L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1969L + "'", long49 == 1969L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "TimePeriodValue[1969,4]" + "'", str53.equals("TimePeriodValue[1969,4]"));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-14400001L), (long) ' ');
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long9 = simpleTimePeriod8.getStartMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 10L);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int18 = timePeriodValues17.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass21 = seriesException20.getClass();
        java.lang.Class<?> wildcardClass22 = seriesException20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long26 = simpleTimePeriod25.getStartMillis();
        java.util.Date date27 = simpleTimePeriod25.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long33 = simpleTimePeriod32.getStartMillis();
        java.util.Date date34 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date27, date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year36, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year36.next();
        boolean boolean40 = simpleTimePeriod8.equals((java.lang.Object) regularTimePeriod39);
        java.util.Date date41 = simpleTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long9 = simpleTimePeriod8.getStartMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass16 = seriesException15.getClass();
        java.lang.String str17 = seriesException15.toString();
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) str17);
        timePeriodValues3.setDescription("13-June-2019");
        int int21 = timePeriodValues3.getMaxEndIndex();
        int int22 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy(11, (int) (short) 10);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues3.createCopy(7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int4 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
//        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long12 = simpleTimePeriod11.getStartMillis();
//        java.util.Date date13 = simpleTimePeriod11.getEnd();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long19 = simpleTimePeriod18.getStartMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
//        int int25 = timePeriodValues3.getMaxMiddleIndex();
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener27);
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getLastMillisecond();
//        int int37 = day34.compareTo((java.lang.Object) (-1));
//        long long38 = day34.getSerialIndex();
//        int int39 = day34.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day34, (double) (byte) 1);
//        int int42 = timePeriodValues3.getMaxStartIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560495599999L + "'", long35 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43629L + "'", long38 == 43629L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test38");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int3 = day0.compareTo((java.lang.Object) (-1));
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        java.util.Date date8 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
//        int int4 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
//        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long12 = simpleTimePeriod11.getStartMillis();
//        java.util.Date date13 = simpleTimePeriod11.getEnd();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long19 = simpleTimePeriod18.getStartMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
//        timePeriodValues3.setDescription("hi!");
//        int int27 = timePeriodValues3.getMinMiddleIndex();
//        int int28 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getLastMillisecond();
//        int int32 = day29.compareTo((java.lang.Object) (-1));
//        long long33 = day29.getLastMillisecond();
//        int int34 = day29.getDayOfMonth();
//        long long35 = day29.getMiddleMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 10L);
//        int int38 = timePeriodValues3.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 13 + "'", int34 == 13);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560452399999L + "'", long35 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        java.lang.Class<?> wildcardClass3 = seriesException1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long7 = simpleTimePeriod6.getStartMillis();
        java.util.Date date8 = simpleTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date8, date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
        java.util.Date date22 = day19.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        boolean boolean9 = year7.equals((java.lang.Object) 1969L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        int int6 = timePeriodValues3.getMinStartIndex();
        boolean boolean7 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodValues3.delete(1969, 31);
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10L + "'", comparable13.equals(10L));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int12 = timePeriodValues11.getMinEndIndex();
        java.lang.String str13 = timePeriodValues11.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long17 = simpleTimePeriod16.getStartMillis();
        long long18 = simpleTimePeriod16.getStartMillis();
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 10L);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int26 = timePeriodValues25.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass29 = seriesException28.getClass();
        java.lang.Class<?> wildcardClass30 = seriesException28.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long34 = simpleTimePeriod33.getStartMillis();
        java.util.Date date35 = simpleTimePeriod33.getEnd();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date35, timeZone36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long41 = simpleTimePeriod40.getStartMillis();
        java.util.Date date42 = simpleTimePeriod40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date35, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year44, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.next();
        boolean boolean48 = simpleTimePeriod16.equals((java.lang.Object) regularTimePeriod47);
        java.lang.Number number49 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod47, number49);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long56 = simpleTimePeriod55.getStartMillis();
        long long57 = simpleTimePeriod55.getStartMillis();
        java.util.Date date58 = simpleTimePeriod55.getEnd();
        java.util.Date date59 = simpleTimePeriod55.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int64 = timePeriodValues63.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException66 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass67 = seriesException66.getClass();
        java.lang.Class<?> wildcardClass68 = seriesException66.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long72 = simpleTimePeriod71.getStartMillis();
        java.util.Date date73 = simpleTimePeriod71.getEnd();
        java.util.TimeZone timeZone74 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date73, timeZone74);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod78 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long79 = simpleTimePeriod78.getStartMillis();
        java.util.Date date80 = simpleTimePeriod78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod(date73, date80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80);
        timePeriodValues63.add((org.jfree.data.time.TimePeriod) year82, (double) 5);
        long long85 = year82.getSerialIndex();
        int int86 = simpleTimePeriod55.compareTo((java.lang.Object) year82);
        org.jfree.data.time.TimePeriodValue timePeriodValue88 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod55, (double) 12);
        java.lang.Number number89 = timePeriodValue88.getValue();
        java.lang.Object obj90 = timePeriodValue88.clone();
        timePeriodValue88.setValue((java.lang.Number) 12.0d);
        timePeriodValue88.setValue((java.lang.Number) (-1.0f));
        timePeriodValues3.add(timePeriodValue88);
        java.lang.String str96 = timePeriodValue88.toString();
        java.lang.Object obj97 = timePeriodValue88.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 35L + "'", long56 == 35L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 35L + "'", long57 == 35L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 35L + "'", long72 == 35L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 35L + "'", long79 == 35L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1969L + "'", long85 == 1969L);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + 12.0d + "'", number89.equals(12.0d));
        org.junit.Assert.assertNotNull(obj90);
        org.junit.Assert.assertNotNull(obj97);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        java.lang.Class<?> wildcardClass8 = seriesException6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
        boolean boolean27 = year22.equals((java.lang.Object) 35L);
        int int28 = year22.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
        timePeriodValue30.setValue((java.lang.Number) (byte) 0);
        java.lang.Object obj33 = null;
        boolean boolean34 = timePeriodValue30.equals(obj33);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L, "org.jfree.data.general.SeriesChangeEvent[source=0]", "org.jfree.data.general.SeriesException: ");
        int int11 = timePeriodValues10.getMinEndIndex();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass14 = seriesException13.getClass();
        java.lang.Class<?> wildcardClass15 = seriesException13.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
        long long26 = simpleTimePeriod25.getStartMillis();
        java.util.Date date27 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year29, (double) 5);
        long long32 = year29.getSerialIndex();
        int int33 = simpleTimePeriod2.compareTo((java.lang.Object) year29);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 12);
        java.lang.Number number36 = timePeriodValue35.getValue();
        java.lang.Object obj37 = timePeriodValue35.clone();
        java.lang.Number number38 = null;
        timePeriodValue35.setValue(number38);
        timePeriodValue35.setValue((java.lang.Number) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 12.0d + "'", number36.equals(12.0d));
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray3 = seriesException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException2.getSuppressed();
        boolean boolean5 = year0.equals((java.lang.Object) seriesException2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test47");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getLastMillisecond();
//        int int4 = day1.compareTo((java.lang.Object) (-1));
//        long long5 = day1.getLastMillisecond();
//        long long6 = day1.getMiddleMillisecond();
//        java.util.Date date7 = day1.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long11 = simpleTimePeriod10.getStartMillis();
//        java.util.Date date12 = simpleTimePeriod10.getEnd();
//        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass15 = seriesException14.getClass();
//        java.lang.Class<?> wildcardClass16 = seriesException14.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long20 = simpleTimePeriod19.getStartMillis();
//        java.util.Date date21 = simpleTimePeriod19.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long27 = simpleTimePeriod26.getStartMillis();
//        java.util.Date date28 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date21, date28);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date12, date21);
//        int int31 = day1.compareTo((java.lang.Object) date21);
//        java.util.Date date32 = day1.getEnd();
//        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass35 = seriesException34.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long39 = simpleTimePeriod38.getStartMillis();
//        long long40 = simpleTimePeriod38.getStartMillis();
//        java.util.Date date41 = simpleTimePeriod38.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long48 = simpleTimePeriod47.getStartMillis();
//        long long49 = simpleTimePeriod47.getStartMillis();
//        java.util.Date date50 = simpleTimePeriod47.getEnd();
//        boolean boolean51 = year43.equals((java.lang.Object) date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date50, timeZone52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        long long55 = day54.getLastMillisecond();
//        int int57 = day54.compareTo((java.lang.Object) (-1));
//        long long58 = day54.getLastMillisecond();
//        long long59 = day54.getMiddleMillisecond();
//        java.util.Date date60 = day54.getEnd();
//        org.jfree.data.general.SeriesException seriesException62 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass63 = seriesException62.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long67 = simpleTimePeriod66.getStartMillis();
//        long long68 = simpleTimePeriod66.getStartMillis();
//        java.util.Date date69 = simpleTimePeriod66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year71.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) 100);
//        long long76 = simpleTimePeriod75.getStartMillis();
//        long long77 = simpleTimePeriod75.getStartMillis();
//        java.util.Date date78 = simpleTimePeriod75.getEnd();
//        boolean boolean79 = year71.equals((java.lang.Object) date78);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date78, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date60, timeZone80);
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date60, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date32, timeZone83);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 35L + "'", long48 == 35L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 35L + "'", long49 == 35L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560495599999L + "'", long55 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560495599999L + "'", long58 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560452399999L + "'", long59 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 35L + "'", long67 == 35L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 35L + "'", long68 == 35L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 35L + "'", long76 == 35L);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 35L + "'", long77 == 35L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//    }
//}

