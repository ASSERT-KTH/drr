import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test002");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) (-1), (java.lang.Object) 1L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { 1, 100L, 1, (short) 0, '#', (-1) };
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        try {
            java.util.Date date3 = dateTickUnit0.addToDate(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        java.awt.Stroke stroke3 = null;
        try {
            minMaxCategoryRenderer0.setBaseOutlineStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "", "");
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            xYPlot0.drawBackground(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.Number number11 = boxAndWhiskerItem9.getMinOutlier();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        legendTitle6.setNotify(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.lang.Object obj12 = legendTitle6.draw(graphics2D9, rectangle2D10, (java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) '#', (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean2 = standardCategoryToolTipGenerator0.equals((java.lang.Object) categoryLabelPositions1);
        java.lang.Object obj3 = standardCategoryToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Font font2 = null;
        minMaxCategoryRenderer0.setSeriesItemLabelFont(10, font2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ThreadContext", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        try {
            java.awt.Paint paint4 = xYPlot0.getQuadrantPaint((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        double double3 = stackedBarRenderer3D2.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot5.getRangeMarkers(layer9);
        java.awt.Stroke stroke11 = xYPlot5.getDomainCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color1, stroke3, (java.awt.Paint) color4, stroke11, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = null;
        try {
            minMaxCategoryRenderer0.setMaxIcon(icon1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange6);
        try {
            org.jfree.chart.util.Size2D size2D8 = labelBlock1.arrange(graphics2D2, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("ThreadContext");
        java.awt.Image image3 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        boolean boolean3 = minMaxCategoryRenderer0.getAutoPopulateSeriesOutlineStroke();
        javax.swing.Icon icon4 = null;
        try {
            minMaxCategoryRenderer0.setMaxIcon(icon4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ThreadContext\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        legendItemEntity3.setSeriesKey((java.lang.Comparable) ' ');
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) (short) 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
        java.lang.Object obj4 = standardCategoryURLGenerator3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("ThreadContext", graphics2D1, (float) 100, (float) (short) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape6 = minMaxCategoryRenderer4.lookupSeriesShape((int) (short) 0);
        java.awt.Color color7 = java.awt.Color.blue;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "ThreadContext", "hi!", shape6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp((double) 'a');
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets11.getBottom();
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets11.getUnitType();
        try {
            java.lang.Object obj14 = legendGraphic8.draw(graphics2D9, rectangle2D10, (java.lang.Object) unitType13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getColumnKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Last", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        piePlot3D1.setLabelOutlinePaint(paint8);
        double double10 = piePlot3D1.getShadowYOffset();
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, (float) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((-460), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange3);
        java.lang.String str5 = rectangleConstraint4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            legendGraphic8.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        int int4 = stackedBarRenderer3D2.getColumnCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape4, (double) 13, 0.0f, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        levelRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) ' ', (int) 'a', (int) 'a', 0, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.setValue((java.lang.Number) 1L, (java.lang.Comparable) (short) 100, (java.lang.Comparable) 1);
        org.jfree.data.KeyToGroupMap keyToGroupMap6 = null;
        try {
            org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, keyToGroupMap6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.blue;
        int int3 = color2.getRed();
        try {
            org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("ThreadContext", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) rectangleEdge2);
        int int5 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D2.setItemMargin((double) 100);
        int int6 = stackedBarRenderer3D2.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        boolean boolean3 = minMaxCategoryRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.lang.Boolean boolean5 = minMaxCategoryRenderer0.getSeriesCreateEntities((int) (short) 10);
        java.awt.Stroke stroke6 = null;
        minMaxCategoryRenderer0.setGroupStroke(stroke6);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext");
        java.lang.Object obj2 = standardCategoryURLGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getFillPaint();
        java.lang.Object obj12 = legendGraphic8.clone();
        boolean boolean13 = legendGraphic8.isShapeVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-1.0f), (double) (byte) 0, (int) (short) 1, (java.lang.Comparable) (-8355712));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 4.0d, 1.0d, 0.0d, (double) 1);
        double double7 = rectangleInsets5.trimWidth((double) 100L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-100.0d) + "'", double7 == (-100.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str4 = legendItemEntity3.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10" + "'", str4.equals("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot0.getRangeMarkers(layer8);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Last");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean2 = standardCategoryToolTipGenerator0.equals((java.lang.Object) categoryLabelPositions1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset4.getGroup();
        defaultCategoryDataset3.setGroup(datasetGroup5);
        try {
            java.lang.String str8 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, (java.lang.Boolean) true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = minMaxCategoryRenderer0.getURLGenerator(4, 0);
        java.awt.Color color10 = java.awt.Color.gray;
        try {
            minMaxCategoryRenderer0.setSeriesOutlinePaint((-457), (java.awt.Paint) color10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape9 = textBlock1.calculateBounds(graphics2D2, (float) 'a', (float) 4, textBlockAnchor5, (float) 10, 0.0f, (-1.0d));
        boolean boolean11 = textBlockAnchor5.equals((java.lang.Object) 10.0d);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType12 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor5, categoryLabelWidthType12, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint10 = null;
        try {
            xYPlot0.setDomainZeroBaselinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (-460));
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) 10, (double) 1, (-1));
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        xYPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        try {
            xYPlot0.setQuadrantPaint(68, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimHeight((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "ThreadContext");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        double double10 = rectangleInsets7.trimHeight((double) (-1.0f));
        double double12 = rectangleInsets7.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-3.0d) + "'", double10 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 10, 90.0d);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisible(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        try {
            stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition((int) (byte) -1, itemLabelPosition6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getEndValue((java.lang.Comparable) "", (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, 1.0d, 1.0f, 0.0f);
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color10);
        try {
            java.awt.GradientPaint gradientPaint12 = standardGradientPaintTransformer0.transform(gradientPaint2, shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions4, categoryLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker6.setLabelTextAnchor(textAnchor7);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getUseOutlinePaint();
        statisticalLineAndShapeRenderer13.setUseOutlinePaint(true);
        boolean boolean17 = textAnchor10.equals((java.lang.Object) true);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 1.0f, (float) 4, textAnchor7, (double) (short) 100, textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot4.getRangeCrosshairPaint();
        boolean boolean11 = xYPlot4.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot13.setLegendItemShape(shape16);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot4, (java.lang.Object) piePlot13);
        java.awt.Paint paint19 = piePlot13.getBaseSectionOutlinePaint();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke21 = lineBorder20.getStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 0, paint1, stroke3, paint19, stroke21, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        piePlot14.setMaximumLabelWidth((double) (-457));
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState24 = piePlot1.initialise(graphics2D12, rectangle2D13, piePlot14, (java.lang.Integer) 1, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (-460));
        try {
            java.lang.Number number6 = defaultCategoryDataset0.getValue(15, (-8355712));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color0 = java.awt.Color.blue;
        float[] floatArray4 = new float[] { 10L, (short) 1, 1.0f };
        try {
            float[] floatArray5 = color0.getRGBComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedBarRenderer3D2.drawOutline(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.Number number11 = boxAndWhiskerItem9.getMaxOutlier();
        java.lang.Number number12 = boxAndWhiskerItem9.getMedian();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 60000L + "'", number12.equals(60000L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-1.0f));
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getRowKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Comparable comparable2 = taskSeriesCollection0.getRowKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot8.setLegendItemShape(shape11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke6, jFreeChart13, (int) (short) 0, (int) (byte) -1);
        try {
            org.jfree.chart.plot.XYPlot xYPlot19 = jFreeChart13.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = stackedBarRenderer3D2.initialise(graphics2D7, rectangle2D8, categoryPlot9, (-1), plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled((int) '#', false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        xYPlot0.setRangeAxes(valueAxisArray8);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape3 = minMaxCategoryRenderer1.lookupSeriesShape((int) (short) 0);
        org.jfree.chart.LegendItem legendItem6 = minMaxCategoryRenderer1.getLegendItem((int) ' ', (int) (short) -1);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        try {
            double double10 = piePlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 10, 90.0d);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisible(0);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        try {
            stackedBarRenderer3D2.setSeriesPaint((-460), paint6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, 1.0d, 1.0f, 0.0f);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "Last", shape10, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset(15);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        boolean boolean9 = xYPlot2.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot2.getDomainAxisLocation();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot2.getDomainAxisEdge();
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        double double5 = piePlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = null;
        piePlot9.setLegendLabelToolTipGenerator(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = waterfallBarRenderer0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = waterfallBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = waterfallBarRenderer0.getSeriesItemLabelGenerator(100);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation2, plotOrientation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        double double3 = levelRenderer0.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Paint paint12 = xYPlot6.getRangeCrosshairPaint();
        piePlot3D5.setLabelOutlinePaint(paint12);
        levelRenderer0.setBaseOutlinePaint(paint12, false);
        levelRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        int int3 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue(0, (-8355712));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        legendTitle12.setItemLabelPadding(rectangleInsets16);
        boolean boolean18 = legendTitle12.getNotify();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot12.setLegendItemShape(shape15);
        java.awt.Paint paint17 = piePlot12.getLabelPaint();
        try {
            xYPlot0.setQuadrantPaint(13, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Last", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean8 = statisticalLineAndShapeRenderer7.getUseOutlinePaint();
        statisticalLineAndShapeRenderer7.setUseOutlinePaint(true);
        boolean boolean11 = textAnchor4.equals((java.lang.Object) true);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("HorizontalAlignment.CENTER", graphics2D1, (float) 'a', (float) (byte) 100, textAnchor4, (double) 100.0f, (float) (byte) 10, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo1.setCopyright("ThreadContext");
        projectInfo1.addOptionalLibrary("TextBlockAnchor.CENTER_LEFT");
        boolean boolean6 = datasetRenderingOrder0.equals((java.lang.Object) "TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        boolean boolean3 = minMaxCategoryRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape15 = textBlock7.calculateBounds(graphics2D8, (float) 'a', (float) 4, textBlockAnchor11, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer6.setBaseShape(shape15);
        minMaxCategoryRenderer0.setBaseShape(shape15, true);
        java.lang.Boolean boolean20 = minMaxCategoryRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color25 = java.awt.Color.gray;
        stackedBarRenderer3D23.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color25, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = null;
        stackedBarRenderer3D23.setLegendItemToolTipGenerator(categorySeriesLabelGenerator28);
        stackedBarRenderer3D23.setBaseCreateEntities(false, false);
        stackedBarRenderer3D23.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D23.getBasePositiveItemLabelPosition();
        minMaxCategoryRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition35);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(13, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 6);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", graphics2D1, (float) (-8355712), (float) (-8355712), (double) 10, (float) (short) 100, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) rectangleEdge2);
        try {
            defaultKeyedValues2D1.removeColumn((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        int int3 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getValue((java.lang.Comparable) 1.0f, (java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        legendTitle6.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle6.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets10.getBottom();
        legendTitle6.setPadding(rectangleInsets10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle6.getLegendItemGraphicAnchor();
        java.lang.String str14 = rectangleAnchor13.toString();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleAnchor.CENTER" + "'", str14.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsGroupSize();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        int int3 = segmentedTimeline0.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke17 = lineBorder16.getStroke();
        xYPlot12.setRangeGridlineStroke(stroke17);
        minMaxCategoryRenderer11.setGroupStroke(stroke17);
        xYPlot0.setDomainGridlineStroke(stroke17);
        org.jfree.chart.plot.Plot plot21 = xYPlot0.getParent();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(plot21);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        intervalMarker2.setEndValue((double) 68);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        xYPlot0.setRangeGridlineStroke(stroke5);
        xYPlot0.clearDomainMarkers(5);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        double double14 = stackedBarRenderer3D2.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) (byte) -1, (float) ' ', (float) 9999);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ThreadContext", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        int int3 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getStartValue((int) (short) 0, 8, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        try {
            piePlot1.setInteriorGap((double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (32.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 'a', (float) 4, textBlockAnchor4, (float) 10, 0.0f, (-1.0d));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textBlock0.getLineAlignment();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        java.util.List list2 = axisState0.getTicks();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font10);
        boolean boolean12 = stackedBarRenderer3D2.equals((java.lang.Object) font10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { '4', 1L };
        double[] doubleArray10 = new double[] { 90.0d, 10.0f, 4.0d, (short) 100, 60000L, (-8355712) };
        double[] doubleArray17 = new double[] { 90.0d, 10.0f, 4.0d, (short) 100, 60000L, (-8355712) };
        double[] doubleArray24 = new double[] { 90.0d, 10.0f, 4.0d, (short) 100, 60000L, (-8355712) };
        double[] doubleArray31 = new double[] { 90.0d, 10.0f, 4.0d, (short) 100, 60000L, (-8355712) };
        double[] doubleArray38 = new double[] { 90.0d, 10.0f, 4.0d, (short) 100, 60000L, (-8355712) };
        double[] doubleArray45 = new double[] { 90.0d, 10.0f, 4.0d, (short) 100, 60000L, (-8355712) };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray3, doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        boolean boolean5 = xYPlot1.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range9 = rectangleConstraint8.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint8.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D11 = labelBlock2.arrange(graphics2D3, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("hi!");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range7 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, (double) 0.0f, (double) (short) 0);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = dateRange3.equals((java.lang.Object) color8);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) (byte) 1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart8.setPadding(rectangleInsets9);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.event.ChartChangeListener chartChangeListener12 = null;
        try {
            jFreeChart8.removeChangeListener(chartChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 6, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        java.lang.Boolean boolean7 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible((-460));
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle6.setWrapper(blockContainer7);
        boolean boolean9 = legendTitle6.getNotify();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        boolean boolean9 = stackedBarRenderer3D2.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        boolean boolean9 = xYPlot2.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot2.getDomainAxisLocation();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot2);
        xYPlot2.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Stroke stroke11 = legendGraphic8.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor4, textAnchor5, (double) (-460));
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor4, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color1);
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot4.setLegendItemShape(shape7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Paint paint10 = piePlot4.getLabelPaint();
        waterfallBarRenderer0.setBaseFillPaint(paint10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        piePlot1.setMaximumLabelWidth((double) 60000L);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        int int4 = stackedBarRenderer3D2.getColumnCount();
        boolean boolean7 = stackedBarRenderer3D2.isItemLabelVisible((int) (byte) 10, 15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        defaultCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        java.awt.Color color23 = java.awt.Color.yellow;
        xYPlot18.setDomainCrosshairPaint((java.awt.Paint) color23);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot18.getDomainAxisForDataset(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { "hi!", "RectangleAnchor.CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]" };
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        piePlot9.setMaximumLabelWidth((double) (-457));
        boolean boolean16 = numberTickUnit8.equals((java.lang.Object) piePlot9);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        xYPlot17.setDomainAxes(valueAxisArray19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getRangeMarkers(layer21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot17);
        org.jfree.chart.block.BlockContainer blockContainer24 = null;
        legendTitle23.setWrapper(blockContainer24);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle23.getBounds();
        boolean boolean27 = numberTickUnit8.equals((java.lang.Object) rectangle2D26);
        java.lang.Comparable[] comparableArray28 = new java.lang.Comparable[] { (byte) 10, "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", numberTickUnit8 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 68, (-460), 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 68, (-460), 100 };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray32, numberArray36 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] {};
        java.lang.Number[] numberArray39 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray38, numberArray39 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset41 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray3, comparableArray28, numberArray37, numberArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(comparableArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D2.getBasePositiveItemLabelPosition();
        boolean boolean16 = stackedBarRenderer3D2.isSeriesItemLabelsVisible((int) '4');
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range19, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange26);
        org.jfree.data.Range range30 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange26, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange34);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = rectangleConstraint35.getWidthConstraintType();
        org.jfree.data.Range range40 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType41 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range30, lengthConstraintType36, (double) 6, range40, lengthConstraintType41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) '4', range8, lengthConstraintType15, (double) 0.0f, range19, lengthConstraintType41);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(lengthConstraintType41);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        xYPlot7.setDomainAxes(valueAxisArray9);
        xYPlot0.setDomainAxes(valueAxisArray9);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        int int13 = xYPlot0.indexOf(xYDataset12);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        xYPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        xYPlot4.setRangeGridlineStroke(stroke9);
        piePlot3D3.setLabelLinkStroke(stroke9);
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) piePlot3D3);
        java.lang.String str13 = datasetGroup1.getID();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "NOID" + "'", str13.equals("NOID"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets2.getBottom();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets2.getUnitType();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        labelBlock1.setPadding(rectangleInsets2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        xYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot10.getRangeMarkers(layer14);
        java.awt.Paint paint16 = xYPlot10.getRangeCrosshairPaint();
        piePlot3D9.setLabelOutlinePaint(paint16);
        boolean boolean18 = labelBlock1.equals((java.lang.Object) paint16);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot22.setLegendItemShape(shape25);
        piePlot22.setMaximumLabelWidth((double) (-457));
        boolean boolean29 = numberTickUnit21.equals((java.lang.Object) piePlot22);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        xYPlot30.setDomainAxes(valueAxisArray32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getRangeMarkers(layer34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot30);
        org.jfree.chart.block.BlockContainer blockContainer37 = null;
        legendTitle36.setWrapper(blockContainer37);
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        boolean boolean40 = numberTickUnit21.equals((java.lang.Object) rectangle2D39);
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot42.setLegendItemShape(shape45);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot42);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart47.setPadding(rectangleInsets48);
        jFreeChart47.setAntiAlias(true);
        boolean boolean52 = jFreeChart47.isBorderVisible();
        try {
            java.lang.Object obj53 = labelBlock1.draw(graphics2D19, rectangle2D39, (java.lang.Object) boolean52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        xYPlot4.setRangeGridlineStroke(stroke9);
        piePlot3D3.setLabelLinkStroke(stroke9);
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) piePlot3D3);
        java.awt.Stroke stroke14 = piePlot3D3.getSectionOutlineStroke((java.lang.Comparable) 10L);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { valueAxis16 };
        xYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot15.getRangeMarkers(layer19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot15);
        float float22 = xYPlot15.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot15.drawBackgroundImage(graphics2D23, rectangle2D24);
        xYPlot15.clearAnnotations();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot15.setDomainGridlinePaint((java.awt.Paint) color27);
        piePlot3D3.setLabelPaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer2.getItemFillPaint(10, 96);
        boolean boolean15 = statisticalLineAndShapeRenderer2.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        defaultCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { valueAxis24 };
        xYPlot23.setDomainAxes(valueAxisArray25);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = xYPlot23.getRangeMarkers(layer27);
        java.awt.Paint paint29 = xYPlot23.getRangeCrosshairPaint();
        xYPlot18.setRangeGridlinePaint(paint29);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor6, textAnchor7, (double) (-460));
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {3} - {4}", graphics2D1, (float) 3, 0.0f, textAnchor6, (double) 1900, 0.0f, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        statisticalLineAndShapeRenderer2.setBaseStroke(stroke7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        stackedBarRenderer3D2.setBaseOutlinePaint(paint9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultCategoryDataset11.getGroup();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (-460));
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.KeyToGroupMap keyToGroupMap16 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, keyToGroupMap16);
        java.util.List list18 = keyToGroupMap16.getGroups();
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        java.awt.Paint paint9 = xYPlot0.getDomainGridlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset11.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot12);
        java.awt.Image image16 = null;
        xYPlot12.setBackgroundImage(image16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(axisLocation18);
        xYPlot0.setDomainAxisLocation((int) '#', axisLocation18);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("ThreadContext");
        projectInfo0.addOptionalLibrary("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = stackedBarRenderer3D2.getURLGenerator((-1), (int) 'a');
        double double7 = stackedBarRenderer3D2.getYOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        defaultCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        java.awt.Color color23 = java.awt.Color.yellow;
        xYPlot18.setDomainCrosshairPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getRangeAxisEdge((int) (byte) 0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator7);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer2.getBaseOutlinePaint();
        java.awt.Paint paint12 = statisticalLineAndShapeRenderer2.getItemLabelPaint(9999, 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot6.setLegendItemShape(shape9);
        piePlot6.setMaximumLabelWidth((double) (-457));
        boolean boolean13 = numberTickUnit5.equals((java.lang.Object) piePlot6);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        xYPlot14.setDomainAxes(valueAxisArray16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getRangeMarkers(layer18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot14);
        org.jfree.chart.block.BlockContainer blockContainer21 = null;
        legendTitle20.setWrapper(blockContainer21);
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        boolean boolean24 = numberTickUnit5.equals((java.lang.Object) rectangle2D23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        try {
            java.lang.Object obj26 = labelBlock2.draw(graphics2D3, rectangle2D23, (java.lang.Object) itemLabelAnchor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        java.lang.String str2 = projectInfo0.getCopyright();
        projectInfo0.setVersion("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getOutlinePaint();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range15 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range15, (double) (short) 0);
        try {
            org.jfree.chart.util.Size2D size2D18 = legendGraphic8.arrange(graphics2D12, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        xYPlot3.setRangeCrosshairValue(0.0d);
        boolean boolean9 = chartChangeEventType2.equals((java.lang.Object) xYPlot3);
        chartChangeEvent1.setType(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.centerRange((double) (byte) -1);
        numberAxis0.setLowerBound((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange43);
        org.jfree.data.Range range47 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange43, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange51 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange51);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType53 = rectangleConstraint52.getWidthConstraintType();
        org.jfree.data.Range range57 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType58 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range47, lengthConstraintType53, (double) 6, range57, lengthConstraintType58);
        org.jfree.data.time.DateRange dateRange63 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange63);
        org.jfree.data.Range range67 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange63, (double) 0.0f, (double) (short) 0);
        java.awt.Color color68 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean69 = dateRange63.equals((java.lang.Object) color68);
        org.jfree.data.Range range70 = org.jfree.data.Range.combine(range57, (org.jfree.data.Range) dateRange63);
        numberAxis38.setDefaultAutoRange((org.jfree.data.Range) dateRange63);
        org.jfree.data.RangeType rangeType72 = numberAxis38.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit74 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot75 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape78 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot75.setLegendItemShape(shape78);
        piePlot75.setMaximumLabelWidth((double) (-457));
        boolean boolean82 = numberTickUnit74.equals((java.lang.Object) piePlot75);
        numberAxis38.setTickUnit(numberTickUnit74);
        org.jfree.data.Range range84 = numberAxis38.getDefaultAutoRange();
        numberAxis0.setRange(range84);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(lengthConstraintType53);
        org.junit.Assert.assertNotNull(lengthConstraintType58);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(rangeType72);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(range84);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Paint paint6 = stackedBarRenderer3D2.getSeriesPaint(0);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        xYPlot11.setRangeCrosshairValue(0.0d);
        boolean boolean17 = boxAndWhiskerItem9.equals((java.lang.Object) xYPlot11);
        java.lang.String str18 = boxAndWhiskerItem9.toString();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(layer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle24.setWrapper(blockContainer25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        try {
            jFreeChart10.addSubtitle(68, (org.jfree.chart.title.Title) legendTitle24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        xYPlot18.setRangeGridlineStroke(stroke23);
        minMaxCategoryRenderer17.setGroupStroke(stroke23);
        jFreeChart10.setBorderStroke(stroke23);
        org.jfree.chart.event.ChartChangeListener chartChangeListener27 = null;
        try {
            jFreeChart10.removeChangeListener(chartChangeListener27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(15, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        java.text.DateFormat dateFormat5 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(2, 1, (-8355712), (int) (short) 100, dateFormat5);
        boolean boolean7 = areaRendererEndType0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.util.Rotation rotation15 = piePlot9.getDirection();
        org.jfree.data.general.PieDataset pieDataset16 = piePlot9.getDataset();
        java.lang.Comparable comparable17 = null;
        try {
            double double18 = piePlot9.getExplodePercent(comparable17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(pieDataset16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10, (double) (byte) 1, (double) 1, (double) (byte) -1, (java.awt.Paint) color4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        boolean boolean3 = areaRendererEndType0.equals((java.lang.Object) standardGradientPaintTransformer1);
        java.lang.String str4 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str4.equals("AreaRendererEndType.LEVEL"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getRangeMarkers(layer15);
        java.awt.Stroke stroke17 = xYPlot11.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart24.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke17, jFreeChart24, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle30 = null;
        jFreeChart24.setTitle(textTitle30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        xYPlot32.setDomainAxes(valueAxisArray34);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = xYPlot32.getRangeMarkers(layer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        xYPlot32.drawRangeTickBands(graphics2D38, rectangle2D39, list40);
        xYPlot32.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer43 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray46 = new org.jfree.chart.axis.ValueAxis[] { valueAxis45 };
        xYPlot44.setDomainAxes(valueAxisArray46);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke49 = lineBorder48.getStroke();
        xYPlot44.setRangeGridlineStroke(stroke49);
        minMaxCategoryRenderer43.setGroupStroke(stroke49);
        xYPlot32.setDomainGridlineStroke(stroke49);
        jFreeChart24.setBorderStroke(stroke49);
        java.awt.Paint paint54 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape10, stroke49, paint54);
        try {
            stackedBarRenderer3D2.setSeriesPaint((int) (byte) -1, paint54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(legendTitle26);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(valueAxisArray46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(textLine8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getRenderAsPercentages();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            stackedBarRenderer0.drawDomainGridline(graphics2D2, categoryPlot3, rectangle2D4, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.Date date4 = segment3.getDate();
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("Last", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", image8, "ThreadContext", "ThreadContext", "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10");
        try {
            int int13 = segment3.compareTo((java.lang.Object) "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        boolean boolean4 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape3);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int2 = segmentedTimeline1.getSegmentsExcluded();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
        java.util.Date date5 = segment4.getDate();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        try {
            org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("NOID", date5, date10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset1);
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot4.setLegendItemShape(shape7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Paint paint10 = piePlot4.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot4.setToolTipGenerator(pieToolTipGenerator11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot4.setLabelBackgroundPaint((java.awt.Paint) color13);
        boolean boolean15 = groupedStackedBarRenderer0.equals((java.lang.Object) piePlot4);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(layer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle24.setWrapper(blockContainer25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup34 = defaultCategoryDataset33.getGroup();
        defaultCategoryDataset32.setGroup(datasetGroup34);
        org.jfree.data.general.DatasetGroup datasetGroup36 = defaultCategoryDataset32.getGroup();
        try {
            groupedStackedBarRenderer0.drawItem(graphics2D16, categoryItemRendererState17, rectangle2D27, categoryPlot28, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, valueAxis31, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset32, 0, 8, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(datasetGroup34);
        org.junit.Assert.assertNotNull(datasetGroup36);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor2, textAnchor3, (double) (-460));
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getTextAnchor();
        java.lang.String str7 = numberTick5.getText();
        double double8 = numberTick5.getValue();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str7.equals("GradientPaintTransformType.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-100.0d) + "'", double8 == (-100.0d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        intervalBarRenderer1.setSeriesItemLabelGenerator(12, categoryItemLabelGenerator3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke5 = null;
        try {
            xYPlot0.setDomainZeroBaselineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        java.awt.Stroke stroke10 = piePlot2.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.util.Rotation rotation15 = piePlot9.getDirection();
        org.jfree.data.general.PieDataset pieDataset16 = piePlot9.getDataset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = null;
        piePlot9.setLabelGenerator(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(pieDataset16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
        float float5 = categoryLabelPosition1.getWidthRatio();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getWidthConstraintType();
        org.jfree.data.Range range24 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range14, lengthConstraintType20, (double) 6, range24, lengthConstraintType25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint4.toRangeHeight(range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint27.getWidthConstraintType();
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj6 = null;
        boolean boolean7 = taskSeriesCollection5.equals(obj6);
        boolean boolean8 = stackedBarRenderer3D2.hasListener((java.util.EventListener) taskSeriesCollection5);
        try {
            java.lang.Number number12 = taskSeriesCollection5.getPercentComplete(9, (int) (byte) -1, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj21 = null;
        boolean boolean22 = taskSeriesCollection20.equals(obj21);
        taskSeriesCollection20.removeAll();
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection20);
        try {
            java.lang.Number number28 = taskSeriesCollection20.getStartValue(0, 8, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        intervalMarker2.setLabel("HorizontalAlignment.CENTER");
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot9.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        xYPlot9.clearRangeMarkers();
        boolean boolean20 = xYPlot9.isRangeZoomable();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        boolean boolean22 = xYPlot9.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot9.setRenderer((int) (short) 1, xYItemRenderer24, true);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue8 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "hi!", (java.lang.Number) 1L);
        java.lang.Comparable comparable9 = defaultKeyedValue8.getKey();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot10.setLegendItemShape(shape13);
        java.awt.Paint paint15 = piePlot10.getLabelPaint();
        boolean boolean16 = defaultKeyedValue8.equals((java.lang.Object) paint15);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("", font3, paint15);
        float float18 = textFragment17.getBaselineOffset();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "hi!" + "'", comparable9.equals("hi!"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        boolean boolean44 = numberTickUnit36.equals((java.lang.Object) piePlot37);
        numberAxis0.setTickUnit(numberTickUnit36);
        boolean boolean46 = numberAxis0.isPositiveArrowVisible();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit50 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot51.setLegendItemShape(shape54);
        piePlot51.setMaximumLabelWidth((double) (-457));
        boolean boolean58 = numberTickUnit50.equals((java.lang.Object) piePlot51);
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] { valueAxis60 };
        xYPlot59.setDomainAxes(valueAxisArray61);
        org.jfree.chart.util.Layer layer63 = null;
        java.util.Collection collection64 = xYPlot59.getRangeMarkers(layer63);
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot59);
        org.jfree.chart.block.BlockContainer blockContainer66 = null;
        legendTitle65.setWrapper(blockContainer66);
        java.awt.geom.Rectangle2D rectangle2D68 = legendTitle65.getBounds();
        boolean boolean69 = numberTickUnit50.equals((java.lang.Object) rectangle2D68);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit71 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape75 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot72.setLegendItemShape(shape75);
        piePlot72.setMaximumLabelWidth((double) (-457));
        boolean boolean79 = numberTickUnit71.equals((java.lang.Object) piePlot72);
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis81 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray82 = new org.jfree.chart.axis.ValueAxis[] { valueAxis81 };
        xYPlot80.setDomainAxes(valueAxisArray82);
        org.jfree.chart.util.Layer layer84 = null;
        java.util.Collection collection85 = xYPlot80.getRangeMarkers(layer84);
        org.jfree.chart.title.LegendTitle legendTitle86 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot80);
        org.jfree.chart.block.BlockContainer blockContainer87 = null;
        legendTitle86.setWrapper(blockContainer87);
        java.awt.geom.Rectangle2D rectangle2D89 = legendTitle86.getBounds();
        boolean boolean90 = numberTickUnit71.equals((java.lang.Object) rectangle2D89);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo92 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo92);
        try {
            org.jfree.chart.axis.AxisState axisState94 = numberAxis0.draw(graphics2D47, (double) (short) 10, rectangle2D68, rectangle2D89, rectangleEdge91, plotRenderingInfo93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(valueAxisArray82);
        org.junit.Assert.assertNull(collection85);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(rectangleEdge91);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset10.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, true);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity19 = new org.jfree.chart.entity.CategoryItemEntity(shape6, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke21 = lineBorder20.getStroke();
        boolean boolean22 = categoryItemEntity19.equals((java.lang.Object) stroke21);
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot24.setLegendItemShape(shape27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot24);
        java.awt.Paint paint30 = piePlot24.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { valueAxis32 };
        xYPlot31.setDomainAxes(valueAxisArray33);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot31.getRangeMarkers(layer35);
        java.awt.Stroke stroke37 = xYPlot31.getDomainCrosshairStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker((double) (-8355712), (double) (byte) 1, paint2, stroke21, paint30, stroke37, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getOutlinePaint();
        java.awt.Color color12 = java.awt.Color.yellow;
        legendGraphic8.setLinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        axisState0.cursorUp((double) 100.0f);
        axisState0.cursorRight((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge(68);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getOutlinePaint();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer12 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType13 = standardGradientPaintTransformer12.getType();
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, 4.0d, 1.0d, 0.0d, (double) 1);
        boolean boolean20 = standardGradientPaintTransformer12.equals((java.lang.Object) unitType14);
        legendGraphic8.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType13);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        java.lang.Object obj14 = legendItemEntity3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot8.setLegendItemShape(shape11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke6, jFreeChart13, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle19 = null;
        jFreeChart13.setTitle(textTitle19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        xYPlot21.setDomainAxes(valueAxisArray23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getRangeMarkers(layer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot21.drawRangeTickBands(graphics2D27, rectangle2D28, list29);
        xYPlot21.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer32 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] { valueAxis34 };
        xYPlot33.setDomainAxes(valueAxisArray35);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        xYPlot33.setRangeGridlineStroke(stroke38);
        minMaxCategoryRenderer32.setGroupStroke(stroke38);
        xYPlot21.setDomainGridlineStroke(stroke38);
        jFreeChart13.setBorderStroke(stroke38);
        try {
            org.jfree.chart.title.Title title44 = jFreeChart13.getSubtitle(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend((int) (short) 10);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double18 = rectangleInsets17.getBottom();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        xYPlot19.setDomainAxes(valueAxisArray21);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot19.getRangeMarkers(layer23);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot19);
        org.jfree.chart.block.BlockContainer blockContainer26 = null;
        legendTitle25.setWrapper(blockContainer26);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle25.getBounds();
        rectangleInsets17.trim(rectangle2D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        try {
            jFreeChart8.draw(graphics2D16, rectangle2D28, chartRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        double double7 = piePlot1.getShadowYOffset();
        piePlot1.setBackgroundImageAlignment(10);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        boolean boolean44 = numberTickUnit36.equals((java.lang.Object) piePlot37);
        numberAxis0.setTickUnit(numberTickUnit36);
        boolean boolean46 = numberAxis0.isPositiveArrowVisible();
        try {
            numberAxis0.setRange((double) 12, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (12.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot11 = jFreeChart10.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        java.lang.Boolean boolean7 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(1);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        boolean boolean44 = numberTickUnit36.equals((java.lang.Object) piePlot37);
        numberAxis0.setTickUnit(numberTickUnit36);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint47 = xYPlot46.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot46.getDomainAxisLocation();
        boolean boolean49 = numberAxis0.hasListener((java.util.EventListener) xYPlot46);
        int int50 = xYPlot46.getSeriesCount();
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        boolean boolean44 = numberTickUnit36.equals((java.lang.Object) piePlot37);
        numberAxis0.setTickUnit(numberTickUnit36);
        boolean boolean46 = numberAxis0.isPositiveArrowVisible();
        java.awt.Shape shape47 = numberAxis0.getRightArrow();
        java.awt.Font font48 = null;
        try {
            numberAxis0.setLabelFont(font48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.CENTER_LEFT", "", "", "ThreadContext", "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10");
        basicProjectInfo5.addOptionalLibrary("hi!");
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        java.awt.Paint paint15 = piePlot9.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = piePlot9.getToolTipGenerator();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(pieToolTipGenerator16);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        double double7 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(rotation8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape9 = textBlock1.calculateBounds(graphics2D2, (float) 'a', (float) 4, textBlockAnchor5, (float) 10, 0.0f, (-1.0d));
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        boolean boolean11 = rectangleInsets0.equals((java.lang.Object) shape9);
        double double13 = rectangleInsets0.extendHeight((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-2.208959999998E12d) + "'", double13 == (-2.208959999998E12d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        boolean boolean44 = numberTickUnit36.equals((java.lang.Object) piePlot37);
        numberAxis0.setTickUnit(numberTickUnit36);
        boolean boolean46 = numberAxis0.isPositiveArrowVisible();
        try {
            numberAxis0.zoomRange((double) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        double double7 = stackedBarRenderer3D2.getBase();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer9 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer9, dataset10);
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer9);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets15.getBottom();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        xYPlot17.setDomainAxes(valueAxisArray19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getRangeMarkers(layer21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot17);
        org.jfree.chart.block.BlockContainer blockContainer24 = null;
        legendTitle23.setWrapper(blockContainer24);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle23.getBounds();
        rectangleInsets15.trim(rectangle2D26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D30.configure();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        try {
            stackedBarRenderer3D2.drawItem(graphics2D13, categoryItemRendererState14, rectangle2D26, categoryPlot28, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, valueAxis32, categoryDataset33, 100, (int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        jFreeChart6.setAntiAlias(true);
        boolean boolean11 = jFreeChart6.isBorderVisible();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape14);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItemEntity15.setDataset(dataset16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(layer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        boolean boolean25 = legendItemEntity15.equals((java.lang.Object) legendTitle24);
        jFreeChart6.removeSubtitle((org.jfree.chart.title.Title) legendTitle24);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        double double3 = levelRenderer0.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Paint paint12 = xYPlot6.getRangeCrosshairPaint();
        piePlot3D5.setLabelOutlinePaint(paint12);
        levelRenderer0.setBaseOutlinePaint(paint12, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = levelRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color22 = java.awt.Color.gray;
        stackedBarRenderer3D20.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color22, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = null;
        stackedBarRenderer3D20.setLegendItemToolTipGenerator(categorySeriesLabelGenerator25);
        stackedBarRenderer3D20.setBaseCreateEntities(false, false);
        stackedBarRenderer3D20.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedBarRenderer3D20.getBasePositiveItemLabelPosition();
        levelRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition32);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { valueAxis35 };
        xYPlot34.setDomainAxes(valueAxisArray36);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot34.getRangeMarkers(layer38);
        java.awt.Paint paint40 = xYPlot34.getRangeCrosshairPaint();
        boolean boolean41 = xYPlot34.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot34.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot43.setLegendItemShape(shape46);
        boolean boolean48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot34, (java.lang.Object) piePlot43);
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        xYPlot49.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D52 = xYPlot49.getQuadrantOrigin();
        xYPlot34.setQuadrantOrigin(point2D52);
        xYPlot34.mapDatasetToRangeAxis(10, 0);
        xYPlot34.configureRangeAxes();
        levelRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot34);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(point2D52);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        segment3.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segment3.copy();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long7 = segmentedTimeline6.getSegmentsGroupSize();
        boolean boolean8 = segmentedTimeline6.getAdjustForDaylightSaving();
        try {
            int int9 = segment3.compareTo((java.lang.Object) boolean8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D4 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list5 = defaultKeyedValues2D4.getRowKeys();
        axisState2.setTicks(list5);
        projectInfo0.setContributors(list5);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        stackedBarRenderer3D2.setBaseOutlinePaint(paint9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultCategoryDataset11.getGroup();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (-460));
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.KeyToGroupMap keyToGroupMap16 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, keyToGroupMap16);
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) defaultCategoryDataset11);
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle12.getPosition();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange21);
        double double23 = rectangleConstraint22.getHeight();
        org.jfree.chart.util.Size2D size2D24 = legendTitle12.arrange(graphics2D17, rectangleConstraint22);
        legendTitle12.setWidth((double) 0L);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(size2D24);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        double double4 = axisState3.getCursor();
        axisState3.cursorLeft((-100.0d));
        axisState3.cursorUp((double) (short) 100);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot16.setLegendItemShape(shape19);
        piePlot16.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint23 = piePlot16.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape11, paint23);
        java.awt.geom.Rectangle2D rectangle2D25 = legendGraphic24.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list27 = dateAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D25, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = xYPlot11.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, false);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range8, lengthConstraintType14, (double) 6, range18, lengthConstraintType19);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange24);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange24, (double) 0.0f, (double) (short) 0);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean30 = dateRange24.equals((java.lang.Object) color29);
        org.jfree.data.Range range31 = org.jfree.data.Range.combine(range18, (org.jfree.data.Range) dateRange24);
        try {
            org.jfree.data.Range range34 = org.jfree.data.Range.expand(range31, (double) (-1L), (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (90.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-8355712), "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", textAnchor2, textAnchor3, (double) 60000L);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = waterfallBarRenderer0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        waterfallBarRenderer0.setBaseShape(shape6);
        boolean boolean9 = waterfallBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        defaultCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        double double23 = xYPlot18.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color1 = java.awt.Color.darkGray;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset2.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot3);
        boolean boolean7 = xYPlot3.isDomainZoomable();
        java.awt.Stroke stroke8 = xYPlot3.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        java.awt.Paint paint15 = xYPlot9.getRangeCrosshairPaint();
        boolean boolean16 = xYPlot9.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot9.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot18.setLegendItemShape(shape21);
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot9, (java.lang.Object) piePlot18);
        java.awt.Paint paint24 = piePlot18.getBaseSectionOutlinePaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer25 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        waterfallBarRenderer25.setPositiveBarPaint((java.awt.Paint) color26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = waterfallBarRenderer25.getPositiveItemLabelPositionFallback();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot32.setLegendItemShape(shape35);
        piePlot32.setMaximumLabelWidth((double) (-457));
        boolean boolean39 = numberTickUnit31.equals((java.lang.Object) piePlot32);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot32);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D42 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list43 = defaultKeyedValues2D42.getRowKeys();
        jFreeChart40.setSubtitles(list43);
        jFreeChart40.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer47 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { valueAxis49 };
        xYPlot48.setDomainAxes(valueAxisArray50);
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke53 = lineBorder52.getStroke();
        xYPlot48.setRangeGridlineStroke(stroke53);
        minMaxCategoryRenderer47.setGroupStroke(stroke53);
        jFreeChart40.setBorderStroke(stroke53);
        waterfallBarRenderer25.setSeriesOutlineStroke((int) (short) 0, stroke53);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 100L, (java.awt.Paint) color1, stroke8, paint24, stroke53, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        double double3 = levelRenderer0.getMaximumItemWidth();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Paint paint12 = xYPlot6.getRangeCrosshairPaint();
        piePlot3D5.setLabelOutlinePaint(paint12);
        levelRenderer0.setBaseOutlinePaint(paint12, false);
        double double16 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        int int2 = objectList0.indexOf((java.lang.Object) textAnchor1);
        objectList0.clear();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot4.setLegendItemShape(shape7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset11.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, true);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 86400000L, 0.0f, (float) (-457));
        int int25 = objectList0.indexOf((java.lang.Object) (-457));
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        double double7 = piePlot1.getShadowYOffset();
        piePlot1.setShadowXOffset((double) (short) 10);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        int int4 = stackedBarRenderer3D2.getColumnCount();
        boolean boolean5 = stackedBarRenderer3D2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("ThreadContext");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape5 = minMaxCategoryRenderer3.lookupSeriesShape((int) (short) 0);
        boolean boolean6 = projectInfo0.equals((java.lang.Object) (short) 0);
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getCopyright();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        xYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot10.getRangeMarkers(layer14);
        java.awt.Paint paint16 = xYPlot10.getRangeCrosshairPaint();
        boolean boolean17 = xYPlot10.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot10.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        boolean boolean24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot10, (java.lang.Object) piePlot19);
        java.awt.Paint paint25 = piePlot19.getBaseSectionOutlinePaint();
        boolean boolean26 = projectInfo7.equals((java.lang.Object) piePlot19);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo7);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.centerRange((double) (byte) -1);
        numberAxis0.setFixedAutoRange((double) 1L);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset1.getGroup();
        defaultCategoryDataset0.setGroup(datasetGroup2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset0.getGroup();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.setAutoTickUnitSelection(false);
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        java.awt.Paint paint5 = piePlot0.getLabelPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        piePlot0.setBaseSectionPaint(paint6);
        piePlot0.setPieIndex(6);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        textBlock0.addLine("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", font2, (java.awt.Paint) color3);
        float[] floatArray5 = new float[] {};
        try {
            float[] floatArray6 = color3.getRGBColorComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.util.Rotation rotation15 = piePlot9.getDirection();
        org.jfree.data.general.PieDataset pieDataset16 = piePlot9.getDataset();
        java.lang.Object obj17 = piePlot9.clone();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(pieDataset16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBaseCreateEntities(true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj21 = null;
        boolean boolean22 = taskSeriesCollection20.equals(obj21);
        taskSeriesCollection20.removeAll();
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection20);
        try {
            java.lang.Number number27 = taskSeriesCollection20.getStartValue((int) (byte) 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font1);
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock2.setFont(font3);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue7 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "hi!", (java.lang.Number) 1L);
        java.lang.Comparable comparable8 = defaultKeyedValue7.getKey();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        java.awt.Paint paint14 = piePlot9.getLabelPaint();
        boolean boolean15 = defaultKeyedValue7.equals((java.lang.Object) paint14);
        labelBlock2.setPaint(paint14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "hi!" + "'", comparable8.equals("hi!"));
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.String str11 = boxAndWhiskerItem9.toString();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(96, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        java.lang.Boolean boolean5 = stackedBarRenderer3D2.getSeriesVisibleInLegend((int) (short) -1);
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset2.getGroup();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, (java.lang.Comparable) (-460));
        double double6 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 'a', (org.jfree.data.KeyedValues) pieDataset5);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, (org.jfree.data.KeyedValues) pieDataset5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(categoryDataset7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getBaseSectionOutlineStroke();
        java.awt.Color color4 = java.awt.Color.GRAY;
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 8, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getVersion();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryItemEntity16.getDataset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryDataset17);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        boolean boolean9 = textBlock7.equals((java.lang.Object) 4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        java.lang.Object obj20 = categoryItemEntity16.clone();
        java.lang.Comparable comparable21 = categoryItemEntity16.getColumnKey();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + ' ' + "'", comparable21.equals(' '));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.lang.String str51 = legendItem50.getDescription();
        int int52 = legendItem50.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = stackedBarRenderer3D2.getURLGenerator((-1), (int) 'a');
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 13, (int) ' ', (int) (byte) 10);
        long long4 = segmentedTimeline3.getSegmentsIncludedSize();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 416L + "'", long4 == 416L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj6 = null;
        boolean boolean7 = taskSeriesCollection5.equals(obj6);
        boolean boolean8 = stackedBarRenderer3D2.hasListener((java.util.EventListener) taskSeriesCollection5);
        try {
            java.lang.Number number12 = taskSeriesCollection5.getEndValue(9999, (int) (short) 100, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets3.getBottom();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets3.getUnitType();
        double double7 = rectangleInsets3.calculateTopInset(0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot10.setLegendItemShape(shape13);
        piePlot10.setMaximumLabelWidth((double) (-457));
        boolean boolean17 = numberTickUnit9.equals((java.lang.Object) piePlot10);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(layer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle24.setWrapper(blockContainer25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        boolean boolean28 = numberTickUnit9.equals((java.lang.Object) rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets3.createInsetRectangle(rectangle2D27);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape32, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint44 = piePlot37.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape32, paint44);
        java.awt.geom.Rectangle2D rectangle2D46 = legendGraphic45.getBounds();
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor50 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker49.setLabelTextAnchor(textAnchor50);
        java.awt.Stroke stroke52 = intervalMarker49.getOutlineStroke();
        java.awt.Paint paint53 = intervalMarker49.getOutlinePaint();
        intervalMarker49.setLabel("HorizontalAlignment.CENTER");
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { valueAxis57 };
        xYPlot56.setDomainAxes(valueAxisArray58);
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = xYPlot56.getRangeMarkers(layer60);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        java.util.List list64 = null;
        xYPlot56.drawRangeTickBands(graphics2D62, rectangle2D63, list64);
        xYPlot56.clearRangeMarkers();
        boolean boolean67 = xYPlot56.isRangeZoomable();
        intervalMarker49.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot56);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = xYPlot56.getDomainAxisEdge((-8355712));
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        try {
            org.jfree.chart.axis.AxisState axisState73 = dateAxis0.draw(graphics2D1, (double) 9999, rectangle2D27, rectangle2D46, rectangleEdge70, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(textAnchor50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        java.awt.Paint paint2 = lineBorder0.getPaint();
        java.awt.Paint paint3 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint4.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint4.toUnconstrainedWidth();
        java.lang.String str8 = rectangleConstraint4.toString();
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]" + "'", str8.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("GradientPaintTransformType.HORIZONTAL", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint4 = minMaxCategoryRenderer0.getSeriesFillPaint((-457));
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator5 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        minMaxCategoryRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator5, true);
        javax.swing.Icon icon8 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator6 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        statisticalLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator6, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        java.awt.image.BufferedImage bufferedImage19 = jFreeChart8.createBufferedImage(6, (int) (short) 100, 4.0d, (double) 10, chartRenderingInfo18);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNotNull(bufferedImage19);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "hi!", "hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        try {
            java.lang.String str7 = standardCategoryURLGenerator3.generateURL(categoryDataset4, (-1), 96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE12" + "'", str1.equals("ItemLabelAnchor.OUTSIDE12"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setSeriesVisible(9999, (java.lang.Boolean) false, false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        xYPlot0.handleClick((-460), (int) (byte) 10, plotRenderingInfo14);
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        xYPlot18.setRangeGridlineStroke(stroke23);
        minMaxCategoryRenderer17.setGroupStroke(stroke23);
        jFreeChart10.setBorderStroke(stroke23);
        jFreeChart10.setNotify(false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        jFreeChart6.setAntiAlias(true);
        boolean boolean11 = jFreeChart6.isBorderVisible();
        jFreeChart6.setAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart6.removeProgressListener(chartProgressListener14);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        boolean boolean4 = segment3.inExceptionSegments();
        boolean boolean5 = segment3.inExceptionSegments();
        boolean boolean7 = segment3.contains((long) (short) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        boolean boolean11 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getDomainCrosshairStroke();
        xYPlot0.setDomainCrosshairStroke(stroke18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        xYPlot0.handleClick((-1), 2, plotRenderingInfo23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        xYPlot0.setRenderer(xYItemRenderer25);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = waterfallBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint4 = waterfallBarRenderer0.getLastBarPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59008924800000L) + "'", long3 == (-59008924800000L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(15, 4, (int) ' ', 2, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue3 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "hi!", (java.lang.Number) 1L);
        java.lang.Comparable comparable4 = defaultKeyedValue3.getKey();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot5.setLegendItemShape(shape8);
        java.awt.Paint paint10 = piePlot5.getLabelPaint();
        boolean boolean11 = defaultKeyedValue3.equals((java.lang.Object) paint10);
        java.lang.Comparable comparable12 = defaultKeyedValue3.getKey();
        boolean boolean13 = textAnchor0.equals((java.lang.Object) comparable12);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "hi!" + "'", comparable12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        axisState0.cursorLeft((-100.0d));
        axisState0.setCursor((double) '4');
        axisState0.cursorDown((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        try {
            java.lang.String str11 = standardCategoryToolTipGenerator7.generateRowLabel(categoryDataset9, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Third" + "'", str1.equals("Third"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext");
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) standardCategoryURLGenerator3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultCategoryDataset5.getGroup();
        defaultCategoryDataset5.setValue((double) 10.0f, (java.lang.Comparable) (short) 100, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
        try {
            java.lang.String str13 = standardCategoryURLGenerator3.generateURL((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, (int) (short) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(datasetGroup6);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-457), 68, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.setAutoTickUnitSelection(false);
        try {
            numberAxis0.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        legendTitle12.setItemLabelPadding(rectangleInsets16);
        java.lang.Object obj18 = legendTitle12.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer3, dataset4);
        xYPlot0.datasetChanged(datasetChangeEvent5);
        xYPlot0.setRangeCrosshairValue((double) 12, false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext");
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) standardCategoryURLGenerator3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        xYPlot6.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        xYPlot6.handleClick((-460), (int) (byte) 10, plotRenderingInfo20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot22.setLegendItemShape(shape25);
        java.awt.Paint paint27 = piePlot22.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        piePlot22.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo31);
        plotRenderingInfo20.addSubplotInfo(plotRenderingInfo31);
        keyedObjects0.addObject((java.lang.Comparable) 15, (java.lang.Object) plotRenderingInfo31);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-8355712));
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { valueAxis9 };
        xYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getRangeMarkers(layer12);
        java.awt.Paint paint14 = xYPlot8.getRangeCrosshairPaint();
        piePlot3D7.setLabelOutlinePaint(paint14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean19 = statisticalLineAndShapeRenderer18.getUseOutlinePaint();
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer18.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D7.setShadowPaint(paint22);
        try {
            org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem(attributedString0, "NOID", "{0}", "NOID", shape5, paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getItemShapeVisible(9999, 6);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        java.awt.Paint paint8 = stackedBarRenderer3D2.getSeriesFillPaint(0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, true);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot5.setLegendItemShape(shape8);
        java.awt.Paint paint10 = piePlot5.getLabelPaint();
        boolean boolean11 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot5);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets13.getBottom();
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets13.getUnitType();
        double double17 = rectangleInsets13.calculateTopInset(0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot20.setLegendItemShape(shape23);
        piePlot20.setMaximumLabelWidth((double) (-457));
        boolean boolean27 = numberTickUnit19.equals((java.lang.Object) piePlot20);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        xYPlot28.setDomainAxes(valueAxisArray30);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getRangeMarkers(layer32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot28);
        org.jfree.chart.block.BlockContainer blockContainer35 = null;
        legendTitle34.setWrapper(blockContainer35);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle34.getBounds();
        boolean boolean38 = numberTickUnit19.equals((java.lang.Object) rectangle2D37);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets13.createInsetRectangle(rectangle2D37);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D43 = xYPlot40.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] { valueAxis46 };
        xYPlot45.setDomainAxes(valueAxisArray47);
        org.jfree.chart.util.Layer layer49 = null;
        java.util.Collection collection50 = xYPlot45.getRangeMarkers(layer49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        java.util.List list53 = null;
        xYPlot45.drawRangeTickBands(graphics2D51, rectangle2D52, list53);
        xYPlot45.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        xYPlot45.handleClick((-460), (int) (byte) 10, plotRenderingInfo59);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot61.setLegendItemShape(shape64);
        java.awt.Paint paint66 = piePlot61.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo69);
        piePlot61.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo70);
        plotRenderingInfo59.addSubplotInfo(plotRenderingInfo70);
        try {
            piePlot5.draw(graphics2D12, rectangle2D39, point2D43, plotState44, plotRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        piePlot3D1.setLabelOutlinePaint(paint8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = piePlot3D1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat36 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { valueAxis39 };
        xYPlot38.setDomainAxes(valueAxisArray40);
        xYPlot38.setRangeCrosshairValue(0.0d);
        boolean boolean44 = chartChangeEventType37.equals((java.lang.Object) xYPlot38);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot38);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font3);
        java.awt.Paint paint5 = null;
        try {
            textBlock0.addLine("({0}, {1}) = {3} - {4}", font3, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D18 = xYPlot15.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D18);
        xYPlot0.mapDatasetToRangeAxis(10, 0);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange37);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = rectangleConstraint38.getWidthConstraintType();
        org.jfree.data.Range range43 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range33, lengthConstraintType39, (double) 6, range43, lengthConstraintType44);
        org.jfree.data.time.DateRange dateRange49 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange49);
        org.jfree.data.Range range53 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange49, (double) 0.0f, (double) (short) 0);
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean55 = dateRange49.equals((java.lang.Object) color54);
        org.jfree.data.Range range56 = org.jfree.data.Range.combine(range43, (org.jfree.data.Range) dateRange49);
        numberAxis24.setDefaultAutoRange((org.jfree.data.Range) dateRange49);
        org.jfree.data.RangeType rangeType58 = numberAxis24.getRangeType();
        xYPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        int int61 = xYPlot0.getIndexOf(xYItemRenderer60);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(rangeType58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 10, 90.0d);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisible(0);
        java.awt.Shape shape5 = stackedBarRenderer3D2.getBaseShape();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        boolean boolean7 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Paint paint8 = stackedBarRenderer3D2.getBaseFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        boolean boolean3 = minMaxCategoryRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape15 = textBlock7.calculateBounds(graphics2D8, (float) 'a', (float) 4, textBlockAnchor11, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer6.setBaseShape(shape15);
        minMaxCategoryRenderer0.setBaseShape(shape15, true);
        java.lang.Boolean boolean20 = minMaxCategoryRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Paint paint22 = null;
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(96, paint22);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("ThreadContext");
        projectInfo0.addOptionalLibrary("TextBlockAnchor.CENTER_LEFT");
        projectInfo0.setLicenceText("");
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot3.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        xYPlot3.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        xYPlot3.handleClick((-460), (int) (byte) 10, plotRenderingInfo17);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        java.awt.Paint paint24 = piePlot19.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        piePlot19.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo28);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo28.getDataArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        xYPlot32.setDomainAxes(valueAxisArray34);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = xYPlot32.getRangeMarkers(layer36);
        java.awt.Paint paint38 = xYPlot32.getRangeCrosshairPaint();
        boolean boolean39 = xYPlot32.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot32.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot41.setLegendItemShape(shape44);
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot32, (java.lang.Object) piePlot41);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        xYPlot47.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D50 = xYPlot47.getQuadrantOrigin();
        xYPlot32.setQuadrantOrigin(point2D50);
        org.jfree.chart.plot.PlotState plotState52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray55 = new org.jfree.chart.axis.ValueAxis[] { valueAxis54 };
        xYPlot53.setDomainAxes(valueAxisArray55);
        org.jfree.chart.util.Layer layer57 = null;
        java.util.Collection collection58 = xYPlot53.getRangeMarkers(layer57);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        java.util.List list61 = null;
        xYPlot53.drawRangeTickBands(graphics2D59, rectangle2D60, list61);
        xYPlot53.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        xYPlot53.handleClick((-460), (int) (byte) 10, plotRenderingInfo67);
        org.jfree.chart.plot.PiePlot piePlot69 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot69.setLegendItemShape(shape72);
        java.awt.Paint paint74 = piePlot69.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        piePlot69.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo78);
        plotRenderingInfo67.addSubplotInfo(plotRenderingInfo78);
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D31, point2D50, plotState52, plotRenderingInfo67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertNotNull(valueAxisArray55);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(paint74);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) 0);
        java.lang.Comparable comparable7 = null;
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) 0.2d, (java.lang.Comparable) (short) -1, comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        java.awt.Paint paint15 = piePlot9.getBaseSectionOutlinePaint();
        org.jfree.chart.text.TextBlock textBlock16 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        textBlock16.addLine("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", font18, (java.awt.Paint) color19);
        piePlot9.setBaseSectionPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        taskSeriesCollection0.removeAll();
        int int4 = taskSeriesCollection0.getSeriesCount();
        try {
            java.lang.Comparable comparable6 = taskSeriesCollection0.getColumnKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("{0}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        polarPlot0.setDataset(xYDataset1);
        java.awt.Font font3 = polarPlot0.getAngleLabelFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int3 = month2.getMonth();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1202L + "'", long4 == 1202L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) segment3);
        segment3.moveIndexToEnd();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range34 = numberAxis0.getDefaultAutoRange();
        try {
            numberAxis0.setAutoRangeMinimumSize((double) (-460), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        double double14 = legendTitle12.getContentXOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(68, (double) 15);
        double double5 = layeredBarRenderer0.getSeriesBarWidth((int) (short) 100);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.setValue((java.lang.Number) 1L, (java.lang.Comparable) (short) 100, (java.lang.Comparable) 1);
        java.lang.Object obj6 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj3 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.lang.Object obj7 = jFreeChart6.getTextAntiAlias();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot16.setLegendItemShape(shape19);
        piePlot16.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint23 = piePlot16.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape11, paint23);
        java.awt.geom.Rectangle2D rectangle2D25 = legendGraphic24.getBounds();
        try {
            jFreeChart6.draw(graphics2D8, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("ThreadContext");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape5 = minMaxCategoryRenderer3.lookupSeriesShape((int) (short) 0);
        boolean boolean6 = projectInfo0.equals((java.lang.Object) (short) 0);
        projectInfo0.setLicenceText("NOID");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets19.getBottom();
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets19.getUnitType();
        double double23 = rectangleInsets19.calculateTopInset(0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot26.setLegendItemShape(shape29);
        piePlot26.setMaximumLabelWidth((double) (-457));
        boolean boolean33 = numberTickUnit25.equals((java.lang.Object) piePlot26);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { valueAxis35 };
        xYPlot34.setDomainAxes(valueAxisArray36);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot34.getRangeMarkers(layer38);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot34);
        org.jfree.chart.block.BlockContainer blockContainer41 = null;
        legendTitle40.setWrapper(blockContainer41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle40.getBounds();
        boolean boolean44 = numberTickUnit25.equals((java.lang.Object) rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets19.createInsetRectangle(rectangle2D43);
        try {
            jFreeChart10.draw(graphics2D18, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        xYPlot0.setBackgroundAlpha(0.5f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset1);
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot4.setLegendItemShape(shape7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Paint paint10 = piePlot4.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot4.setToolTipGenerator(pieToolTipGenerator11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot4.setLabelBackgroundPaint((java.awt.Paint) color13);
        boolean boolean15 = groupedStackedBarRenderer0.equals((java.lang.Object) piePlot4);
        boolean boolean16 = groupedStackedBarRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertNotNull(color1);
    }
}

