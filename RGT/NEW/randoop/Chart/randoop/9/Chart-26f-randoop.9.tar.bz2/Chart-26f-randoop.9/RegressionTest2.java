import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        int int7 = xYPlot0.getWeight();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 10, (double) (byte) 1, (double) 1, (double) (byte) -1, (java.awt.Paint) color12);
        xYPlot0.setOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseShapesFilled(false);
        boolean boolean12 = statisticalLineAndShapeRenderer2.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int2 = segmentedTimeline1.getSegmentsExcluded();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) segment4);
        java.lang.Object obj6 = rendererChangeEvent5.getRenderer();
        waferMapPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot0.setDataset(waferMapDataset8);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        java.lang.Object obj8 = xYPlot0.clone();
        xYPlot0.mapDatasetToDomainAxis(10, 10);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj1 = polarPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getAutoRangeMinimumSize();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.configure();
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = new org.jfree.chart.axis.DateTickUnit(2, 1, (-8355712), (int) (short) 100, dateFormat10);
        java.util.Date date12 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit11);
        org.jfree.data.Range range13 = dateAxis2.getRange();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.data.Range range21 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range11, lengthConstraintType17, (double) 6, range21, lengthConstraintType22);
        boolean boolean24 = taskSeriesCollection0.equals((java.lang.Object) range21);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int26 = segmentedTimeline25.getSegmentsExcluded();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment28 = segmentedTimeline25.getSegment(date27);
        boolean boolean29 = segment28.inExceptionSegments();
        boolean boolean30 = segment28.inExceptionSegments();
        long long32 = segment28.calculateSegmentNumber((long) 8);
        int int33 = taskSeriesCollection0.indexOf((java.lang.Comparable) long32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 68 + "'", int26 == 68);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(segment28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2454364L + "'", long32 == 2454364L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.0d + "'", number34.equals(0.0d));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range7 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, (double) 0.0f, (double) (short) 0);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) '4');
        double double10 = range7.getUpperBound();
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.Object obj2 = null;
        boolean boolean3 = sortOrder1.equals(obj2);
        categoryPlot0.setColumnRenderingOrder(sortOrder1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getWidthConstraintType();
        org.jfree.data.Range range24 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range14, lengthConstraintType20, (double) 6, range24, lengthConstraintType25);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range34 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange30, (double) 0.0f, (double) (short) 0);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean36 = dateRange30.equals((java.lang.Object) color35);
        org.jfree.data.Range range37 = org.jfree.data.Range.combine(range24, (org.jfree.data.Range) dateRange30);
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range39 = numberAxis5.getRange();
        java.lang.String str40 = numberAxis5.getLabelToolTip();
        org.jfree.data.Range range41 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        int int42 = categoryPlot0.getWeight();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 10, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryPlot0.setDomainAxis(2958465, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, false);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3);
        textBlock0.addLine(textLine5);
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textBlock0.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        boolean boolean11 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getDomainCrosshairStroke();
        xYPlot0.setDomainCrosshairStroke(stroke18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        xYPlot0.handleClick((-1), 2, plotRenderingInfo23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot0.getDomainAxisEdge(5);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = xYPlot0.getInsets();
        java.awt.geom.Point2D point2D28 = xYPlot0.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge(68);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker3.setLabelTextAnchor(textAnchor4);
        java.awt.Stroke stroke6 = intervalMarker3.getOutlineStroke();
        java.awt.Paint paint7 = intervalMarker3.getOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        multiplePiePlot0.setLimit(1.0d);
        java.awt.Paint paint11 = multiplePiePlot0.getAggregatedItemsPaint();
        java.awt.Paint paint12 = multiplePiePlot0.getAggregatedItemsPaint();
        java.awt.Paint paint13 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset20.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot21);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, 13);
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        java.lang.Comparable comparable28 = categoryItemEntity16.getColumnKey();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(pieDataset26);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + ' ' + "'", comparable28.equals(' '));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.blue;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("0.5", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.blue;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("0.5", font5, (java.awt.Paint) color6);
        labelBlock3.setFont(font5);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getWidthConstraintType();
        org.jfree.data.Range range24 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range14, lengthConstraintType20, (double) 6, range24, lengthConstraintType25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint4.toRangeHeight(range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint4.toFixedHeight((double) 100);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj32 = null;
        boolean boolean33 = taskSeriesCollection31.equals(obj32);
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange38);
        org.jfree.data.Range range42 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange38, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange46);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType48 = rectangleConstraint47.getWidthConstraintType();
        org.jfree.data.Range range52 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType53 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range42, lengthConstraintType48, (double) 6, range52, lengthConstraintType53);
        boolean boolean55 = taskSeriesCollection31.equals((java.lang.Object) range52);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = rectangleConstraint30.toRangeWidth(range52);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(lengthConstraintType48);
        org.junit.Assert.assertNotNull(lengthConstraintType53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint56);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range8, lengthConstraintType14, (double) 6, range18, lengthConstraintType19);
        double double22 = range8.constrain((double) 10);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        xYPlot29.setDomainAxes(valueAxisArray31);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot29.getRangeMarkers(layer33);
        java.awt.Paint paint35 = xYPlot29.getRangeCrosshairPaint();
        stackedBarRenderer3D28.setBaseOutlinePaint(paint35);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset37 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup38 = defaultCategoryDataset37.getGroup();
        org.jfree.data.general.PieDataset pieDataset40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset37, (java.lang.Comparable) (-460));
        org.jfree.data.Range range41 = stackedBarRenderer3D28.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset37);
        org.jfree.data.KeyToGroupMap keyToGroupMap42 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset37, keyToGroupMap42);
        org.jfree.data.Range range44 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange25, range43);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint(range8, range43);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(datasetGroup38);
        org.junit.Assert.assertNotNull(pieDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        double double7 = stackedBarRenderer3D2.getBase();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer9 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer9, dataset10);
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer9);
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font14);
        stackedBarRenderer3D2.setBaseItemLabelFont(font14);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        piePlot0.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint7 = piePlot0.getShadowPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer10.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean14 = statisticalLineAndShapeRenderer10.getBaseLinesVisible();
        boolean boolean17 = statisticalLineAndShapeRenderer10.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer10.setBaseLinesVisible(false);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer10.getItemFillPaint(10, 96);
        piePlot0.setLabelOutlinePaint(paint22);
        double double24 = piePlot0.getShadowXOffset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator7);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible((-457));
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D2.getBasePositiveItemLabelPosition();
        stackedBarRenderer3D2.setRenderAsPercentages(false);
        stackedBarRenderer3D2.setSeriesVisibleInLegend(100, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-457), (-3.0d));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-8355712));
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        boolean boolean6 = segment3.contained((long) 6, (long) 13);
        segment3.inc();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        jFreeChart6.setAntiAlias(true);
        boolean boolean11 = jFreeChart6.isBorderVisible();
        jFreeChart6.setAntiAlias(true);
        java.awt.Image image14 = jFreeChart6.getBackgroundImage();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(image14);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        double double3 = levelRenderer0.getItemMargin();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot4.getRangeCrosshairPaint();
        boolean boolean11 = xYPlot4.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot13.setLegendItemShape(shape16);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot4, (java.lang.Object) piePlot13);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D22 = xYPlot19.getQuadrantOrigin();
        xYPlot4.setQuadrantOrigin(point2D22);
        xYPlot4.mapDatasetToRangeAxis(10, 0);
        levelRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        stackedBarRenderer3D30.setNegativeItemLabelPositionFallback(itemLabelPosition31);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection33 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj34 = null;
        boolean boolean35 = taskSeriesCollection33.equals(obj34);
        boolean boolean36 = stackedBarRenderer3D30.hasListener((java.util.EventListener) taskSeriesCollection33);
        boolean boolean37 = stackedBarRenderer3D30.getBaseCreateEntities();
        java.lang.Object obj38 = stackedBarRenderer3D30.clone();
        boolean boolean39 = levelRenderer0.equals(obj38);
        org.jfree.chart.LegendItem legendItem42 = levelRenderer0.getLegendItem(0, (int) (byte) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier43 = levelRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(legendItem42);
        org.junit.Assert.assertNull(drawingSupplier43);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) ' ');
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot10.setLegendItemShape(shape13);
        piePlot10.setMaximumLabelWidth((double) (-457));
        boolean boolean17 = numberTickUnit9.equals((java.lang.Object) piePlot10);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(layer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle24.setWrapper(blockContainer25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        boolean boolean28 = numberTickUnit9.equals((java.lang.Object) rectangle2D27);
        try {
            stackedBarRenderer3D2.drawOutline(graphics2D4, categoryPlot5, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        xYPlot7.setDomainAxes(valueAxisArray9);
        xYPlot0.setDomainAxes(valueAxisArray9);
        xYPlot0.mapDatasetToRangeAxis((int) 'a', 100);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray9);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D18 = xYPlot15.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D18);
        xYPlot0.mapDatasetToRangeAxis(10, 0);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange37);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = rectangleConstraint38.getWidthConstraintType();
        org.jfree.data.Range range43 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range33, lengthConstraintType39, (double) 6, range43, lengthConstraintType44);
        org.jfree.data.time.DateRange dateRange49 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange49);
        org.jfree.data.Range range53 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange49, (double) 0.0f, (double) (short) 0);
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean55 = dateRange49.equals((java.lang.Object) color54);
        org.jfree.data.Range range56 = org.jfree.data.Range.combine(range43, (org.jfree.data.Range) dateRange49);
        numberAxis24.setDefaultAutoRange((org.jfree.data.Range) dateRange49);
        org.jfree.data.RangeType rangeType58 = numberAxis24.getRangeType();
        xYPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder60 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(rangeType58);
        org.junit.Assert.assertNotNull(datasetRenderingOrder60);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D18 = xYPlot15.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D18);
        xYPlot0.mapDatasetToRangeAxis(10, 0);
        xYPlot0.configureRangeAxes();
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color5 = java.awt.Color.gray;
        stackedBarRenderer3D3.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color5, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        stackedBarRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator8);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset10.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot11);
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int20 = month19.getMonth();
        defaultCategoryDataset10.addValue(0.0d, (java.lang.Comparable) month19, (java.lang.Comparable) 4);
        org.jfree.data.gantt.Task task23 = new org.jfree.data.gantt.Task("0.5", (org.jfree.data.time.TimePeriod) month19);
        org.jfree.data.time.TimePeriod timePeriod24 = task23.getDuration();
        java.lang.Double double25 = task23.getPercentComplete();
        java.lang.Double double26 = task23.getPercentComplete();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(timePeriod24);
        org.junit.Assert.assertNull(double25);
        org.junit.Assert.assertNull(double26);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) 100, (double) 6, 1.0d);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = month4.getYear();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double8 = categoryAxis3D7.getFixedDimension();
        categoryAxis3D7.setUpperMargin((double) 9999);
        java.lang.Object obj11 = categoryAxis3D7.clone();
        int int12 = categoryAxis3D7.getCategoryLabelPositionOffset();
        boolean boolean13 = year5.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj1 = polarPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getAutoRangeMinimumSize();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.configure();
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = new org.jfree.chart.axis.DateTickUnit(2, 1, (-8355712), (int) (short) 100, dateFormat10);
        java.util.Date date12 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit11);
        java.text.DateFormat dateFormat17 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 8, 13, 1, dateFormat17);
        java.util.Date date19 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit18);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue3 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "hi!", (java.lang.Number) 1L);
        java.lang.Comparable comparable4 = defaultKeyedValue3.getKey();
        boolean boolean5 = color0.equals((java.lang.Object) comparable4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        java.lang.String str3 = unitType2.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.ABSOLUTE" + "'", str3.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj6 = null;
        boolean boolean7 = taskSeriesCollection5.equals(obj6);
        boolean boolean8 = stackedBarRenderer3D2.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int10 = segmentedTimeline9.getSegmentsExcluded();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment12 = segmentedTimeline9.getSegment(date11);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D14 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list15 = defaultKeyedValues2D14.getRowKeys();
        segmentedTimeline9.addExceptions(list15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = segmentedTimeline9.getBaseTimeline();
        long long20 = segmentedTimeline17.getExceptionSegmentCount((long) (byte) 10, (long) (short) 1);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline17.addException(date21);
        int int23 = taskSeriesCollection5.indexOf((java.lang.Comparable) date21);
        try {
            java.lang.Number number26 = taskSeriesCollection5.getPercentComplete(2958465, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(segment12);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }
}

