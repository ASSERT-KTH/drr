import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        segmentedTimeline0.addExceptions(list6);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = segmentedTimeline0.getBaseTimeline();
        long long11 = segmentedTimeline8.getExceptionSegmentCount((long) (byte) 10, (long) (short) 1);
        int int12 = segmentedTimeline8.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke7 = lineBorder6.getStroke();
        xYPlot2.setRangeGridlineStroke(stroke7);
        piePlot3D1.setLabelLinkStroke(stroke7);
        piePlot3D1.setSectionOutlinesVisible(false);
        java.lang.Object obj12 = piePlot3D1.clone();
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int8 = segmentedTimeline7.getSegmentsExcluded();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline7.getSegment(date9);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        segmentedTimeline7.addExceptions(list13);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = segmentedTimeline7.getBaseTimeline();
        long long18 = segmentedTimeline15.getExceptionSegmentCount((long) (byte) 10, (long) (short) 1);
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline15.addException(date19);
        boolean boolean21 = segmentedTimeline0.containsDomainRange(date6, date19);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 68 + "'", int8 == 68);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean35 = dateRange29.equals((java.lang.Object) color34);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange29);
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.RangeType rangeType38 = numberAxis4.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot41.setLegendItemShape(shape44);
        piePlot41.setMaximumLabelWidth((double) (-457));
        boolean boolean48 = numberTickUnit40.equals((java.lang.Object) piePlot41);
        numberAxis4.setTickUnit(numberTickUnit40);
        boolean boolean50 = numberAxis4.isPositiveArrowVisible();
        java.awt.Shape shape51 = numberAxis4.getRightArrow();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer54 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock55 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor59 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape63 = textBlock55.calculateBounds(graphics2D56, (float) 'a', (float) 4, textBlockAnchor59, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer54.setBaseShape(shape63);
        double double65 = statisticalLineAndShapeRenderer54.getItemLabelAnchorOffset();
        java.awt.Paint paint66 = statisticalLineAndShapeRenderer54.getBaseItemLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray69 = new org.jfree.chart.axis.ValueAxis[] { valueAxis68 };
        xYPlot67.setDomainAxes(valueAxisArray69);
        org.jfree.chart.util.Layer layer71 = null;
        java.util.Collection collection72 = xYPlot67.getRangeMarkers(layer71);
        org.jfree.chart.title.LegendTitle legendTitle73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot67);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset74 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot();
        xYPlot75.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset74.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot75);
        boolean boolean79 = xYPlot75.isDomainZoomable();
        java.awt.Stroke stroke80 = xYPlot75.getRangeZeroBaselineStroke();
        xYPlot67.setRangeCrosshairStroke(stroke80);
        java.awt.Color color82 = java.awt.Color.gray;
        java.awt.image.ColorModel colorModel83 = null;
        java.awt.Rectangle rectangle84 = null;
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        java.awt.geom.AffineTransform affineTransform86 = null;
        java.awt.RenderingHints renderingHints87 = null;
        java.awt.PaintContext paintContext88 = color82.createContext(colorModel83, rectangle84, rectangle2D85, affineTransform86, renderingHints87);
        try {
            org.jfree.chart.LegendItem legendItem89 = new org.jfree.chart.LegendItem(attributedString0, "GradientPaintTransformType.HORIZONTAL", "ItemLabelAnchor.OUTSIDE12", "", shape51, paint66, stroke80, (java.awt.Paint) color82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(textBlockAnchor59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 2.0d + "'", double65 == 2.0d);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(valueAxisArray69);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(paintContext88);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ThreadContext", jFreeChart1, (int) (short) 10, (int) '#');
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        chartProgressEvent4.setType((-8355712));
        chartProgressEvent4.setType((int) '4');
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D9 = xYPlot6.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 0, (double) (-1.0f), plotRenderingInfo5, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getRangeMarkers(layer15);
        java.awt.Stroke stroke17 = xYPlot11.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart24.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke17, jFreeChart24, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle30 = null;
        jFreeChart24.setTitle(textTitle30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        xYPlot32.setDomainAxes(valueAxisArray34);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = xYPlot32.getRangeMarkers(layer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        xYPlot32.drawRangeTickBands(graphics2D38, rectangle2D39, list40);
        xYPlot32.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer43 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray46 = new org.jfree.chart.axis.ValueAxis[] { valueAxis45 };
        xYPlot44.setDomainAxes(valueAxisArray46);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke49 = lineBorder48.getStroke();
        xYPlot44.setRangeGridlineStroke(stroke49);
        minMaxCategoryRenderer43.setGroupStroke(stroke49);
        xYPlot32.setDomainGridlineStroke(stroke49);
        jFreeChart24.setBorderStroke(stroke49);
        xYPlot0.setDomainCrosshairStroke(stroke49);
        org.jfree.chart.axis.ValueAxis valueAxis56 = xYPlot0.getRangeAxis(10);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(legendTitle26);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(valueAxisArray46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(valueAxis56);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean35 = dateRange29.equals((java.lang.Object) color34);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange29);
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.RangeType rangeType38 = numberAxis4.getRangeType();
        xYPlot0.setDomainAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rangeType38);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D9 = xYPlot6.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 0, (double) (-1.0f), plotRenderingInfo5, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getRangeMarkers(layer15);
        java.awt.Stroke stroke17 = xYPlot11.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart24.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke17, jFreeChart24, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle30 = null;
        jFreeChart24.setTitle(textTitle30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        xYPlot32.setDomainAxes(valueAxisArray34);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = xYPlot32.getRangeMarkers(layer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        xYPlot32.drawRangeTickBands(graphics2D38, rectangle2D39, list40);
        xYPlot32.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer43 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray46 = new org.jfree.chart.axis.ValueAxis[] { valueAxis45 };
        xYPlot44.setDomainAxes(valueAxisArray46);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke49 = lineBorder48.getStroke();
        xYPlot44.setRangeGridlineStroke(stroke49);
        minMaxCategoryRenderer43.setGroupStroke(stroke49);
        xYPlot32.setDomainGridlineStroke(stroke49);
        jFreeChart24.setBorderStroke(stroke49);
        xYPlot0.setDomainCrosshairStroke(stroke49);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(legendTitle26);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(valueAxisArray46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 1900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer4.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator9 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer4.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator9);
        java.text.NumberFormat numberFormat11 = standardCategoryToolTipGenerator9.getNumberFormat();
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator12 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ThreadContext", numberFormat11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) 3600000L, numberFormat11);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup54 = defaultCategoryDataset53.getGroup();
        defaultCategoryDataset53.removeColumn((java.lang.Comparable) 60000L);
        legendItem50.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset53);
        try {
            java.lang.Comparable comparable59 = defaultCategoryDataset53.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetGroup54);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor8, textAnchor9, (double) (-460));
        textLine0.draw(graphics2D3, 1.0f, (float) 6, textAnchor9, (float) 15, (float) 12, 12.0d);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        java.awt.Paint paint8 = stackedBarRenderer3D2.getSeriesFillPaint(8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        polarPlot0.setDataset(xYDataset1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        intervalMarker2.setLabel("HorizontalAlignment.CENTER");
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot9.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        xYPlot9.clearRangeMarkers();
        boolean boolean20 = xYPlot9.isRangeZoomable();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        boolean boolean22 = xYPlot9.isRangeCrosshairLockedOnData();
        org.jfree.data.general.DatasetGroup datasetGroup23 = xYPlot9.getDatasetGroup();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(datasetGroup23);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart6.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(legendTitle8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        boolean boolean10 = piePlot1.getIgnoreNullValues();
        piePlot1.setInteriorGap((double) (byte) 0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str4 = textBlockAnchor3.toString();
        boolean boolean5 = groupedStackedBarRenderer0.equals((java.lang.Object) textBlockAnchor3);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str4.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        numberAxis0.setAutoRange(true);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-8355712));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape38, "GradientPaintTransformType.HORIZONTAL", "");
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) 0);
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Number number8 = defaultKeyedValues2D1.getValue(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsGroupSize();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long3 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        piePlot1.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo10);
        boolean boolean12 = layer0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D18 = xYPlot15.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D18);
        xYPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape11 = textBlock3.calculateBounds(graphics2D4, (float) 'a', (float) 4, textBlockAnchor7, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer2.setBaseShape(shape11);
        double double13 = statisticalLineAndShapeRenderer2.getItemLabelAnchorOffset();
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { valueAxis16 };
        xYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot15.getRangeMarkers(layer19);
        java.awt.Paint paint21 = xYPlot15.getRangeCrosshairPaint();
        boolean boolean22 = xYPlot15.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot15.getDomainAxisLocation();
        java.awt.Paint paint24 = xYPlot15.getDomainGridlinePaint();
        statisticalLineAndShapeRenderer2.setBasePaint(paint24);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        java.awt.Paint paint5 = piePlot0.getLabelPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { valueAxis9 };
        xYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getRangeMarkers(layer12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot8);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle14.setWrapper(blockContainer15);
        java.awt.geom.Rectangle2D rectangle2D17 = legendTitle14.getBounds();
        try {
            piePlot0.drawBackground(graphics2D7, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.data.Range range21 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range11, lengthConstraintType17, (double) 6, range21, lengthConstraintType22);
        boolean boolean24 = taskSeriesCollection0.equals((java.lang.Object) range21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent25);
        org.jfree.data.gantt.TaskSeries taskSeries27 = null;
        try {
            taskSeriesCollection0.remove(taskSeries27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj21 = null;
        boolean boolean22 = taskSeriesCollection20.equals(obj21);
        taskSeriesCollection20.removeAll();
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection20);
        taskSeriesCollection20.removeAll();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        boolean boolean9 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.Date date4 = segment3.getDate();
        boolean boolean5 = segment3.inExceptionSegments();
        boolean boolean6 = segment3.inExcludeSegments();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj8 = polarPlot7.clone();
        try {
            int int9 = segment3.compareTo(obj8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange20);
        org.jfree.data.Range range22 = rectangleConstraint21.getWidthRange();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange27);
        org.jfree.data.Range range31 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange27, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange35);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType37 = rectangleConstraint36.getWidthConstraintType();
        org.jfree.data.Range range41 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range31, lengthConstraintType37, (double) 6, range41, lengthConstraintType42);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint21.toRangeHeight(range31);
        org.jfree.chart.util.Size2D size2D45 = legendTitle12.arrange(graphics2D16, rectangleConstraint44);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(lengthConstraintType37);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(size2D45);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        polarPlot0.setDataset(xYDataset1);
        polarPlot0.addCornerTextItem("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10");
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot0.getAxis();
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        stackedBarRenderer3D2.setBaseOutlinePaint(paint9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        xYPlot5.setRangeGridlineStroke(stroke10);
        piePlot3D4.setLabelLinkStroke(stroke10);
        java.awt.Stroke stroke13 = piePlot3D4.getBaseSectionOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke13);
        java.lang.Object obj15 = null;
        boolean boolean16 = polarPlot0.equals(obj15);
        polarPlot0.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot3);
        stackedBarRenderer3D2.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot3);
        double double11 = stackedBarRenderer3D2.getMinimumBarLength();
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset1.getGroup();
        defaultCategoryDataset0.setGroup(datasetGroup2);
        java.lang.String str4 = datasetGroup2.getID();
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NOID" + "'", str4.equals("NOID"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        java.lang.String str3 = numberTickUnit1.valueToString((double) 0.5f);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.5" + "'", str3.equals("0.5"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator5 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext");
        stackedBarRenderer3D2.setSeriesURLGenerator(12, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator5, true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator11 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
        boolean boolean12 = standardCategoryURLGenerator5.equals((java.lang.Object) standardCategoryURLGenerator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange8);
        org.jfree.data.Range range12 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange8, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange16);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.jfree.data.Range range22 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range12, lengthConstraintType18, (double) 6, range22, lengthConstraintType23);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange28);
        org.jfree.data.Range range32 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange28, (double) 0.0f, (double) (short) 0);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean34 = dateRange28.equals((java.lang.Object) color33);
        org.jfree.data.Range range35 = org.jfree.data.Range.combine(range22, (org.jfree.data.Range) dateRange28);
        numberAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange28);
        dateAxis0.setRange((org.jfree.data.Range) dateRange28, true, true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Color color1 = java.awt.Color.getColor("({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        legendTitle6.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle6.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets10.getBottom();
        legendTitle6.setPadding(rectangleInsets10);
        java.lang.Object obj13 = legendTitle6.clone();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        double double3 = levelRenderer0.getItemMargin();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot4.getRangeCrosshairPaint();
        boolean boolean11 = xYPlot4.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot13.setLegendItemShape(shape16);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot4, (java.lang.Object) piePlot13);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D22 = xYPlot19.getQuadrantOrigin();
        xYPlot4.setQuadrantOrigin(point2D22);
        xYPlot4.mapDatasetToRangeAxis(10, 0);
        levelRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot4);
        boolean boolean29 = levelRenderer0.isSeriesVisible((int) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot0.getLabelDistributor();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker3.setLabelTextAnchor(textAnchor4);
        java.awt.Stroke stroke6 = intervalMarker3.getOutlineStroke();
        java.awt.Paint paint7 = intervalMarker3.getOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) date15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(categoryDataset17);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, true);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot5.setLegendItemShape(shape8);
        java.awt.Paint paint10 = piePlot5.getLabelPaint();
        boolean boolean11 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot5);
        try {
            java.lang.Comparable comparable13 = defaultCategoryDataset0.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int4 = month3.getMonth();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color6 = color5.darker();
        piePlot0.setSectionPaint((java.lang.Comparable) int4, (java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range8, lengthConstraintType14, (double) 6, range18, lengthConstraintType19);
        double double22 = range8.constrain((double) 10);
        double double23 = range8.getUpperBound();
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3);
        textBlock0.addLine(textLine5);
        org.jfree.chart.text.TextLine textLine7 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textLine7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        java.util.List list3 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend((int) (short) 10);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItemEntity19.setDataset(dataset20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        xYPlot22.setDomainAxes(valueAxisArray24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot22.getRangeMarkers(layer26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot22);
        boolean boolean29 = legendItemEntity19.equals((java.lang.Object) legendTitle28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = legendTitle28.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle28);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        legendTitle28.setItemLabelPadding(rectangleInsets32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle28.setVerticalAlignment(verticalAlignment34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle28.getPadding();
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) legendTitle28);
        java.awt.Paint paint38 = null;
        legendTitle28.setBackgroundPaint(paint38);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend((int) (short) 10);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItemEntity19.setDataset(dataset20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        xYPlot22.setDomainAxes(valueAxisArray24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot22.getRangeMarkers(layer26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot22);
        boolean boolean29 = legendItemEntity19.equals((java.lang.Object) legendTitle28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = legendTitle28.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle28);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        legendTitle28.setItemLabelPadding(rectangleInsets32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle28.setVerticalAlignment(verticalAlignment34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle28.getPadding();
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) legendTitle28);
        org.jfree.chart.event.ChartProgressListener chartProgressListener38 = null;
        jFreeChart8.addProgressListener(chartProgressListener38);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext");
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) standardCategoryURLGenerator3);
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange8);
        org.jfree.data.Range range10 = rectangleConstraint9.getWidthRange();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.data.Range range19 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange15, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange23);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = rectangleConstraint24.getWidthConstraintType();
        org.jfree.data.Range range29 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range19, lengthConstraintType25, (double) 6, range29, lengthConstraintType30);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint9.toRangeHeight(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint9.toFixedHeight((double) 100);
        boolean boolean36 = keyedObjects0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        int int3 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 3600000L, (java.lang.Comparable) "({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        boolean boolean6 = segment3.contained((long) 6, (long) 13);
        boolean boolean7 = segment3.inExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator7);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer2.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D15.configure();
        categoryAxis3D15.setLowerMargin((double) 12);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj21 = null;
        boolean boolean22 = taskSeriesCollection20.equals(obj21);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange27);
        org.jfree.data.Range range31 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange27, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange35);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType37 = rectangleConstraint36.getWidthConstraintType();
        org.jfree.data.Range range41 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range31, lengthConstraintType37, (double) 6, range41, lengthConstraintType42);
        boolean boolean44 = taskSeriesCollection20.equals((java.lang.Object) range41);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = null;
        taskSeriesCollection20.seriesChanged(seriesChangeEvent45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection20, true);
        int int49 = taskSeriesCollection20.getRowCount();
        try {
            statisticalLineAndShapeRenderer2.drawItem(graphics2D10, categoryItemRendererState11, rectangle2D12, categoryPlot13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, valueAxis19, (org.jfree.data.category.CategoryDataset) taskSeriesCollection20, (-460), 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(lengthConstraintType37);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font2);
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock3.setFont(font4);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textFragment6.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape11 = textBlock3.calculateBounds(graphics2D4, (float) 'a', (float) 4, textBlockAnchor7, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer2.setBaseShape(shape11);
        double double13 = statisticalLineAndShapeRenderer2.getItemLabelAnchorOffset();
        java.awt.Font font14 = null;
        try {
            statisticalLineAndShapeRenderer2.setBaseItemLabelFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int7 = month6.getMonth();
        try {
            org.jfree.data.xy.XYDataset xYDataset8 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 1202L, (double) (byte) 1, 2, (java.lang.Comparable) month6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker3.setLabelTextAnchor(textAnchor4);
        java.awt.Stroke stroke6 = intervalMarker3.getOutlineStroke();
        java.awt.Paint paint7 = intervalMarker3.getOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        java.lang.String str9 = multiplePiePlot0.getPlotType();
        java.awt.Paint paint10 = null;
        try {
            multiplePiePlot0.setAggregatedItemsPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        jFreeChart6.setAntiAlias(true);
        boolean boolean11 = jFreeChart6.isBorderVisible();
        jFreeChart6.setAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            java.awt.image.BufferedImage bufferedImage19 = jFreeChart6.createBufferedImage(5, 0, (double) 3, (double) 100.0f, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (5) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        double double7 = stackedBarRenderer3D2.getBase();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D2.getLegendItems();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-8355712));
        java.awt.Color color15 = java.awt.Color.gray;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("{0}", "RectangleAnchor.CENTER", "", "", shape14, (java.awt.Paint) color15);
        legendItemCollection8.add(legendItem16);
        java.lang.Object obj18 = legendItemCollection8.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean2 = standardCategoryToolTipGenerator0.equals((java.lang.Object) categoryLabelPositions1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) (-2.0d), (java.lang.Object) categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        xYPlot18.setRangeGridlineStroke(stroke23);
        minMaxCategoryRenderer17.setGroupStroke(stroke23);
        jFreeChart10.setBorderStroke(stroke23);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot27);
        org.jfree.chart.block.BlockContainer blockContainer34 = null;
        legendTitle33.setWrapper(blockContainer34);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle33);
        java.awt.RenderingHints renderingHints37 = null;
        try {
            jFreeChart10.setRenderingHints(renderingHints37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range34 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock38 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape46 = textBlock38.calculateBounds(graphics2D39, (float) 'a', (float) 4, textBlockAnchor42, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer37.setBaseShape(shape46);
        numberAxis0.setDownArrow(shape46);
        double double49 = numberAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge(68);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint4 = minMaxCategoryRenderer0.lookupSeriesFillPaint(2);
        boolean boolean5 = minMaxCategoryRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer2.getItemOutlineStroke((int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange6, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.jfree.data.Range range20 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range10, lengthConstraintType16, (double) 6, range20, lengthConstraintType21);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange26);
        org.jfree.data.Range range30 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange26, (double) 0.0f, (double) (short) 0);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean32 = dateRange26.equals((java.lang.Object) color31);
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range20, (org.jfree.data.Range) dateRange26);
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange26);
        numberAxis1.centerRange((double) (byte) -1);
        numberAxis1.setLowerBound((double) 100);
        numberAxis1.setTickMarksVisible(true);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis1);
        polarPlot0.removeCornerTextItem("RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        xYPlot1.setDomainAxes(valueAxisArray3);
        xYPlot1.setRangeCrosshairValue(0.0d);
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot8.setLegendItemShape(shape11);
        java.awt.Paint paint13 = piePlot8.getLabelPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = piePlot8.getLegendItems();
        int int15 = legendItemCollection14.getItemCount();
        int int16 = legendItemCollection14.getItemCount();
        xYPlot1.setFixedLegendItems(legendItemCollection14);
        int int18 = legendItemCollection14.getItemCount();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) columnArrangement10);
        columnArrangement10.clear();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        boolean boolean4 = textBlockAnchor0.equals((java.lang.Object) dateRange3);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot12);
        legendTitle18.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets22.getBottom();
        legendTitle18.setPadding(rectangleInsets22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendTitle18.getLegendItemGraphicAnchor();
        legendTitle11.setLegendItemGraphicLocation(rectangleAnchor25);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot12.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend((int) (short) 10);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItemEntity19.setDataset(dataset20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        xYPlot22.setDomainAxes(valueAxisArray24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot22.getRangeMarkers(layer26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot22);
        boolean boolean29 = legendItemEntity19.equals((java.lang.Object) legendTitle28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = legendTitle28.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle28);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        legendTitle28.setItemLabelPadding(rectangleInsets32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle28.setVerticalAlignment(verticalAlignment34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle28.getPadding();
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) legendTitle28);
        jFreeChart8.setBackgroundImageAlignment(15);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getRenderAsPercentages();
        boolean boolean2 = stackedBarRenderer0.getRenderAsPercentages();
        stackedBarRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) segment3);
        boolean boolean6 = segment3.contains(60000L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        org.jfree.chart.LegendItem legendItem12 = statisticalLineAndShapeRenderer2.getLegendItem(0, 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D2.getBasePositiveItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D(pieDataset15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        xYPlot17.setDomainAxes(valueAxisArray19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getRangeMarkers(layer21);
        java.awt.Paint paint23 = xYPlot17.getRangeCrosshairPaint();
        piePlot3D16.setLabelOutlinePaint(paint23);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean28 = statisticalLineAndShapeRenderer27.getUseOutlinePaint();
        java.awt.Paint paint31 = statisticalLineAndShapeRenderer27.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D16.setShadowPaint(paint31);
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        polarPlot33.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D(pieDataset36);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { valueAxis39 };
        xYPlot38.setDomainAxes(valueAxisArray40);
        org.jfree.chart.block.LineBorder lineBorder42 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke43 = lineBorder42.getStroke();
        xYPlot38.setRangeGridlineStroke(stroke43);
        piePlot3D37.setLabelLinkStroke(stroke43);
        java.awt.Stroke stroke46 = piePlot3D37.getBaseSectionOutlineStroke();
        polarPlot33.setAngleGridlineStroke(stroke46);
        piePlot3D16.setBaseSectionOutlineStroke(stroke46);
        stackedBarRenderer3D2.setBaseStroke(stroke46);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getBaseSectionOutlineStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot5.getRangeMarkers(layer9);
        java.awt.Paint paint11 = xYPlot5.getRangeCrosshairPaint();
        boolean boolean12 = xYPlot5.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot5.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot5, (java.lang.Object) piePlot14);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D23 = xYPlot20.getQuadrantOrigin();
        xYPlot5.setQuadrantOrigin(point2D23);
        org.jfree.chart.plot.PlotState plotState25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { valueAxis27 };
        xYPlot26.setDomainAxes(valueAxisArray28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = xYPlot26.getRangeMarkers(layer30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot26.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        xYPlot26.clearRangeMarkers();
        boolean boolean37 = xYPlot26.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { valueAxis39 };
        xYPlot38.setDomainAxes(valueAxisArray40);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = xYPlot38.getRangeMarkers(layer42);
        java.awt.Stroke stroke44 = xYPlot38.getDomainCrosshairStroke();
        xYPlot26.setDomainCrosshairStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        xYPlot26.handleClick((-1), 2, plotRenderingInfo49);
        try {
            piePlot3D1.draw(graphics2D3, rectangle2D4, point2D23, plotState25, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NOID", "", doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(categoryDataset6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup54 = defaultCategoryDataset53.getGroup();
        defaultCategoryDataset53.removeColumn((java.lang.Comparable) 60000L);
        legendItem50.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset53);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset53);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetGroup54);
        org.junit.Assert.assertNull(range58);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getFillPaint();
        java.lang.Object obj12 = legendGraphic8.clone();
        java.awt.Stroke stroke13 = legendGraphic8.getLineStroke();
        boolean boolean14 = legendGraphic8.isShapeOutlineVisible();
        java.lang.Object obj15 = legendGraphic8.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot10);
        org.jfree.data.Range range14 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int19 = month18.getMonth();
        defaultCategoryDataset9.addValue(0.0d, (java.lang.Comparable) month18, (java.lang.Comparable) 4);
        java.lang.String str22 = month18.toString();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "February 100" + "'", str22.equals("February 100"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        taskSeriesCollection0.removeAll();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        taskSeriesCollection0.addChangeListener(datasetChangeListener4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue(0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (-460));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) defaultCategoryDataset0);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int9 = month8.getMonth();
        long long10 = month8.getSerialIndex();
        defaultCategoryDataset0.setValue((java.lang.Number) 3600000L, (java.lang.Comparable) long10, (java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1202L + "'", long10 == 1202L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        intervalMarker2.setLabel("HorizontalAlignment.CENTER");
        java.lang.Object obj9 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        piePlot0.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint7 = piePlot0.getShadowPaint();
        piePlot0.setIgnoreNullValues(true);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape12, 1.0d, 1.0f, 0.0f);
        piePlot0.setLegendItemShape(shape12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange6, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.jfree.data.Range range20 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range10, lengthConstraintType16, (double) 6, range20, lengthConstraintType21);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange26);
        org.jfree.data.Range range30 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange26, (double) 0.0f, (double) (short) 0);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean32 = dateRange26.equals((java.lang.Object) color31);
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range20, (org.jfree.data.Range) dateRange26);
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange26);
        numberAxis1.centerRange((double) (byte) -1);
        numberAxis1.setLowerBound((double) 100);
        numberAxis1.setTickMarksVisible(true);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape44 = minMaxCategoryRenderer42.lookupSeriesShape((int) (short) 0);
        javax.swing.Icon icon45 = minMaxCategoryRenderer42.getMinIcon();
        java.awt.Paint paint48 = minMaxCategoryRenderer42.getItemLabelPaint((int) 'a', 15);
        polarPlot0.setAngleLabelPaint(paint48);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot51.setLegendItemShape(shape54);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot51);
        java.awt.Paint paint57 = piePlot51.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator58 = null;
        piePlot51.setToolTipGenerator(pieToolTipGenerator58);
        boolean boolean60 = piePlot51.getIgnoreNullValues();
        java.awt.Color color61 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color62 = color61.darker();
        piePlot51.setBaseSectionPaint((java.awt.Paint) color61);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color61);
        java.awt.Stroke stroke65 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(icon45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        float float18 = jFreeChart10.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        double double7 = stackedBarRenderer3D2.getBase();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D2.getLegendItems();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-8355712));
        java.awt.Color color15 = java.awt.Color.gray;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("{0}", "RectangleAnchor.CENTER", "", "", shape14, (java.awt.Paint) color15);
        legendItemCollection8.add(legendItem16);
        boolean boolean18 = legendItem16.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj21 = null;
        boolean boolean22 = taskSeriesCollection20.equals(obj21);
        taskSeriesCollection20.removeAll();
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection20);
        try {
            taskSeriesCollection20.remove(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("({0}, {1}) = {3} - {4}", "RangeType.FULL");
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator7 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator7);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range12 = groupedStackedBarRenderer10.findRangeBounds(categoryDataset11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        xYPlot13.setDomainAxes(valueAxisArray15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot13.getRangeMarkers(layer17);
        java.awt.Paint paint19 = xYPlot13.getRangeCrosshairPaint();
        boolean boolean20 = xYPlot13.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot22.setLegendItemShape(shape25);
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot13, (java.lang.Object) piePlot22);
        boolean boolean28 = groupedStackedBarRenderer10.equals((java.lang.Object) xYPlot13);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer29 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape31 = minMaxCategoryRenderer29.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint33 = minMaxCategoryRenderer29.getSeriesFillPaint((-457));
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator34 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        minMaxCategoryRenderer29.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator34, true);
        groupedStackedBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator34);
        statisticalLineAndShapeRenderer2.setSeriesToolTipGenerator((int) ' ', (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator34, false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        double double10 = piePlot1.getExplodePercent((java.lang.Comparable) (-59008924800000L));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator11);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        boolean boolean9 = legendTitle6.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.util.List list10 = boxAndWhiskerItem9.getOutliers();
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(datasetGroup2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        boolean boolean7 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Paint paint8 = stackedBarRenderer3D2.getBaseFillPaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextPaint();
        stackedBarRenderer3D2.setBaseFillPaint(paint10, false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        piePlot3D1.setLabelOutlinePaint(paint8);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean13 = statisticalLineAndShapeRenderer12.getUseOutlinePaint();
        java.awt.Paint paint16 = statisticalLineAndShapeRenderer12.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D1.setShadowPaint(paint16);
        double double18 = piePlot3D1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getLowerMargin();
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        java.lang.String str53 = legendItem50.getDescription();
        boolean boolean54 = legendItem50.isShapeFilled();
        org.jfree.data.general.Dataset dataset55 = legendItem50.getDataset();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(dataset55);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        piePlot3.setMaximumLabelWidth((double) (-457));
        boolean boolean10 = numberTickUnit2.equals((java.lang.Object) piePlot3);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getRangeMarkers(layer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot11);
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        legendTitle17.setWrapper(blockContainer18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        boolean boolean21 = numberTickUnit2.equals((java.lang.Object) rectangle2D20);
        int int22 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) numberTickUnit2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list1 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue(13, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = waterfallBarRenderer0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        waterfallBarRenderer0.setBaseShape(shape6);
        java.awt.Font font9 = null;
        waterfallBarRenderer0.setBaseItemLabelFont(font9, false);
        double double12 = waterfallBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        boolean boolean6 = segment3.contained((long) 6, (long) 13);
        boolean boolean7 = segment3.inExcludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseShapesFilled(false);
        boolean boolean12 = statisticalLineAndShapeRenderer2.getDrawOutlines();
        org.jfree.chart.util.ShapeList shapeList13 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        boolean boolean16 = shapeList13.equals((java.lang.Object) shape15);
        statisticalLineAndShapeRenderer2.setBaseShape(shape15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-8355712));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D9 = xYPlot6.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 0, (double) (-1.0f), plotRenderingInfo5, point2D9);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer11, dataset12);
        xYPlot0.datasetChanged(datasetChangeEvent13);
        org.junit.Assert.assertNotNull(point2D9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        minMaxCategoryRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator7);
        minMaxCategoryRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double[][] doubleArray0 = null;
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray3);
        double[][] doubleArray7 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray7);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray3, doubleArray7);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray0, doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        xYPlot0.handleClick((-460), (int) (byte) 10, plotRenderingInfo14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot16.setLegendItemShape(shape19);
        java.awt.Paint paint21 = piePlot16.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        piePlot16.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo25);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo25);
        org.jfree.chart.renderer.RendererState rendererState28 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo25);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (-460));
        double double4 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset3);
        double double5 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset3);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot10);
        org.jfree.data.Range range14 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = stackedBarRenderer3D2.getURLGenerator((int) (short) 1, (-457));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryURLGenerator17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = waterfallBarRenderer0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        waterfallBarRenderer0.setBaseShape(shape6);
        waterfallBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        java.lang.Boolean boolean14 = waterfallBarRenderer0.getSeriesVisibleInLegend(68);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        java.lang.String str53 = legendItem50.getDescription();
        java.awt.Paint paint54 = legendItem50.getOutlinePaint();
        boolean boolean55 = legendItem50.isShapeFilled();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        size2D2.setHeight(1.0d);
        size2D2.height = 10;
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker3.setLabelTextAnchor(textAnchor4);
        java.awt.Stroke stroke6 = intervalMarker3.getOutlineStroke();
        java.awt.Paint paint7 = intervalMarker3.getOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) date15);
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("hi!", font18);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset20.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot21);
        boolean boolean25 = textFragment19.equals((java.lang.Object) defaultCategoryDataset20);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        stackedBarRenderer3D2.setBaseOutlinePaint(paint9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultCategoryDataset11.getGroup();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (-460));
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        double double16 = stackedBarRenderer3D2.getLowerClip();
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        textBlock0.addLine("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", font2, (java.awt.Paint) color3);
        int int5 = color3.getTransparency();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getFixedDimension();
        categoryAxis3D1.setUpperMargin((double) 9999);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot10.setLegendItemShape(shape13);
        piePlot10.setMaximumLabelWidth((double) (-457));
        boolean boolean17 = numberTickUnit9.equals((java.lang.Object) piePlot10);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(layer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle24.setWrapper(blockContainer25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        boolean boolean28 = numberTickUnit9.equals((java.lang.Object) rectangle2D27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint30 = xYPlot29.getRangeTickBandPaint();
        java.awt.Image image31 = xYPlot29.getBackgroundImage();
        xYPlot29.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement39 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment35, verticalAlignment36, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot29, (org.jfree.chart.block.Arrangement) columnArrangement34, (org.jfree.chart.block.Arrangement) columnArrangement39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = legendTitle40.getPosition();
        try {
            double double42 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor5, (int) (byte) 10, 0, rectangle2D27, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", str1.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D2.setItemMargin((double) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = stackedBarRenderer3D2.getToolTipGenerator(10, (int) '4');
        boolean boolean9 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Paint paint9 = legendGraphic8.getLinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (-59008924800000L), (double) 172800000L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart6.getLegend((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets9.getBottom();
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets9.getUnitType();
        double double13 = rectangleInsets9.calculateTopInset(10.0d);
        jFreeChart6.setPadding(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(legendTitle8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        java.lang.Boolean boolean5 = stackedBarRenderer3D2.getSeriesVisibleInLegend((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D2.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Color color2 = java.awt.Color.BLUE;
        int int3 = color2.getTransparency();
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color2, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range8, lengthConstraintType14, (double) 6, range18, lengthConstraintType19);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange24);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange24, (double) 0.0f, (double) (short) 0);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean30 = dateRange24.equals((java.lang.Object) color29);
        org.jfree.data.Range range31 = org.jfree.data.Range.combine(range18, (org.jfree.data.Range) dateRange24);
        java.util.Date date32 = dateRange24.getUpperDate();
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("ThreadContext");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape5 = minMaxCategoryRenderer3.lookupSeriesShape((int) (short) 0);
        boolean boolean6 = projectInfo0.equals((java.lang.Object) (short) 0);
        projectInfo0.setCopyright("XY Plot");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        java.lang.Object obj6 = legendItemEntity3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range34 = numberAxis0.getRange();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape37);
        org.jfree.data.general.Dataset dataset39 = null;
        legendItemEntity38.setDataset(dataset39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray43 = new org.jfree.chart.axis.ValueAxis[] { valueAxis42 };
        xYPlot41.setDomainAxes(valueAxisArray43);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot41.getRangeMarkers(layer45);
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot41);
        boolean boolean48 = legendItemEntity38.equals((java.lang.Object) legendTitle47);
        java.awt.Font font49 = legendTitle47.getItemFont();
        java.awt.Font font51 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font51);
        java.awt.Font font53 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock52.setFont(font53);
        legendTitle47.setItemFont(font53);
        numberAxis0.setLabelFont(font53);
        numberAxis0.setFixedDimension((double) (short) 1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(valueAxisArray43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(font53);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        xYPlot0.handleClick((-460), (int) (byte) 10, plotRenderingInfo14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        xYPlot0.setInsets(rectangleInsets16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYPlot0.setDomainTickBandPaint(paint18);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) 31);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets2.getBottom();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets2.getUnitType();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        labelBlock1.setPadding(rectangleInsets2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        xYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot10.getRangeMarkers(layer14);
        java.awt.Paint paint16 = xYPlot10.getRangeCrosshairPaint();
        piePlot3D9.setLabelOutlinePaint(paint16);
        boolean boolean18 = labelBlock1.equals((java.lang.Object) paint16);
        java.lang.Object obj19 = labelBlock1.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        float float7 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        xYPlot0.clearAnnotations();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        double double14 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint17 = xYPlot16.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation18, plotOrientation19);
        xYPlot0.setDomainAxisLocation(0, axisLocation18);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str8 = legendItemEntity7.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("Third", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getRangeMarkers(layer15);
        java.awt.Paint paint17 = xYPlot11.getRangeCrosshairPaint();
        piePlot3D10.setLabelOutlinePaint(paint17);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean22 = statisticalLineAndShapeRenderer21.getUseOutlinePaint();
        java.awt.Paint paint25 = statisticalLineAndShapeRenderer21.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D10.setShadowPaint(paint25);
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape2, paint25);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke29 = lineBorder28.getStroke();
        legendGraphic27.setFrame((org.jfree.chart.block.BlockFrame) lineBorder28);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 90.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(pieDataset18);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) rectangleEdge2);
        java.util.List list4 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray2);
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray6);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray2, doubleArray6);
        try {
            java.lang.Comparable comparable10 = defaultIntervalCategoryDataset8.getSeriesKey(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) (-2.0d), (java.lang.Object) categoryLabelPosition1);
        java.lang.Object obj3 = keyedObject2.clone();
        java.lang.Object obj4 = keyedObject2.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        legendItemEntity3.setURLText("");
        java.lang.Object obj8 = legendItemEntity3.clone();
        java.lang.String str9 = legendItemEntity3.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str9.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        waterfallBarRenderer1.setPositiveBarPaint((java.awt.Paint) color2);
        barRenderer3D0.setBasePaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        java.awt.Paint paint5 = piePlot0.getLabelPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        piePlot0.setBaseSectionPaint(paint6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint4 = minMaxCategoryRenderer0.getSeriesFillPaint((-457));
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape7 = minMaxCategoryRenderer5.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint9 = minMaxCategoryRenderer5.getSeriesFillPaint((-457));
        boolean boolean11 = minMaxCategoryRenderer5.isSeriesItemLabelsVisible(4);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer12 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape14 = minMaxCategoryRenderer12.lookupSeriesShape((int) (short) 0);
        javax.swing.Icon icon15 = minMaxCategoryRenderer12.getMinIcon();
        minMaxCategoryRenderer5.setMaxIcon(icon15);
        minMaxCategoryRenderer0.setMinIcon(icon15);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(icon15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation2, plotOrientation3);
        java.lang.String str5 = axisLocation2.toString();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str5.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getFixedDimension();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets5.getBottom();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets5.getUnitType();
        double double9 = rectangleInsets5.calculateTopInset(0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot12.setLegendItemShape(shape15);
        piePlot12.setMaximumLabelWidth((double) (-457));
        boolean boolean19 = numberTickUnit11.equals((java.lang.Object) piePlot12);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        xYPlot20.setDomainAxes(valueAxisArray22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot20.getRangeMarkers(layer24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot20);
        org.jfree.chart.block.BlockContainer blockContainer27 = null;
        legendTitle26.setWrapper(blockContainer27);
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        boolean boolean30 = numberTickUnit11.equals((java.lang.Object) rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets5.createInsetRectangle(rectangle2D29);
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape34, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot39.setLegendItemShape(shape42);
        piePlot39.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint46 = piePlot39.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic47 = new org.jfree.chart.title.LegendGraphic(shape34, paint46);
        java.awt.geom.Rectangle2D rectangle2D48 = legendGraphic47.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray52 = new org.jfree.chart.axis.ValueAxis[] { valueAxis51 };
        xYPlot50.setDomainAxes(valueAxisArray52);
        org.jfree.chart.util.Layer layer54 = null;
        java.util.Collection collection55 = xYPlot50.getRangeMarkers(layer54);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.util.List list58 = null;
        xYPlot50.drawRangeTickBands(graphics2D56, rectangle2D57, list58);
        xYPlot50.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo63);
        xYPlot50.handleClick((-460), (int) (byte) 10, plotRenderingInfo64);
        org.jfree.chart.plot.PiePlot piePlot66 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape69 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot66.setLegendItemShape(shape69);
        java.awt.Paint paint71 = piePlot66.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo74);
        piePlot66.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo75);
        plotRenderingInfo64.addSubplotInfo(plotRenderingInfo75);
        java.awt.geom.Rectangle2D rectangle2D78 = plotRenderingInfo75.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState79 = categoryAxis3D1.draw(graphics2D3, 0.0d, rectangle2D31, rectangle2D48, rectangleEdge49, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(valueAxisArray52);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(rectangle2D78);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-59008924800000L), 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        legendTitle12.setItemLabelPadding(rectangleInsets16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle12.setVerticalAlignment(verticalAlignment18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            legendTitle12.setBounds(rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment18);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        intervalMarker2.setLabel("HorizontalAlignment.CENTER");
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot9.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        xYPlot9.clearRangeMarkers();
        boolean boolean20 = xYPlot9.isRangeZoomable();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        intervalMarker2.setStartValue((double) 9999);
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font25);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock26.setFont(font27);
        intervalMarker2.setLabelFont(font27);
        intervalMarker2.setStartValue((double) 'a');
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker6.setLabelTextAnchor(textAnchor7);
        java.awt.Stroke stroke9 = intervalMarker6.getOutlineStroke();
        java.awt.Paint paint10 = intervalMarker6.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker6);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart6.getLegend((int) (short) 100);
        java.util.List list9 = jFreeChart6.getSubtitles();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(legendTitle8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = waterfallBarRenderer0.getNegativeBarPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot7.setLegendItemShape(shape10);
        piePlot7.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint14 = piePlot7.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape2, paint14);
        java.awt.Paint paint16 = null;
        legendGraphic15.setLinePaint(paint16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range17 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange13, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange21);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = rectangleConstraint22.getWidthConstraintType();
        org.jfree.data.Range range27 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range17, lengthConstraintType23, (double) 6, range27, lengthConstraintType28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint7.toRangeHeight(range17);
        try {
            org.jfree.chart.util.Size2D size2D31 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint30);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        piePlot3D1.setLabelOutlinePaint(paint8);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean13 = statisticalLineAndShapeRenderer12.getUseOutlinePaint();
        java.awt.Paint paint16 = statisticalLineAndShapeRenderer12.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D1.setShadowPaint(paint16);
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        polarPlot18.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D(pieDataset21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { valueAxis24 };
        xYPlot23.setDomainAxes(valueAxisArray25);
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke28 = lineBorder27.getStroke();
        xYPlot23.setRangeGridlineStroke(stroke28);
        piePlot3D22.setLabelLinkStroke(stroke28);
        java.awt.Stroke stroke31 = piePlot3D22.getBaseSectionOutlineStroke();
        polarPlot18.setAngleGridlineStroke(stroke31);
        piePlot3D1.setBaseSectionOutlineStroke(stroke31);
        double double34 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryLabelPosition4.getRotationAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.text.TextUtilities.drawAlignedString("Last", graphics2D1, (float) 68, (float) (-1), textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            blockContainer0.setArrangement(arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(arrangement1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) (short) 100, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        java.lang.Boolean boolean10 = stackedBarRenderer3D2.getSeriesCreateEntities((-1));
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        xYPlot18.setRangeGridlineStroke(stroke23);
        minMaxCategoryRenderer17.setGroupStroke(stroke23);
        jFreeChart10.setBorderStroke(stroke23);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot27);
        org.jfree.chart.block.BlockContainer blockContainer34 = null;
        legendTitle33.setWrapper(blockContainer34);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle33);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.text.TextBlock textBlock38 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape46 = textBlock38.calculateBounds(graphics2D39, (float) 'a', (float) 4, textBlockAnchor42, (float) 10, 0.0f, (-1.0d));
        org.jfree.chart.entity.LegendItemEntity legendItemEntity47 = new org.jfree.chart.entity.LegendItemEntity(shape46);
        boolean boolean48 = rectangleInsets37.equals((java.lang.Object) shape46);
        legendTitle33.setItemLabelPadding(rectangleInsets37);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        xYPlot5.setRangeGridlineStroke(stroke10);
        piePlot3D4.setLabelLinkStroke(stroke10);
        java.awt.Stroke stroke13 = piePlot3D4.getBaseSectionOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke13);
        polarPlot0.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        xYPlot5.setRangeGridlineStroke(stroke10);
        piePlot3D4.setLabelLinkStroke(stroke10);
        java.awt.Stroke stroke13 = piePlot3D4.getBaseSectionOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke13);
        java.lang.Object obj15 = null;
        boolean boolean16 = polarPlot0.equals(obj15);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        polarPlot0.setRadiusGridlinePaint(paint18);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        float float7 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        xYPlot0.clearAnnotations();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker16.setLabelTextAnchor(textAnchor17);
        java.awt.Stroke stroke19 = intervalMarker16.getOutlineStroke();
        java.awt.Paint paint20 = intervalMarker16.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker16);
        xYPlot0.markerChanged(markerChangeEvent21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        xYPlot0.setRangeAxis(96, valueAxis24, false);
        boolean boolean27 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = waterfallBarRenderer0.equals((java.lang.Object) rectangleEdge1);
        waterfallBarRenderer0.setItemMargin(90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle12.getPosition();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange21);
        double double23 = rectangleConstraint22.getHeight();
        org.jfree.chart.util.Size2D size2D24 = legendTitle12.arrange(graphics2D17, rectangleConstraint22);
        java.lang.String str25 = legendTitle12.getID();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot1.getDatasetRenderingOrder();
        try {
            xYPlot1.setBackgroundImageAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        defaultCategoryDataset7.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot18);
        java.awt.Color color23 = java.awt.Color.yellow;
        xYPlot18.setDomainCrosshairPaint((java.awt.Paint) color23);
        double double25 = xYPlot18.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range8, lengthConstraintType14, (double) 6, range18, lengthConstraintType19);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange(range8);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker13.setLabelTextAnchor(textAnchor14);
        java.awt.Stroke stroke16 = intervalMarker13.getOutlineStroke();
        java.awt.Paint paint17 = intervalMarker13.getOutlinePaint();
        legendGraphic8.setOutlinePaint(paint17);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setIncludeBaseInRange(true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset1.getGroup();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        boolean boolean10 = xYPlot3.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot3.getDomainAxisLocation();
        defaultCategoryDataset1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot3);
        xYPlot3.clearAnnotations();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("Third", (org.jfree.chart.plot.Plot) xYPlot3);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) 10, (double) (byte) 1, (double) 1, (double) (byte) -1, (java.awt.Paint) color19);
        xYPlot3.setOutlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle11.getPosition();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        xYPlot13.setDomainAxes(valueAxisArray15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot13.getRangeMarkers(layer17);
        java.awt.Paint paint19 = xYPlot13.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot13.getRangeAxisEdge();
        legendTitle11.setPosition(rectangleEdge20);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
        java.lang.Object obj2 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        xYPlot6.setRangeGridlineStroke(stroke11);
        statisticalLineAndShapeRenderer2.setBaseStroke(stroke11, false);
        java.awt.Stroke stroke16 = statisticalLineAndShapeRenderer2.getSeriesStroke((-457));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        statisticalLineAndShapeRenderer2.setSeriesItemLabelGenerator(100, categoryItemLabelGenerator18, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(stroke16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getLowerMargin();
        categoryAxis3D1.setVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = waterfallBarRenderer0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        waterfallBarRenderer0.setBaseShape(shape6);
        java.awt.Font font9 = null;
        waterfallBarRenderer0.setBaseItemLabelFont(font9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = waterfallBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, (float) 'a', (float) 4, textBlockAnchor15, (float) 10, 0.0f, (-1.0d));
        boolean boolean21 = textBlockAnchor15.equals((java.lang.Object) 10.0d);
        textBlock7.draw(graphics2D8, (float) '4', 0.0f, textBlockAnchor15);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange6, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.jfree.data.Range range20 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range10, lengthConstraintType16, (double) 6, range20, lengthConstraintType21);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange26);
        org.jfree.data.Range range30 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange26, (double) 0.0f, (double) (short) 0);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean32 = dateRange26.equals((java.lang.Object) color31);
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range20, (org.jfree.data.Range) dateRange26);
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange26);
        numberAxis1.centerRange((double) (byte) -1);
        numberAxis1.setLowerBound((double) 100);
        numberAxis1.setTickMarksVisible(true);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape44 = minMaxCategoryRenderer42.lookupSeriesShape((int) (short) 0);
        javax.swing.Icon icon45 = minMaxCategoryRenderer42.getMinIcon();
        java.awt.Paint paint48 = minMaxCategoryRenderer42.getItemLabelPaint((int) 'a', 15);
        polarPlot0.setAngleLabelPaint(paint48);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot51.setLegendItemShape(shape54);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot51);
        java.awt.Paint paint57 = piePlot51.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator58 = null;
        piePlot51.setToolTipGenerator(pieToolTipGenerator58);
        boolean boolean60 = piePlot51.getIgnoreNullValues();
        java.awt.Color color61 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color62 = color61.darker();
        piePlot51.setBaseSectionPaint((java.awt.Paint) color61);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color61);
        polarPlot0.removeCornerTextItem("ThreadContext");
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(icon45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot3.drawRangeTickBands(graphics2D9, rectangle2D10, list11);
        xYPlot3.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        xYPlot3.handleClick((-460), (int) (byte) 10, plotRenderingInfo17);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        java.awt.Paint paint24 = piePlot19.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        piePlot19.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo28);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo28.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj36 = polarPlot35.clone();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange42);
        org.jfree.data.Range range46 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange42, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange50);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType52 = rectangleConstraint51.getWidthConstraintType();
        org.jfree.data.Range range56 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType57 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range46, lengthConstraintType52, (double) 6, range56, lengthConstraintType57);
        org.jfree.data.time.DateRange dateRange62 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange62);
        org.jfree.data.Range range66 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange62, (double) 0.0f, (double) (short) 0);
        java.awt.Color color67 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean68 = dateRange62.equals((java.lang.Object) color67);
        org.jfree.data.Range range69 = org.jfree.data.Range.combine(range56, (org.jfree.data.Range) dateRange62);
        numberAxis37.setDefaultAutoRange((org.jfree.data.Range) dateRange62);
        org.jfree.data.RangeType rangeType71 = numberAxis37.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit73 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot74 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot74.setLegendItemShape(shape77);
        piePlot74.setMaximumLabelWidth((double) (-457));
        boolean boolean81 = numberTickUnit73.equals((java.lang.Object) piePlot74);
        numberAxis37.setTickUnit(numberTickUnit73);
        boolean boolean83 = numberAxis37.isPositiveArrowVisible();
        java.awt.Font font85 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment86 = new org.jfree.chart.text.TextFragment("hi!", font85);
        numberAxis37.setTickLabelFont(font85);
        polarPlot35.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection89 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj90 = null;
        boolean boolean91 = taskSeriesCollection89.equals(obj90);
        taskSeriesCollection89.removeAll();
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D31, categoryPlot32, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D34, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.data.category.CategoryDataset) taskSeriesCollection89, 0, 1900, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: BoxAndWhiskerRenderer.drawItem() : the data should be of type BoxAndWhiskerCategoryDataset only.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(lengthConstraintType52);
        org.junit.Assert.assertNotNull(lengthConstraintType57);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(rangeType71);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(font85);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor2, textAnchor3, (double) (-460));
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getTextAnchor();
        java.awt.Image image10 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("Last", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10", image10, "ThreadContext", "ThreadContext", "0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10");
        boolean boolean15 = numberTick5.equals((java.lang.Object) image10);
        java.lang.Object obj16 = numberTick5.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        java.util.List list3 = taskSeriesCollection0.getRowKeys();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue((int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-8355712));
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets4.getBottom();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.chart.block.BlockContainer blockContainer13 = null;
        legendTitle12.setWrapper(blockContainer13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle12.getBounds();
        rectangleInsets4.trim(rectangle2D15);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape3, (java.awt.Shape) rectangle2D15);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        boolean boolean11 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getDomainCrosshairStroke();
        xYPlot0.setDomainCrosshairStroke(stroke18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        xYPlot0.handleClick((-1), 2, plotRenderingInfo23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot0.getDomainAxisEdge(5);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        xYPlot28.setDomainAxes(valueAxisArray30);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getRangeMarkers(layer32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot28);
        org.jfree.chart.block.BlockContainer blockContainer35 = null;
        legendTitle34.setWrapper(blockContainer35);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle34.getBounds();
        try {
            xYPlot0.drawBackground(graphics2D27, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D2.getLegendItems();
        int int10 = legendItemCollection9.getItemCount();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
//        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
//        piePlot0.setLegendItemShape(shape3);
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
//        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
//        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
//        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
//        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int21 = segmentedTimeline20.getSegmentsExcluded();
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline20.getSegment(date22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
//        dateAxis19.setMaximumDate(date22);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int27 = segmentedTimeline26.getSegmentsExcluded();
//        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment29 = segmentedTimeline26.getSegment(date28);
//        segment29.moveIndexToEnd();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment31 = segment29.copy();
//        long long32 = segment31.getSegmentNumber();
//        try {
//            defaultCategoryDataset7.incrementValue(0.0d, (java.lang.Comparable) date22, (java.lang.Comparable) segment31);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: org.jfree.chart.axis.SegmentedTimeline$Segment@29c72ef7");
//        } catch (org.jfree.data.UnknownKeyException e) {
//        }
//        org.junit.Assert.assertNotNull(shape3);
//        org.junit.Assert.assertNull(range11);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertNotNull(segmentedTimeline20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 68 + "'", int21 == 68);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(segment23);
//        org.junit.Assert.assertNotNull(segmentedTimeline26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 68 + "'", int27 == 68);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(segment29);
//        org.junit.Assert.assertNotNull(segment31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4187896L + "'", long32 == 4187896L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3, categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition2);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        java.awt.Font font14 = legendTitle12.getItemFont();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font16);
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock17.setFont(font18);
        legendTitle12.setItemFont(font18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle12.setVerticalAlignment(verticalAlignment21);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        double double4 = rectangleInsets0.calculateTopInset((double) 4187896L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot8.setLegendItemShape(shape11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke6, jFreeChart13, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle19 = null;
        jFreeChart13.setTitle(textTitle19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        xYPlot21.setDomainAxes(valueAxisArray23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getRangeMarkers(layer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot21.drawRangeTickBands(graphics2D27, rectangle2D28, list29);
        xYPlot21.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer32 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] { valueAxis34 };
        xYPlot33.setDomainAxes(valueAxisArray35);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        xYPlot33.setRangeGridlineStroke(stroke38);
        minMaxCategoryRenderer32.setGroupStroke(stroke38);
        xYPlot21.setDomainGridlineStroke(stroke38);
        jFreeChart13.setBorderStroke(stroke38);
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape45, 1.0d, 1.0f, 0.0f);
        java.awt.Color color50 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic51 = new org.jfree.chart.title.LegendGraphic(shape45, (java.awt.Paint) color50);
        java.awt.Shape shape52 = null;
        legendGraphic51.setShape(shape52);
        java.awt.Paint paint54 = legendGraphic51.getFillPaint();
        jFreeChart13.setBorderPaint(paint54);
        org.jfree.chart.title.LegendTitle legendTitle56 = jFreeChart13.getLegend();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(legendTitle56);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj1 = polarPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getAutoRangeMinimumSize();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxis5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.data.general.Dataset dataset10 = null;
        legendItemEntity9.setDataset(dataset10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot12);
        boolean boolean19 = legendItemEntity9.equals((java.lang.Object) legendTitle18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets();
        legendTitle18.setItemLabelPadding(rectangleInsets22);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle18.setVerticalAlignment(verticalAlignment24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle18.getItemLabelPadding();
        int int27 = year5.compareTo((java.lang.Object) legendTitle18);
        int int28 = year5.getYear();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D2.setItemMargin((double) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = stackedBarRenderer3D2.getToolTipGenerator(10, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            stackedBarRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean35 = dateRange29.equals((java.lang.Object) color34);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange29);
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.RangeType rangeType38 = numberAxis4.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot41.setLegendItemShape(shape44);
        piePlot41.setMaximumLabelWidth((double) (-457));
        boolean boolean48 = numberTickUnit40.equals((java.lang.Object) piePlot41);
        numberAxis4.setTickUnit(numberTickUnit40);
        defaultStatisticalCategoryDataset0.add((double) 9, 3.0d, (java.lang.Comparable) 'a', (java.lang.Comparable) numberTickUnit40);
        double double52 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 9.0d + "'", double52 == 9.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        java.awt.Shape shape13 = statisticalLineAndShapeRenderer2.getSeriesShape(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(shape13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.getWidth();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean12 = statisticalLineAndShapeRenderer2.getSeriesVisible(13);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color6 = java.awt.Color.gray;
        stackedBarRenderer3D4.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color6, false);
        boolean boolean9 = stackedBarRenderer3D4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint10 = stackedBarRenderer3D4.getBaseFillPaint();
        textTitle1.setBackgroundPaint(paint10);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        javax.swing.Icon icon3 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Stroke stroke4 = minMaxCategoryRenderer0.getGroupStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(icon3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (-460));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) defaultCategoryDataset0);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 9999);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset7, (java.lang.Comparable) "Multiple Pie Plot", 0.0d);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextOutlinePaint();
        java.awt.Stroke stroke4 = defaultDrawingSupplier2.getNextOutlineStroke();
        strokeList0.setStroke(1900, stroke4);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.2d, (double) 8);
        double double3 = intervalMarker2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        xYPlot7.setDomainAxes(valueAxisArray9);
        xYPlot0.setDomainAxes(valueAxisArray9);
        xYPlot0.setForegroundAlpha((float) (byte) 0);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        java.lang.String str53 = legendItem50.getDescription();
        boolean boolean54 = legendItem50.isShapeFilled();
        java.awt.Paint paint55 = legendItem50.getFillPaint();
        boolean boolean56 = legendItem50.isShapeVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getTransparency();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke2 = levelRenderer0.lookupSeriesOutlineStroke(0);
        java.lang.Boolean boolean4 = levelRenderer0.getSeriesItemLabelsVisible(8);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.height;
        size2D2.setWidth((double) 10);
        size2D2.height = (-59008924800000L);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        java.awt.Paint paint5 = piePlot0.getLabelPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        piePlot0.setBaseSectionPaint(paint6);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape10 = minMaxCategoryRenderer8.lookupSeriesShape((int) (short) 0);
        boolean boolean11 = minMaxCategoryRenderer8.getAutoPopulateSeriesOutlineStroke();
        java.lang.Boolean boolean13 = minMaxCategoryRenderer8.getSeriesCreateEntities((int) (short) 10);
        boolean boolean14 = minMaxCategoryRenderer8.getBaseCreateEntities();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        minMaxCategoryRenderer8.setBaseFillPaint((java.awt.Paint) color15);
        piePlot0.setLabelPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) rectangleEdge2);
        java.util.List list4 = defaultKeyedValues2D1.getRowKeys();
        int int5 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Comparable comparable7 = defaultKeyedValues2D1.getRowKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.Date date4 = segment3.getDate();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        java.lang.String str2 = projectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        projectInfo0.setLicenceName("RectangleAnchor.CENTER");
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        int int3 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot4.getRangeCrosshairPaint();
        boolean boolean11 = xYPlot4.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot13.setLegendItemShape(shape16);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot4, (java.lang.Object) piePlot13);
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke20 = lineBorder19.getStroke();
        piePlot13.setLabelLinkStroke(stroke20);
        xYPlot0.setDomainCrosshairStroke(stroke20);
        java.awt.Stroke stroke23 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        legendTitle6.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle6.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle6.getHorizontalAlignment();
        legendTitle6.setID("Multiple Pie Plot");
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        java.lang.Boolean boolean7 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible((-460));
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(13, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "PlotOrientation.VERTICAL", "", "Multiple Pie Plot", "ThreadContext");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset4.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot5);
        boolean boolean9 = xYPlot5.isDomainZoomable();
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        minMaxCategoryRenderer0.setSeriesStroke(68, stroke10);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        xYPlot4.setRangeGridlineStroke(stroke9);
        piePlot3D3.setLabelLinkStroke(stroke9);
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) piePlot3D3);
        java.lang.Object obj13 = datasetGroup1.clone();
        java.lang.Object obj14 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        xYPlot6.setRangeGridlineStroke(stroke11);
        statisticalLineAndShapeRenderer2.setBaseStroke(stroke11, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled((int) (short) 100, (java.lang.Boolean) false);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.data.Range range3 = groupedStackedBarRenderer1.findRangeBounds(categoryDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot4.getRangeCrosshairPaint();
        boolean boolean11 = xYPlot4.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot13.setLegendItemShape(shape16);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot4, (java.lang.Object) piePlot13);
        boolean boolean19 = groupedStackedBarRenderer1.equals((java.lang.Object) xYPlot4);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer20 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape22 = minMaxCategoryRenderer20.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint24 = minMaxCategoryRenderer20.getSeriesFillPaint((-457));
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator25 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        minMaxCategoryRenderer20.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator25, true);
        groupedStackedBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator25);
        boolean boolean29 = statisticalBarRenderer0.equals((java.lang.Object) intervalCategoryToolTipGenerator25);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection30 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj31 = null;
        boolean boolean32 = taskSeriesCollection30.equals(obj31);
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange37);
        org.jfree.data.Range range41 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange37, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange45);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType47 = rectangleConstraint46.getWidthConstraintType();
        org.jfree.data.Range range51 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType52 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range41, lengthConstraintType47, (double) 6, range51, lengthConstraintType52);
        boolean boolean54 = taskSeriesCollection30.equals((java.lang.Object) range51);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent55 = null;
        taskSeriesCollection30.seriesChanged(seriesChangeEvent55);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection30, true);
        try {
            java.lang.String str60 = intervalCategoryToolTipGenerator25.generateColumnLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection30, (-8355712));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(lengthConstraintType47);
        org.junit.Assert.assertNotNull(lengthConstraintType52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(range58);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Last", "", "", "GradientPaintTransformType.HORIZONTAL");
        basicProjectInfo4.setName("hi!");
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int3 = month2.getMonth();
        long long4 = month2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1202L + "'", long4 == 1202L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        float float7 = xYPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker10.setLabelTextAnchor(textAnchor11);
        java.awt.Stroke stroke13 = intervalMarker10.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = intervalMarker10.getLabelOffset();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker17.setLabelTextAnchor(textAnchor18);
        java.awt.Stroke stroke20 = intervalMarker17.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = intervalMarker17.getLabelOffset();
        intervalMarker10.setLabelOffset(rectangleInsets21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer23);
        java.lang.Class class25 = null;
        try {
            java.util.EventListener[] eventListenerArray26 = intervalMarker10.getListeners(class25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(layer23);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        java.awt.Paint paint4 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat5 = null;
        dateAxis4.setDateFormatOverride(dateFormat5);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit8, false, true);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        xYPlot11.setRangeCrosshairValue(0.0d);
        boolean boolean17 = boxAndWhiskerItem9.equals((java.lang.Object) xYPlot11);
        java.awt.Paint paint19 = xYPlot11.getQuadrantPaint((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot11.getRangeAxisEdge((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(false);
        java.awt.Stroke stroke4 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        stackedBarRenderer3D2.setBaseOutlinePaint(paint9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultCategoryDataset11.getGroup();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (-460));
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.KeyToGroupMap keyToGroupMap16 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, keyToGroupMap16);
        double double18 = range17.getLowerBound();
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        legendTitle6.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle6.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets10.getBottom();
        legendTitle6.setPadding(rectangleInsets10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle6.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlock textBlock14 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, (float) 'a', (float) 4, textBlockAnchor18, (float) 10, 0.0f, (-1.0d));
        java.lang.String str23 = textBlockAnchor18.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor18, categoryLabelWidthType24, (float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str23.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset20.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot21);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, 13);
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(pieDataset26);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        axisState0.cursorLeft((-100.0d));
        axisState0.cursorUp((double) (short) 100);
        axisState0.cursorDown((double) 2019);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray2);
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray6);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray2, doubleArray6);
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] { (-2208960000000L), "NOID", 10.0f, 9.0d };
        try {
            defaultIntervalCategoryDataset8.setSeriesKeys(comparableArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(comparableArray13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot18.setLegendItemShape(shape21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot18);
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart23.getLegend((int) (short) 100);
        jFreeChart23.setAntiAlias(true);
        chartChangeEvent16.setChart(jFreeChart23);
        org.jfree.chart.title.LegendTitle legendTitle30 = jFreeChart23.getLegend((int) (short) 10);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity34 = new org.jfree.chart.entity.LegendItemEntity(shape33);
        org.jfree.data.general.Dataset dataset35 = null;
        legendItemEntity34.setDataset(dataset35);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] { valueAxis38 };
        xYPlot37.setDomainAxes(valueAxisArray39);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot37.getRangeMarkers(layer41);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot37);
        boolean boolean44 = legendItemEntity34.equals((java.lang.Object) legendTitle43);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = legendTitle43.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle43);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets();
        legendTitle43.setItemLabelPadding(rectangleInsets47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle43.setVerticalAlignment(verticalAlignment49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = legendTitle43.getPadding();
        jFreeChart23.addSubtitle((org.jfree.chart.title.Title) legendTitle43);
        try {
            jFreeChart10.setTextAntiAlias((java.lang.Object) jFreeChart23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.JFreeChart@21715834 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(legendTitle25);
        org.junit.Assert.assertNull(legendTitle30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets2.getBottom();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets2.getUnitType();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        labelBlock1.setPadding(rectangleInsets2);
        java.lang.String str8 = labelBlock1.getToolTipText();
        labelBlock1.setPadding((double) 10.0f, (double) (-2208960000000L), (double) ' ', (double) (-8355712));
        java.lang.Object obj14 = labelBlock1.clone();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { valueAxis16 };
        xYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot15.getRangeMarkers(layer19);
        java.awt.Stroke stroke21 = xYPlot15.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot23.setLegendItemShape(shape26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.chart.title.LegendTitle legendTitle30 = jFreeChart28.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent33 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke21, jFreeChart28, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle34 = null;
        jFreeChart28.setTitle(textTitle34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        xYPlot36.setDomainAxes(valueAxisArray38);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot36.getRangeMarkers(layer40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.util.List list44 = null;
        xYPlot36.drawRangeTickBands(graphics2D42, rectangle2D43, list44);
        xYPlot36.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer47 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { valueAxis49 };
        xYPlot48.setDomainAxes(valueAxisArray50);
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke53 = lineBorder52.getStroke();
        xYPlot48.setRangeGridlineStroke(stroke53);
        minMaxCategoryRenderer47.setGroupStroke(stroke53);
        xYPlot36.setDomainGridlineStroke(stroke53);
        jFreeChart28.setBorderStroke(stroke53);
        boolean boolean58 = labelBlock1.equals((java.lang.Object) stroke53);
        java.awt.Font font59 = labelBlock1.getFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(legendTitle30);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("hi!", font1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset3.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot4);
        boolean boolean8 = textFragment2.equals((java.lang.Object) defaultCategoryDataset3);
        java.awt.Paint paint9 = textFragment2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        java.awt.Paint paint9 = xYPlot0.getDomainGridlinePaint();
        double double10 = xYPlot0.getDomainCrosshairValue();
        boolean boolean11 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("XY Plot", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.height;
        java.lang.String str4 = size2D2.toString();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str4.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean2 = paintList0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        boolean boolean3 = shapeList0.equals((java.lang.Object) shape2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = defaultKeyedValues2D5.equals((java.lang.Object) rectangleEdge6);
        java.util.List list8 = defaultKeyedValues2D5.getRowKeys();
        boolean boolean9 = shapeList0.equals((java.lang.Object) list8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("PlotOrientation.VERTICAL");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range17 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange13, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange21);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = rectangleConstraint22.getWidthConstraintType();
        org.jfree.data.Range range27 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range17, lengthConstraintType23, (double) 6, range27, lengthConstraintType28);
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange33);
        org.jfree.data.Range range37 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange33, (double) 0.0f, (double) (short) 0);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean39 = dateRange33.equals((java.lang.Object) color38);
        org.jfree.data.Range range40 = org.jfree.data.Range.combine(range27, (org.jfree.data.Range) dateRange33);
        numberAxis8.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        org.jfree.data.RangeType rangeType42 = numberAxis8.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot45.setLegendItemShape(shape48);
        piePlot45.setMaximumLabelWidth((double) (-457));
        boolean boolean52 = numberTickUnit44.equals((java.lang.Object) piePlot45);
        numberAxis8.setTickUnit(numberTickUnit44);
        boolean boolean54 = numberAxis8.isPositiveArrowVisible();
        java.awt.Shape shape55 = numberAxis8.getRightArrow();
        int int56 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rangeType42);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int2 = segmentedTimeline1.getSegmentsExcluded();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
        java.util.Date date5 = segment4.getDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        boolean boolean7 = segmentedTimeline0.containsDomainValue(date5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = intervalMarker2.getLabelOffset();
        java.awt.Stroke stroke7 = intervalMarker2.getOutlineStroke();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        xYPlot14.setDomainAxes(valueAxisArray16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getRangeMarkers(layer18);
        java.awt.Stroke stroke20 = xYPlot14.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot22.setLegendItemShape(shape25);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot22);
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart27.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke20, jFreeChart27, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle33 = null;
        jFreeChart27.setTitle(textTitle33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray37 = new org.jfree.chart.axis.ValueAxis[] { valueAxis36 };
        xYPlot35.setDomainAxes(valueAxisArray37);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = xYPlot35.getRangeMarkers(layer39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.util.List list43 = null;
        xYPlot35.drawRangeTickBands(graphics2D41, rectangle2D42, list43);
        xYPlot35.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer46 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { valueAxis48 };
        xYPlot47.setDomainAxes(valueAxisArray49);
        org.jfree.chart.block.LineBorder lineBorder51 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke52 = lineBorder51.getStroke();
        xYPlot47.setRangeGridlineStroke(stroke52);
        minMaxCategoryRenderer46.setGroupStroke(stroke52);
        xYPlot35.setDomainGridlineStroke(stroke52);
        jFreeChart27.setBorderStroke(stroke52);
        java.awt.Paint paint57 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape13, stroke52, paint57);
        java.lang.String str59 = legendItem58.getDescription();
        java.awt.Paint paint60 = legendItem58.getOutlinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer61 = legendItem58.getFillPaintTransformer();
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer61);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(legendTitle29);
        org.junit.Assert.assertNotNull(valueAxisArray37);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(gradientPaintTransformer61);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers(13, layer5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot10);
        org.jfree.data.Range range14 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int19 = month18.getMonth();
        defaultCategoryDataset9.addValue(0.0d, (java.lang.Comparable) month18, (java.lang.Comparable) 4);
        int int23 = defaultCategoryDataset9.getRowIndex((java.lang.Comparable) (-59008924800000L));
        try {
            org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        xYPlot5.setRangeGridlineStroke(stroke10);
        piePlot3D4.setLabelLinkStroke(stroke10);
        java.awt.Stroke stroke13 = piePlot3D4.getBaseSectionOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer17.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator22 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer17.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator22);
        java.awt.Paint paint24 = statisticalLineAndShapeRenderer17.getBaseOutlinePaint();
        polarPlot0.setAngleGridlinePaint(paint24);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(paint24);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        int int16 = xYPlot0.indexOf(xYDataset15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke18 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Paint paint1 = levelRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D2.setItemMargin((double) 100);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot13.setLegendItemShape(shape16);
        piePlot13.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint20 = piePlot13.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape8, paint20);
        boolean boolean22 = stackedBarRenderer3D2.equals((java.lang.Object) shape8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot8.setLegendItemShape(shape11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke6, jFreeChart13, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle19 = null;
        jFreeChart13.setTitle(textTitle19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        xYPlot21.setDomainAxes(valueAxisArray23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getRangeMarkers(layer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot21.drawRangeTickBands(graphics2D27, rectangle2D28, list29);
        xYPlot21.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer32 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] { valueAxis34 };
        xYPlot33.setDomainAxes(valueAxisArray35);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        xYPlot33.setRangeGridlineStroke(stroke38);
        minMaxCategoryRenderer32.setGroupStroke(stroke38);
        xYPlot21.setDomainGridlineStroke(stroke38);
        jFreeChart13.setBorderStroke(stroke38);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets();
        double double45 = rectangleInsets44.getBottom();
        org.jfree.chart.util.UnitType unitType46 = rectangleInsets44.getUnitType();
        double double48 = rectangleInsets44.calculateTopInset(0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit50 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot51.setLegendItemShape(shape54);
        piePlot51.setMaximumLabelWidth((double) (-457));
        boolean boolean58 = numberTickUnit50.equals((java.lang.Object) piePlot51);
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] { valueAxis60 };
        xYPlot59.setDomainAxes(valueAxisArray61);
        org.jfree.chart.util.Layer layer63 = null;
        java.util.Collection collection64 = xYPlot59.getRangeMarkers(layer63);
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot59);
        org.jfree.chart.block.BlockContainer blockContainer66 = null;
        legendTitle65.setWrapper(blockContainer66);
        java.awt.geom.Rectangle2D rectangle2D68 = legendTitle65.getBounds();
        boolean boolean69 = numberTickUnit50.equals((java.lang.Object) rectangle2D68);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets44.createInsetRectangle(rectangle2D68);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        try {
            jFreeChart13.draw(graphics2D43, rectangle2D68, chartRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(unitType46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) '4', (java.lang.Boolean) false);
        booleanList0.setBoolean(10, (java.lang.Boolean) false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) (-100.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge(68);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Paint paint12 = xYPlot6.getRangeCrosshairPaint();
        boolean boolean13 = xYPlot6.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot6.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot15.setLegendItemShape(shape18);
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot6, (java.lang.Object) piePlot15);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D24 = xYPlot21.getQuadrantOrigin();
        xYPlot6.setQuadrantOrigin(point2D24);
        xYPlot6.mapDatasetToRangeAxis(10, 0);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange35);
        org.jfree.data.Range range39 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange35, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange43);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = rectangleConstraint44.getWidthConstraintType();
        org.jfree.data.Range range49 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType50 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range39, lengthConstraintType45, (double) 6, range49, lengthConstraintType50);
        org.jfree.data.time.DateRange dateRange55 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange55);
        org.jfree.data.Range range59 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange55, (double) 0.0f, (double) (short) 0);
        java.awt.Color color60 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean61 = dateRange55.equals((java.lang.Object) color60);
        org.jfree.data.Range range62 = org.jfree.data.Range.combine(range49, (org.jfree.data.Range) dateRange55);
        numberAxis30.setDefaultAutoRange((org.jfree.data.Range) dateRange55);
        org.jfree.data.RangeType rangeType64 = numberAxis30.getRangeType();
        xYPlot6.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis30);
        boolean boolean66 = numberAxis30.isAxisLineVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer67 = null;
        org.jfree.chart.plot.PolarPlot polarPlot68 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis30, polarItemRenderer67);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis30);
        boolean boolean70 = numberAxis30.isAutoRange();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertNotNull(lengthConstraintType50);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(rangeType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list1 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(true);
        try {
            java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getValue(96, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 96, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) ' ');
        java.awt.Paint paint3 = null;
        try {
            categoryPlot0.setRangeCrosshairPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color40 = java.awt.Color.gray;
        stackedBarRenderer3D38.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color40, false);
        int int43 = color40.getRGB();
        numberAxis0.setTickMarkPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-8355712) + "'", int43 == (-8355712));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.String str2 = piePlot3D1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        java.awt.Paint paint5 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        boolean boolean10 = piePlot1.getIgnoreNullValues();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker13.setLabelTextAnchor(textAnchor14);
        java.awt.Stroke stroke16 = intervalMarker13.getOutlineStroke();
        java.awt.Paint paint17 = intervalMarker13.getOutlinePaint();
        intervalMarker13.setLabel("HorizontalAlignment.CENTER");
        java.awt.Font font20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        intervalMarker13.setLabelFont(font20);
        piePlot1.setLabelFont(font20);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup54 = defaultCategoryDataset53.getGroup();
        defaultCategoryDataset53.removeColumn((java.lang.Comparable) 60000L);
        legendItem50.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset53);
        java.lang.Comparable comparable58 = legendItem50.getSeriesKey();
        int int59 = legendItem50.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetGroup54);
        org.junit.Assert.assertNull(comparable58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange19);
        org.jfree.data.Range range23 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange19, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange27);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = rectangleConstraint28.getWidthConstraintType();
        org.jfree.data.Range range33 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range23, lengthConstraintType29, (double) 6, range33, lengthConstraintType34);
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange39);
        org.jfree.data.Range range43 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange39, (double) 0.0f, (double) (short) 0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean45 = dateRange39.equals((java.lang.Object) color44);
        org.jfree.data.Range range46 = org.jfree.data.Range.combine(range33, (org.jfree.data.Range) dateRange39);
        numberAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange39);
        org.jfree.data.Range range48 = numberAxis14.getDefaultAutoRange();
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range48);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRenderer(6);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.data.Range range16 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange12, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange20);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = rectangleConstraint21.getWidthConstraintType();
        org.jfree.data.Range range26 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range16, lengthConstraintType22, (double) 6, range26, lengthConstraintType27);
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange32);
        org.jfree.data.Range range36 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange32, (double) 0.0f, (double) (short) 0);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean38 = dateRange32.equals((java.lang.Object) color37);
        org.jfree.data.Range range39 = org.jfree.data.Range.combine(range26, (org.jfree.data.Range) dateRange32);
        numberAxis7.setDefaultAutoRange((org.jfree.data.Range) dateRange32);
        org.jfree.data.RangeType rangeType41 = numberAxis7.getRangeType();
        org.jfree.data.Range range42 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = numberAxis7.getTickUnit();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rangeType41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(numberTickUnit43);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint4 = minMaxCategoryRenderer0.getSeriesFillPaint((-457));
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot5.getRangeMarkers(layer9);
        java.awt.Stroke stroke11 = xYPlot5.getDomainCrosshairStroke();
        minMaxCategoryRenderer0.setGroupStroke(stroke11);
        javax.swing.Icon icon13 = minMaxCategoryRenderer0.getObjectIcon();
        boolean boolean16 = minMaxCategoryRenderer0.isItemLabelVisible(2958465, 6);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(icon13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (short) 0);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot10);
        org.jfree.data.Range range14 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getFixedDimension();
        categoryAxis3D1.setUpperMargin((double) 9999);
        java.lang.Object obj5 = categoryAxis3D1.clone();
        int int6 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        piePlot9.setMaximumLabelWidth((double) (-457));
        boolean boolean16 = numberTickUnit8.equals((java.lang.Object) piePlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot9);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape20, 1.0d, 1.0f, 0.0f);
        java.awt.Color color25 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color25);
        piePlot9.setLabelLinkPaint((java.awt.Paint) color25);
        categoryAxis3D1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape3 = minMaxCategoryRenderer1.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint5 = minMaxCategoryRenderer1.getSeriesFillPaint((-457));
        boolean boolean7 = minMaxCategoryRenderer1.isSeriesItemLabelsVisible(4);
        boolean boolean8 = minMaxCategoryRenderer1.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke10 = minMaxCategoryRenderer1.lookupSeriesStroke(0);
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 4187896L, (java.lang.Object) 0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.4d, 12.0d, (double) (-460));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardCategoryToolTipGenerator0.getDateFormat();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj3 = null;
        boolean boolean4 = taskSeriesCollection2.equals(obj3);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        boolean boolean26 = taskSeriesCollection2.equals((java.lang.Object) range23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = null;
        taskSeriesCollection2.seriesChanged(seriesChangeEvent27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, true);
        int int31 = taskSeriesCollection2.getRowCount();
        try {
            java.lang.String str33 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        java.awt.Paint paint52 = legendItem50.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle12.getPosition();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange21);
        double double23 = rectangleConstraint22.getHeight();
        org.jfree.chart.util.Size2D size2D24 = legendTitle12.arrange(graphics2D17, rectangleConstraint22);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj26 = polarPlot25.clone();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        double double28 = dateAxis27.getAutoRangeMinimumSize();
        polarPlot25.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis27);
        boolean boolean30 = size2D24.equals((java.lang.Object) dateAxis27);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj1 = polarPlot0.clone();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot0.getRenderer();
        java.awt.Stroke stroke3 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(polarItemRenderer2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "ItemLabelAnchor.INSIDE7", "RectangleAnchor.CENTER", "Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TextBlockAnchor.CENTER_LEFT");
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        xYPlot0.notifyListeners(plotChangeEvent3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 0.0f, (double) 100);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint6 = waterfallBarRenderer5.getFirstBarPaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range10 = waterfallBarRenderer5.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        boolean boolean11 = meanAndStandardDeviation2.equals((java.lang.Object) defaultCategoryDataset7);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker3.setLabelTextAnchor(textAnchor4);
        java.awt.Stroke stroke6 = intervalMarker3.getOutlineStroke();
        java.awt.Paint paint7 = intervalMarker3.getOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick14 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor11, textAnchor12, (double) (-460));
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) textAnchor11);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jFreeChart16);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        areaRenderer0.setEndType(areaRendererEndType1);
        org.junit.Assert.assertNotNull(areaRendererEndType1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D18 = xYPlot15.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection20);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer12 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer12, dataset13);
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer12);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        java.awt.Paint paint3 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.configure();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot5.setLegendItemShape(shape8);
        piePlot5.setMaximumLabelWidth((double) (-457));
        boolean boolean12 = numberTickUnit4.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        xYPlot13.setDomainAxes(valueAxisArray15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot13.getRangeMarkers(layer17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot13);
        org.jfree.chart.block.BlockContainer blockContainer20 = null;
        legendTitle19.setWrapper(blockContainer20);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle19.getBounds();
        boolean boolean23 = numberTickUnit4.equals((java.lang.Object) rectangle2D22);
        java.lang.String str24 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) boolean23);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        xYPlot28.setDomainAxes(valueAxisArray30);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getRangeMarkers(layer32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.util.List list36 = null;
        xYPlot28.drawRangeTickBands(graphics2D34, rectangle2D35, list36);
        xYPlot28.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        xYPlot28.handleClick((-460), (int) (byte) 10, plotRenderingInfo42);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot44.setLegendItemShape(shape47);
        java.awt.Paint paint49 = piePlot44.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo52);
        piePlot44.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo53);
        plotRenderingInfo42.addSubplotInfo(plotRenderingInfo53);
        java.awt.geom.Rectangle2D rectangle2D56 = plotRenderingInfo53.getDataArea();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint58 = xYPlot57.getRangeTickBandPaint();
        java.awt.Image image59 = xYPlot57.getBackgroundImage();
        xYPlot57.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement62 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment64 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement67 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment63, verticalAlignment64, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot57, (org.jfree.chart.block.Arrangement) columnArrangement62, (org.jfree.chart.block.Arrangement) columnArrangement67);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = legendTitle68.getPosition();
        try {
            double double70 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor25, 100, 9, rectangle2D56, rectangleEdge69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNull(image59);
        org.junit.Assert.assertNotNull(rectangleEdge69);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.BOTTOM", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot2.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        xYPlot2.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        xYPlot14.setDomainAxes(valueAxisArray16);
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke19 = lineBorder18.getStroke();
        xYPlot14.setRangeGridlineStroke(stroke19);
        minMaxCategoryRenderer13.setGroupStroke(stroke19);
        xYPlot2.setDomainGridlineStroke(stroke19);
        stackedBarRenderer0.setSeriesOutlineStroke(5, stroke19, false);
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets2.getBottom();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets2.getUnitType();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        labelBlock1.setPadding(rectangleInsets2);
        java.lang.String str8 = labelBlock1.getToolTipText();
        java.awt.Paint paint9 = labelBlock1.getPaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toUnconstrainedWidth();
        java.lang.String str18 = rectangleConstraint17.toString();
        try {
            org.jfree.chart.util.Size2D size2D19 = labelBlock1.arrange(graphics2D10, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]" + "'", str18.equals("RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.lang.Comparable comparable12 = null;
        try {
            java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke(comparable12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.configure();
        categoryAxis3D1.setLowerMargin((double) 12);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape7);
        org.jfree.data.general.Dataset dataset9 = null;
        legendItemEntity8.setDataset(dataset9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        xYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getRangeMarkers(layer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot11);
        boolean boolean18 = legendItemEntity8.equals((java.lang.Object) legendTitle17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = legendTitle17.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle17);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        legendTitle17.setItemLabelPadding(rectangleInsets21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle17.setVerticalAlignment(verticalAlignment23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle17.getItemLabelPadding();
        categoryAxis3D1.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color31 = java.awt.Color.gray;
        stackedBarRenderer3D29.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color31, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = null;
        stackedBarRenderer3D29.setLegendItemToolTipGenerator(categorySeriesLabelGenerator34);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        xYPlot37.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset36.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot37);
        org.jfree.data.Range range41 = stackedBarRenderer3D29.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int46 = month45.getMonth();
        defaultCategoryDataset36.addValue(0.0d, (java.lang.Comparable) month45, (java.lang.Comparable) 4);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer49 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape51 = minMaxCategoryRenderer49.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint53 = minMaxCategoryRenderer49.lookupSeriesFillPaint(2);
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) month45, paint53);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend((int) (short) 10);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItemEntity19.setDataset(dataset20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        xYPlot22.setDomainAxes(valueAxisArray24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot22.getRangeMarkers(layer26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot22);
        boolean boolean29 = legendItemEntity19.equals((java.lang.Object) legendTitle28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = legendTitle28.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle28);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        legendTitle28.setItemLabelPadding(rectangleInsets32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle28.setVerticalAlignment(verticalAlignment34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle28.getPadding();
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) legendTitle28);
        jFreeChart8.setTitle("Multiple Pie Plot");
        org.jfree.chart.event.ChartProgressListener chartProgressListener40 = null;
        jFreeChart8.removeProgressListener(chartProgressListener40);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj6 = null;
        boolean boolean7 = taskSeriesCollection5.equals(obj6);
        boolean boolean8 = stackedBarRenderer3D2.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int10 = segmentedTimeline9.getSegmentsExcluded();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment12 = segmentedTimeline9.getSegment(date11);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D14 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list15 = defaultKeyedValues2D14.getRowKeys();
        segmentedTimeline9.addExceptions(list15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = segmentedTimeline9.getBaseTimeline();
        long long20 = segmentedTimeline17.getExceptionSegmentCount((long) (byte) 10, (long) (short) 1);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline17.addException(date21);
        int int23 = taskSeriesCollection5.indexOf((java.lang.Comparable) date21);
        int int24 = taskSeriesCollection5.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(segment12);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 13);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        org.jfree.chart.util.Rotation rotation8 = piePlot3D7.getDirection();
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNotNull(rotation8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list1 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(true);
        try {
            java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((int) (short) 100, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker6.setLabelTextAnchor(textAnchor7);
        java.awt.Stroke stroke9 = intervalMarker6.getOutlineStroke();
        java.awt.Paint paint10 = intervalMarker6.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker6);
        java.awt.Paint paint12 = intervalMarker6.getLabelPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = intervalMarker6.getGradientPaintTransformer();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-100.0d), "GradientPaintTransformType.HORIZONTAL", textAnchor16, textAnchor17, (double) (-460));
        intervalMarker6.setLabelTextAnchor(textAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ClassContext", graphics2D1, 0.5f, (float) 6, textAnchor16, (double) '#', textAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers(13, layer5);
        float float7 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets2.getBottom();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets2.getUnitType();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        labelBlock1.setPadding(rectangleInsets2);
        java.lang.String str8 = labelBlock1.getToolTipText();
        java.awt.Paint paint9 = labelBlock1.getPaint();
        java.awt.Font font10 = labelBlock1.getFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        java.awt.RenderingHints renderingHints9 = jFreeChart6.getRenderingHints();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(renderingHints9);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        taskSeriesCollection0.removeAll();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) dateTickUnit4);
        org.jfree.data.gantt.TaskSeries taskSeries6 = null;
        try {
            taskSeriesCollection0.add(taskSeries6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape3, 1.0d, 1.0f, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color8);
        java.awt.Shape shape10 = null;
        legendGraphic9.setShape(shape10);
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) shape10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) '4');
        boolean boolean17 = simpleTimePeriod15.equals((java.lang.Object) (-1.0d));
        java.util.Date date18 = simpleTimePeriod15.getStart();
        boolean boolean19 = gradientPaintTransformType0.equals((java.lang.Object) simpleTimePeriod15);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        intervalMarker2.setLabel("HorizontalAlignment.CENTER");
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot9.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        xYPlot9.clearRangeMarkers();
        boolean boolean20 = xYPlot9.isRangeZoomable();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        java.awt.Stroke stroke22 = intervalMarker2.getStroke();
        intervalMarker2.setLabel("XY Plot");
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = xYPlot0.getDataRange(valueAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setDomainCrosshairValue((double) (byte) 1);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer7, dataset8);
        xYPlot4.datasetChanged(datasetChangeEvent9);
        xYPlot0.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getAutoRangeMinimumSize();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape18, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot23.setLegendItemShape(shape26);
        piePlot23.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint30 = piePlot23.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape18, paint30);
        java.awt.geom.Rectangle2D rectangle2D32 = legendGraphic31.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint34 = xYPlot33.getRangeTickBandPaint();
        java.awt.Image image35 = xYPlot33.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot33.getDomainAxisEdge(68);
        double double38 = dateAxis13.java2DToValue((double) 1, rectangle2D32, rectangleEdge37);
        try {
            xYPlot0.drawBackground(graphics2D12, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(image35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 9.223372036854776E18d + "'", double38 == 9.223372036854776E18d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getFixedDimension();
        categoryAxis3D1.setUpperMargin((double) 9999);
        java.lang.Object obj5 = categoryAxis3D1.clone();
        int int6 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D2.getBasePositiveItemLabelPosition();
        java.lang.Object obj15 = null;
        boolean boolean16 = stackedBarRenderer3D2.equals(obj15);
        java.lang.Boolean boolean18 = stackedBarRenderer3D2.getSeriesVisibleInLegend((int) (short) 100);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        boolean boolean3 = areaRendererEndType0.equals((java.lang.Object) standardGradientPaintTransformer1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean35 = dateRange29.equals((java.lang.Object) color34);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange29);
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.RangeType rangeType38 = numberAxis4.getRangeType();
        boolean boolean39 = numberAxis4.isTickLabelsVisible();
        boolean boolean40 = areaRendererEndType0.equals((java.lang.Object) boolean39);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.lang.Object obj7 = jFreeChart6.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        int int16 = xYPlot0.indexOf(xYDataset15);
        java.awt.Stroke stroke17 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation19, true);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.Object obj2 = null;
        boolean boolean3 = sortOrder1.equals(obj2);
        categoryPlot0.setColumnRenderingOrder(sortOrder1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getWidthConstraintType();
        org.jfree.data.Range range24 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range14, lengthConstraintType20, (double) 6, range24, lengthConstraintType25);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range34 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange30, (double) 0.0f, (double) (short) 0);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean36 = dateRange30.equals((java.lang.Object) color35);
        org.jfree.data.Range range37 = org.jfree.data.Range.combine(range24, (org.jfree.data.Range) dateRange30);
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range39 = numberAxis5.getRange();
        java.lang.String str40 = numberAxis5.getLabelToolTip();
        org.jfree.data.Range range41 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer42 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer42.setAutoPopulateSeriesOutlineStroke(false);
        double double45 = levelRenderer42.getItemMargin();
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray48 = new org.jfree.chart.axis.ValueAxis[] { valueAxis47 };
        xYPlot46.setDomainAxes(valueAxisArray48);
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = xYPlot46.getRangeMarkers(layer50);
        java.awt.Paint paint52 = xYPlot46.getRangeCrosshairPaint();
        boolean boolean53 = xYPlot46.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot46.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot55 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot55.setLegendItemShape(shape58);
        boolean boolean60 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot46, (java.lang.Object) piePlot55);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        xYPlot61.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D64 = xYPlot61.getQuadrantOrigin();
        xYPlot46.setQuadrantOrigin(point2D64);
        xYPlot46.mapDatasetToRangeAxis(10, 0);
        levelRenderer42.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot46);
        boolean boolean71 = levelRenderer42.isSeriesVisible((int) 'a');
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer74 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer74.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean78 = statisticalLineAndShapeRenderer74.getBaseLinesVisible();
        boolean boolean81 = statisticalLineAndShapeRenderer74.getItemShapeFilled(4, (int) (byte) 0);
        boolean boolean82 = statisticalLineAndShapeRenderer74.getBaseShapesFilled();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer83 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset84 = null;
        org.jfree.data.Range range85 = groupedStackedBarRenderer83.findRangeBounds(categoryDataset84);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer86 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer86.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D90 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Color color91 = java.awt.Color.BLUE;
        int int92 = color91.getTransparency();
        stackedBarRenderer3D90.setBaseOutlinePaint((java.awt.Paint) color91, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray95 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { levelRenderer42, statisticalLineAndShapeRenderer74, groupedStackedBarRenderer83, waterfallBarRenderer86, stackedBarRenderer3D90 };
        categoryPlot0.setRenderers(categoryItemRendererArray95);
        boolean boolean97 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.2d + "'", double45 == 0.2d);
        org.junit.Assert.assertNotNull(valueAxisArray48);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNull(range85);
        org.junit.Assert.assertNotNull(color91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot10.setLegendItemShape(shape13);
        piePlot10.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint17 = piePlot10.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape5, paint17);
        java.awt.geom.Rectangle2D rectangle2D19 = legendGraphic18.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj24 = polarPlot23.clone();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range34 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange30, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange38);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType40 = rectangleConstraint39.getWidthConstraintType();
        org.jfree.data.Range range44 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range34, lengthConstraintType40, (double) 6, range44, lengthConstraintType45);
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange50);
        org.jfree.data.Range range54 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange50, (double) 0.0f, (double) (short) 0);
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean56 = dateRange50.equals((java.lang.Object) color55);
        org.jfree.data.Range range57 = org.jfree.data.Range.combine(range44, (org.jfree.data.Range) dateRange50);
        numberAxis25.setDefaultAutoRange((org.jfree.data.Range) dateRange50);
        org.jfree.data.RangeType rangeType59 = numberAxis25.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit61 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot62.setLegendItemShape(shape65);
        piePlot62.setMaximumLabelWidth((double) (-457));
        boolean boolean69 = numberTickUnit61.equals((java.lang.Object) piePlot62);
        numberAxis25.setTickUnit(numberTickUnit61);
        boolean boolean71 = numberAxis25.isPositiveArrowVisible();
        java.awt.Font font73 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment74 = new org.jfree.chart.text.TextFragment("hi!", font73);
        numberAxis25.setTickLabelFont(font73);
        polarPlot23.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        double double77 = numberAxis25.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D80 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition81 = null;
        stackedBarRenderer3D80.setNegativeItemLabelPositionFallback(itemLabelPosition81);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection83 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj84 = null;
        boolean boolean85 = taskSeriesCollection83.equals(obj84);
        boolean boolean86 = stackedBarRenderer3D80.hasListener((java.util.EventListener) taskSeriesCollection83);
        try {
            ganttRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D19, categoryPlot20, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.data.category.CategoryDataset) taskSeriesCollection83, (int) (short) -1, 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(lengthConstraintType40);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(rangeType59);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0E-8d + "'", double77 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        stackedBarRenderer3D2.setBaseOutlinePaint(paint9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultCategoryDataset11.getGroup();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (-460));
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.KeyToGroupMap keyToGroupMap16 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, keyToGroupMap16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        int int21 = month20.getMonth();
        int int22 = keyToGroupMap16.getGroupIndex((java.lang.Comparable) int21);
        java.util.List list23 = keyToGroupMap16.getGroups();
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition1.getCategoryAnchor();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        java.lang.Object obj2 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset8.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot9);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue15 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "hi!", (java.lang.Number) 1L);
        java.lang.Comparable comparable16 = defaultKeyedValue15.getKey();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot17.setLegendItemShape(shape20);
        java.awt.Paint paint22 = piePlot17.getLabelPaint();
        boolean boolean23 = defaultKeyedValue15.equals((java.lang.Object) paint22);
        xYPlot9.setRangeGridlinePaint(paint22);
        labelBlock7.setPaint(paint22);
        try {
            java.lang.Object obj26 = blockContainer0.draw(graphics2D3, rectangle2D4, (java.lang.Object) paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + "hi!" + "'", comparable16.equals("hi!"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 13);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        double double8 = piePlot3D7.getInteriorGap();
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.25d + "'", double8 == 0.25d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D3 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        polarPlot4.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke14 = lineBorder13.getStroke();
        xYPlot9.setRangeGridlineStroke(stroke14);
        piePlot3D8.setLabelLinkStroke(stroke14);
        java.awt.Stroke stroke17 = piePlot3D8.getBaseSectionOutlineStroke();
        polarPlot4.setAngleGridlineStroke(stroke17);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer21.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator26 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer21.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator26);
        java.awt.Paint paint28 = statisticalLineAndShapeRenderer21.getBaseOutlinePaint();
        polarPlot4.setAngleGridlinePaint(paint28);
        xYPlot0.setRangeTickBandPaint(paint28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray32 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer31 };
        xYPlot0.setRenderers(xYItemRendererArray32);
        org.junit.Assert.assertNotNull(point2D3);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(xYItemRendererArray32);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getFillPaint();
        legendGraphic8.setMargin((double) ' ', (double) (short) 100, (double) 96, (double) (byte) 100);
        org.jfree.chart.block.BlockFrame blockFrame17 = legendGraphic8.getFrame();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendGraphic8.setShapeLocation(rectangleAnchor18);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (float) 0L);
        legendGraphic8.setLine(shape22);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = waterfallBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint4 = waterfallBarRenderer0.getNegativeBarPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("LegendItemEntity: seriesKey=null, dataset=null");
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, (double) (short) 10);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            boolean boolean13 = xYPlot0.removeAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int2 = segmentedTimeline1.getSegmentsExcluded();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        dateAxis0.setMaximumDate(date3);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range10 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, (double) 10, (double) '#');
        dateAxis0.setRange((org.jfree.data.Range) dateRange7, true, false);
        boolean boolean14 = dateAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, (int) (byte) 100);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "ThreadContext", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) 2, (java.lang.Comparable) ' ');
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        boolean boolean19 = categoryItemEntity16.equals((java.lang.Object) stroke18);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset20.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot21);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, 13);
        categoryItemEntity16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryItemEntity16.getDataset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(pieDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj1 = polarPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getAutoRangeMinimumSize();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.configure();
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = new org.jfree.chart.axis.DateTickUnit(2, 1, (-8355712), (int) (short) 100, dateFormat10);
        java.util.Date date12 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit11);
        int int13 = dateTickUnit11.getRollUnit();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-8355712) + "'", int13 == (-8355712));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        java.lang.Object obj2 = categoryPlot0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean35 = dateRange29.equals((java.lang.Object) color34);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange29);
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range38 = numberAxis4.getRange();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity42 = new org.jfree.chart.entity.LegendItemEntity(shape41);
        org.jfree.data.general.Dataset dataset43 = null;
        legendItemEntity42.setDataset(dataset43);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] { valueAxis46 };
        xYPlot45.setDomainAxes(valueAxisArray47);
        org.jfree.chart.util.Layer layer49 = null;
        java.util.Collection collection50 = xYPlot45.getRangeMarkers(layer49);
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot45);
        boolean boolean52 = legendItemEntity42.equals((java.lang.Object) legendTitle51);
        java.awt.Font font53 = legendTitle51.getItemFont();
        java.awt.Font font55 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font55);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock56.setFont(font57);
        legendTitle51.setItemFont(font57);
        numberAxis4.setLabelFont(font57);
        categoryPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset63 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset64 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup65 = defaultCategoryDataset64.getGroup();
        defaultCategoryDataset63.setGroup(datasetGroup65);
        org.jfree.data.general.DatasetGroup datasetGroup67 = defaultCategoryDataset63.getGroup();
        try {
            categoryPlot0.setDataset((int) (byte) -1, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(datasetGroup65);
        org.junit.Assert.assertNotNull(datasetGroup67);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (-1.0f), (java.lang.Number) 60000L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, (java.lang.Number) 0.0d, (java.lang.Number) 100.0d, (java.lang.Number) 0.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.Number number11 = boxAndWhiskerItem9.getMaxOutlier();
        java.lang.Number number12 = boxAndWhiskerItem9.getMean();
        java.lang.Number number13 = boxAndWhiskerItem9.getMean();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 1 + "'", number10.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0f) + "'", number13.equals((-1.0f)));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot37);
        java.awt.Paint paint43 = piePlot37.getLabelPaint();
        boolean boolean44 = piePlot37.getIgnoreZeroValues();
        double double46 = piePlot37.getExplodePercent((java.lang.Comparable) (-59008924800000L));
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot37);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.data.Range range21 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range11, lengthConstraintType17, (double) 6, range21, lengthConstraintType22);
        boolean boolean24 = taskSeriesCollection0.equals((java.lang.Object) range21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent25);
        try {
            java.lang.Number number29 = taskSeriesCollection0.getPercentComplete(13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        java.awt.Stroke stroke15 = xYPlot9.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot17.setLegendItemShape(shape20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.title.LegendTitle legendTitle24 = jFreeChart22.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke15, jFreeChart22, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle28 = null;
        jFreeChart22.setTitle(textTitle28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        xYPlot30.setDomainAxes(valueAxisArray32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getRangeMarkers(layer34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.util.List list38 = null;
        xYPlot30.drawRangeTickBands(graphics2D36, rectangle2D37, list38);
        xYPlot30.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer41 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] { valueAxis43 };
        xYPlot42.setDomainAxes(valueAxisArray44);
        org.jfree.chart.block.LineBorder lineBorder46 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke47 = lineBorder46.getStroke();
        xYPlot42.setRangeGridlineStroke(stroke47);
        minMaxCategoryRenderer41.setGroupStroke(stroke47);
        xYPlot30.setDomainGridlineStroke(stroke47);
        jFreeChart22.setBorderStroke(stroke47);
        java.awt.Paint paint52 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape8, stroke47, paint52);
        minMaxCategoryRenderer0.setGroupStroke(stroke47);
        javax.swing.Icon icon55 = minMaxCategoryRenderer0.getMaxIcon();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(legendTitle24);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(icon55);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.Object obj1 = polarPlot0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.data.Range range21 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range11, lengthConstraintType17, (double) 6, range21, lengthConstraintType22);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange27);
        org.jfree.data.Range range31 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange27, (double) 0.0f, (double) (short) 0);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean33 = dateRange27.equals((java.lang.Object) color32);
        org.jfree.data.Range range34 = org.jfree.data.Range.combine(range21, (org.jfree.data.Range) dateRange27);
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange27);
        org.jfree.data.RangeType rangeType36 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot39.setLegendItemShape(shape42);
        piePlot39.setMaximumLabelWidth((double) (-457));
        boolean boolean46 = numberTickUnit38.equals((java.lang.Object) piePlot39);
        numberAxis2.setTickUnit(numberTickUnit38);
        boolean boolean48 = numberAxis2.isPositiveArrowVisible();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment51 = new org.jfree.chart.text.TextFragment("hi!", font50);
        numberAxis2.setTickLabelFont(font50);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = numberAxis2.getMarkerBand();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(rangeType36);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNull(markerAxisBand54);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        xYPlot3.setRangeCrosshairValue(0.0d);
        boolean boolean9 = chartChangeEventType2.equals((java.lang.Object) xYPlot3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rangeType0, jFreeChart1, chartChangeEventType2);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        numberAxis0.centerRange((double) (byte) -1);
        numberAxis0.setLowerBound((double) 100);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] { valueAxis41 };
        xYPlot40.setDomainAxes(valueAxisArray42);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = xYPlot40.getRangeMarkers(layer44);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.util.List list48 = null;
        xYPlot40.drawRangeTickBands(graphics2D46, rectangle2D47, list48);
        xYPlot40.clearRangeMarkers();
        boolean boolean51 = xYPlot40.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { valueAxis53 };
        xYPlot52.setDomainAxes(valueAxisArray54);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = xYPlot52.getRangeMarkers(layer56);
        java.awt.Stroke stroke58 = xYPlot52.getDomainCrosshairStroke();
        xYPlot40.setDomainCrosshairStroke(stroke58);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        xYPlot40.handleClick((-1), 2, plotRenderingInfo63);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot40.getDomainAxisEdge(5);
        try {
            double double67 = numberAxis0.lengthToJava2D(0.05d, rectangle2D39, rectangleEdge66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        java.lang.Object obj3 = blockContainer1.clone();
        boolean boolean4 = strokeList0.equals((java.lang.Object) blockContainer1);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        xYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke17 = lineBorder16.getStroke();
        xYPlot12.setRangeGridlineStroke(stroke17);
        minMaxCategoryRenderer11.setGroupStroke(stroke17);
        xYPlot0.setDomainGridlineStroke(stroke17);
        boolean boolean21 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = polarPlot0.getOrientation();
        java.awt.Stroke stroke2 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemShapeFilled(4, (int) (byte) 0);
        statisticalLineAndShapeRenderer2.setBaseShapesFilled(false);
        int int12 = statisticalLineAndShapeRenderer2.getColumnCount();
        boolean boolean13 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] { valueAxis3 };
        xYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        java.awt.Paint paint8 = xYPlot2.getRangeCrosshairPaint();
        boolean boolean9 = xYPlot2.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot2.getDomainAxisLocation();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot2.getDomainAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot2.getDataset();
        java.lang.String str14 = xYPlot2.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot2.setDomainAxisLocation(axisLocation15, false);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "XY Plot" + "'", str14.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis3D1.equals(obj2);
        java.lang.String str4 = categoryAxis3D1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("ThreadContext", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "", image3, "RectangleAnchor.CENTER", "", "RectangleAnchor.CENTER");
        projectInfo7.addOptionalLibrary("PlotOrientation.VERTICAL");
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ItemLabelAnchor.INSIDE7", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot37.setLegendItemShape(shape40);
        piePlot37.setMaximumLabelWidth((double) (-457));
        boolean boolean44 = numberTickUnit36.equals((java.lang.Object) piePlot37);
        numberAxis0.setTickUnit(numberTickUnit36);
        org.jfree.data.Range range46 = numberAxis0.getDefaultAutoRange();
        java.awt.Shape shape47 = numberAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        java.awt.Shape shape9 = null;
        legendGraphic8.setShape(shape9);
        java.awt.Paint paint11 = legendGraphic8.getFillPaint();
        java.awt.Paint paint12 = legendGraphic8.getLinePaint();
        legendGraphic8.setLineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker18.setLabelTextAnchor(textAnchor19);
        java.awt.Stroke stroke21 = intervalMarker18.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = intervalMarker18.getLabelOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        double double24 = rectangleInsets23.getBottom();
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { valueAxis26 };
        xYPlot25.setDomainAxes(valueAxisArray27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot25.getRangeMarkers(layer29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot25);
        org.jfree.chart.block.BlockContainer blockContainer32 = null;
        legendTitle31.setWrapper(blockContainer32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle31.getBounds();
        rectangleInsets23.trim(rectangle2D34);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D34, (double) ' ', 0.0d);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets22.createInsetRectangle(rectangle2D34, false, false);
        try {
            legendGraphic8.draw(graphics2D15, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot2.setLegendItemShape(shape5);
        piePlot2.setMaximumLabelWidth((double) (-457));
        boolean boolean9 = numberTickUnit1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        xYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        xYPlot18.setRangeGridlineStroke(stroke23);
        minMaxCategoryRenderer17.setGroupStroke(stroke23);
        jFreeChart10.setBorderStroke(stroke23);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot27);
        org.jfree.chart.block.BlockContainer blockContainer34 = null;
        legendTitle33.setWrapper(blockContainer34);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle33);
        java.lang.Object obj37 = null;
        boolean boolean38 = legendTitle33.equals(obj37);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle12.getPosition();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange21);
        double double23 = rectangleConstraint22.getHeight();
        org.jfree.chart.util.Size2D size2D24 = legendTitle12.arrange(graphics2D17, rectangleConstraint22);
        java.lang.Object obj25 = size2D24.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        boolean boolean15 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer16 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape18 = minMaxCategoryRenderer16.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint20 = minMaxCategoryRenderer16.lookupSeriesFillPaint(2);
        xYPlot0.setRangeGridlinePaint(paint20);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 'a', (float) 4, textBlockAnchor4, (float) 10, 0.0f, (-1.0d));
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.data.Range range19 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange15, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange23);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = rectangleConstraint24.getWidthConstraintType();
        org.jfree.data.Range range29 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range19, lengthConstraintType25, (double) 6, range29, lengthConstraintType30);
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange35);
        org.jfree.data.Range range39 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange35, (double) 0.0f, (double) (short) 0);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean41 = dateRange35.equals((java.lang.Object) color40);
        org.jfree.data.Range range42 = org.jfree.data.Range.combine(range29, (org.jfree.data.Range) dateRange35);
        numberAxis10.setDefaultAutoRange((org.jfree.data.Range) dateRange35);
        org.jfree.data.RangeType rangeType44 = numberAxis10.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot47.setLegendItemShape(shape50);
        piePlot47.setMaximumLabelWidth((double) (-457));
        boolean boolean54 = numberTickUnit46.equals((java.lang.Object) piePlot47);
        numberAxis10.setTickUnit(numberTickUnit46);
        boolean boolean56 = numberAxis10.isPositiveArrowVisible();
        java.awt.Shape shape57 = numberAxis10.getRightArrow();
        boolean boolean58 = legendItemEntity9.equals((java.lang.Object) numberAxis10);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(rangeType44);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup54 = defaultCategoryDataset53.getGroup();
        defaultCategoryDataset53.removeColumn((java.lang.Comparable) 60000L);
        legendItem50.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset53);
        java.awt.Shape shape58 = legendItem50.getLine();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetGroup54);
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("0,10,-10,10,-10,0,10,0,10,10,0,10,0,-10,10,-10,10,0,-10,0,-10,-10,0,-10,0,-10");
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset1);
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot4.setLegendItemShape(shape7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Paint paint10 = piePlot4.getLabelPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot4.setToolTipGenerator(pieToolTipGenerator11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot4.setLabelBackgroundPaint((java.awt.Paint) color13);
        boolean boolean15 = groupedStackedBarRenderer0.equals((java.lang.Object) piePlot4);
        java.awt.Paint paint17 = piePlot4.getSectionPaint((java.lang.Comparable) 1.0E-8d);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot19.setLegendItemShape(shape22);
        piePlot19.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint26 = piePlot19.getShadowPaint();
        java.awt.Paint paint27 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        piePlot19.setNoDataMessagePaint(paint27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        xYPlot30.setDomainAxes(valueAxisArray32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getRangeMarkers(layer34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot30);
        org.jfree.chart.block.BlockContainer blockContainer37 = null;
        legendTitle36.setWrapper(blockContainer37);
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D39, "RangeType.FULL");
        piePlot19.drawBackgroundImage(graphics2D29, rectangle2D39);
        try {
            piePlot4.drawOutline(graphics2D18, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Color color6 = java.awt.Color.BLUE;
        stackedBarRenderer3D2.setSeriesOutlinePaint((int) 'a', (java.awt.Paint) color6, true);
        java.awt.Paint paint10 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) (short) 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] { valueAxis4 };
        xYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot3.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot3.getRangeCrosshairPaint();
        boolean boolean10 = xYPlot3.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot3.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot12.setLegendItemShape(shape15);
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot3, (java.lang.Object) piePlot12);
        boolean boolean18 = groupedStackedBarRenderer0.equals((java.lang.Object) xYPlot3);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer19 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape21 = minMaxCategoryRenderer19.lookupSeriesShape((int) (short) 0);
        java.awt.Paint paint23 = minMaxCategoryRenderer19.getSeriesFillPaint((-457));
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator24 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        minMaxCategoryRenderer19.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator24, true);
        groupedStackedBarRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator24);
        int int28 = groupedStackedBarRenderer0.getPassCount();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.chart.block.BlockContainer blockContainer13 = null;
        legendTitle12.setWrapper(blockContainer13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle12.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D15, "RangeType.FULL");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean19 = categoryPlot18.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot21.setLegendItemShape(shape24);
        java.awt.Paint paint26 = piePlot21.getLabelPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        piePlot21.handleClick((-8355712), (int) (byte) 10, plotRenderingInfo30);
        int int32 = plotRenderingInfo30.getSubplotCount();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = stackedBarRenderer3D2.initialise(graphics2D5, rectangle2D15, categoryPlot18, 15, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        java.awt.Image image5 = null;
        xYPlot1.setBackgroundImage(image5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot1.setDomainAxisLocation(axisLocation7);
        xYPlot1.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj6 = null;
        boolean boolean7 = taskSeriesCollection5.equals(obj6);
        boolean boolean8 = stackedBarRenderer3D2.hasListener((java.util.EventListener) taskSeriesCollection5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int10 = segmentedTimeline9.getSegmentsExcluded();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment12 = segmentedTimeline9.getSegment(date11);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D14 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list15 = defaultKeyedValues2D14.getRowKeys();
        segmentedTimeline9.addExceptions(list15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = segmentedTimeline9.getBaseTimeline();
        long long20 = segmentedTimeline17.getExceptionSegmentCount((long) (byte) 10, (long) (short) 1);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline17.addException(date21);
        int int23 = taskSeriesCollection5.indexOf((java.lang.Comparable) date21);
        taskSeriesCollection5.removeAll();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(segment12);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot3.setLegendItemShape(shape6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend((int) (short) 100);
        jFreeChart8.setAntiAlias(true);
        chartChangeEvent1.setChart(jFreeChart8);
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart8.addProgressListener(chartProgressListener14);
        jFreeChart8.setBackgroundImageAlignment(12);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(legendTitle10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer1 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double2 = boxAndWhiskerRenderer1.getItemMargin();
        boolean boolean3 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) boxAndWhiskerRenderer1);
        org.jfree.chart.LegendItem legendItem6 = boxAndWhiskerRenderer1.getLegendItem((int) 'a', 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (short) 100);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(categoryAxis4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape11 = textBlock3.calculateBounds(graphics2D4, (float) 'a', (float) 4, textBlockAnchor7, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer2.setBaseShape(shape11);
        boolean boolean13 = statisticalLineAndShapeRenderer2.getDrawOutlines();
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        try {
            statisticalLineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        xYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        xYPlot5.setRangeGridlineStroke(stroke10);
        piePlot3D4.setLabelLinkStroke(stroke10);
        java.awt.Stroke stroke13 = piePlot3D4.getBaseSectionOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke13);
        java.awt.Font font15 = polarPlot0.getAngleLabelFont();
        boolean boolean16 = polarPlot0.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray2);
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray6);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray2, doubleArray6);
        int int9 = defaultIntervalCategoryDataset8.getSeriesCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int12 = segmentedTimeline11.getSegmentsExcluded();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segmentedTimeline11.getSegment(date13);
        java.util.Date date15 = segment14.getDate();
        boolean boolean16 = segment14.inExceptionSegments();
        boolean boolean17 = segment14.inExcludeSegments();
        try {
            defaultIntervalCategoryDataset8.setEndValue(1900, (java.lang.Comparable) boolean17, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(segment14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) '#', 7, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape11 = textBlock3.calculateBounds(graphics2D4, (float) 'a', (float) 4, textBlockAnchor7, (float) 10, 0.0f, (-1.0d));
        statisticalLineAndShapeRenderer2.setBaseShape(shape11);
        boolean boolean13 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        try {
            statisticalLineAndShapeRenderer2.setSeriesVisibleInLegend((-1), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("RangeType.FULL");
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        java.lang.Object obj2 = categoryPlot0.clone();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.Object obj2 = null;
        boolean boolean3 = sortOrder1.equals(obj2);
        categoryPlot0.setColumnRenderingOrder(sortOrder1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getWidthConstraintType();
        org.jfree.data.Range range24 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range14, lengthConstraintType20, (double) 6, range24, lengthConstraintType25);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range34 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange30, (double) 0.0f, (double) (short) 0);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean36 = dateRange30.equals((java.lang.Object) color35);
        org.jfree.data.Range range37 = org.jfree.data.Range.combine(range24, (org.jfree.data.Range) dateRange30);
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range39 = numberAxis5.getRange();
        java.lang.String str40 = numberAxis5.getLabelToolTip();
        org.jfree.data.Range range41 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        xYPlot43.setDomainAxes(valueAxisArray45);
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = xYPlot43.getRangeMarkers(layer47);
        java.awt.Paint paint49 = xYPlot43.getRangeCrosshairPaint();
        boolean boolean50 = xYPlot43.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot43.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(5, axisLocation51, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(categoryAxis55);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 10.0d, (-2.0d), 0.0d, (-1.0d));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        boolean boolean8 = unitType0.equals((java.lang.Object) (byte) 10);
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        boolean boolean10 = unitType0.equals((java.lang.Object) paint9);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItemEntity6.setDataset(dataset7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot9);
        boolean boolean16 = legendItemEntity6.equals((java.lang.Object) legendTitle15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle15.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle15.getPosition();
        axisState0.moveCursor((double) 100, rectangleEdge19);
        axisState0.setCursor(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        java.lang.Object obj7 = jFreeChart6.getTextAntiAlias();
        jFreeChart6.setAntiAlias(false);
        float float10 = jFreeChart6.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 100, (double) 6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getBaseItemLabelPaint();
        int int2 = waterfallBarRenderer0.getPassCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = waterfallBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(false);
        double double4 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        stackedBarRenderer3D2.setBaseCreateEntities(false, false);
        boolean boolean12 = stackedBarRenderer3D2.getBaseItemLabelsVisible();
        java.awt.Font font14 = stackedBarRenderer3D2.getSeriesItemLabelFont(8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range34 = numberAxis0.getRange();
        java.lang.String str35 = numberAxis0.getLabelToolTip();
        numberAxis0.setLabelURL("Multiple Pie Plot");
        numberAxis0.setAutoRangeMinimumSize((double) 4, false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCount();
        int int2 = dateTickUnit0.getCalendarField();
        int int3 = dateTickUnit0.getCalendarField();
        java.lang.String str5 = dateTickUnit0.valueToString(Double.NaN);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69 4:00 PM" + "'", str5.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setDomainCrosshairValue((double) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D12 = xYPlot9.getQuadrantOrigin();
        xYPlot3.zoomRangeAxes((double) (byte) 0, (double) (-1.0f), plotRenderingInfo8, point2D12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        xYPlot14.setDomainAxes(valueAxisArray16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getRangeMarkers(layer18);
        java.awt.Stroke stroke20 = xYPlot14.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot22.setLegendItemShape(shape25);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot22);
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart27.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke20, jFreeChart27, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle33 = null;
        jFreeChart27.setTitle(textTitle33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray37 = new org.jfree.chart.axis.ValueAxis[] { valueAxis36 };
        xYPlot35.setDomainAxes(valueAxisArray37);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = xYPlot35.getRangeMarkers(layer39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.util.List list43 = null;
        xYPlot35.drawRangeTickBands(graphics2D41, rectangle2D42, list43);
        xYPlot35.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer46 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { valueAxis48 };
        xYPlot47.setDomainAxes(valueAxisArray49);
        org.jfree.chart.block.LineBorder lineBorder51 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke52 = lineBorder51.getStroke();
        xYPlot47.setRangeGridlineStroke(stroke52);
        minMaxCategoryRenderer46.setGroupStroke(stroke52);
        xYPlot35.setDomainGridlineStroke(stroke52);
        jFreeChart27.setBorderStroke(stroke52);
        xYPlot3.setDomainCrosshairStroke(stroke52);
        dateAxis0.setTickMarkStroke(stroke52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit59 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit59);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(legendTitle29);
        org.junit.Assert.assertNotNull(valueAxisArray37);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(dateTickUnit59);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        xYPlot4.setDomainAxes(valueAxisArray6);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        xYPlot4.setRangeGridlineStroke(stroke9);
        piePlot3D3.setLabelLinkStroke(stroke9);
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) piePlot3D3);
        java.awt.Stroke stroke14 = piePlot3D3.getSectionOutlineStroke((java.lang.Comparable) 10L);
        piePlot3D3.setStartAngle((double) (byte) -1);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer1 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double2 = boxAndWhiskerRenderer1.getItemMargin();
        boolean boolean3 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) boxAndWhiskerRenderer1);
        double double4 = boxAndWhiskerRenderer1.getItemMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int1 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((int) (byte) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("February 100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        java.awt.Stroke stroke5 = intervalMarker2.getOutlineStroke();
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        xYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot10.getRangeMarkers(layer14);
        java.awt.Paint paint16 = xYPlot10.getRangeCrosshairPaint();
        piePlot3D9.setLabelOutlinePaint(paint16);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean21 = statisticalLineAndShapeRenderer20.getUseOutlinePaint();
        java.awt.Paint paint24 = statisticalLineAndShapeRenderer20.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D9.setShadowPaint(paint24);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot3D9);
        float float27 = intervalMarker2.getAlpha();
        java.awt.Color color28 = java.awt.Color.pink;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.8f + "'", float27 == 0.8f);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets2.getBottom();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets2.getUnitType();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        labelBlock1.setPadding(rectangleInsets2);
        java.lang.String str8 = labelBlock1.getToolTipText();
        labelBlock1.setPadding((double) 10.0f, (double) (-2208960000000L), (double) ' ', (double) (-8355712));
        java.lang.Object obj14 = labelBlock1.clone();
        java.lang.String str15 = labelBlock1.getID();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.configure();
        categoryAxis3D1.setLowerMargin((double) 12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis3D1.getCategoryLabelPositions();
        java.lang.String str6 = categoryAxis3D1.getLabelToolTip();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        java.awt.Image image2 = xYPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge(68);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Paint paint12 = xYPlot6.getRangeCrosshairPaint();
        boolean boolean13 = xYPlot6.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot6.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot15.setLegendItemShape(shape18);
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot6, (java.lang.Object) piePlot15);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setDomainCrosshairValue((double) (byte) 1);
        java.awt.geom.Point2D point2D24 = xYPlot21.getQuadrantOrigin();
        xYPlot6.setQuadrantOrigin(point2D24);
        xYPlot6.mapDatasetToRangeAxis(10, 0);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange35);
        org.jfree.data.Range range39 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange35, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange43);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = rectangleConstraint44.getWidthConstraintType();
        org.jfree.data.Range range49 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType50 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range39, lengthConstraintType45, (double) 6, range49, lengthConstraintType50);
        org.jfree.data.time.DateRange dateRange55 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange55);
        org.jfree.data.Range range59 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange55, (double) 0.0f, (double) (short) 0);
        java.awt.Color color60 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean61 = dateRange55.equals((java.lang.Object) color60);
        org.jfree.data.Range range62 = org.jfree.data.Range.combine(range49, (org.jfree.data.Range) dateRange55);
        numberAxis30.setDefaultAutoRange((org.jfree.data.Range) dateRange55);
        org.jfree.data.RangeType rangeType64 = numberAxis30.getRangeType();
        xYPlot6.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis30);
        boolean boolean66 = numberAxis30.isAxisLineVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer67 = null;
        org.jfree.chart.plot.PolarPlot polarPlot68 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis30, polarItemRenderer67);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis30);
        boolean boolean70 = numberAxis30.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertNotNull(lengthConstraintType50);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(rangeType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        java.lang.String str53 = legendItem50.getToolTipText();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]" + "'", str53.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.RangeType rangeType34 = numberAxis0.getRangeType();
        numberAxis0.setAutoRange(true);
        boolean boolean37 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0d, 1.0f, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        boolean boolean9 = legendGraphic8.isShapeFilled();
        boolean boolean10 = legendGraphic8.isLineVisible();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape13, 1.0d, 1.0f, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        xYPlot22.setDomainAxes(valueAxisArray24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot22.getRangeMarkers(layer26);
        java.awt.Paint paint28 = xYPlot22.getRangeCrosshairPaint();
        piePlot3D21.setLabelOutlinePaint(paint28);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean33 = statisticalLineAndShapeRenderer32.getUseOutlinePaint();
        java.awt.Paint paint36 = statisticalLineAndShapeRenderer32.getItemFillPaint((int) (byte) 1, (int) '#');
        piePlot3D21.setShadowPaint(paint36);
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape13, paint36);
        legendGraphic8.setLinePaint(paint36);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
        java.lang.String str2 = textTitle1.getText();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset8.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot9);
        java.awt.Image image13 = null;
        xYPlot9.setBackgroundImage(image13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setDomainAxisLocation(axisLocation15);
        xYPlot0.setDomainAxisLocation(10, axisLocation15, false);
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot0.getFixedRangeAxisSpace();
        int int20 = xYPlot0.getRangeAxisCount();
        java.awt.Paint paint21 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Shape shape2 = minMaxCategoryRenderer0.lookupSeriesShape((int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        minMaxCategoryRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.height;
        size2D2.setWidth((double) 10);
        double double6 = size2D2.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str10 = rectangleAnchor9.toString();
        java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) 11, 12.0d, rectangleAnchor9);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str10.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getBaseItemLabelPaint();
        int int2 = waterfallBarRenderer0.getPassCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = waterfallBarRenderer0.getSeriesToolTipGenerator(8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.Object obj2 = null;
        boolean boolean3 = sortOrder1.equals(obj2);
        categoryPlot0.setColumnRenderingOrder(sortOrder1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getWidthConstraintType();
        org.jfree.data.Range range24 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range14, lengthConstraintType20, (double) 6, range24, lengthConstraintType25);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range34 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange30, (double) 0.0f, (double) (short) 0);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean36 = dateRange30.equals((java.lang.Object) color35);
        org.jfree.data.Range range37 = org.jfree.data.Range.combine(range24, (org.jfree.data.Range) dateRange30);
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        org.jfree.data.Range range39 = numberAxis5.getRange();
        java.lang.String str40 = numberAxis5.getLabelToolTip();
        org.jfree.data.Range range41 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        int int42 = categoryPlot0.getWeight();
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint44 = xYPlot43.getRangeTickBandPaint();
        java.awt.Image image45 = xYPlot43.getBackgroundImage();
        xYPlot43.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke48 = xYPlot43.getRangeGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke48);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNull(image45);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 10, (double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.gray;
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color4, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setDomainCrosshairValue((double) (byte) 1);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot10);
        org.jfree.data.Range range14 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        boolean boolean16 = stackedBarRenderer3D2.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = stackedBarRenderer3D2.getLegendItems();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getWidthConstraintType();
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range8, lengthConstraintType14, (double) 6, range18, lengthConstraintType19);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange24);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange24, (double) 0.0f, (double) (short) 0);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean30 = dateRange24.equals((java.lang.Object) color29);
        org.jfree.data.Range range31 = org.jfree.data.Range.combine(range18, (org.jfree.data.Range) dateRange24);
        org.jfree.data.Range range33 = org.jfree.data.Range.expandToInclude(range31, (double) 3600000L);
        boolean boolean36 = range33.intersects(8.0d, (double) 100.0f);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        java.lang.Object obj2 = categoryPlot0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange9, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range13, lengthConstraintType19, (double) 6, range23, lengthConstraintType24);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range33 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange29, (double) 0.0f, (double) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean35 = dateRange29.equals((java.lang.Object) color34);
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange29);
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range38 = numberAxis4.getRange();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity42 = new org.jfree.chart.entity.LegendItemEntity(shape41);
        org.jfree.data.general.Dataset dataset43 = null;
        legendItemEntity42.setDataset(dataset43);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] { valueAxis46 };
        xYPlot45.setDomainAxes(valueAxisArray47);
        org.jfree.chart.util.Layer layer49 = null;
        java.util.Collection collection50 = xYPlot45.getRangeMarkers(layer49);
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot45);
        boolean boolean52 = legendItemEntity42.equals((java.lang.Object) legendTitle51);
        java.awt.Font font53 = legendTitle51.getItemFont();
        java.awt.Font font55 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", font55);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock56.setFont(font57);
        legendTitle51.setItemFont(font57);
        numberAxis4.setLabelFont(font57);
        categoryPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation62 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation62, plotOrientation63);
        categoryPlot0.setRangeAxisLocation(axisLocation62, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (-460));
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setCircular(false, false);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange5, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range9, lengthConstraintType15, (double) 6, range19, lengthConstraintType20);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange25, (double) 0.0f, (double) (short) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean31 = dateRange25.equals((java.lang.Object) color30);
        org.jfree.data.Range range32 = org.jfree.data.Range.combine(range19, (org.jfree.data.Range) dateRange25);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range34 = numberAxis0.getRange();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray43 = new org.jfree.chart.axis.ValueAxis[] { valueAxis42 };
        xYPlot41.setDomainAxes(valueAxisArray43);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot41.getRangeMarkers(layer45);
        java.awt.Stroke stroke47 = xYPlot41.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot49.setLegendItemShape(shape52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot49);
        org.jfree.chart.title.LegendTitle legendTitle56 = jFreeChart54.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent59 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke47, jFreeChart54, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle60 = null;
        jFreeChart54.setTitle(textTitle60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray64 = new org.jfree.chart.axis.ValueAxis[] { valueAxis63 };
        xYPlot62.setDomainAxes(valueAxisArray64);
        org.jfree.chart.util.Layer layer66 = null;
        java.util.Collection collection67 = xYPlot62.getRangeMarkers(layer66);
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.util.List list70 = null;
        xYPlot62.drawRangeTickBands(graphics2D68, rectangle2D69, list70);
        xYPlot62.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer73 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray76 = new org.jfree.chart.axis.ValueAxis[] { valueAxis75 };
        xYPlot74.setDomainAxes(valueAxisArray76);
        org.jfree.chart.block.LineBorder lineBorder78 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke79 = lineBorder78.getStroke();
        xYPlot74.setRangeGridlineStroke(stroke79);
        minMaxCategoryRenderer73.setGroupStroke(stroke79);
        xYPlot62.setDomainGridlineStroke(stroke79);
        jFreeChart54.setBorderStroke(stroke79);
        java.awt.Paint paint84 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape40, stroke79, paint84);
        java.awt.Shape shape86 = legendItem85.getLine();
        boolean boolean87 = legendItem85.isShapeOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset88 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup89 = defaultCategoryDataset88.getGroup();
        defaultCategoryDataset88.removeColumn((java.lang.Comparable) 60000L);
        legendItem85.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset88);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit94 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        defaultCategoryDataset88.removeValue((java.lang.Comparable) numberTickUnit94, (java.lang.Comparable) (-2.0d));
        numberAxis0.setTickUnit(numberTickUnit94);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(valueAxisArray43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(legendTitle56);
        org.junit.Assert.assertNotNull(valueAxisArray64);
        org.junit.Assert.assertNull(collection67);
        org.junit.Assert.assertNotNull(valueAxisArray76);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(datasetGroup89);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = taskSeriesCollection0.equals(obj1);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, (double) 0.0f, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (short) -1, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (short) 1, (org.jfree.data.Range) dateRange15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.data.Range range21 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range11, lengthConstraintType17, (double) 6, range21, lengthConstraintType22);
        boolean boolean24 = taskSeriesCollection0.equals((java.lang.Object) range21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent25);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot(pieDataset30);
        java.awt.Color color32 = java.awt.Color.DARK_GRAY;
        boolean boolean33 = ringPlot31.equals((java.lang.Object) color32);
        java.awt.Stroke stroke34 = ringPlot31.getSeparatorStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(pieDataset30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        java.awt.Stroke stroke12 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot14.setLegendItemShape(shape17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart19.getLegend((int) (short) 100);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke12, jFreeChart19, (int) (short) 0, (int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle25 = null;
        jFreeChart19.setTitle(textTitle25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        xYPlot27.setDomainAxes(valueAxisArray29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getRangeMarkers(layer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        xYPlot27.clearRangeMarkers();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        xYPlot39.setDomainAxes(valueAxisArray41);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        xYPlot39.setRangeGridlineStroke(stroke44);
        minMaxCategoryRenderer38.setGroupStroke(stroke44);
        xYPlot27.setDomainGridlineStroke(stroke44);
        jFreeChart19.setBorderStroke(stroke44);
        java.awt.Paint paint49 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", shape5, stroke44, paint49);
        java.awt.Shape shape51 = legendItem50.getLine();
        boolean boolean52 = legendItem50.isShapeOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset53 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup54 = defaultCategoryDataset53.getGroup();
        defaultCategoryDataset53.removeColumn((java.lang.Comparable) 60000L);
        legendItem50.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset53);
        try {
            defaultCategoryDataset53.incrementValue(0.0d, (java.lang.Comparable) 90.0d, (java.lang.Comparable) "RangeType.FULL");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: RangeType.FULL");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetGroup54);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer3.setSeriesShapesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator8 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        statisticalLineAndShapeRenderer3.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator8);
        java.text.NumberFormat numberFormat10 = standardCategoryToolTipGenerator8.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator11 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", numberFormat10);
        java.text.NumberFormat numberFormat12 = standardCategoryToolTipGenerator11.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat12);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = statisticalLineAndShapeRenderer2.getBaseToolTipGenerator();
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer2.getSeriesItemLabelsVisible(100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        float float7 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        xYPlot0.clearAnnotations();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        float[] floatArray17 = null;
        float[] floatArray18 = color16.getRGBComponents(floatArray17);
        float[] floatArray19 = color12.getComponents(colorSpace15, floatArray17);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) '4');
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) (-1.0d));
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.Object obj2 = null;
        boolean boolean3 = sortOrder1.equals(obj2);
        categoryPlot0.setColumnRenderingOrder(sortOrder1);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(1);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        boolean boolean4 = segment3.inExceptionSegments();
        boolean boolean5 = segment3.inExceptionSegments();
        long long7 = segment3.calculateSegmentNumber((long) 8);
        boolean boolean10 = segment3.contains((long) 8, (long) 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int12 = segmentedTimeline11.getSegmentsExcluded();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segmentedTimeline11.getSegment(date13);
        segment14.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segment14.copy();
        boolean boolean17 = segment3.contains(segment14);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2454364L + "'", long7 == 2454364L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(segment14);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        jFreeChart6.setAntiAlias(true);
        int int11 = jFreeChart6.getBackgroundImageAlignment();
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart6.getTitle();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot16.setLegendItemShape(shape19);
        piePlot16.setMaximumLabelWidth((double) (-457));
        boolean boolean23 = numberTickUnit15.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        xYPlot24.setDomainAxes(valueAxisArray26);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot24.getRangeMarkers(layer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot24);
        org.jfree.chart.block.BlockContainer blockContainer31 = null;
        legendTitle30.setWrapper(blockContainer31);
        java.awt.geom.Rectangle2D rectangle2D33 = legendTitle30.getBounds();
        boolean boolean34 = numberTickUnit15.equals((java.lang.Object) rectangle2D33);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition37 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.data.KeyedObject keyedObject38 = new org.jfree.data.KeyedObject((java.lang.Comparable) (-2.0d), (java.lang.Object) categoryLabelPosition37);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions39 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions35, categoryLabelPosition37);
        org.jfree.data.KeyedObjects2D keyedObjects2D40 = new org.jfree.data.KeyedObjects2D();
        int int42 = keyedObjects2D40.getColumnIndex((java.lang.Comparable) 15);
        java.util.List list43 = keyedObjects2D40.getRowKeys();
        boolean boolean44 = categoryLabelPositions39.equals((java.lang.Object) list43);
        java.lang.Object obj45 = textTitle12.draw(graphics2D13, rectangle2D33, (java.lang.Object) list43);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = textTitle12.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(textTitle12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(categoryLabelPositions39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot1.setLegendItemShape(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        jFreeChart6.setAntiAlias(true);
        boolean boolean11 = jFreeChart6.isBorderVisible();
        jFreeChart6.setAntiAlias(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItemEntity6.setDataset(dataset7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        xYPlot9.setDomainAxes(valueAxisArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot9);
        boolean boolean16 = legendItemEntity6.equals((java.lang.Object) legendTitle15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle15.getHorizontalAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle15.getPosition();
        axisState0.moveCursor((double) 100, rectangleEdge19);
        axisState0.setMax((double) (short) -1);
        axisState0.cursorLeft((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        java.lang.String str2 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str1.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str2.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset4 = null;
        legendItemEntity3.setDataset(dataset4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        xYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(layer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        boolean boolean13 = legendItemEntity3.equals((java.lang.Object) legendTitle12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle12.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = legendTitle12.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] { valueAxis1 };
        xYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean7 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot9.setLegendItemShape(shape12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot0, (java.lang.Object) piePlot9);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor15 = piePlot9.getLabelDistributor();
        piePlot9.setPieIndex((int) (short) 10);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape20, 1.0d, 1.0f, 0.0f);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot25.setLegendItemShape(shape28);
        piePlot25.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint32 = piePlot25.getShadowPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape20, paint32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendGraphic33.getBounds();
        piePlot9.setLegendItemShape((java.awt.Shape) rectangle2D34);
        piePlot9.setPieIndex(0);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        piePlot0.setLegendItemShape(shape3);
        piePlot0.setMaximumLabelWidth((double) (-457));
        java.awt.Paint paint7 = piePlot0.getShadowPaint();
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        piePlot0.setNoDataMessagePaint(paint8);
        double double10 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        segmentedTimeline0.addExceptions(list6);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = segmentedTimeline0.getBaseTimeline();
        long long11 = segmentedTimeline8.getExceptionSegmentCount((long) (byte) 10, (long) (short) 1);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline8.addException(date12);
        java.util.Date date14 = null;
        try {
            long long15 = segmentedTimeline8.getTime(date14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
    }
}

