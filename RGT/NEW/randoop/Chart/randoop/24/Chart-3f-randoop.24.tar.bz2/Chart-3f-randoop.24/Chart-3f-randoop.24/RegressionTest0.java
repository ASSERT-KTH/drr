import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        long long5 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61157520000000L) + "'", long5 == (-61157520000000L));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month3.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        long long6 = month3.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        long long14 = year13.getMiddleMillisecond();
        java.util.Date date15 = year13.getEnd();
        int int16 = month10.compareTo((java.lang.Object) year13);
        int int17 = month10.getMonth();
        boolean boolean19 = month10.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month10.previous();
        int int21 = month3.compareTo((java.lang.Object) month10);
        java.util.Calendar calendar22 = null;
        try {
            month10.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61141708800001L) + "'", long14 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 12, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (byte) 1);
        boolean boolean18 = timeSeriesDataItem17.isSelected();
        try {
            timeSeries3.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        try {
            timeSeries3.update(regularTimePeriod9, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        int int2 = year1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1);
        boolean boolean16 = timeSeriesDataItem15.isSelected();
        timeSeriesDataItem15.setValue((java.lang.Number) (byte) 100);
        try {
            timeSeries3.add(timeSeriesDataItem15, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        long long11 = month3.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month3.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61128576000000L) + "'", long11 == (-61128576000000L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        long long14 = year13.getMiddleMillisecond();
        java.util.Date date15 = year13.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61141708800001L) + "'", long14 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (byte) 1);
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) '4', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185237086L + "'", long2 == 1560185237086L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) (short) 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        try {
            java.lang.Number number17 = timeSeries14.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        try {
            timeSeries3.delete(2147483647, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day6.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61154841600001L) + "'", long6 == (-61154841600001L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month7.next();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        try {
            timeSeries57.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 385L + "'", long6 == 385L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        long long13 = year12.getMiddleMillisecond();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61141708800001L) + "'", long13 == (-61141708800001L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        try {
            timeSeries3.update(1, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (byte) 1);
        boolean boolean41 = timeSeriesDataItem40.isSelected();
        timeSeriesDataItem40.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem40.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem40.setSelected(false);
        try {
            timeSeries15.add(timeSeriesDataItem40, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        timeSeries34.setMaximumItemAge((long) 2147483647);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month40.next();
        java.lang.String str44 = month40.toString();
        timeSeries34.setKey((java.lang.Comparable) month40);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "December 32" + "'", str44.equals("December 32"));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        int int8 = day6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.previous();
//        try {
//            timeSeries5.update((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 1.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        java.util.Calendar calendar13 = null;
        try {
            month3.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        try {
            org.jfree.data.time.TimeSeries timeSeries38 = timeSeries15.createCopy(8, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setMaximumItemAge(1206L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        long long17 = month16.getSerialIndex();
        long long18 = month16.getFirstMillisecond();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 10, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period December 32 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 396L + "'", long17 == 396L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61128576000000L) + "'", long18 == (-61128576000000L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        timeSeries3.setKey((java.lang.Comparable) year13);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year13.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.next();
        java.lang.String str7 = month3.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(5, 100);
        boolean boolean11 = month3.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 32" + "'", str7.equals("December 32"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries3.getNotify();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) (byte) 1);
        boolean boolean43 = timeSeriesDataItem42.isSelected();
        timeSeriesDataItem42.setValue((java.lang.Number) (byte) 100);
        try {
            timeSeries3.add(timeSeriesDataItem42, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Overwritten values from: 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("December 32");
//        int int5 = day0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61125897600001L) + "'", long7 == (-61125897600001L));
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year5 = month3.getYear();
        java.util.Calendar calendar6 = null;
        try {
            month3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
        int int15 = timeSeriesDataItem8.compareTo((java.lang.Object) month12);
        boolean boolean16 = year1.equals((java.lang.Object) timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        int int4 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries23.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date55 = year54.getEnd();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) month56, (java.lang.Number) (byte) 10);
        timeSeries52.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date67 = year66.getEnd();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month68.next();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) ' ');
        long long72 = year71.getMiddleMillisecond();
        java.util.Date date73 = year71.getEnd();
        int int74 = month68.compareTo((java.lang.Object) year71);
        int int75 = month68.getMonth();
        boolean boolean77 = month68.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month68.previous();
        timeSeries64.add(regularTimePeriod78, (double) 32);
        boolean boolean81 = timeSeries64.getNotify();
        java.lang.Object obj82 = timeSeries64.clone();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries52.addAndOrUpdate(timeSeries64);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener84 = null;
        timeSeries52.addChangeListener(seriesChangeListener84);
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date88 = year87.getEnd();
        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = month89.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem92 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month89, (java.lang.Number) 12);
        try {
            timeSeries3.add(timeSeriesDataItem92);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period December 32 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-61141708800001L) + "'", long72 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 12 + "'", int75 == 12);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeSeriesDataItem92);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        long long5 = year1.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem(regularTimePeriod17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        int int23 = timeSeriesDataItem16.compareTo((java.lang.Object) month20);
        long long24 = month20.getLastMillisecond();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (double) 8, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period December 32 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61125897600001L) + "'", long24 == (-61125897600001L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (java.lang.Number) (short) 0);
        java.util.Date date5 = regularTimePeriod2.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        java.lang.Comparable comparable13 = timeSeries3.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10L + "'", comparable13.equals(10L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        timeSeries3.setKey((java.lang.Comparable) year13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        java.util.Date date19 = year17.getEnd();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560185236136L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        java.lang.Object obj18 = timeSeriesDataItem16.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem16.getPeriod();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        try {
            timeSeries3.delete(8, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        boolean boolean22 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date52 = year51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (byte) 10);
        timeSeries49.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) ' ');
        long long69 = year68.getMiddleMillisecond();
        java.util.Date date70 = year68.getEnd();
        int int71 = month65.compareTo((java.lang.Object) year68);
        int int72 = month65.getMonth();
        boolean boolean74 = month65.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month65.previous();
        timeSeries61.add(regularTimePeriod75, (double) 32);
        boolean boolean78 = timeSeries61.getNotify();
        java.lang.Object obj79 = timeSeries61.clone();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries49.addAndOrUpdate(timeSeries61);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries49.addChangeListener(seriesChangeListener81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date85 = year84.getEnd();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month86.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month86, (java.lang.Number) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        java.util.Collection collection91 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61141708800001L) + "'", long69 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertNotNull(collection91);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((-1), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener20);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries24 = timeSeries5.createCopy(11, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        try {
//            timeSeries5.delete((-9999), (int) '#', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date19);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries14.createCopy(regularTimePeriod16, regularTimePeriod24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61125897600001L) + "'", long23 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date52 = year51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (byte) 10);
        timeSeries49.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) ' ');
        long long69 = year68.getMiddleMillisecond();
        java.util.Date date70 = year68.getEnd();
        int int71 = month65.compareTo((java.lang.Object) year68);
        int int72 = month65.getMonth();
        boolean boolean74 = month65.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month65.previous();
        timeSeries61.add(regularTimePeriod75, (double) 32);
        boolean boolean78 = timeSeries61.getNotify();
        java.lang.Object obj79 = timeSeries61.clone();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries49.addAndOrUpdate(timeSeries61);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries49.addChangeListener(seriesChangeListener81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date85 = year84.getEnd();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month86.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month86, (java.lang.Number) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        java.lang.Number number91 = timeSeriesDataItem90.getValue();
        java.lang.Object obj92 = timeSeriesDataItem90.clone();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61141708800001L) + "'", long69 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertTrue("'" + number91 + "' != '" + 12 + "'", number91.equals(12));
        org.junit.Assert.assertNotNull(obj92);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries3.removeChangeListener(seriesChangeListener46);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date54 = year53.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month55, (java.lang.Number) (byte) 10);
        timeSeries51.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date66 = year65.getEnd();
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month67.next();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year((int) ' ');
        long long71 = year70.getMiddleMillisecond();
        java.util.Date date72 = year70.getEnd();
        int int73 = month67.compareTo((java.lang.Object) year70);
        int int74 = month67.getMonth();
        boolean boolean76 = month67.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month67.previous();
        timeSeries63.add(regularTimePeriod77, (double) 32);
        boolean boolean80 = timeSeries63.getNotify();
        java.lang.Object obj81 = timeSeries63.clone();
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries51.addAndOrUpdate(timeSeries63);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener83 = null;
        timeSeries51.addChangeListener(seriesChangeListener83);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date87 = year86.getEnd();
        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = month88.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month88, (java.lang.Number) 12);
        org.jfree.data.time.Month month94 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year95 = month94.getYear();
        java.lang.Number number96 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) month94);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem97 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month94);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-61141708800001L) + "'", long71 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(obj81);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem91);
        org.junit.Assert.assertNotNull(year95);
        org.junit.Assert.assertNull(number96);
        org.junit.Assert.assertNull(timeSeriesDataItem97);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy(11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        java.lang.String str6 = month3.toString();
        long long7 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 32" + "'", str6.equals("December 32"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61128576000000L) + "'", long7 == (-61128576000000L));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = null;
//        try {
//            timeSeries9.add(regularTimePeriod41, (double) (byte) -1, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("32");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem4.setSelected(false);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        java.util.Date date15 = year13.getEnd();
        int int16 = timeSeriesDataItem4.compareTo((java.lang.Object) year13);
        boolean boolean17 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        int int17 = timeSeriesDataItem10.compareTo((java.lang.Object) month14);
        long long18 = month14.getLastMillisecond();
        boolean boolean19 = year4.equals((java.lang.Object) month14);
        java.lang.String str20 = month14.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61125897600001L) + "'", long18 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "December 32" + "'", str20.equals("December 32"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timeSeries23.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10);
        timeSeries35.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection47 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries31.addAndOrUpdate(timeSeries35);
        timeSeries35.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries23.addAndOrUpdate(timeSeries35);
        timeSeries23.clear();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries54);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Date date5 = day0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        try {
            java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((int) (byte) 0, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 1);
        boolean boolean35 = timeSeriesDataItem34.isSelected();
        timeSeriesDataItem34.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str40 = timePeriodFormatException39.toString();
        int int41 = timeSeriesDataItem34.compareTo((java.lang.Object) timePeriodFormatException39);
        java.lang.Object obj42 = timeSeriesDataItem34.clone();
        try {
            timeSeries7.add(timeSeriesDataItem34);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        java.util.Calendar calendar7 = null;
        try {
            year1.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-9999), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        try {
            timeSeries3.delete((-9999), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getYear();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        try {
            timeSeries3.delete(11, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (short) 100, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32" + "'", str4.equals("32"));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        long long6 = day4.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timeSeries9.setKey((java.lang.Comparable) day10);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries14 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries9.addAndOrUpdate(timeSeries14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185258154L + "'", long3 == 1560185258154L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185258465L + "'", long2 == 1560185258465L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185258465L + "'", long4 == 1560185258465L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        long long7 = month6.getSerialIndex();
        long long8 = month6.getFirstMillisecond();
        boolean boolean9 = month2.equals((java.lang.Object) long8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month2.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 396L + "'", long7 == 396L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61128576000000L) + "'", long8 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) ' ');
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 6);
        int int23 = year19.getYear();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year19);
        try {
            java.lang.Number number26 = timeSeries14.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61141708800001L) + "'", long20 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Date date5 = day0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) (byte) -1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries7.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61125897600001L) + "'", long43 == (-61125897600001L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) (-61157520000000L));
        java.lang.Object obj7 = null;
        int int8 = timeSeriesDataItem4.compareTo(obj7);
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem4.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        java.lang.Object obj5 = timeSeriesDataItem4.clone();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = timeSeriesDataItem4.compareTo((java.lang.Object) month8);
        java.util.Calendar calendar12 = null;
        try {
            month8.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) (-61157520000000L));
        java.lang.Object obj7 = null;
        int int8 = timeSeriesDataItem4.compareTo(obj7);
        java.lang.Object obj9 = timeSeriesDataItem4.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        try {
            org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (byte) 10);
        timeSeries11.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection23 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries7.addAndOrUpdate(timeSeries11);
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems((long) (short) 0, false);
        boolean boolean32 = day0.equals((java.lang.Object) false);
        java.util.Calendar calendar33 = null;
        try {
            day0.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        java.lang.Comparable comparable13 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10L + "'", comparable13.equals(10L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getSerialIndex();
        long long5 = month3.getFirstMillisecond();
        java.util.Date date6 = month3.getEnd();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 396L + "'", long4 == 396L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61128576000000L) + "'", long5 == (-61128576000000L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getSerialIndex();
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond8);
        java.util.Calendar calendar14 = null;
        fixedMillisecond8.peg(calendar14);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61125897600001L) + "'", long10 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 0L);
        timeSeriesDataItem6.setValue((java.lang.Number) 1.0d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        java.lang.Comparable comparable13 = timeSeries3.getKey();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (byte) 1);
        int int20 = timeSeriesDataItem18.compareTo((java.lang.Object) (-61157520000000L));
        try {
            timeSeries3.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10L + "'", comparable13.equals(10L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1);
//        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) (-61157520000000L));
//        java.lang.Object obj29 = null;
//        int int30 = timeSeriesDataItem26.compareTo(obj29);
//        try {
//            timeSeries5.add(timeSeriesDataItem26, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 32 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        java.lang.String str14 = seriesChangeEvent12.toString();
        java.lang.String str15 = seriesChangeEvent12.toString();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 10);
        java.lang.Number number10 = timeSeriesDataItem4.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 10 + "'", number10.equals((byte) 10));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        timeSeries15.setKey((java.lang.Comparable) fixedMillisecond26);
        long long29 = fixedMillisecond26.getMiddleMillisecond();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        boolean boolean32 = timeSeries3.equals((java.lang.Object) fixedMillisecond26);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61125897600001L) + "'", long29 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61125897600001L) + "'", long31 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getSerialIndex();
        long long5 = month3.getFirstMillisecond();
        java.util.Date date6 = month3.getEnd();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 396L + "'", long4 == 396L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61128576000000L) + "'", long5 == (-61128576000000L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        java.lang.String str11 = month3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December 32" + "'", str11.equals("December 32"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        timeSeries3.setRangeDescription("32");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (double) (byte) 1);
        boolean boolean44 = timeSeriesDataItem43.isSelected();
        timeSeriesDataItem43.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem43.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem43.setSelected(false);
        java.lang.Number number51 = timeSeriesDataItem43.getValue();
        java.lang.Number number52 = null;
        timeSeriesDataItem43.setValue(number52);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries3.addOrUpdate(timeSeriesDataItem43);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (byte) 10 + "'", number51.equals((byte) 10));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        java.lang.Object obj18 = timeSeriesDataItem16.clone();
        timeSeries3.add(timeSeriesDataItem16);
        timeSeriesDataItem16.setValue((java.lang.Number) Double.NaN);
        timeSeriesDataItem16.setValue((java.lang.Number) (byte) 0);
        boolean boolean25 = timeSeriesDataItem16.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        long long42 = year41.getMiddleMillisecond();
        java.util.Date date43 = year41.getEnd();
        int int44 = month38.compareTo((java.lang.Object) year41);
        int int45 = month38.getMonth();
        boolean boolean47 = month38.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month38.previous();
        long long49 = month38.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean54 = month38.equals((java.lang.Object) timeSeries53);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 1560150000000L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period December 32 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61141708800001L) + "'", long42 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-61128576000000L) + "'", long49 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        timeSeries3.setKey((java.lang.Comparable) year13);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        int int18 = day16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
//        long long20 = day16.getSerialIndex();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day16, (double) 1560236399999L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean4 = timeSeries3.isEmpty();
        timeSeries3.setDomainDescription("32");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem28.getPeriod();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month3.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        boolean boolean5 = day0.equals((java.lang.Object) 1.0d);
//        int int6 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185266088L + "'", long3 == 1560185266088L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185266088L + "'", long5 == 1560185266088L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        int int11 = timeSeriesDataItem4.compareTo((java.lang.Object) timePeriodFormatException9);
        java.lang.Object obj12 = timeSeriesDataItem4.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        boolean boolean19 = timeSeriesDataItem4.equals((java.lang.Object) regularTimePeriod18);
        boolean boolean20 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        long long3 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1205L + "'", long3 == 1205L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.previous();
        try {
            timeSeries3.update(regularTimePeriod14, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = day0.getSerialIndex();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
//        long long27 = month26.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
//        java.lang.String str30 = timeSeries7.getRangeDescription();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        int int33 = day31.getMonth();
//        long long34 = day31.getSerialIndex();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (double) 2);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43626L + "'", long34 == 43626L);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        try {
            timeSeries3.delete(9, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 32, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries3.removeChangeListener(seriesChangeListener46);
        double double48 = timeSeries3.getMaxY();
        try {
            timeSeries3.delete(12, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 32.0d + "'", double48 == 32.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        int int7 = year1.getYear();
        int int8 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        timeSeries3.setKey((java.lang.Comparable) year13);
        int int16 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        timeSeries3.setNotify(false);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getSerialIndex();
        long long5 = month3.getFirstMillisecond();
        java.util.Date date6 = month3.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month3.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 396L + "'", long4 == 396L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61128576000000L) + "'", long5 == (-61128576000000L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
        java.util.Date date2 = year1.getStart();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        java.util.Date date4 = year2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        int int13 = month7.compareTo((java.lang.Object) year10);
//        int int14 = month7.getMonth();
//        boolean boolean16 = month7.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
//        timeSeries3.add(regularTimePeriod17, (double) 32);
//        boolean boolean20 = timeSeries3.getNotify();
//        java.lang.Object obj21 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date28 = year27.getEnd();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date40 = year39.getEnd();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
//        long long45 = year44.getMiddleMillisecond();
//        java.util.Date date46 = year44.getEnd();
//        int int47 = month41.compareTo((java.lang.Object) year44);
//        int int48 = month41.getMonth();
//        boolean boolean50 = month41.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
//        timeSeries37.add(regularTimePeriod51, (double) 32);
//        boolean boolean54 = timeSeries37.getNotify();
//        java.lang.Object obj55 = timeSeries37.clone();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getMonth();
//        long long60 = day58.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day58.previous();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day58, (double) (short) -1, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(obj55);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 43626L + "'", long60 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        timeSeries3.setRangeDescription("32");
        double double39 = timeSeries3.getMinY();
        int int40 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.0d + "'", double39 == 10.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10);
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        timeSeries20.setDomainDescription("");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 6);
        int int29 = year25.getYear();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year25);
        int int31 = month5.compareTo((java.lang.Object) timeSeries20);
        int int32 = month5.getMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32 + "'", int29 == 32);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Date date3 = year1.getEnd();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getLastMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61125897600001L) + "'", long14 == (-61125897600001L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1);
        try {
            timeSeries1.delete(7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "32", "Overwritten values from: 10");
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 0);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(2147483647, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        long long15 = day13.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        timeSeries18.setKey((java.lang.Comparable) day19);
//        int int22 = day19.getDayOfMonth();
//        long long23 = day19.getLastMillisecond();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, number24);
//        int int26 = fixedMillisecond7.compareTo((java.lang.Object) number24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("December 32");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem4.setSelected(false);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        java.util.Date date15 = year13.getEnd();
        int int16 = timeSeriesDataItem4.compareTo((java.lang.Object) year13);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date19);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        long long24 = fixedMillisecond21.getSerialIndex();
        int int25 = timeSeriesDataItem4.compareTo((java.lang.Object) long24);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61125897600001L) + "'", long23 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61125897600001L) + "'", long24 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185269767L + "'", long2 == 1560185269767L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185269767L + "'", long3 == 1560185269767L);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
//        boolean boolean24 = timeSeries23.getNotify();
//        timeSeries23.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
//        int int29 = day27.getMonth();
//        long long30 = day27.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day27.next();
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        long long7 = month6.getSerialIndex();
        long long8 = month6.getFirstMillisecond();
        boolean boolean9 = month2.equals((java.lang.Object) long8);
        long long10 = month2.getLastMillisecond();
        long long11 = month2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 396L + "'", long7 == 396L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61128576000000L) + "'", long8 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58995878400001L) + "'", long10 == (-58995878400001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58997174400001L) + "'", long11 == (-58997174400001L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        long long47 = year46.getMiddleMillisecond();
        java.util.Date date48 = year46.getEnd();
        int int49 = month43.compareTo((java.lang.Object) year46);
        int int50 = month43.getMonth();
        boolean boolean52 = month43.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month43.previous();
        timeSeries39.add(regularTimePeriod53, (double) 32);
        boolean boolean56 = timeSeries39.getNotify();
        java.lang.Object obj57 = timeSeries39.clone();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 10);
        timeSeries61.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date76 = year75.getEnd();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month77.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) ' ');
        long long81 = year80.getMiddleMillisecond();
        java.util.Date date82 = year80.getEnd();
        int int83 = month77.compareTo((java.lang.Object) year80);
        int int84 = month77.getMonth();
        boolean boolean86 = month77.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month77.previous();
        timeSeries73.add(regularTimePeriod87, (double) 32);
        boolean boolean90 = timeSeries73.getNotify();
        java.lang.Object obj91 = timeSeries73.clone();
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries61.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries39.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries15.addAndOrUpdate(timeSeries73);
        double double95 = timeSeries15.getMinY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61141708800001L) + "'", long47 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61141708800001L) + "'", long81 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(timeSeries94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 32.0d + "'", double95 == 32.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1560185266088L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        try {
            timeSeries3.delete((int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Overwritten values from: 10");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        boolean boolean6 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        int int44 = month40.getMonth();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener20);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries5.getTimePeriod(2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries7.setDomainDescription("");
        timeSeries7.setNotify(true);
        java.lang.Comparable comparable28 = timeSeries7.getKey();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 10L + "'", comparable28.equals(10L));
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        timeSeries9.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener42);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries3.removeChangeListener(seriesChangeListener46);
        try {
            timeSeries3.delete(10, 8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        java.util.Date date4 = year2.getEnd();
        long long5 = year2.getFirstMillisecond();
        int int6 = year2.getYear();
        long long7 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(3, year2);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61157520000000L) + "'", long5 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61157520000000L) + "'", long7 == (-61157520000000L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        timeSeries3.setKey((java.lang.Comparable) year13);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year13.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        int int7 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        int int22 = timeSeries3.getMaximumItemCount();
        timeSeries3.setRangeDescription("Overwritten values from: 10");
        try {
            timeSeries3.delete(10, 6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        long long6 = month5.getLastMillisecond();
        int int7 = month5.getYearValue();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = seriesChangeEvent12.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = seriesChangeEvent12.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = seriesChangeEvent12.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = seriesChangeEvent12.getSummary();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(seriesChangeInfo14);
        org.junit.Assert.assertNull(seriesChangeInfo15);
        org.junit.Assert.assertNull(seriesChangeInfo16);
        org.junit.Assert.assertNull(seriesChangeInfo17);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Date date3 = year1.getEnd();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, "December 32", "org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        timeSeries3.removeAgedItems(true);
        java.util.List list14 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        int int6 = month5.getMonth();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        timeSeriesDataItem4.setValue((java.lang.Number) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getSerialIndex();
        long long5 = month3.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 396L + "'", long4 == 396L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61128576000000L) + "'", long5 == (-61128576000000L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        timeSeries7.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.List list4 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(list4);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = day0.equals(obj4);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNull(class2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        java.lang.Comparable comparable25 = timeSeries23.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries23.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + "Overwritten values from: 10" + "'", comparable25.equals("Overwritten values from: 10"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone17);
        java.util.TimeZone timeZone19 = null;
        try {
            org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.fireSeriesChanged();
//        boolean boolean11 = timeSeries3.isEmpty();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond16.peg(calendar18);
//        int int20 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getMonth();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
//        java.lang.Number number37 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month34);
//        java.util.Collection collection38 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date45 = year44.getEnd();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month46.next();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
//        long long50 = year49.getMiddleMillisecond();
//        java.util.Date date51 = year49.getEnd();
//        int int52 = month46.compareTo((java.lang.Object) year49);
//        int int53 = month46.getMonth();
//        boolean boolean55 = month46.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month46.previous();
//        timeSeries42.add(regularTimePeriod56, (double) 32);
//        timeSeries30.add(regularTimePeriod56, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass62 = timeSeries30.getClass();
//        boolean boolean63 = timeSeries3.equals((java.lang.Object) wildcardClass62);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61141708800001L) + "'", long50 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(class64);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = seriesChangeEvent12.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo16);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = seriesChangeEvent12.getSummary();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(seriesChangeInfo15);
        org.junit.Assert.assertNull(seriesChangeInfo18);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        int int6 = year5.getYear();
//        int int7 = day0.compareTo((java.lang.Object) int6);
//        int int8 = day0.getYear();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        double double58 = timeSeries3.getMaxY();
        double double59 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.0d + "'", double58 == 32.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 32.0d + "'", double59 == 32.0d);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        long long6 = day4.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timeSeries9.setKey((java.lang.Comparable) day10);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) timeSeries9);
//        timeSeries9.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185276949L + "'", long3 == 1560185276949L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries3.removeAgedItems(true);
        timeSeries3.setMaximumItemAge(0L);
        java.lang.Object obj53 = null;
        boolean boolean54 = timeSeries3.equals(obj53);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1);
//        boolean boolean9 = timeSeriesDataItem8.isSelected();
//        timeSeriesDataItem8.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str14 = timePeriodFormatException13.toString();
//        int int15 = timeSeriesDataItem8.compareTo((java.lang.Object) timePeriodFormatException13);
//        java.lang.Object obj16 = timeSeriesDataItem8.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem8.getPeriod();
//        int int18 = day0.compareTo((java.lang.Object) regularTimePeriod17);
//        int int19 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        timeSeries3.setDescription("10-June-2019");
        try {
            java.lang.Number number16 = timeSeries3.getValue(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.List list11 = timeSeries3.getItems();
        double double12 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
        long long8 = year7.getMiddleMillisecond();
        java.util.Date date9 = year7.getEnd();
        int int10 = month4.compareTo((java.lang.Object) year7);
        int int11 = month4.getMonth();
        boolean boolean13 = month4.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month4.previous();
        long long15 = month4.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean20 = month4.equals((java.lang.Object) timeSeries19);
        java.util.Date date21 = month4.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date21, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61141708800001L) + "'", long8 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61128576000000L) + "'", long15 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, number30);
        long long32 = month26.getLastMillisecond();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-58995878400001L) + "'", long32 == (-58995878400001L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = timeSeriesDataItem4.compareTo((java.lang.Object) month8);
        long long12 = month8.getLastMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month8.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        try {
            timeSeries23.update((int) (byte) 10, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getLastMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, number11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str15 = timePeriodFormatException14.toString();
//        java.lang.String str16 = timePeriodFormatException14.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("December 32");
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException21.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
//        boolean boolean29 = timeSeriesDataItem28.isSelected();
//        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str34 = timePeriodFormatException33.toString();
//        int int35 = timeSeriesDataItem28.compareTo((java.lang.Object) timePeriodFormatException33);
//        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str39 = timePeriodFormatException38.toString();
//        java.lang.String str40 = timePeriodFormatException38.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("December 32");
//        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        java.lang.Class<?> wildcardClass47 = timePeriodFormatException45.getClass();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date50 = year49.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (double) (byte) 1);
//        boolean boolean53 = timeSeriesDataItem52.isSelected();
//        timeSeriesDataItem52.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str58 = timePeriodFormatException57.toString();
//        int int59 = timeSeriesDataItem52.compareTo((java.lang.Object) timePeriodFormatException57);
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
//        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
//        int int62 = day6.compareTo((java.lang.Object) timePeriodFormatException57);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str58.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond4.getTime();
        int int8 = fixedMillisecond4.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond4.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date46 = year45.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) 0);
        java.lang.Number number52 = null;
        timeSeriesDataItem51.setValue(number52);
        try {
            timeSeries3.add(timeSeriesDataItem51);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-61125897600001L) + "'", long49 == (-61125897600001L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
        timeSeries6.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        java.util.Date date27 = year25.getEnd();
        int int28 = month22.compareTo((java.lang.Object) year25);
        int int29 = month22.getMonth();
        boolean boolean31 = month22.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month22.previous();
        timeSeries18.add(regularTimePeriod32, (double) 32);
        boolean boolean35 = timeSeries18.getNotify();
        java.lang.Object obj36 = timeSeries18.clone();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries6.addAndOrUpdate(timeSeries18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries6.addChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 12);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year50 = month49.getYear();
        java.lang.Number number51 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month49);
        boolean boolean52 = month2.equals((java.lang.Object) timeSeries6);
        long long53 = timeSeries6.getMaximumItemAge();
        int int54 = timeSeries6.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 9223372036854775807L + "'", long53 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        long long6 = day4.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timeSeries9.setKey((java.lang.Comparable) day10);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) timeSeries9);
//        boolean boolean14 = timeSeries9.getNotify();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185279176L + "'", long3 == 1560185279176L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.next();
        int int40 = timeSeries15.getIndex(regularTimePeriod39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) (-1L));
        java.lang.Number number51 = timeSeries15.getValue(0);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener52);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 32.0d + "'", number51.equals(32.0d));
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.fireSeriesChanged();
//        boolean boolean11 = timeSeries3.isEmpty();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond16.peg(calendar18);
//        int int20 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getMonth();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
//        java.lang.Number number37 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month34);
//        java.util.Collection collection38 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date45 = year44.getEnd();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month46.next();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
//        long long50 = year49.getMiddleMillisecond();
//        java.util.Date date51 = year49.getEnd();
//        int int52 = month46.compareTo((java.lang.Object) year49);
//        int int53 = month46.getMonth();
//        boolean boolean55 = month46.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month46.previous();
//        timeSeries42.add(regularTimePeriod56, (double) 32);
//        timeSeries30.add(regularTimePeriod56, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass62 = timeSeries30.getClass();
//        boolean boolean63 = timeSeries3.equals((java.lang.Object) wildcardClass62);
//        java.beans.PropertyChangeListener propertyChangeListener64 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener64);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61141708800001L) + "'", long50 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        java.lang.String str6 = month3.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 32" + "'", str6.equals("December 32"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) ' ');
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 6);
        int int23 = year19.getYear();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.Calendar calendar25 = null;
        try {
            year19.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61141708800001L) + "'", long20 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timeSeries23.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10);
        timeSeries35.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection47 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries31.addAndOrUpdate(timeSeries35);
        timeSeries35.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries23.addAndOrUpdate(timeSeries35);
        timeSeries23.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries54);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        java.lang.Object obj18 = timeSeriesDataItem16.clone();
        timeSeries3.add(timeSeriesDataItem16);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        long long22 = year21.getMiddleMillisecond();
        java.util.Date date23 = year21.getEnd();
        java.util.Date date24 = year21.getStart();
        boolean boolean25 = timeSeries3.equals((java.lang.Object) year21);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61141708800001L) + "'", long22 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        long long7 = month6.getSerialIndex();
        long long8 = month6.getFirstMillisecond();
        boolean boolean9 = month2.equals((java.lang.Object) long8);
        long long10 = month2.getLastMillisecond();
        org.jfree.data.time.Year year11 = month2.getYear();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 396L + "'", long7 == 396L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61128576000000L) + "'", long8 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58995878400001L) + "'", long10 == (-58995878400001L));
        org.junit.Assert.assertNotNull(year11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        int int7 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) (byte) 0);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond3.getFirstMillisecond(calendar8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61125897600001L) + "'", long9 == (-61125897600001L));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        double double58 = timeSeries3.getMaxY();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date61 = year60.getEnd();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.next();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
        long long66 = year65.getMiddleMillisecond();
        java.util.Date date67 = year65.getEnd();
        int int68 = month62.compareTo((java.lang.Object) year65);
        int int69 = month62.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month62, 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month62.next();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.0d + "'", double58 == 32.0d);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61141708800001L) + "'", long66 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 32 + "'", int69 == 32);
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        int int11 = timeSeriesDataItem4.compareTo((java.lang.Object) timePeriodFormatException9);
        java.lang.Object obj12 = timeSeriesDataItem4.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        boolean boolean19 = timeSeriesDataItem4.equals((java.lang.Object) regularTimePeriod18);
        timeSeriesDataItem4.setSelected(false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("December 32");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getLastMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        fixedMillisecond7.peg(calendar13);
        long long15 = fixedMillisecond7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61125897600001L) + "'", long15 == (-61125897600001L));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getSerialIndex();
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond8);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond8.getFirstMillisecond(calendar14);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61125897600001L) + "'", long10 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61125897600001L) + "'", long15 == (-61125897600001L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        try {
            timeSeries18.delete(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        int int5 = day0.getMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10);
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        timeSeries20.setDomainDescription("");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 6);
        int int29 = year25.getYear();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year25);
        int int31 = month5.compareTo((java.lang.Object) timeSeries20);
        long long32 = timeSeries20.getMaximumItemAge();
        double double33 = timeSeries20.getMaxY();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32 + "'", int29 == 32);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getSerialIndex();
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond1.next();
        long long15 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61125897600001L) + "'", long10 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9999L) + "'", long15 == (-9999L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        int int24 = timeSeries23.getMaximumItemCount();
        java.lang.Comparable comparable25 = null;
        try {
            timeSeries23.setKey(comparable25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        boolean boolean8 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries9.addPropertyChangeListener(propertyChangeListener42);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries3.removeAgedItems(true);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries3.getDataItem(0);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener55);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("100");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        long long47 = year46.getMiddleMillisecond();
        java.util.Date date48 = year46.getEnd();
        int int49 = month43.compareTo((java.lang.Object) year46);
        int int50 = month43.getMonth();
        boolean boolean52 = month43.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month43.previous();
        timeSeries39.add(regularTimePeriod53, (double) 32);
        boolean boolean56 = timeSeries39.getNotify();
        java.lang.Object obj57 = timeSeries39.clone();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 10);
        timeSeries61.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date76 = year75.getEnd();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month77.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) ' ');
        long long81 = year80.getMiddleMillisecond();
        java.util.Date date82 = year80.getEnd();
        int int83 = month77.compareTo((java.lang.Object) year80);
        int int84 = month77.getMonth();
        boolean boolean86 = month77.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month77.previous();
        timeSeries73.add(regularTimePeriod87, (double) 32);
        boolean boolean90 = timeSeries73.getNotify();
        java.lang.Object obj91 = timeSeries73.clone();
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries61.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries39.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries15.addAndOrUpdate(timeSeries73);
        java.util.List list95 = timeSeries94.getItems();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61141708800001L) + "'", long47 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61141708800001L) + "'", long81 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(timeSeries94);
        org.junit.Assert.assertNotNull(list95);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Date date5 = day0.getEnd();
//        long long6 = day0.getLastMillisecond();
//        int int7 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 100);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        java.lang.Number number14 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean15 = month2.equals((java.lang.Object) number14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(6, 100);
        long long19 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        java.lang.Number number30 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        boolean boolean31 = month18.equals((java.lang.Object) number30);
        boolean boolean32 = month2.equals((java.lang.Object) boolean31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1206L + "'", long3 == 1206L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1206L + "'", long19 == 1206L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        long long6 = month3.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        long long14 = year13.getMiddleMillisecond();
        java.util.Date date15 = year13.getEnd();
        int int16 = month10.compareTo((java.lang.Object) year13);
        int int17 = month10.getMonth();
        boolean boolean19 = month10.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month10.previous();
        int int21 = month3.compareTo((java.lang.Object) month10);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month10.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61141708800001L) + "'", long14 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        boolean boolean11 = timeSeries3.isEmpty();
        try {
            timeSeries3.update((int) (byte) 100, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond4.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
        timeSeries6.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        java.util.Date date27 = year25.getEnd();
        int int28 = month22.compareTo((java.lang.Object) year25);
        int int29 = month22.getMonth();
        boolean boolean31 = month22.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month22.previous();
        timeSeries18.add(regularTimePeriod32, (double) 32);
        boolean boolean35 = timeSeries18.getNotify();
        java.lang.Object obj36 = timeSeries18.clone();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries6.addAndOrUpdate(timeSeries18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries6.addChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 12);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year50 = month49.getYear();
        java.lang.Number number51 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month49);
        boolean boolean52 = month2.equals((java.lang.Object) timeSeries6);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date55 = year54.getEnd();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month56.next();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year((int) ' ');
        long long60 = year59.getMiddleMillisecond();
        java.util.Date date61 = year59.getEnd();
        int int62 = month56.compareTo((java.lang.Object) year59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond64.next();
        int int66 = year59.compareTo((java.lang.Object) regularTimePeriod65);
        timeSeries6.delete(regularTimePeriod65);
        timeSeries6.setRangeDescription("");
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61141708800001L) + "'", long60 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) 10.0d);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        double double12 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        int int6 = year5.getYear();
//        int int7 = day0.compareTo((java.lang.Object) int6);
//        int int8 = day0.getYear();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getSerialIndex();
//        int int12 = year10.getYear();
//        int int13 = day0.compareTo((java.lang.Object) int12);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = seriesChangeEvent12.getSummary();
        java.lang.Object obj16 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(seriesChangeInfo15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.next();
        java.lang.String str7 = month3.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 32" + "'", str7.equals("December 32"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        java.lang.Object obj18 = timeSeriesDataItem16.clone();
        timeSeries3.add(timeSeriesDataItem16);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10);
        timeSeries23.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries23);
        java.lang.Object obj33 = seriesChangeEvent32.getSource();
        java.lang.String str34 = seriesChangeEvent32.toString();
        java.lang.Object obj35 = seriesChangeEvent32.getSource();
        int int36 = timeSeriesDataItem16.compareTo(obj35);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day6.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 6);
        int int6 = year2.getYear();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) '#', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        fixedMillisecond16.peg(calendar18);
        int int20 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.lang.Object obj21 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        java.lang.Object obj37 = timeSeries15.clone();
        try {
            java.lang.Number number39 = timeSeries15.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        try {
            timeSeries3.delete(11, 9999, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        long long2 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62072668800001L) + "'", long2 == (-62072668800001L));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("32");
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = day0.compareTo((java.lang.Object) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str9 = timePeriodFormatException8.toString();
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) timePeriodFormatException8);
//        long long12 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185286444L + "'", long2 == 1560185286444L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185286444L + "'", long4 == 1560185286444L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185286444L + "'", long6 == 1560185286444L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185286444L + "'", long12 == 1560185286444L);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.lang.String str19 = timeSeries17.getDescription();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        long long21 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        long long47 = year46.getMiddleMillisecond();
        java.util.Date date48 = year46.getEnd();
        int int49 = month43.compareTo((java.lang.Object) year46);
        int int50 = month43.getMonth();
        boolean boolean52 = month43.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month43.previous();
        timeSeries39.add(regularTimePeriod53, (double) 32);
        boolean boolean56 = timeSeries39.getNotify();
        java.lang.Object obj57 = timeSeries39.clone();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 10);
        timeSeries61.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date76 = year75.getEnd();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month77.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) ' ');
        long long81 = year80.getMiddleMillisecond();
        java.util.Date date82 = year80.getEnd();
        int int83 = month77.compareTo((java.lang.Object) year80);
        int int84 = month77.getMonth();
        boolean boolean86 = month77.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month77.previous();
        timeSeries73.add(regularTimePeriod87, (double) 32);
        boolean boolean90 = timeSeries73.getNotify();
        java.lang.Object obj91 = timeSeries73.clone();
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries61.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries39.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries15.addAndOrUpdate(timeSeries73);
        try {
            timeSeries94.delete(8, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61141708800001L) + "'", long47 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61141708800001L) + "'", long81 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(timeSeries94);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        boolean boolean24 = timeSeries23.getNotify();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date35 = year34.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (byte) 10);
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries28.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(6, 100);
        long long52 = month51.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, (double) (byte) 10);
        java.lang.Number number55 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, number55);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 10.0d, false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1206L + "'", long52 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        long long44 = month40.getFirstMillisecond();
        java.util.Date date45 = month40.getEnd();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61128576000000L) + "'", long44 == (-61128576000000L));
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getLastMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day6.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        int int5 = year1.getYear();
        long long6 = year1.getFirstMillisecond();
        long long7 = year1.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year1.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157520000000L) + "'", long6 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year6.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = regularTimePeriod11.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries3.getNotify();
        long long38 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day2.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener18);
        timeSeries14.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        java.util.Date date19 = year17.getEnd();
        java.lang.Number number20 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeries14.setMaximumItemAge((long) (byte) 100);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(number20);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        int int6 = year5.getYear();
//        int int7 = day0.compareTo((java.lang.Object) int6);
//        int int8 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond14.previous();
        long long21 = fixedMillisecond14.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61125897600001L) + "'", long21 == (-61125897600001L));
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date47 = year46.getEnd();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) (byte) 10);
//        timeSeries44.fireSeriesChanged();
//        boolean boolean52 = timeSeries44.isEmpty();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeries44.getNextTimePeriod();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date56 = year55.getEnd();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date56);
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond58.getMiddleMillisecond(calendar59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond58.previous();
//        timeSeries44.update(regularTimePeriod61, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
//        long long66 = year65.getMiddleMillisecond();
//        java.util.Date date67 = year65.getEnd();
//        long long68 = year65.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries9.createCopy(regularTimePeriod61, (org.jfree.data.time.RegularTimePeriod) year65);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61125897600001L) + "'", long60 == (-61125897600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61141708800001L) + "'", long66 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61157520000000L) + "'", long68 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(timeSeries69);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries3.removeAgedItems(true);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries3.getDataItem(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long57 = fixedMillisecond56.getMiddleMillisecond();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond56);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-9999L) + "'", long57 == (-9999L));
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond0.peg(calendar7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185290132L + "'", long2 == 1560185290132L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185290132L + "'", long4 == 1560185290132L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185290132L + "'", long6 == 1560185290132L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Date date5 = day0.getEnd();
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem4.setSelected(false);
        java.lang.Object obj12 = timeSeriesDataItem4.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        double double58 = timeSeries3.getMaxY();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date61 = year60.getEnd();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.next();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
        long long66 = year65.getMiddleMillisecond();
        java.util.Date date67 = year65.getEnd();
        int int68 = month62.compareTo((java.lang.Object) year65);
        int int69 = month62.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month62, 10.0d);
        long long72 = month62.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.0d + "'", double58 == 32.0d);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61141708800001L) + "'", long66 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 32 + "'", int69 == 32);
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-61128576000000L) + "'", long72 == (-61128576000000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(7, year6);
        long long8 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61141795200000L) + "'", long8 == (-61141795200000L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.next();
        int int40 = timeSeries15.getIndex(regularTimePeriod39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) (-1L));
        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries15.addChangeListener(seriesChangeListener50);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("100");
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        int int24 = timeSeries23.getMaximumItemCount();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond29.getMiddleMillisecond(calendar31);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 1560185238055L, false);
        long long36 = fixedMillisecond29.getLastMillisecond();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61125897600001L) + "'", long32 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61125897600001L) + "'", long36 == (-61125897600001L));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setDomainDescription("");
        long long9 = timeSeries3.getMaximumItemAge();
        long long10 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        java.util.Date date4 = year2.getEnd();
        long long5 = year2.getFirstMillisecond();
        int int6 = year2.getYear();
        long long7 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(3, year2);
        int int9 = month8.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61157520000000L) + "'", long5 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61157520000000L) + "'", long7 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        timeSeries3.setKey((java.lang.Comparable) year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.previous();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        int int3 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries3.removeAgedItems(true);
        java.lang.Object obj51 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(obj51);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
//        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
//        java.lang.String str11 = timeSeries3.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
//        boolean boolean17 = timeSeriesDataItem16.isSelected();
//        java.lang.Object obj18 = timeSeriesDataItem16.clone();
//        timeSeries3.add(timeSeriesDataItem16);
//        timeSeriesDataItem16.setValue((java.lang.Number) Double.NaN);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getMonth();
//        long long24 = day22.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day22, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        timeSeries27.setKey((java.lang.Comparable) day28);
//        java.lang.String str31 = timeSeries27.getDomainDescription();
//        boolean boolean32 = timeSeriesDataItem16.equals((java.lang.Object) str31);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Overwritten values from: 10");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        long long47 = year46.getMiddleMillisecond();
        java.util.Date date48 = year46.getEnd();
        int int49 = month43.compareTo((java.lang.Object) year46);
        int int50 = month43.getMonth();
        boolean boolean52 = month43.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month43.previous();
        timeSeries39.add(regularTimePeriod53, (double) 32);
        boolean boolean56 = timeSeries39.getNotify();
        java.lang.Object obj57 = timeSeries39.clone();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 10);
        timeSeries61.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date76 = year75.getEnd();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month77.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) ' ');
        long long81 = year80.getMiddleMillisecond();
        java.util.Date date82 = year80.getEnd();
        int int83 = month77.compareTo((java.lang.Object) year80);
        int int84 = month77.getMonth();
        boolean boolean86 = month77.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month77.previous();
        timeSeries73.add(regularTimePeriod87, (double) 32);
        boolean boolean90 = timeSeries73.getNotify();
        java.lang.Object obj91 = timeSeries73.clone();
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries61.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries39.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries15.addAndOrUpdate(timeSeries73);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem96 = timeSeries15.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61141708800001L) + "'", long47 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61141708800001L) + "'", long81 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(timeSeries94);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) 5);
        java.lang.String str6 = fixedMillisecond3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 23:59:59 PST 32" + "'", str6.equals("Wed Dec 31 23:59:59 PST 32"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        long long42 = year41.getMiddleMillisecond();
        java.util.Date date43 = year41.getEnd();
        java.util.Date date44 = year41.getStart();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
        java.lang.Number number47 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        long long48 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61141708800001L) + "'", long42 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 32.0d + "'", number47.equals(32.0d));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) ' ');
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 6);
        int int23 = year19.getYear();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year19.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61141708800001L) + "'", long20 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getYear();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getMonth();
//        long long3 = day1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day1, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        long long9 = year8.getMiddleMillisecond();
//        java.util.Date date10 = year8.getEnd();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        long long12 = year11.getSerialIndex();
//        java.lang.Number number13 = null;
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year11, number13, true);
//        try {
//            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(0, year11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61141708800001L) + "'", long9 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        long long10 = month7.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            month7.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61128576000000L) + "'", long10 == (-61128576000000L));
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.util.Collection collection42 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        timeSeries9.setKey((java.lang.Comparable) serialDate44);
//        java.util.List list47 = timeSeries9.getItems();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(list47);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(385L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) false);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
//        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getMonth();
//        long long13 = day11.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day11, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date19 = year18.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (byte) 1);
//        boolean boolean22 = timeSeriesDataItem21.isSelected();
//        timeSeriesDataItem21.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries16.addOrUpdate(timeSeriesDataItem21);
//        timeSeries16.fireSeriesChanged();
//        boolean boolean27 = month7.equals((java.lang.Object) timeSeries16);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "", "December 32");
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        timeSeries15.setMaximumItemAge(1560185243804L);
        timeSeries15.setDescription("June 2019");
        int int40 = timeSeries15.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2147483647 + "'", int40 == 2147483647);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        long long11 = month3.getFirstMillisecond();
        int int12 = month3.getMonth();
        long long13 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61128576000000L) + "'", long11 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61125897600001L) + "'", long13 == (-61125897600001L));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        long long47 = year46.getMiddleMillisecond();
        java.util.Date date48 = year46.getEnd();
        int int49 = month43.compareTo((java.lang.Object) year46);
        int int50 = month43.getMonth();
        boolean boolean52 = month43.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month43.previous();
        timeSeries39.add(regularTimePeriod53, (double) 32);
        boolean boolean56 = timeSeries39.getNotify();
        java.lang.Object obj57 = timeSeries39.clone();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 10);
        timeSeries61.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date76 = year75.getEnd();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month77.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) ' ');
        long long81 = year80.getMiddleMillisecond();
        java.util.Date date82 = year80.getEnd();
        int int83 = month77.compareTo((java.lang.Object) year80);
        int int84 = month77.getMonth();
        boolean boolean86 = month77.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month77.previous();
        timeSeries73.add(regularTimePeriod87, (double) 32);
        boolean boolean90 = timeSeries73.getNotify();
        java.lang.Object obj91 = timeSeries73.clone();
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries61.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries39.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries15.addAndOrUpdate(timeSeries73);
        timeSeries15.setMaximumItemAge(1560185286621L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61141708800001L) + "'", long47 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61141708800001L) + "'", long81 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(timeSeries94);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener20);
//        try {
//            timeSeries5.delete(9, (int) (short) 100, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        int int24 = timeSeries23.getMaximumItemCount();
        try {
            timeSeries23.update(100, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        double double25 = timeSeries23.getMinY();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date52 = year51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (byte) 10);
        timeSeries49.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) ' ');
        long long69 = year68.getMiddleMillisecond();
        java.util.Date date70 = year68.getEnd();
        int int71 = month65.compareTo((java.lang.Object) year68);
        int int72 = month65.getMonth();
        boolean boolean74 = month65.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month65.previous();
        timeSeries61.add(regularTimePeriod75, (double) 32);
        boolean boolean78 = timeSeries61.getNotify();
        java.lang.Object obj79 = timeSeries61.clone();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries49.addAndOrUpdate(timeSeries61);
        double double81 = timeSeries61.getMinY();
        timeSeries61.setMaximumItemAge(1560185243804L);
        timeSeries61.setDescription("June 2019");
        java.util.Collection collection86 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries61);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61125897600001L) + "'", long43 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61141708800001L) + "'", long69 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 32.0d + "'", double81 == 32.0d);
        org.junit.Assert.assertNotNull(collection86);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo15);
        java.lang.String str17 = seriesChangeEvent12.toString();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        int int41 = timeSeries9.getItemCount();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getLastMillisecond();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
        long long24 = year23.getMiddleMillisecond();
        java.util.Date date25 = year23.getEnd();
        int int26 = month20.compareTo((java.lang.Object) year23);
        int int27 = month20.getMonth();
        boolean boolean29 = month20.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month20.previous();
        int int31 = month13.compareTo((java.lang.Object) month20);
        timeSeries3.setKey((java.lang.Comparable) month13);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61125897600001L) + "'", long16 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61141708800001L) + "'", long24 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        int int17 = timeSeriesDataItem10.compareTo((java.lang.Object) month14);
        long long18 = month14.getLastMillisecond();
        boolean boolean19 = year4.equals((java.lang.Object) month14);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = month14.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61125897600001L) + "'", long18 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getRangeDescription();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond14.getFirstMillisecond(calendar18);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond14.getMiddleMillisecond(calendar22);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61125897600001L) + "'", long23 == (-61125897600001L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str10 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        java.lang.String str14 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timeSeries23.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10);
        timeSeries35.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection47 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries31.addAndOrUpdate(timeSeries35);
        timeSeries35.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries23.addAndOrUpdate(timeSeries35);
        java.lang.Class class55 = timeSeries23.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNull(class55);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener31);
        double double33 = timeSeries7.getMinY();
        try {
            org.jfree.data.time.TimeSeries timeSeries36 = timeSeries7.createCopy((int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (byte) 0);
        java.lang.Number number27 = null;
        timeSeriesDataItem26.setValue(number27);
        timeSeries14.add(timeSeriesDataItem26, true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61125897600001L) + "'", long24 == (-61125897600001L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        boolean boolean6 = timeSeriesDataItem4.isSelected();
        boolean boolean7 = timeSeriesDataItem4.isSelected();
        boolean boolean8 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6 + "'", number5.equals(6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        try {
            timeSeries3.delete(1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185297894L + "'", long2 == 1560185297894L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185297894L + "'", long4 == 1560185297894L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185297894L + "'", long6 == 1560185297894L);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) 10);
        timeSeries38.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection50 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries34.addAndOrUpdate(timeSeries49);
        timeSeries52.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(timeSeries52);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond14.previous();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setDomainDescription("");
        try {
            java.lang.Number number10 = timeSeries3.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        boolean boolean36 = timeSeriesDataItem28.isSelected();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.next();
        boolean boolean4 = year0.equals((java.lang.Object) fixedMillisecond2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries3.getNotify();
        java.lang.String str38 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.next();
        int int40 = timeSeries15.getIndex(regularTimePeriod39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) (-1L));
        java.lang.Number number51 = timeSeries15.getValue(0);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date54 = year53.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, (double) (byte) 1);
        long long57 = year53.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year53.previous();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-61127236800001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 32.0d + "'", number51.equals(32.0d));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61125897600001L) + "'", long57 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries3.removeChangeListener(seriesChangeListener46);
        boolean boolean48 = timeSeries3.isEmpty();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone17);
        java.util.TimeZone timeZone19 = null;
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date14, timeZone19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        timeSeries3.setKey((java.lang.Comparable) year13);
        java.lang.String str16 = year13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        int int3 = day2.getYear();
//        long long4 = day2.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        long long11 = month3.getFirstMillisecond();
        long long12 = month3.getLastMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            month3.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61128576000000L) + "'", long11 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = day0.compareTo((java.lang.Object) year7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) 1L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.fireSeriesChanged();
//        boolean boolean11 = timeSeries3.isEmpty();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond16.peg(calendar18);
//        int int20 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getMonth();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date33 = year32.getEnd();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
//        java.lang.Number number37 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month34);
//        java.util.Collection collection38 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date45 = year44.getEnd();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month46.next();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
//        long long50 = year49.getMiddleMillisecond();
//        java.util.Date date51 = year49.getEnd();
//        int int52 = month46.compareTo((java.lang.Object) year49);
//        int int53 = month46.getMonth();
//        boolean boolean55 = month46.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month46.previous();
//        timeSeries42.add(regularTimePeriod56, (double) 32);
//        timeSeries30.add(regularTimePeriod56, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass62 = timeSeries30.getClass();
//        boolean boolean63 = timeSeries3.equals((java.lang.Object) wildcardClass62);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
//        long long66 = year65.getSerialIndex();
//        int int67 = year65.getYear();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = null;
//        try {
//            timeSeries3.add(regularTimePeriod70, (double) 100, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61141708800001L) + "'", long50 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 32L + "'", long66 == 32L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 32 + "'", int67 == 32);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = day0.compareTo((java.lang.Object) year7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year12 = month11.getYear();
        int int13 = year7.compareTo((java.lang.Object) year12);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-68) + "'", int13 == (-68));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5);
        try {
            timeSeries6.delete((-9999), 32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        java.lang.Object obj6 = null;
        int int7 = timeSeriesDataItem4.compareTo(obj6);
        boolean boolean8 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6 + "'", number5.equals(6));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        timeSeries9.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries9.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1);
//        boolean boolean11 = timeSeriesDataItem10.isSelected();
//        timeSeriesDataItem10.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
//        long long18 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date21 = year20.getEnd();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        int int29 = month22.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) month22);
//        java.util.Calendar calendar31 = null;
//        try {
//            month22.peg(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9999L) + "'", long18 == (-9999L));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        java.util.List list18 = timeSeries14.getItems();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (byte) 1);
        int int25 = timeSeriesDataItem23.compareTo((java.lang.Object) (-61157520000000L));
        java.lang.Number number26 = timeSeriesDataItem23.getValue();
        timeSeries14.setKey((java.lang.Comparable) timeSeriesDataItem23);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) ' ');
        long long30 = year29.getMiddleMillisecond();
        java.util.Date date31 = year29.getEnd();
        java.util.Date date32 = year29.getStart();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) 10);
        timeSeries38.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries38.getNextTimePeriod();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.next();
        timeSeries38.setKey((java.lang.Comparable) year48);
        java.lang.String str51 = year48.toString();
        long long52 = year48.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) year48);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date56 = year55.getEnd();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) ' ');
        long long61 = year60.getMiddleMillisecond();
        java.util.Date date62 = year60.getEnd();
        int int63 = month57.compareTo((java.lang.Object) year60);
        int int64 = month57.getMonth();
        long long65 = month57.getFirstMillisecond();
        int int66 = month57.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1.0d);
        timeSeries53.add(timeSeriesDataItem68);
        double double70 = timeSeries53.getMinY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.0d + "'", number26.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61141708800001L) + "'", long30 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "32" + "'", str51.equals("32"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61125897600001L) + "'", long52 == (-61125897600001L));
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-61141708800001L) + "'", long61 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 12 + "'", int64 == 12);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-61128576000000L) + "'", long65 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        double double58 = timeSeries3.getMaxY();
        timeSeries3.setDescription("Value");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.0d + "'", double58 == 32.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        long long11 = month3.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month3.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 396L + "'", long11 == 396L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        long long5 = year1.getLastMillisecond();
        long long6 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157520000000L) + "'", long6 == (-61157520000000L));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        long long6 = month3.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        long long14 = year13.getMiddleMillisecond();
        java.util.Date date15 = year13.getEnd();
        int int16 = month10.compareTo((java.lang.Object) year13);
        int int17 = month10.getMonth();
        boolean boolean19 = month10.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month10.previous();
        int int21 = month3.compareTo((java.lang.Object) month10);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month3.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61141708800001L) + "'", long14 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
//        java.lang.String str24 = timeSeries23.getDescription();
//        timeSeries23.removeAgedItems((long) (short) 0, false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getMonth();
//        java.lang.String str30 = day28.toString();
//        long long31 = day28.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.next();
//        int int33 = day28.getYear();
//        long long34 = day28.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 2147483647);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43626L + "'", long34 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
        long long24 = year23.getMiddleMillisecond();
        java.util.Date date25 = year23.getEnd();
        long long26 = year23.getFirstMillisecond();
        long long27 = year23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        java.lang.Number number29 = timeSeries3.getValue(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61141708800001L) + "'", long24 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61157520000000L) + "'", long26 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61125897600001L) + "'", long27 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 32.0d + "'", number29.equals(32.0d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        fixedMillisecond16.peg(calendar18);
        int int20 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        int int21 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(7, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.next();
        int int40 = timeSeries15.getIndex(regularTimePeriod39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
        long long8 = year7.getMiddleMillisecond();
        java.util.Date date9 = year7.getEnd();
        int int10 = month4.compareTo((java.lang.Object) year7);
        int int11 = month4.getMonth();
        boolean boolean13 = month4.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month4.previous();
        long long15 = month4.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean20 = month4.equals((java.lang.Object) timeSeries19);
        java.util.Date date21 = month4.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date21, timeZone22);
        try {
            org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61141708800001L) + "'", long8 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61128576000000L) + "'", long15 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) ' ');
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 6);
        int int23 = year19.getYear();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.List list25 = timeSeries14.getItems();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener26);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61141708800001L) + "'", long20 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
        org.junit.Assert.assertNotNull(list25);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("December 32");
//        int int5 = day0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(throwableArray6);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.next();
        java.util.Calendar calendar8 = null;
        fixedMillisecond6.peg(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.removeAgedItems((long) (short) 10, false);
        double double19 = timeSeries14.getMinY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries3.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries3.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Overwritten values from: 10");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray10 = seriesException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, 0.0d);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        long long5 = year1.getMiddleMillisecond();
        int int7 = year1.compareTo((java.lang.Object) 385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61141708800001L) + "'", long5 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        long long6 = month3.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        long long14 = year13.getMiddleMillisecond();
        java.util.Date date15 = year13.getEnd();
        int int16 = month10.compareTo((java.lang.Object) year13);
        int int17 = month10.getMonth();
        boolean boolean19 = month10.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month10.previous();
        int int21 = month3.compareTo((java.lang.Object) month10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month3.next();
        org.jfree.data.time.Year year24 = month3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61141708800001L) + "'", long14 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        java.util.List list18 = timeSeries5.getItems();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(list18);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        int int5 = year1.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) 10);
        timeSeries38.fireSeriesChanged();
        boolean boolean46 = timeSeries38.isEmpty();
        int int47 = timeSeries38.getMaximumItemCount();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
        long long50 = year49.getMiddleMillisecond();
        java.util.Date date51 = year49.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year49.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year49);
        timeSeriesDataItem53.setSelected(true);
        java.lang.Object obj56 = timeSeriesDataItem53.clone();
        timeSeries34.add(timeSeriesDataItem53, true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61141708800001L) + "'", long50 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(obj56);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        long long47 = year46.getMiddleMillisecond();
        java.util.Date date48 = year46.getEnd();
        int int49 = month43.compareTo((java.lang.Object) year46);
        int int50 = month43.getMonth();
        boolean boolean52 = month43.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month43.previous();
        timeSeries39.add(regularTimePeriod53, (double) 32);
        boolean boolean56 = timeSeries39.getNotify();
        java.lang.Object obj57 = timeSeries39.clone();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) (byte) 10);
        timeSeries61.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date76 = year75.getEnd();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month77.next();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) ' ');
        long long81 = year80.getMiddleMillisecond();
        java.util.Date date82 = year80.getEnd();
        int int83 = month77.compareTo((java.lang.Object) year80);
        int int84 = month77.getMonth();
        boolean boolean86 = month77.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month77.previous();
        timeSeries73.add(regularTimePeriod87, (double) 32);
        boolean boolean90 = timeSeries73.getNotify();
        java.lang.Object obj91 = timeSeries73.clone();
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries61.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries39.addAndOrUpdate(timeSeries73);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries15.addAndOrUpdate(timeSeries73);
        double double95 = timeSeries73.getMaxY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61141708800001L) + "'", long47 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61141708800001L) + "'", long81 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(timeSeries94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 32.0d + "'", double95 == 32.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        java.util.List list18 = timeSeries14.getItems();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (byte) 1);
        int int25 = timeSeriesDataItem23.compareTo((java.lang.Object) (-61157520000000L));
        java.lang.Number number26 = timeSeriesDataItem23.getValue();
        timeSeries14.setKey((java.lang.Comparable) timeSeriesDataItem23);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) ' ');
        long long30 = year29.getMiddleMillisecond();
        java.util.Date date31 = year29.getEnd();
        java.util.Date date32 = year29.getStart();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) 10);
        timeSeries38.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries38.getNextTimePeriod();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.next();
        timeSeries38.setKey((java.lang.Comparable) year48);
        java.lang.String str51 = year48.toString();
        long long52 = year48.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) year48);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries14.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.0d + "'", number26.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61141708800001L) + "'", long30 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "32" + "'", str51.equals("32"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61125897600001L) + "'", long52 == (-61125897600001L));
        org.junit.Assert.assertNotNull(timeSeries53);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.lang.String str19 = timeSeries17.getDescription();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day0.next();
//        java.lang.String str22 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        long long9 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(5);
        int int13 = year8.compareTo((java.lang.Object) year12);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        org.jfree.data.time.Year year11 = month3.getYear();
        long long12 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 396L + "'", long12 == 396L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
        int int38 = day36.getMonth();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 385L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond14.getLastMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond14.getMiddleMillisecond(calendar22);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number24);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61125897600001L) + "'", long21 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61125897600001L) + "'", long23 == (-61125897600001L));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date52 = year51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (byte) 10);
        timeSeries49.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) ' ');
        long long69 = year68.getMiddleMillisecond();
        java.util.Date date70 = year68.getEnd();
        int int71 = month65.compareTo((java.lang.Object) year68);
        int int72 = month65.getMonth();
        boolean boolean74 = month65.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month65.previous();
        timeSeries61.add(regularTimePeriod75, (double) 32);
        boolean boolean78 = timeSeries61.getNotify();
        java.lang.Object obj79 = timeSeries61.clone();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries49.addAndOrUpdate(timeSeries61);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries49.addChangeListener(seriesChangeListener81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date85 = year84.getEnd();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month86.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month86, (java.lang.Number) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        org.jfree.data.time.Year year91 = month86.getYear();
        int int92 = month86.getYearValue();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61141708800001L) + "'", long69 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertNotNull(year91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 32 + "'", int92 == 32);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1);
//        boolean boolean11 = timeSeriesDataItem10.isSelected();
//        timeSeriesDataItem10.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
//        long long18 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date21 = year20.getEnd();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        int int29 = month22.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) month22);
//        int int31 = month22.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        long long34 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getFirstMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond32.getLastMillisecond(calendar37);
//        boolean boolean39 = month22.equals((java.lang.Object) calendar37);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9999L) + "'", long18 == (-9999L));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 32 + "'", int31 == 32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560185306149L + "'", long34 == 1560185306149L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560185306149L + "'", long36 == 1560185306149L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560185306149L + "'", long38 == 1560185306149L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        timeSeries3.setMaximumItemAge((long) ' ');
        try {
            java.lang.Number number52 = timeSeries3.getValue(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 0);
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
//        java.lang.Number number28 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month25);
//        java.lang.String str29 = timeSeries21.getRangeDescription();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 1);
//        boolean boolean35 = timeSeriesDataItem34.isSelected();
//        java.lang.Object obj36 = timeSeriesDataItem34.clone();
//        timeSeries21.add(timeSeriesDataItem34);
//        timeSeries21.removeAgedItems(true);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        int int41 = timeSeries21.getMaximumItemCount();
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2147483647 + "'", int41 == 2147483647);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(385L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 385L + "'", long3 == 385L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 385L + "'", long4 == 385L);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        long long6 = day4.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timeSeries9.setKey((java.lang.Comparable) day10);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) timeSeries9);
//        long long14 = fixedMillisecond0.getSerialIndex();
//        long long15 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185306599L + "'", long3 == 1560185306599L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185306599L + "'", long14 == 1560185306599L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185306599L + "'", long15 == 1560185306599L);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        try {
//            timeSeries5.update((-1), (java.lang.Number) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo15);
        java.lang.Object obj17 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        int int3 = day0.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        long long20 = month3.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month3.previous();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, "org.jfree.data.time.TimePeriodFormatException: ", "32");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61127236800001L) + "'", long20 == (-61127236800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        boolean boolean20 = timeSeries18.isEmpty();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (byte) 1);
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) (-61157520000000L));
        java.lang.Number number28 = timeSeriesDataItem25.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries18.addOrUpdate(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10);
//        timeSeries23.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection35 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        timeSeries34.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries34.removePropertyChangeListener(propertyChangeListener38);
//        java.util.Collection collection40 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        timeSeries5.setDomainDescription("");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertNotNull(collection40);
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) (-68));
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 32");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 1560185269767L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (double) (byte) 1);
        boolean boolean40 = timeSeriesDataItem39.isSelected();
        timeSeriesDataItem39.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem39.setValue((java.lang.Number) (byte) 10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries3.addOrUpdate(timeSeriesDataItem39);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        java.util.Calendar calendar6 = null;
//        try {
//            day5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
        long long31 = year30.getMiddleMillisecond();
        java.util.Date date32 = year30.getEnd();
        int int33 = month27.compareTo((java.lang.Object) year30);
        int int34 = month27.getMonth();
        boolean boolean36 = month27.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month27.previous();
        long long38 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean43 = month27.equals((java.lang.Object) timeSeries42);
        boolean boolean44 = timeSeries42.isEmpty();
        boolean boolean45 = timeSeries7.equals((java.lang.Object) timeSeries42);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61141708800001L) + "'", long31 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61128576000000L) + "'", long38 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries23.setDescription("Value");
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.next();
        int int40 = timeSeries15.getIndex(regularTimePeriod39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) (-1L));
        java.lang.Number number51 = timeSeries15.getValue(0);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date54 = year53.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month55.next();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year((int) ' ');
        long long59 = year58.getMiddleMillisecond();
        java.util.Date date60 = year58.getEnd();
        int int61 = month55.compareTo((java.lang.Object) year58);
        int int62 = month55.getMonth();
        long long63 = month55.getFirstMillisecond();
        long long64 = month55.getLastMillisecond();
        timeSeries15.setKey((java.lang.Comparable) long64);
        java.util.List list66 = timeSeries15.getItems();
        int int67 = timeSeries15.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 32.0d + "'", number51.equals(32.0d));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-61141708800001L) + "'", long59 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61128576000000L) + "'", long63 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61125897600001L) + "'", long64 == (-61125897600001L));
        org.junit.Assert.assertNotNull(list66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2147483647 + "'", int67 == 2147483647);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        long long4 = year2.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(2147483647, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        java.lang.String str14 = month3.toString();
        long long15 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "December 32" + "'", str14.equals("December 32"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 396L + "'", long15 == 396L);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185309076L + "'", long5 == 1560185309076L);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date47 = year46.getEnd();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) (byte) 10);
//        timeSeries44.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date59 = year58.getEnd();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
//        long long64 = year63.getMiddleMillisecond();
//        java.util.Date date65 = year63.getEnd();
//        int int66 = month60.compareTo((java.lang.Object) year63);
//        int int67 = month60.getMonth();
//        boolean boolean69 = month60.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month60.previous();
//        timeSeries56.add(regularTimePeriod70, (double) 32);
//        boolean boolean73 = timeSeries56.getNotify();
//        java.lang.Object obj74 = timeSeries56.clone();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries44.addAndOrUpdate(timeSeries56);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener76 = null;
//        timeSeries44.addChangeListener(seriesChangeListener76);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date80 = year79.getEnd();
//        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(date80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = month81.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month81, (java.lang.Number) 12);
//        timeSeries44.setDescription("");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener87 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener87);
//        boolean boolean89 = timeSeries9.equals((java.lang.Object) timeSeries44);
//        java.lang.Class class90 = timeSeries9.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61141708800001L) + "'", long64 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 12 + "'", int67 == 12);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//        org.junit.Assert.assertNotNull(obj74);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem84);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(class90);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        int int5 = year1.getYear();
        long long6 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        int int6 = year5.getYear();
//        int int7 = day0.compareTo((java.lang.Object) int6);
//        int int8 = day0.getYear();
//        int int9 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185310999L + "'", long4 == 1560185310999L);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        java.util.Date date20 = month3.getEnd();
        java.lang.String str21 = month3.toString();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month3.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "December 32" + "'", str21.equals("December 32"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        double double21 = timeSeries3.getMaxY();
        double double22 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year28 = month27.getYear();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        java.util.Calendar calendar31 = null;
        try {
            year28.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 32.0d + "'", double22 == 32.0d);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        timeSeries15.setDomainDescription("");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }
}

