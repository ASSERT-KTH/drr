import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.util.Collection collection42 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        timeSeries9.setKey((java.lang.Comparable) serialDate44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
//        java.util.Date date48 = day47.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48);
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries49.removePropertyChangeListener(propertyChangeListener50);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(date48);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        boolean boolean11 = timeSeries3.isEmpty();
        java.lang.Class class12 = timeSeries3.getTimePeriodClass();
        timeSeries3.setMaximumItemCount((int) '#');
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        long long22 = year21.getMiddleMillisecond();
        java.util.Date date23 = year21.getEnd();
        int int24 = month18.compareTo((java.lang.Object) year21);
        int int25 = month18.getMonth();
        long long26 = month18.getSerialIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
        long long29 = year28.getMiddleMillisecond();
        java.util.Date date30 = year28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) month32);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61141708800001L) + "'", long22 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 396L + "'", long26 == 396L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        int int11 = timeSeriesDataItem4.compareTo((java.lang.Object) timePeriodFormatException9);
        java.lang.Object obj12 = timeSeriesDataItem4.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10);
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        java.lang.String str29 = timeSeries27.getDescription();
        java.lang.String str30 = timeSeries27.getDomainDescription();
        boolean boolean31 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries27);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getYear();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) 1);
//        boolean boolean12 = timeSeriesDataItem11.isSelected();
//        java.lang.Object obj13 = timeSeriesDataItem11.clone();
//        boolean boolean14 = day0.equals(obj13);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (-68));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (byte) 1);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        timeSeriesDataItem6.setValue((java.lang.Number) (byte) 100);
        java.lang.Object obj10 = null;
        boolean boolean11 = timeSeriesDataItem6.equals(obj10);
        int int12 = year1.compareTo(obj10);
        java.lang.String str13 = year1.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        double double21 = timeSeries3.getMaxY();
        double double22 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year28 = month27.getYear();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        java.lang.Number number31 = timeSeriesDataItem30.getValue();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem30, seriesChangeInfo32);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 32.0d + "'", double22 == 32.0d);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 32.0d + "'", number31.equals(32.0d));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getYear();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10);
//        timeSeries23.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection35 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        timeSeries34.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries34.removePropertyChangeListener(propertyChangeListener38);
//        java.util.Collection collection40 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        java.lang.Class class41 = timeSeries5.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(class41);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        int int6 = month5.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32" + "'", str4.equals("32"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond17.previous();
        timeSeries3.update(regularTimePeriod20, (java.lang.Number) 100.0f);
        java.util.Date date23 = regularTimePeriod20.getEnd();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date23);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.util.Collection collection42 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        timeSeries9.setKey((java.lang.Comparable) serialDate44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
//        java.util.Date date48 = day47.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48);
//        java.lang.String str50 = timeSeries49.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = seriesChangeEvent13.getSummary();
        java.lang.String str15 = seriesChangeEvent13.toString();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(seriesChangeInfo14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str15.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean4 = timeSeries3.isEmpty();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date4 = year3.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (byte) 1);
//        boolean boolean7 = timeSeriesDataItem6.isSelected();
//        timeSeriesDataItem6.setValue((java.lang.Number) (byte) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = timeSeriesDataItem6.equals(obj10);
//        int int12 = year1.compareTo(obj10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        long long15 = day13.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        timeSeries18.setKey((java.lang.Comparable) day19);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        long long24 = year23.getMiddleMillisecond();
//        java.util.Date date25 = year23.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        int int29 = year23.compareTo((java.lang.Object) regularTimePeriod28);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year23, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener33);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date37 = year36.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (double) (byte) 1);
//        boolean boolean40 = timeSeriesDataItem39.isSelected();
//        timeSeriesDataItem39.setValue((java.lang.Number) (byte) 100);
//        timeSeriesDataItem39.setValue((java.lang.Number) (byte) 10);
//        timeSeriesDataItem39.setSelected(false);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date49 = year48.getEnd();
//        java.util.Date date50 = year48.getEnd();
//        int int51 = timeSeriesDataItem39.compareTo((java.lang.Object) year48);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries18.addOrUpdate(timeSeriesDataItem39);
//        int int53 = year1.compareTo((java.lang.Object) timeSeries18);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61141708800001L) + "'", long24 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1);
//        boolean boolean27 = timeSeriesDataItem26.isSelected();
//        timeSeriesDataItem26.setValue((java.lang.Number) (byte) 100);
//        timeSeriesDataItem26.setValue((java.lang.Number) (byte) 10);
//        timeSeriesDataItem26.setSelected(false);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date36 = year35.getEnd();
//        java.util.Date date37 = year35.getEnd();
//        int int38 = timeSeriesDataItem26.compareTo((java.lang.Object) year35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries5.addOrUpdate(timeSeriesDataItem26);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener40);
//        java.util.Collection collection42 = timeSeries5.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNotNull(collection42);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        timeSeries3.removeAgedItems(true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1);
//        boolean boolean11 = timeSeriesDataItem10.isSelected();
//        timeSeriesDataItem10.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
//        long long18 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date21 = year20.getEnd();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        int int29 = month22.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) month22);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date38 = year37.getEnd();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10);
//        timeSeries35.fireSeriesChanged();
//        boolean boolean43 = timeSeries35.isEmpty();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date46 = year45.getEnd();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.previous();
//        java.util.Calendar calendar50 = null;
//        fixedMillisecond48.peg(calendar50);
//        int int52 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        try {
//            timeSeries30.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 6, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9999L) + "'", long18 == (-9999L));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond7, seriesChangeInfo11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 0);
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
//        java.lang.Number number28 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month25);
//        java.lang.String str29 = timeSeries21.getRangeDescription();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 1);
//        boolean boolean35 = timeSeriesDataItem34.isSelected();
//        java.lang.Object obj36 = timeSeriesDataItem34.clone();
//        timeSeries21.add(timeSeriesDataItem34);
//        timeSeries21.removeAgedItems(true);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries21);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(collection40);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getSerialIndex();
        long long5 = month3.getFirstMillisecond();
        long long6 = month3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 396L + "'", long4 == 396L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61128576000000L) + "'", long5 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61127236800001L) + "'", long6 == (-61127236800001L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(27);
        java.util.Date date2 = year1.getStart();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        int int30 = month26.getMonth();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        java.util.Date date20 = month3.getEnd();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1);
        boolean boolean27 = timeSeriesDataItem26.isSelected();
        timeSeriesDataItem26.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem26.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem26.setSelected(false);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date36 = year35.getEnd();
        java.util.Date date37 = year35.getEnd();
        int int38 = timeSeriesDataItem26.compareTo((java.lang.Object) year35);
        timeSeries21.add(timeSeriesDataItem26);
        timeSeries21.setMaximumItemAge((long) 10);
        timeSeries21.setMaximumItemCount((int) 'a');
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        timeSeriesDataItem28.setValue((java.lang.Number) (-1L));
        boolean boolean38 = timeSeriesDataItem28.isSelected();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo15);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = seriesChangeEvent12.getSummary();
        java.lang.Object obj18 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(seriesChangeInfo17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getMiddleMillisecond();
        java.util.Date date4 = year2.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61141708800001L) + "'", long3 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        timeSeries3.setRangeDescription("32");
        int int39 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getLastMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, number11);
//        java.lang.String str13 = day6.toString();
//        java.lang.String str14 = day6.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        double double24 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10);
        timeSeries28.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) ' ');
        long long48 = year47.getMiddleMillisecond();
        java.util.Date date49 = year47.getEnd();
        int int50 = month44.compareTo((java.lang.Object) year47);
        int int51 = month44.getMonth();
        boolean boolean53 = month44.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month44.previous();
        timeSeries40.add(regularTimePeriod54, (double) 32);
        boolean boolean57 = timeSeries40.getNotify();
        java.lang.Object obj58 = timeSeries40.clone();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries28.addAndOrUpdate(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries28.addChangeListener(seriesChangeListener60);
        boolean boolean62 = timeSeries28.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timeSeries28.removePropertyChangeListener(propertyChangeListener63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year((int) ' ');
        long long67 = year66.getMiddleMillisecond();
        java.util.Date date68 = year66.getEnd();
        java.util.Date date69 = year66.getStart();
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond(date69);
        java.lang.Number number72 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71);
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries7.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) ' ');
        long long76 = year75.getSerialIndex();
        java.util.Date date77 = year75.getStart();
        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year75, (java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61141708800001L) + "'", long48 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 12 + "'", int51 == 12);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-61141708800001L) + "'", long67 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 32.0d + "'", number72.equals(32.0d));
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 32L + "'", long76 == 32L);
        org.junit.Assert.assertNotNull(date77);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 0);
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
//        java.lang.Number number28 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month25);
//        java.lang.String str29 = timeSeries21.getRangeDescription();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 1);
//        boolean boolean35 = timeSeriesDataItem34.isSelected();
//        java.lang.Object obj36 = timeSeriesDataItem34.clone();
//        timeSeries21.add(timeSeriesDataItem34);
//        timeSeries21.removeAgedItems(true);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond42.next();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond42.getFirstMillisecond(calendar44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getMonth();
//        long long48 = day46.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day46, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate53 = day52.getSerialDate();
//        timeSeries51.setKey((java.lang.Comparable) day52);
//        boolean boolean55 = fixedMillisecond42.equals((java.lang.Object) timeSeries51);
//        long long56 = fixedMillisecond42.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 6);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries3.getDataItem((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560185316350L + "'", long45 == 1560185316350L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560185316350L + "'", long56 == 1560185316350L);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timeSeries23.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10);
        timeSeries35.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection47 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) ' ');
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries31.addAndOrUpdate(timeSeries35);
        timeSeries35.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries23.addAndOrUpdate(timeSeries35);
        boolean boolean56 = timeSeries54.equals((java.lang.Object) (-61141708800001L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        long long30 = month27.getLastMillisecond();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        long long38 = year37.getMiddleMillisecond();
        java.util.Date date39 = year37.getEnd();
        int int40 = month34.compareTo((java.lang.Object) year37);
        int int41 = month34.getMonth();
        boolean boolean43 = month34.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month34.previous();
        int int45 = month27.compareTo((java.lang.Object) month34);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month34, (double) 11, true);
        timeSeries3.removeAgedItems((-62072668800001L), true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61125897600001L) + "'", long30 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61141708800001L) + "'", long38 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (byte) 10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        long long4 = year1.getFirstMillisecond();
        int int5 = year1.getYear();
        long long6 = year1.getFirstMillisecond();
        long long7 = year1.getSerialIndex();
        long long8 = year1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157520000000L) + "'", long6 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61141708800001L) + "'", long8 == (-61141708800001L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Overwritten values from: 10");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.String str10 = seriesException8.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: Overwritten values from: 10" + "'", str10.equals("org.jfree.data.general.SeriesException: Overwritten values from: 10"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        timeSeries14.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries14.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1);
        boolean boolean27 = timeSeriesDataItem26.isSelected();
        timeSeriesDataItem26.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem26.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem26.setSelected(false);
        timeSeries14.add(timeSeriesDataItem26, true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond7, seriesChangeInfo11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = seriesChangeEvent12.getSummary();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(seriesChangeInfo13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 23:59:59 PST 32]" + "'", str14.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 23:59:59 PST 32]"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) (byte) -1);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1);
//        boolean boolean9 = timeSeriesDataItem8.isSelected();
//        timeSeriesDataItem8.setValue((java.lang.Number) (byte) 100);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str14 = timePeriodFormatException13.toString();
//        int int15 = timeSeriesDataItem8.compareTo((java.lang.Object) timePeriodFormatException13);
//        java.lang.Object obj16 = timeSeriesDataItem8.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem8.getPeriod();
//        int int18 = day0.compareTo((java.lang.Object) regularTimePeriod17);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day0.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        int int24 = timeSeries7.getItemCount();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("32");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setDescription("Overwritten values from: 10");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.lang.String str24 = timeSeries23.getDescription();
        java.lang.Comparable comparable25 = timeSeries23.getKey();
        timeSeries23.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + "Overwritten values from: 10" + "'", comparable25.equals("Overwritten values from: 10"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        double double58 = timeSeries3.getMaxY();
        timeSeries3.update(0, (java.lang.Number) 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.0d + "'", double58 == 32.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date52 = year51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (byte) 10);
        timeSeries49.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) ' ');
        long long69 = year68.getMiddleMillisecond();
        java.util.Date date70 = year68.getEnd();
        int int71 = month65.compareTo((java.lang.Object) year68);
        int int72 = month65.getMonth();
        boolean boolean74 = month65.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month65.previous();
        timeSeries61.add(regularTimePeriod75, (double) 32);
        boolean boolean78 = timeSeries61.getNotify();
        java.lang.Object obj79 = timeSeries61.clone();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries49.addAndOrUpdate(timeSeries61);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries49.addChangeListener(seriesChangeListener81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date85 = year84.getEnd();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month86.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month86, (java.lang.Number) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        java.lang.Number number91 = timeSeriesDataItem90.getValue();
        boolean boolean92 = timeSeriesDataItem90.isSelected();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61141708800001L) + "'", long69 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertTrue("'" + number91 + "' != '" + 12 + "'", number91.equals(12));
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond14.getLastMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond14.getMiddleMillisecond(calendar22);
        java.util.Calendar calendar24 = null;
        fixedMillisecond14.peg(calendar24);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61125897600001L) + "'", long21 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61125897600001L) + "'", long23 == (-61125897600001L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10);
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        timeSeries20.setDomainDescription("");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 6);
        int int29 = year25.getYear();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year25);
        int int31 = month5.compareTo((java.lang.Object) timeSeries20);
        java.lang.String str32 = month5.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32 + "'", int29 == 32);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January 32" + "'", str32.equals("January 32"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond14);
        long long17 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond14.previous();
        java.util.Calendar calendar21 = null;
        long long22 = regularTimePeriod20.getMiddleMillisecond(calendar21);
        long long23 = regularTimePeriod20.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61125897600001L) + "'", long17 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61125897600002L) + "'", long22 == (-61125897600002L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61125897600002L) + "'", long23 == (-61125897600002L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long14 = fixedMillisecond13.getMiddleMillisecond();
        java.lang.Number number15 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem(0);
        java.lang.String str18 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9999L) + "'", long14 == (-9999L));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod13, "100", "hi!");
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) (byte) 10);
        timeSeries21.fireSeriesChanged();
        boolean boolean29 = timeSeries21.isEmpty();
        int int30 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
        long long33 = year32.getMiddleMillisecond();
        java.util.Date date34 = year32.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) year32);
        timeSeriesDataItem36.setSelected(true);
        java.lang.Object obj39 = timeSeriesDataItem36.clone();
        timeSeries16.add(timeSeriesDataItem36, false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61141708800001L) + "'", long33 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        java.lang.Class class22 = timeSeries3.getTimePeriodClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        int int5 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 100" + "'", str4.equals("June 100"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(27, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
//        timeSeries7.fireSeriesChanged();
//        java.lang.Object obj15 = timeSeries7.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        long long18 = fixedMillisecond17.getMiddleMillisecond();
//        java.lang.Number number19 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        boolean boolean20 = day2.equals((java.lang.Object) timeSeries7);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9999L) + "'", long18 == (-9999L));
//        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (byte) 10 + "'", number19.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1);
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        java.lang.Object obj18 = timeSeriesDataItem16.clone();
        timeSeries3.add(timeSeriesDataItem16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = seriesChangeEvent13.getSummary();
        java.lang.Object obj15 = seriesChangeEvent13.getSource();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(seriesChangeInfo14);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + (byte) 1 + "'", obj15.equals((byte) 1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener18);
        timeSeries14.setDomainDescription("June 100");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = year6.equals(obj11);
        long long13 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61157520000000L) + "'", long13 == (-61157520000000L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = day0.compareTo((java.lang.Object) year7);
        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 100" + "'", str4.equals("May 100"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        int int20 = timeSeries18.getMaximumItemCount();
        timeSeries18.setDomainDescription("32");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        java.lang.Number number26 = timeSeries18.getValue(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(number26);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        timeSeries3.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date52 = year51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (byte) 10);
        timeSeries49.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) ' ');
        long long69 = year68.getMiddleMillisecond();
        java.util.Date date70 = year68.getEnd();
        int int71 = month65.compareTo((java.lang.Object) year68);
        int int72 = month65.getMonth();
        boolean boolean74 = month65.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month65.previous();
        timeSeries61.add(regularTimePeriod75, (double) 32);
        boolean boolean78 = timeSeries61.getNotify();
        java.lang.Object obj79 = timeSeries61.clone();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries49.addAndOrUpdate(timeSeries61);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries49.addChangeListener(seriesChangeListener81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date85 = year84.getEnd();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month86.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month86, (java.lang.Number) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        java.beans.PropertyChangeListener propertyChangeListener91 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener91);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61141708800001L) + "'", long69 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getMonth();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.util.Collection collection42 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        timeSeries9.setKey((java.lang.Comparable) serialDate44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
//        java.util.Date date48 = day47.getEnd();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getMonth();
//        long long51 = day49.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day49, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date61 = year60.getEnd();
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month62.next();
//        java.lang.Number number65 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) month62);
//        java.util.Collection collection66 = timeSeries54.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date73 = year72.getEnd();
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month74.next();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year((int) ' ');
//        long long78 = year77.getMiddleMillisecond();
//        java.util.Date date79 = year77.getEnd();
//        int int80 = month74.compareTo((java.lang.Object) year77);
//        int int81 = month74.getMonth();
//        boolean boolean83 = month74.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = month74.previous();
//        timeSeries70.add(regularTimePeriod84, (double) 32);
//        timeSeries58.add(regularTimePeriod84, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass90 = timeSeries58.getClass();
//        java.util.Collection collection91 = timeSeries58.getTimePeriods();
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate93 = day92.getSerialDate();
//        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(serialDate93);
//        timeSeries58.setKey((java.lang.Comparable) serialDate93);
//        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(serialDate93);
//        java.util.Date date97 = day96.getEnd();
//        boolean boolean98 = day47.equals((java.lang.Object) day96);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43626L + "'", long51 == 43626L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertNotNull(collection66);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-61141708800001L) + "'", long78 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 12 + "'", int81 == 12);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(wildcardClass90);
//        org.junit.Assert.assertNotNull(collection91);
//        org.junit.Assert.assertNotNull(serialDate93);
//        org.junit.Assert.assertNotNull(date97);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
        timeSeries6.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        java.util.Date date27 = year25.getEnd();
        int int28 = month22.compareTo((java.lang.Object) year25);
        int int29 = month22.getMonth();
        boolean boolean31 = month22.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month22.previous();
        timeSeries18.add(regularTimePeriod32, (double) 32);
        boolean boolean35 = timeSeries18.getNotify();
        java.lang.Object obj36 = timeSeries18.clone();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries6.addAndOrUpdate(timeSeries18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries6.addChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 12);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year50 = month49.getYear();
        java.lang.Number number51 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month49);
        boolean boolean52 = month2.equals((java.lang.Object) timeSeries6);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date55 = year54.getEnd();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month56.next();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year((int) ' ');
        long long60 = year59.getMiddleMillisecond();
        java.util.Date date61 = year59.getEnd();
        int int62 = month56.compareTo((java.lang.Object) year59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond64.next();
        int int66 = year59.compareTo((java.lang.Object) regularTimePeriod65);
        timeSeries6.delete(regularTimePeriod65);
        timeSeries6.setNotify(false);
        java.lang.String str70 = timeSeries6.getDescription();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61141708800001L) + "'", long60 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNull(str70);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        long long30 = month27.getLastMillisecond();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        long long38 = year37.getMiddleMillisecond();
        java.util.Date date39 = year37.getEnd();
        int int40 = month34.compareTo((java.lang.Object) year37);
        int int41 = month34.getMonth();
        boolean boolean43 = month34.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month34.previous();
        int int45 = month27.compareTo((java.lang.Object) month34);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month34, (double) 11, true);
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61125897600001L) + "'", long30 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61141708800001L) + "'", long38 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean4 = timeSeries3.isEmpty();
        try {
            timeSeries3.update((-68), (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getLastMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, number11);
//        java.lang.String str13 = day6.toString();
//        long long14 = day6.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.lang.Number number10 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.List list11 = timeSeries3.getItems();
        timeSeries3.setRangeDescription("");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=1]");
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.util.Collection collection42 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        timeSeries9.setKey((java.lang.Comparable) serialDate44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
//        java.util.Date date48 = day47.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48);
//        java.util.TimeZone timeZone50 = null;
//        java.util.Locale locale51 = null;
//        try {
//            org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date48, timeZone50, locale51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(date48);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560150000000L, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1560150000000L + "'", obj3.equals(1560150000000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1560150000000]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1560150000000]"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (byte) 1);
        java.lang.String str6 = year2.toString();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(27, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32" + "'", str6.equals("32"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "Value", seriesChangeInfo1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1);
        boolean boolean16 = timeSeriesDataItem15.isSelected();
        timeSeriesDataItem15.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        int int22 = timeSeriesDataItem15.compareTo((java.lang.Object) timePeriodFormatException20);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str26 = timePeriodFormatException25.toString();
        java.lang.String str27 = timePeriodFormatException25.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("December 32");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (double) (byte) 1);
        boolean boolean40 = timeSeriesDataItem39.isSelected();
        timeSeriesDataItem39.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str45 = timePeriodFormatException44.toString();
        int int46 = timeSeriesDataItem39.compareTo((java.lang.Object) timePeriodFormatException44);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str45.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setDomainDescription("");
        long long9 = timeSeries3.getMaximumItemAge();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185322437L + "'", long2 == 1560185322437L);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, (int) (byte) 1, (-68));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries3.getTimePeriod(0);
        java.lang.String str22 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener31);
        double double33 = timeSeries7.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries7.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        double double21 = timeSeries3.getMaxY();
        double double22 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems(false);
        java.util.Collection collection25 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 32.0d + "'", double22 == 32.0d);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        long long13 = year12.getMiddleMillisecond();
        java.util.Date date14 = year12.getEnd();
        long long15 = year12.getFirstMillisecond();
        int int16 = year12.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year12.next();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61141708800001L) + "'", long13 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61157520000000L) + "'", long15 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        long long31 = fixedMillisecond28.getSerialIndex();
        boolean boolean32 = timeSeries7.equals((java.lang.Object) long31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61125897600001L) + "'", long30 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61125897600001L) + "'", long31 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        timeSeries14.removeAgedItems(false);
        timeSeries14.setRangeDescription("Time");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 10);
        timeSeriesDataItem4.setSelected(false);
        java.lang.Number number12 = timeSeriesDataItem4.getValue();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) number12, seriesChangeInfo13);
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 10 + "'", number12.equals((byte) 10));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        int int22 = timeSeries3.getMaximumItemCount();
        timeSeries3.setRangeDescription("Overwritten values from: 10");
        boolean boolean25 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
        long long37 = year36.getMiddleMillisecond();
        java.util.Date date38 = year36.getEnd();
        int int39 = month33.compareTo((java.lang.Object) year36);
        int int40 = month33.getMonth();
        boolean boolean42 = month33.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month33.previous();
        timeSeries29.add(regularTimePeriod43, (double) 32);
        boolean boolean46 = timeSeries29.getNotify();
        java.lang.Object obj47 = timeSeries29.clone();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date54 = year53.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month55, (java.lang.Number) (byte) 10);
        timeSeries51.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date66 = year65.getEnd();
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month67.next();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year((int) ' ');
        long long71 = year70.getMiddleMillisecond();
        java.util.Date date72 = year70.getEnd();
        int int73 = month67.compareTo((java.lang.Object) year70);
        int int74 = month67.getMonth();
        boolean boolean76 = month67.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month67.previous();
        timeSeries63.add(regularTimePeriod77, (double) 32);
        boolean boolean80 = timeSeries63.getNotify();
        java.lang.Object obj81 = timeSeries63.clone();
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries51.addAndOrUpdate(timeSeries63);
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries29.addAndOrUpdate(timeSeries63);
        double double84 = timeSeries63.getMinY();
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries3.addAndOrUpdate(timeSeries63);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61141708800001L) + "'", long37 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-61141708800001L) + "'", long71 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(obj81);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 32.0d + "'", double84 == 32.0d);
        org.junit.Assert.assertNotNull(timeSeries85);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        int int22 = timeSeries3.getMaximumItemCount();
        timeSeries3.setRangeDescription("Overwritten values from: 10");
        timeSeries3.setRangeDescription("Wed Dec 31 23:59:59 PST 32");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61125897600001L) + "'", long8 == (-61125897600001L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("January 32");
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) ' ');
        long long5 = year4.getMiddleMillisecond();
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 1);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        int int20 = timeSeriesDataItem13.compareTo((java.lang.Object) month17);
        long long21 = month17.getLastMillisecond();
        boolean boolean22 = year7.equals((java.lang.Object) month17);
        int int23 = fixedMillisecond1.compareTo((java.lang.Object) month17);
        long long24 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9999L) + "'", long2 == (-9999L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61141708800001L) + "'", long5 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61125897600001L) + "'", long8 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61125897600001L) + "'", long21 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9999L) + "'", long24 == (-9999L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        timeSeriesDataItem4.setSelected(false);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) (byte) -1);
        timeSeries7.setDescription("December 32");
        timeSeries7.setDomainDescription("May 100");
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61125897600001L) + "'", long43 == (-61125897600001L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        double double35 = timeSeries15.getMinY();
        java.util.List list36 = timeSeries15.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries15.getNextTimePeriod();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        int int7 = year4.getYear();
        long long8 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61157520000000L) + "'", long8 == (-61157520000000L));
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 0);
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
//        java.lang.Number number28 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month25);
//        java.lang.String str29 = timeSeries21.getRangeDescription();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 1);
//        boolean boolean35 = timeSeriesDataItem34.isSelected();
//        java.lang.Object obj36 = timeSeriesDataItem34.clone();
//        timeSeries21.add(timeSeriesDataItem34);
//        timeSeries21.removeAgedItems(true);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        java.lang.Class class41 = timeSeries21.getTimePeriodClass();
//        timeSeries21.setDescription("Overwritten values from: 10");
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(class41);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.lang.String str19 = timeSeries17.getDescription();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day0.next();
//        java.lang.String str22 = day0.toString();
//        java.util.Calendar calendar23 = null;
//        try {
//            day0.peg(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        int int16 = year10.compareTo((java.lang.Object) regularTimePeriod15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 100, false);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener20);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getMonth();
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        long long7 = year6.getMiddleMillisecond();
        java.util.Date date8 = year6.getEnd();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int10 = month3.getMonth();
        boolean boolean12 = month3.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        long long14 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        boolean boolean19 = month3.equals((java.lang.Object) timeSeries18);
        int int20 = timeSeries18.getMaximumItemCount();
        java.lang.Object obj21 = timeSeries18.clone();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61128576000000L) + "'", long14 == (-61128576000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 0);
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        timeSeries3.setMaximumItemCount(11);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
//        long long31 = year30.getMiddleMillisecond();
//        java.util.Date date32 = year30.getEnd();
//        int int33 = month27.compareTo((java.lang.Object) year30);
//        int int34 = month27.getMonth();
//        boolean boolean36 = month27.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month27.previous();
//        timeSeries23.add(regularTimePeriod37, (double) 32);
//        boolean boolean40 = timeSeries23.getNotify();
//        java.lang.Object obj41 = timeSeries23.clone();
//        int int42 = timeSeries23.getMaximumItemCount();
//        timeSeries23.setRangeDescription("Overwritten values from: 10");
//        java.util.Collection collection45 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getMonth();
//        java.lang.String str48 = day46.toString();
//        long long49 = day46.getSerialIndex();
//        int int50 = day46.getDayOfMonth();
//        long long51 = day46.getSerialIndex();
//        long long52 = day46.getFirstMillisecond();
//        java.lang.Number number53 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61141708800001L) + "'", long31 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43626L + "'", long51 == 43626L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertNull(number53);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
//        boolean boolean5 = timeSeriesDataItem4.isSelected();
//        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 100);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = timeSeriesDataItem4.equals(obj8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        long long12 = day10.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
//        java.lang.Number number26 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) month23);
//        java.util.Collection collection27 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        boolean boolean28 = timeSeries15.getNotify();
//        int int29 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries15);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        timeSeries14.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries14.getDataItem(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        int int24 = timeSeries23.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10);
        timeSeries28.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries28.getNextTimePeriod();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        timeSeries28.setKey((java.lang.Comparable) year38);
        java.util.Collection collection41 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setRangeDescription("");
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(collection41);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 1);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 100);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 10);
        boolean boolean34 = timeSeriesDataItem28.isSelected();
        timeSeries7.add(timeSeriesDataItem28);
        java.lang.String str36 = timeSeries7.getDomainDescription();
        java.lang.Object obj37 = timeSeries7.clone();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(obj37);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.String str20 = day18.toString();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 1);
//        int int23 = timeSeries9.getItemCount();
//        timeSeries9.setRangeDescription("");
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date28 = year27.getEnd();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
//        long long33 = year32.getMiddleMillisecond();
//        java.util.Date date34 = year32.getEnd();
//        int int35 = month29.compareTo((java.lang.Object) year32);
//        int int36 = month29.getMonth();
//        boolean boolean38 = month29.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month29.previous();
//        try {
//            timeSeries9.add(regularTimePeriod39, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61141708800001L) + "'", long33 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(6, 100);
        long long27 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 10);
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, number30);
        int int32 = month26.getMonth();
        int int33 = month26.getMonth();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1206L + "'", long27 == 1206L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        boolean boolean5 = day0.equals((java.lang.Object) 1.0d);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
//        long long8 = year7.getMiddleMillisecond();
//        java.util.Date date9 = year7.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.next();
//        int int13 = year7.compareTo((java.lang.Object) regularTimePeriod12);
//        int int14 = day0.compareTo((java.lang.Object) regularTimePeriod12);
//        long long15 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61141708800001L) + "'", long8 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date18 = year17.getEnd();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
//        long long23 = year22.getMiddleMillisecond();
//        java.util.Date date24 = year22.getEnd();
//        int int25 = month19.compareTo((java.lang.Object) year22);
//        int int26 = month19.getMonth();
//        boolean boolean28 = month19.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
//        timeSeries15.add(regularTimePeriod29, (double) 32);
//        boolean boolean32 = timeSeries15.getNotify();
//        java.lang.Object obj33 = timeSeries15.clone();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
//        long long35 = timeSeries15.getMaximumItemAge();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
//        int int38 = day36.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day36.previous();
//        int int40 = day36.getYear();
//        int int41 = day36.getDayOfMonth();
//        java.lang.Number number42 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day36);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 32.0d + "'", number42.equals(32.0d));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 1);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        timeSeries3.setKey((java.lang.Comparable) timeSeriesDataItem19);
        int int22 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries3.removeChangeListener(seriesChangeListener49);
        boolean boolean51 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 6);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(27);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year7, "May 100", "May 100");
        boolean boolean11 = timeSeriesDataItem4.equals((java.lang.Object) "May 100");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6 + "'", number5.equals(6));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.previous();
        long long8 = fixedMillisecond4.getSerialIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) ' ');
        long long16 = year15.getMiddleMillisecond();
        java.util.Date date17 = year15.getEnd();
        int int18 = month12.compareTo((java.lang.Object) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        boolean boolean20 = fixedMillisecond4.equals((java.lang.Object) regularTimePeriod19);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61125897600001L) + "'", long6 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61125897600001L) + "'", long8 == (-61125897600001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61141708800001L) + "'", long16 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (byte) 10);
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries16.setDomainDescription("");
        java.util.List list20 = timeSeries16.getItems();
        timeSeries16.setDescription("December 32");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10);
        timeSeries28.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries28.getNextTimePeriod();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        timeSeries28.setKey((java.lang.Comparable) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.previous();
        int int42 = year24.compareTo((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 385L);
        boolean boolean45 = fixedMillisecond0.equals((java.lang.Object) 385L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getSerialIndex();
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond8);
        long long14 = fixedMillisecond1.getSerialIndex();
        long long15 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61125897600001L) + "'", long10 == (-61125897600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9999L) + "'", long14 == (-9999L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9999L) + "'", long15 == (-9999L));
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date18 = year17.getEnd();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
//        long long23 = year22.getMiddleMillisecond();
//        java.util.Date date24 = year22.getEnd();
//        int int25 = month19.compareTo((java.lang.Object) year22);
//        int int26 = month19.getMonth();
//        boolean boolean28 = month19.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
//        timeSeries15.add(regularTimePeriod29, (double) 32);
//        boolean boolean32 = timeSeries15.getNotify();
//        java.lang.Object obj33 = timeSeries15.clone();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
//        double double35 = timeSeries15.getMinY();
//        timeSeries15.setMaximumItemAge(1560185243804L);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
//        int int40 = day38.getYear();
//        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
//        long long42 = day38.getLastMillisecond();
//        java.lang.Number number43 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.util.Collection collection44 = timeSeries15.getTimePeriods();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560236399999L + "'", long42 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 32.0d + "'", number43.equals(32.0d));
//        org.junit.Assert.assertNotNull(collection44);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date5 = year4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
//        long long9 = month6.getLastMillisecond();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) ' ');
//        long long17 = year16.getMiddleMillisecond();
//        java.util.Date date18 = year16.getEnd();
//        int int19 = month13.compareTo((java.lang.Object) year16);
//        int int20 = month13.getMonth();
//        boolean boolean22 = month13.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month13.previous();
//        int int24 = month6.compareTo((java.lang.Object) month13);
//        java.lang.String str25 = month6.toString();
//        int int26 = month6.getYearValue();
//        int int27 = day0.compareTo((java.lang.Object) month6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61125897600001L) + "'", long9 == (-61125897600001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61141708800001L) + "'", long17 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "December 32" + "'", str25.equals("December 32"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.lang.String str19 = timeSeries17.getDescription();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        org.jfree.data.time.SerialDate serialDate21 = day0.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) ' ');
//        long long25 = year24.getMiddleMillisecond();
//        java.util.Date date26 = year24.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
//        boolean boolean30 = day22.equals((java.lang.Object) month28);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61141708800001L) + "'", long25 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date5, timeZone6);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
//        boolean boolean24 = timeSeries23.getNotify();
//        timeSeries23.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
//        int int29 = day27.getMonth();
//        long long30 = day27.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        timeSeries23.clear();
//        timeSeries23.setNotify(true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) ' ');
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 6);
        int int23 = year19.getYear();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year19);
        double double25 = timeSeries14.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries14.removeChangeListener(seriesChangeListener26);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61141708800001L) + "'", long20 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.lang.String str19 = timeSeries17.getDescription();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        org.jfree.data.time.SerialDate serialDate21 = day0.getSerialDate();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
//        java.util.Calendar calendar28 = null;
//        fixedMillisecond26.peg(calendar28);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond26.peg(calendar30);
//        boolean boolean32 = day0.equals((java.lang.Object) fixedMillisecond26);
//        long long33 = fixedMillisecond26.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61125897600001L) + "'", long33 == (-61125897600001L));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9999);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getEnd();
//        int int13 = month7.compareTo((java.lang.Object) year10);
//        int int14 = month7.getMonth();
//        boolean boolean16 = month7.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
//        timeSeries3.add(regularTimePeriod17, (double) 32);
//        boolean boolean20 = timeSeries3.getNotify();
//        double double21 = timeSeries3.getMaxY();
//        double double22 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(5, 100);
//        org.jfree.data.time.Year year28 = month27.getYear();
//        java.lang.String str29 = year28.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        long long33 = day31.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        timeSeries36.setKey((java.lang.Comparable) day37);
//        int int40 = day37.getDayOfMonth();
//        long long41 = day37.getFirstMillisecond();
//        java.lang.Number number42 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
//        int int45 = year44.getYear();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date48 = year47.getEnd();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond50.previous();
//        java.util.Calendar calendar52 = null;
//        fixedMillisecond50.peg(calendar52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year44, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 32.0d + "'", double22 == 32.0d);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 32.0d + "'", number42.equals(32.0d));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 32 + "'", int45 == 32);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(timeSeries54);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        timeSeries3.setDescription("Time");
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10);
        timeSeries9.fireSeriesChanged();
        java.lang.Object obj17 = timeSeries9.clone();
        int int18 = year1.compareTo(obj17);
        java.util.Calendar calendar19 = null;
        try {
            year1.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        long long23 = year22.getMiddleMillisecond();
        java.util.Date date24 = year22.getEnd();
        int int25 = month19.compareTo((java.lang.Object) year22);
        int int26 = month19.getMonth();
        boolean boolean28 = month19.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        timeSeries15.add(regularTimePeriod29, (double) 32);
        boolean boolean32 = timeSeries15.getNotify();
        java.lang.Object obj33 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 12);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year47 = month46.getYear();
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        try {
            java.lang.Class<?> wildcardClass49 = number48.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNull(number48);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDomainDescription("");
        java.util.List list18 = timeSeries14.getItems();
        timeSeries14.setDescription("December 32");
        java.lang.String str21 = timeSeries14.getRangeDescription();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        java.util.Collection collection20 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems(true);
        double double23 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 32.0d + "'", double23 == 32.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (byte) 1);
        long long6 = year2.getMiddleMillisecond();
        int int8 = year2.compareTo((java.lang.Object) 385L);
        long long9 = year2.getSerialIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (byte) 1);
        boolean boolean15 = timeSeriesDataItem14.isSelected();
        java.lang.Object obj16 = timeSeriesDataItem14.clone();
        boolean boolean17 = year2.equals(obj16);
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) ' ', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61141708800001L) + "'", long6 == (-61141708800001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        boolean boolean20 = timeSeries3.getNotify();
        java.lang.Object obj21 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10);
        timeSeries25.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        long long45 = year44.getMiddleMillisecond();
        java.util.Date date46 = year44.getEnd();
        int int47 = month41.compareTo((java.lang.Object) year44);
        int int48 = month41.getMonth();
        boolean boolean50 = month41.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month41.previous();
        timeSeries37.add(regularTimePeriod51, (double) 32);
        boolean boolean54 = timeSeries37.getNotify();
        java.lang.Object obj55 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries37);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries57.getDataItem(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61141708800001L) + "'", long45 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        timeSeries3.setKey((java.lang.Comparable) 2147483647);
//        java.util.List list6 = timeSeries3.getItems();
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.String str11 = day9.toString();
//        long long12 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 0);
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
//        java.lang.Number number28 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month25);
//        java.lang.String str29 = timeSeries21.getRangeDescription();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 1);
//        boolean boolean35 = timeSeriesDataItem34.isSelected();
//        java.lang.Object obj36 = timeSeriesDataItem34.clone();
//        timeSeries21.add(timeSeriesDataItem34);
//        timeSeries21.removeAgedItems(true);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        java.lang.Class class41 = timeSeries21.getTimePeriodClass();
//        java.lang.String str42 = timeSeries21.getRangeDescription();
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.next();
        java.lang.String str7 = month3.toString();
        org.jfree.data.time.Year year8 = month3.getYear();
        long long9 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 32" + "'", str7.equals("December 32"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61128576000000L) + "'", long9 == (-61128576000000L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date18 = year17.getEnd();
        java.util.Date date19 = year17.getEnd();
        java.lang.Number number20 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year17.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) ' ');
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries7);
        boolean boolean24 = timeSeries23.getNotify();
        timeSeries23.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(385L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod29, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod29, 0.0d);
        timeSeries23.add(timeSeriesDataItem33);
        java.lang.Number number35 = timeSeriesDataItem33.getValue();
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0.0d + "'", number35.equals(0.0d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61125897600001L) + "'", long12 == (-61125897600001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61125897600001L) + "'", long14 == (-61125897600001L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, "December 32", "hi!");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Date date5 = day0.getEnd();
//        long long6 = day0.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10);
        timeSeries6.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        long long26 = year25.getMiddleMillisecond();
        java.util.Date date27 = year25.getEnd();
        int int28 = month22.compareTo((java.lang.Object) year25);
        int int29 = month22.getMonth();
        boolean boolean31 = month22.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month22.previous();
        timeSeries18.add(regularTimePeriod32, (double) 32);
        boolean boolean35 = timeSeries18.getNotify();
        java.lang.Object obj36 = timeSeries18.clone();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries6.addAndOrUpdate(timeSeries18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries6.addChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 12);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(5, 100);
        org.jfree.data.time.Year year50 = month49.getYear();
        java.lang.Number number51 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month49);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener52);
        boolean boolean54 = month2.equals((java.lang.Object) propertyChangeListener52);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61141708800001L) + "'", long26 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        java.lang.Number number16 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        long long29 = year28.getMiddleMillisecond();
//        java.util.Date date30 = year28.getEnd();
//        int int31 = month25.compareTo((java.lang.Object) year28);
//        int int32 = month25.getMonth();
//        boolean boolean34 = month25.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month25.previous();
//        timeSeries21.add(regularTimePeriod35, (double) 32);
//        timeSeries9.add(regularTimePeriod35, (java.lang.Number) 1206L, false);
//        java.lang.Class<?> wildcardClass41 = timeSeries9.getClass();
//        java.util.Collection collection42 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        timeSeries9.setKey((java.lang.Comparable) serialDate44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
//        java.util.Date date48 = day47.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48, "Value", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61141708800001L) + "'", long29 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(date48);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date18 = year17.getEnd();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
//        long long23 = year22.getMiddleMillisecond();
//        java.util.Date date24 = year22.getEnd();
//        int int25 = month19.compareTo((java.lang.Object) year22);
//        int int26 = month19.getMonth();
//        boolean boolean28 = month19.equals((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
//        timeSeries15.add(regularTimePeriod29, (double) 32);
//        boolean boolean32 = timeSeries15.getNotify();
//        java.lang.Object obj33 = timeSeries15.clone();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
//        double double35 = timeSeries15.getMinY();
//        timeSeries15.setMaximumItemAge(1560185243804L);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
//        int int40 = day38.getYear();
//        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
//        long long42 = day38.getLastMillisecond();
//        java.lang.Number number43 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date46 = year45.getEnd();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
//        long long48 = month47.getSerialIndex();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month47);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61141708800001L) + "'", long23 == (-61141708800001L));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560236399999L + "'", long42 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 32.0d + "'", number43.equals(32.0d));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 396L + "'", long48 == 396L);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        int int3 = day0.getMonth();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1);
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        timeSeriesDataItem8.setValue((java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        int int15 = timeSeriesDataItem8.compareTo((java.lang.Object) timePeriodFormatException13);
        java.lang.Object obj16 = timeSeriesDataItem8.clone();
        boolean boolean17 = day0.equals(obj16);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61141708800001L) + "'", long2 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        timeSeries3.setKey((java.lang.Comparable) 2147483647);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setDomainDescription("");
        long long9 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: Overwritten values from: 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) ' ');
        long long11 = year10.getMiddleMillisecond();
        java.util.Date date12 = year10.getEnd();
        int int13 = month7.compareTo((java.lang.Object) year10);
        int int14 = month7.getMonth();
        boolean boolean16 = month7.equals((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month7.previous();
        timeSeries3.add(regularTimePeriod17, (double) 32);
        java.util.Collection collection20 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) 5);
        timeSeries3.setKey((java.lang.Comparable) 5);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) ' ');
        long long30 = year29.getMiddleMillisecond();
        java.util.Date date31 = year29.getEnd();
        long long32 = year29.getFirstMillisecond();
        int int33 = year29.getYear();
        long long34 = year29.getFirstMillisecond();
        long long35 = year29.getSerialIndex();
        java.lang.Number number36 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.String str37 = year29.toString();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61141708800001L) + "'", long11 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61141708800001L) + "'", long30 == (-61141708800001L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61157520000000L) + "'", long32 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 32 + "'", int33 == 32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61157520000000L) + "'", long34 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 32L + "'", long35 == 32L);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 32.0d + "'", number36.equals(32.0d));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "32" + "'", str37.equals("32"));
    }
}

