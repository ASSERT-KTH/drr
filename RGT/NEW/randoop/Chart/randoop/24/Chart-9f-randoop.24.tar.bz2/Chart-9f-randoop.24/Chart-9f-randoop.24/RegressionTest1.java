import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-3));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day25);
        boolean boolean28 = year18.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        long long30 = month29.getFirstMillisecond();
        org.jfree.data.time.Year year31 = month29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.previous();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month29, number33);
        try {
            java.lang.Number number36 = timeSeries24.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setDomainDescription("10-June-2019");
//        java.lang.String str18 = timeSeries8.getDomainDescription();
//        timeSeries8.removeAgedItems((long) 1900, true);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries25.setNotify(true);
//        java.lang.Object obj28 = timeSeries25.clone();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getStart();
//        int int41 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day39.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 100);
//        java.lang.String str45 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year47 = month46.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
//        timeSeries25.add(timeSeriesDataItem48, true);
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class54);
//        timeSeries55.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries59.removeAgedItems(true);
//        timeSeries59.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries55.addAndOrUpdate(timeSeries59);
//        timeSeries59.removeAgedItems(false);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.util.Date date68 = day67.getStart();
//        long long69 = day67.getSerialIndex();
//        java.lang.String str70 = day67.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day67, (java.lang.Number) 10.0f);
//        java.lang.Class<?> wildcardClass73 = day67.getClass();
//        int int74 = timeSeriesDataItem48.compareTo((java.lang.Object) day67);
//        timeSeries8.add(timeSeriesDataItem48, true);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 43626L + "'", long69 == 43626L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.Object obj9 = null;
        boolean boolean10 = fixedMillisecond5.equals(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
        timeSeries1.setMaximumItemCount(11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.addOrUpdate(regularTimePeriod24, (java.lang.Number) 11);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean29 = month27.equals((java.lang.Object) 4);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getStart();
//        long long32 = day30.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str34 = month27.toString();
//        java.util.Calendar calendar35 = null;
//        try {
//            month27.peg(calendar35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43626L + "'", long32 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) (byte) 0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        int int22 = day16.getDayOfMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        int int26 = day23.getYear();
//        int int27 = day16.compareTo((java.lang.Object) int26);
//        long long28 = day16.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        long long6 = timeSeries1.getMaximumItemAge();
        long long7 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        java.lang.String str16 = timeSeries8.getRangeDescription();
        java.lang.Comparable comparable17 = timeSeries8.getKey();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 0L + "'", comparable17.equals(0L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        boolean boolean14 = timeSeries4.getNotify();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getFirstMillisecond();
        org.jfree.data.time.Year year17 = month15.getYear();
        long long18 = year17.getLastMillisecond();
        int int19 = year17.getYear();
        java.lang.Number number20 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        long long6 = timeSeries1.getMaximumItemAge();
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.removeChangeListener(seriesChangeListener9);
        java.lang.Comparable comparable11 = null;
        try {
            timeSeries1.setKey(comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        boolean boolean22 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int25 = spreadsheetDate24.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean33 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, (int) '#');
        int int34 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean35 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int36 = spreadsheetDate9.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 7 + "'", int36 == 7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', 0, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone0);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-28800000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=2,startDay=8,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=3,endMonth=10,endDay=1,endDayOfWeek=1,endTime=7200000,endTimeMode=0]]]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-28800000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=2,startDay=8,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=3,endMonth=10,endDay=1,endDayOfWeek=1,endTime=7200000,endTimeMode=0]]]"));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        int int4 = month3.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day25);
        boolean boolean28 = year18.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.lang.Object obj30 = null;
        boolean boolean31 = month29.equals(obj30);
        long long32 = month29.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month29, (double) 3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
        long long37 = fixedMillisecond36.getLastMillisecond();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond36.getFirstMillisecond(calendar38);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond36.getLastMillisecond(calendar40);
        java.lang.String str42 = fixedMillisecond36.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (-3));
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries45.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str42.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(timeSeries45);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        java.lang.Number number30 = timeSeries8.getValue(0);
//        boolean boolean31 = timeSeries8.isEmpty();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10.0f + "'", number30.equals(10.0f));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        int int16 = timeSeries8.getItemCount();
        java.util.Collection collection17 = timeSeries8.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(collection17);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date1);
//        long long12 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate6, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean24 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate22, (int) '#');
        boolean boolean25 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean43 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate39, (org.jfree.data.time.SerialDate) spreadsheetDate41, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean51 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate49, (int) '#');
        boolean boolean52 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean53 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean62 = spreadsheetDate56.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate60, (int) '#');
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean71 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, (org.jfree.data.time.SerialDate) spreadsheetDate69, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean79 = spreadsheetDate73.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate75, (org.jfree.data.time.SerialDate) spreadsheetDate77, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean87 = spreadsheetDate81.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate83, (org.jfree.data.time.SerialDate) spreadsheetDate85, (int) '#');
        boolean boolean88 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate73, (org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean90 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate73, (int) (short) 10);
        org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate58.getNearestDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.addDays(716968, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        try {
            org.jfree.data.time.SerialDate serialDate95 = spreadsheetDate58.getNearestDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone7);
        long long10 = year9.getSerialIndex();
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(13, year9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries13.setRangeDescription("3-February-1900");
        java.lang.String str16 = timeSeries13.getDescription();
        int int17 = timeSeries13.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getLastMillisecond();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        long long3 = year2.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        timeSeries8.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries12.removeAgedItems(true);
//        timeSeries12.setMaximumItemCount((int) 'a');
//        long long17 = timeSeries12.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries12);
//        timeSeries12.setDomainDescription("");
//        int int21 = year2.compareTo((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        int int25 = day22.getYear();
//        org.jfree.data.time.SerialDate serialDate26 = day22.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day22);
//        int int29 = day22.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.Object obj2 = null;
        boolean boolean3 = month1.equals(obj2);
        long long4 = month1.getLastMillisecond();
        long long5 = month1.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        long long10 = fixedMillisecond7.getMiddleMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedMillisecond7.equals(obj11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.Year year16 = month14.getYear();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        long long19 = year16.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries21.removeAgedItems(true);
        timeSeries21.setMaximumItemCount((int) 'a');
        long long26 = timeSeries21.getMaximumItemAge();
        timeSeries21.setRangeDescription("hi!");
        java.lang.Class class29 = timeSeries21.getTimePeriodClass();
        java.lang.Class class30 = null;
        java.lang.Class class31 = null;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone34);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date33, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date40, timeZone43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date40, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone45);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, class29);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class29);
        boolean boolean51 = month1.equals((java.lang.Object) class29);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, class29);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class56);
        timeSeries57.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries61.removeAgedItems(true);
        timeSeries61.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries57.addAndOrUpdate(timeSeries61);
        timeSeries61.removeAgedItems(false);
        timeSeries61.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries52.addAndOrUpdate(timeSeries61);
        int int72 = timeSeries71.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2147483647 + "'", int72 == 2147483647);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Following");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        java.lang.String str16 = timeSeries8.getRangeDescription();
//        timeSeries8.setMaximumItemCount(11);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        long long22 = fixedMillisecond21.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
//        long long24 = fixedMillisecond21.getMiddleMillisecond();
//        long long25 = fixedMillisecond21.getSerialIndex();
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 11);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        timeSeries8.setRangeDescription("Sunday");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1L));
        java.lang.Class class23 = timeSeries8.getTimePeriodClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        java.lang.Class<?> wildcardClass22 = day16.getClass();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getFirstMillisecond();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        long long26 = year25.getLastMillisecond();
//        int int27 = year25.getYear();
//        int int28 = day16.compareTo((java.lang.Object) int27);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        long long6 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getLastMillisecond(calendar7);
//        long long9 = fixedMillisecond2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int6 = timeSeries5.getMaximumItemCount();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
//        timeSeries13.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries17.removeAgedItems(true);
//        timeSeries17.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        long long25 = day23.getSerialIndex();
//        java.lang.String str26 = day23.toString();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day23);
//        timeSeries13.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getFirstMillisecond();
//        org.jfree.data.time.Year year32 = month30.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries13.addOrUpdate(regularTimePeriod33, (java.lang.Number) 11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries8.getDataItem(regularTimePeriod33);
//        timeSeries8.setMaximumItemAge((long) 97);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        long long8 = fixedMillisecond2.getMiddleMillisecond();
//        long long9 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond2.getMiddleMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond2.getFirstMillisecond(calendar12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int6 = spreadsheetDate5.getDayOfMonth();
        boolean boolean7 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
//        timeSeries9.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries13.removeAgedItems(true);
//        timeSeries13.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.addAndOrUpdate(timeSeries13);
//        timeSeries13.removeAgedItems(false);
//        timeSeries13.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean23 = day0.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries30.addChangeListener(seriesChangeListener33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class38);
//        timeSeries39.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries43.removeAgedItems(true);
//        timeSeries43.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.addAndOrUpdate(timeSeries43);
//        java.lang.Comparable comparable49 = timeSeries48.getKey();
//        timeSeries48.setRangeDescription("Value");
//        java.util.Collection collection52 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        timeSeries30.setDescription("org.jfree.data.general.SeriesChangeEvent[source= ]");
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + "Overwritten values from:  " + "'", comparable49.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection52);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries4.createCopy((int) (byte) 10, 9999);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        timeSeries14.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setMaximumItemCount((int) 'a');
        long long23 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.addAndOrUpdate(timeSeries18);
        timeSeries25.setRangeDescription("");
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        java.util.Date date10 = day5.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) (-1L));
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class18);
//        timeSeries19.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries23.removeAgedItems(true);
//        timeSeries23.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.addAndOrUpdate(timeSeries23);
//        timeSeries23.removeAgedItems(false);
//        boolean boolean31 = month14.equals((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month14.previous();
//        boolean boolean33 = timeSeriesDataItem13.equals((java.lang.Object) month14);
//        java.lang.String str34 = month14.toString();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getMiddleMillisecond();
        java.lang.String str4 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        long long6 = month0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries13.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        try {
            timeSeries1.update((int) (byte) -1, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Date date4 = month0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Date date2 = day0.getStart();
        int int3 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(65, year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        java.lang.Class class21 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month22.previous();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        java.lang.String str16 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getMiddleMillisecond();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class25);
//        timeSeries26.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries30.removeAgedItems(true);
//        timeSeries30.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries26.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.util.Date date37 = day36.getStart();
//        long long38 = day36.getSerialIndex();
//        java.lang.String str39 = day36.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day36);
//        timeSeries26.setKey((java.lang.Comparable) "3-February-1900");
//        java.lang.Class class43 = timeSeries26.getTimePeriodClass();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        long long45 = month44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 1560150000000L);
//        int int48 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) month44);
//        boolean boolean49 = timeSeries8.isEmpty();
//        java.util.Collection collection50 = timeSeries8.getTimePeriods();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(collection50);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate6, (int) '#');
        spreadsheetDate6.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        spreadsheetDate18.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean30 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean38 = spreadsheetDate32.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate34, (org.jfree.data.time.SerialDate) spreadsheetDate36, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean46 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate44, (int) '#');
        boolean boolean47 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean48 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        boolean boolean51 = spreadsheetDate18.isAfter(serialDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int54 = spreadsheetDate53.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean62 = spreadsheetDate56.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate60, (int) '#');
        int int63 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean71 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, (org.jfree.data.time.SerialDate) spreadsheetDate69, (int) '#');
        int int72 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean73 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        try {
            org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 3 + "'", int54 == 3);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
        timeSeries8.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries12.removeAgedItems(true);
        timeSeries12.setMaximumItemCount((int) 'a');
        long long17 = timeSeries12.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries12);
        timeSeries12.setDomainDescription("");
        int int21 = year2.compareTo((java.lang.Object) timeSeries12);
        long long22 = year2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.addOrUpdate(regularTimePeriod24, (java.lang.Number) 11);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        long long29 = month28.getFirstMillisecond();
//        org.jfree.data.time.Year year30 = month28.getYear();
//        long long31 = year30.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.previous();
//        long long33 = year30.getFirstMillisecond();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 10, year30);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month34);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 10);
        int int3 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.Object obj2 = null;
        boolean boolean3 = month1.equals(obj2);
        long long4 = month1.getLastMillisecond();
        long long5 = month1.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        long long10 = fixedMillisecond7.getMiddleMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedMillisecond7.equals(obj11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.Year year16 = month14.getYear();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        long long19 = year16.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries21.removeAgedItems(true);
        timeSeries21.setMaximumItemCount((int) 'a');
        long long26 = timeSeries21.getMaximumItemAge();
        timeSeries21.setRangeDescription("hi!");
        java.lang.Class class29 = timeSeries21.getTimePeriodClass();
        java.lang.Class class30 = null;
        java.lang.Class class31 = null;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone34);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date33, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date40, timeZone43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date40, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone45);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, class29);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class29);
        boolean boolean51 = month1.equals((java.lang.Object) class29);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, class29);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class56);
        timeSeries57.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries61.removeAgedItems(true);
        timeSeries61.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries57.addAndOrUpdate(timeSeries61);
        timeSeries61.removeAgedItems(false);
        timeSeries61.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries52.addAndOrUpdate(timeSeries61);
        java.lang.Class class75 = null;
        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class75);
        timeSeries76.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries80.removeAgedItems(true);
        timeSeries80.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries76.addAndOrUpdate(timeSeries80);
        timeSeries80.removeAgedItems(false);
        timeSeries80.setDomainDescription("10-June-2019");
        java.lang.String str90 = timeSeries80.getDomainDescription();
        java.util.Collection collection91 = timeSeries52.getTimePeriodsUniqueToOtherSeries(timeSeries80);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(timeSeries85);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "10-June-2019" + "'", str90.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(collection91);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod22, (double) 8);
//        java.lang.Number number25 = timeSeriesDataItem24.getValue();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 8.0d + "'", number25.equals(8.0d));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Date date4 = month0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, 0, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("2019");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str14 = seriesException13.toString();
        java.lang.Throwable[] throwableArray15 = seriesException13.getSuppressed();
        java.lang.Throwable[] throwableArray16 = seriesException13.getSuppressed();
        java.lang.String str17 = seriesException13.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException13);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str14.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str17.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.Object obj2 = null;
        boolean boolean3 = month1.equals(obj2);
        long long4 = month1.getLastMillisecond();
        long long5 = month1.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        long long10 = fixedMillisecond7.getMiddleMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedMillisecond7.equals(obj11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.Year year16 = month14.getYear();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        long long19 = year16.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries21.removeAgedItems(true);
        timeSeries21.setMaximumItemCount((int) 'a');
        long long26 = timeSeries21.getMaximumItemAge();
        timeSeries21.setRangeDescription("hi!");
        java.lang.Class class29 = timeSeries21.getTimePeriodClass();
        java.lang.Class class30 = null;
        java.lang.Class class31 = null;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone34);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date33, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date40, timeZone43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date40, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date33, timeZone45);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, class29);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class29);
        boolean boolean51 = month1.equals((java.lang.Object) class29);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, class29);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class56);
        timeSeries57.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries61.removeAgedItems(true);
        timeSeries61.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries57.addAndOrUpdate(timeSeries61);
        timeSeries61.removeAgedItems(false);
        timeSeries61.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries52.addAndOrUpdate(timeSeries61);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
        java.util.Date date73 = day72.getStart();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean85 = spreadsheetDate79.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate81, (org.jfree.data.time.SerialDate) spreadsheetDate83, (int) '#');
        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate81);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate86);
        org.jfree.data.time.TimeSeries timeSeries88 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate87);
        int int89 = month75.compareTo((java.lang.Object) timeSeries88);
        org.jfree.data.time.Year year90 = month75.getYear();
        try {
            timeSeries71.add((org.jfree.data.time.RegularTimePeriod) year90, (java.lang.Number) 3, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(year90);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries8.addChangeListener(seriesChangeListener14);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        int int23 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.next();
//        int int25 = day21.getDayOfMonth();
//        java.util.Date date26 = day21.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1L));
//        try {
//            timeSeries8.add(timeSeriesDataItem29);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(date26);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int6 = timeSeries5.getMaximumItemCount();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.String str9 = timeSeries1.getDescription();
        java.lang.Object obj10 = timeSeries1.clone();
        java.lang.String str11 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int6 = timeSeries5.getMaximumItemCount();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
//        timeSeries13.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries17.removeAgedItems(true);
//        timeSeries17.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
//        timeSeries17.removeAgedItems(false);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        long long27 = day25.getSerialIndex();
//        java.lang.String str28 = day25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
//        long long34 = fixedMillisecond33.getSerialIndex();
//        java.util.Date date35 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.previous();
//        int int37 = timeSeries17.getIndex(regularTimePeriod36);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int40 = timeSeries39.getMaximumItemCount();
//        java.util.Collection collection41 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries39);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries39.addChangeListener(seriesChangeListener42);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class47);
//        timeSeries48.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries52.removeAgedItems(true);
//        timeSeries52.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries48.addAndOrUpdate(timeSeries52);
//        java.lang.Comparable comparable58 = timeSeries57.getKey();
//        timeSeries57.setRangeDescription("Value");
//        java.util.Collection collection61 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries57);
//        java.util.Collection collection62 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries57);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2147483647 + "'", int40 == 2147483647);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + "Overwritten values from:  " + "'", comparable58.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertNotNull(collection62);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries4.addChangeListener(seriesChangeListener21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class28);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        int int37 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day35.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 100);
//        java.lang.String str41 = timeSeries29.getDomainDescription();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year43 = month42.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) year43);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class48);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.util.Date date56 = day55.getStart();
//        int int57 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day55.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 100);
//        java.lang.String str61 = timeSeries49.getDomainDescription();
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year63 = month62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) year63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year63.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year63.next();
//        int int67 = year63.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, (double) 11);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date71);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date71);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        java.util.Date date75 = day74.getStart();
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
//        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date75);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date75, timeZone78);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month(date71, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = month80.next();
//        boolean boolean82 = year63.equals((java.lang.Object) month80);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month80);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2958465);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        java.lang.Object obj4 = timeSeries1.clone();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getStart();
//        int int17 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 100);
//        java.lang.String str21 = timeSeries9.getDomainDescription();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year23 = month22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
//        timeSeries1.add(timeSeriesDataItem24, true);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class30);
//        timeSeries31.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries35.removeAgedItems(true);
//        timeSeries35.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.addAndOrUpdate(timeSeries35);
//        timeSeries35.removeAgedItems(false);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getStart();
//        long long45 = day43.getSerialIndex();
//        java.lang.String str46 = day43.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 10.0f);
//        java.lang.Class<?> wildcardClass49 = day43.getClass();
//        int int50 = timeSeriesDataItem24.compareTo((java.lang.Object) day43);
//        java.lang.String str51 = day43.toString();
//        long long52 = day43.getFirstMillisecond();
//        java.util.Calendar calendar53 = null;
//        try {
//            day43.peg(calendar53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43626L + "'", long45 == 43626L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean9 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate7, (int) '#');
        spreadsheetDate7.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate7.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate19, (int) '#');
        spreadsheetDate19.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean31 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean39 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate37, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean47 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate45, (int) '#');
        boolean boolean48 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean49 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        boolean boolean52 = spreadsheetDate19.isAfter(serialDate51);
        boolean boolean53 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date54 = spreadsheetDate19.toDate();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1, 1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        timeSeries4.setNotify(false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        long long3 = day0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        int int12 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        int int21 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2019, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        boolean boolean50 = spreadsheetDate17.isAfter(serialDate49);
        int int51 = spreadsheetDate17.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 7 + "'", int51 == 7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        timeSeries13.setRangeDescription("Value");
        try {
            timeSeries13.update(31, (java.lang.Number) (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "Overwritten values from:  " + "'", comparable14.equals("Overwritten values from:  "));
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        int int2 = month0.getYearValue();
//        org.jfree.data.time.Year year3 = month0.getYear();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        timeSeries8.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries12.removeAgedItems(true);
//        timeSeries12.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries8.addAndOrUpdate(timeSeries12);
//        timeSeries12.removeAgedItems(false);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        long long22 = day20.getSerialIndex();
//        java.lang.String str23 = day20.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 10.0f);
//        java.lang.Class<?> wildcardClass26 = day20.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year3, (java.lang.Class) wildcardClass26);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        int int4 = year2.compareTo((java.lang.Object) (byte) -1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.createCopy((int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        int int17 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 100);
        java.lang.String str21 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year23 = month22.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries1.add(timeSeriesDataItem24, true);
        timeSeries1.setNotify(true);
        timeSeries1.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-28800000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=2,startDay=8,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=3,endMonth=10,endDay=1,endDayOfWeek=1,endTime=7200000,endTimeMode=0]]]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone16);
        boolean boolean18 = timeSeries4.equals((java.lang.Object) timeZone16);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        java.lang.Class class21 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1560150000000L);
//        java.util.Collection collection26 = timeSeries4.getTimePeriods();
//        try {
//            timeSeries4.delete(0, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(collection26);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(5, (-457), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        timeSeries4.setMaximumItemAge((long) 6);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        timeSeriesDataItem19.setValue((java.lang.Number) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem19.getPeriod();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = regularTimePeriod22.getMiddleMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setMaximumItemCount((int) (byte) 10);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
//        java.lang.String str34 = timeSeries22.getDomainDescription();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year36 = month35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getStart();
//        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
//        java.lang.String str54 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year56 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
//        int int60 = year56.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.util.Date date64 = day63.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
//        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
//        timeSeries8.add(timeSeriesDataItem62, true);
//        timeSeries8.setDomainDescription("Nearest");
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.util.Date date78 = day77.getStart();
//        int int79 = timeSeries76.getIndex((org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day77.next();
//        int int81 = day77.getDayOfMonth();
//        java.util.Date date82 = day77.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day77.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = day77.previous();
//        long long85 = day77.getLastMillisecond();
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
//        long long87 = month86.getFirstMillisecond();
//        org.jfree.data.time.Year year88 = month86.getYear();
//        int int89 = month86.getMonth();
//        int int90 = month86.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day77, (org.jfree.data.time.RegularTimePeriod) month86);
//        java.util.Calendar calendar92 = null;
//        try {
//            long long93 = month86.getLastMillisecond(calendar92);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560236399999L + "'", long85 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1559372400000L + "'", long87 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 6 + "'", int90 == 6);
//        org.junit.Assert.assertNotNull(timeSeries91);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean9 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate7, (int) '#');
        java.lang.String str10 = spreadsheetDate5.toString();
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int12 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3-February-1900" + "'", str10.equals("3-February-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 65 + "'", int11 == 65);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        long long6 = day4.getSerialIndex();
//        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day4);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
//        timeSeries1.removeAgedItems((-1L), true);
//        java.lang.Comparable comparable13 = timeSeries1.getKey();
//        timeSeries1.clear();
//        timeSeries1.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0L + "'", comparable13.equals(0L));
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        int int12 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean28 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean36 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate34, (int) '#');
        boolean boolean37 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, serialDate38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        long long41 = day40.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 58L + "'", long41 == 58L);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries30.addChangeListener(seriesChangeListener33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class38);
//        timeSeries39.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries43.removeAgedItems(true);
//        timeSeries43.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.addAndOrUpdate(timeSeries43);
//        java.lang.Comparable comparable49 = timeSeries48.getKey();
//        timeSeries48.setRangeDescription("Value");
//        java.util.Collection collection52 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        int int53 = timeSeries48.getItemCount();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + "Overwritten values from:  " + "'", comparable49.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        boolean boolean22 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int25 = spreadsheetDate24.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean33 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, (int) '#');
        int int34 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean35 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int38 = spreadsheetDate37.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean46 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate44, (int) '#');
        int int47 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean55 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate53, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean63 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate59, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean71 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, (org.jfree.data.time.SerialDate) spreadsheetDate69, (int) '#');
        boolean boolean72 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean74 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        long long4 = fixedMillisecond2.getFirstMillisecond();
//        long long5 = fixedMillisecond2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        java.util.Calendar calendar9 = null;
        try {
            day5.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Date date4 = month0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getLastMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        long long13 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.addAndOrUpdate(timeSeries8);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class18);
        timeSeries19.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries23.removeAgedItems(true);
        timeSeries23.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.addAndOrUpdate(timeSeries23);
        timeSeries23.removeAgedItems(false);
        timeSeries23.setDomainDescription("10-June-2019");
        java.lang.String str33 = timeSeries23.getDomainDescription();
        timeSeries23.removeAgedItems((long) 1900, true);
        java.util.Collection collection37 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries23.setMaximumItemAge((long) 1900);
        boolean boolean40 = timeSeries23.isEmpty();
        timeSeries23.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getStart();
//        int int45 = timeSeries42.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day43.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 100);
//        java.lang.String str49 = timeSeries37.getDomainDescription();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year51 = month50.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year51.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year51);
//        try {
//            timeSeries30.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 1.0f, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, 2019, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        int int22 = day16.getDayOfMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        int int26 = day23.getYear();
//        int int27 = day16.compareTo((java.lang.Object) int26);
//        org.jfree.data.time.SerialDate serialDate28 = day16.getSerialDate();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(serialDate28);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        long long3 = year2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day16.getFirstMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        long long3 = month0.getLastMillisecond();
        long long4 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        int int32 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 100);
        java.lang.String str36 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.next();
        int int42 = year38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (double) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
        java.lang.Object obj46 = timeSeriesDataItem44.clone();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        long long30 = month29.getFirstMillisecond();
//        long long31 = month29.getLastMillisecond();
//        java.util.Date date32 = month29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        boolean boolean35 = timeSeries1.equals((java.lang.Object) date32);
//        java.lang.String str36 = timeSeries1.getDomainDescription();
//        boolean boolean37 = timeSeries1.getNotify();
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean12 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) '#');
        int int13 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate19, (int) '#');
        int int22 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(13, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate15.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        int int32 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 100);
        java.lang.String str36 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.next();
        int int42 = year38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (double) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
        timeSeriesDataItem44.setValue((java.lang.Number) 5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        long long6 = day4.getSerialIndex();
//        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day4);
//        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=a]");
//        timeSeries1.setMaximumItemAge(9223372036854775807L);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        java.lang.String str13 = seriesChangeEvent12.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(number7);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        java.lang.String str8 = spreadsheetDate1.getDescription();
        int int9 = spreadsheetDate1.getDayOfMonth();
        java.util.Date date10 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) ' ');
//        int int10 = day0.compareTo((java.lang.Object) seriesChangeEvent9);
//        long long11 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "2019");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + "2019" + "'", obj3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate6, (int) '#');
        java.lang.String str9 = spreadsheetDate2.getDescription();
        int int10 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getFirstMillisecond();
        long long3 = month1.getLastMillisecond();
        java.util.Date date4 = month1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(31, year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 2);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (-2204078400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (-3), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date21, timeZone24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date19, timeZone24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 11);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond1.getMiddleMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = fixedMillisecond1.equals(obj5);
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
//        java.util.Date date9 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getStart();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date12, timeZone18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date12);
//        boolean boolean23 = month10.equals((java.lang.Object) serialDate22);
//        java.lang.String str24 = serialDate22.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate6, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean24 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate22, (int) '#');
        boolean boolean25 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean33 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, (int) '#');
        boolean boolean34 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(11, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(serialDate35);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Date date4 = month0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.lang.Class<?> wildcardClass6 = date4.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(97, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date13, timeZone18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date1, timeZone18);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(timeZone18);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        java.util.Date date10 = day5.getEnd();
//        long long11 = day5.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = month0.equals(obj1);
//        long long3 = month0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        long long12 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond8.getLastMillisecond(calendar13);
//        int int15 = timeSeriesDataItem5.compareTo((java.lang.Object) long14);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class19);
//        timeSeries20.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries24.removeAgedItems(true);
//        timeSeries24.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.addAndOrUpdate(timeSeries24);
//        boolean boolean30 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem5.getPeriod();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.String str19 = timeSeries4.getDescription();
//        int int20 = timeSeries4.getItemCount();
//        try {
//            timeSeries4.removeAgedItems((long) 12, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Overwritten values from:  ");
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        long long13 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.addAndOrUpdate(timeSeries8);
        java.lang.Object obj15 = timeSeries8.clone();
        timeSeries8.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 2);
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.next();
        timeSeries1.add(regularTimePeriod8, (java.lang.Number) 24234L);
        int int11 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 10, year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        java.lang.String str16 = timeSeries8.getRangeDescription();
        timeSeries8.setMaximumItemCount(11);
        timeSeries8.fireSeriesChanged();
        boolean boolean20 = timeSeries8.getNotify();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#');
        long long2 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        timeSeries8.removeAgedItems(false);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class34);
//        timeSeries35.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries39.removeAgedItems(true);
//        timeSeries39.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries35.addAndOrUpdate(timeSeries39);
//        timeSeries44.setRangeDescription("3-February-1900");
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries8.addAndOrUpdate(timeSeries44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = null;
//        try {
//            int int49 = timeSeries44.getIndex(regularTimePeriod48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(timeSeries47);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int5 = spreadsheetDate4.getDayOfMonth();
        boolean boolean6 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int11 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        int int20 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean28 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26, (int) '#');
        int int29 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int33 = spreadsheetDate32.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean41 = spreadsheetDate35.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39, (int) '#');
        int int42 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        boolean boolean45 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SerialDate serialDate46 = serialDate30.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean47 = spreadsheetDate1.isBefore(serialDate30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-457), 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        java.lang.String str10 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        long long10 = fixedMillisecond7.getMiddleMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedMillisecond7.equals(obj11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond7.previous();
        java.util.Date date15 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.util.Date date17 = day16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date21, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date17, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date15, timeZone24);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date1, timeZone24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date1);
        long long30 = month29.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        java.lang.String str16 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getMiddleMillisecond();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        long long22 = day17.getFirstMillisecond();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = day17.getFirstMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=a]");
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean12 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) '#');
        int int13 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate19, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        boolean boolean38 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, serialDate39);
        try {
            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        timeSeries1.fireSeriesChanged();
//        java.lang.String str30 = timeSeries1.getRangeDescription();
//        java.lang.String str31 = timeSeries1.getDescription();
//        boolean boolean32 = timeSeries1.getNotify();
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getStart();
//        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
//        java.lang.String str16 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int19 = timeSeries18.getMaximumItemCount();
//        timeSeries18.fireSeriesChanged();
//        timeSeries18.fireSeriesChanged();
//        timeSeries18.removeAgedItems((long) 100, false);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries4.setNotify(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        long long31 = fixedMillisecond30.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        long long33 = fixedMillisecond30.getLastMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1561964399999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        long long2 = month1.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = month1.getYear();
//        long long4 = year3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
//        long long6 = year3.getFirstMillisecond();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 10, year3);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getStart();
//        int int15 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
//        int int17 = day13.getDayOfMonth();
//        java.util.Date date18 = day13.getEnd();
//        boolean boolean19 = year3.equals((java.lang.Object) day13);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day13.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries13.setRangeDescription("3-February-1900");
        timeSeries13.setDescription("hi!");
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
        java.lang.String str34 = timeSeries22.getDomainDescription();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        timeSeries13.add(timeSeriesDataItem37, true);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1900);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int3 = month0.compareTo((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass2 = serialDate1.getClass();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 2);
        java.util.List list5 = timeSeries1.getItems();
        java.lang.String str6 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(str6);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        java.lang.Number number30 = timeSeries8.getValue(0);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year32 = month31.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 100, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10.0f + "'", number30.equals(10.0f));
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int6 = timeSeries5.getMaximumItemCount();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
        try {
            timeSeries1.delete(7, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) '#');
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        int int20 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int24 = spreadsheetDate23.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean32 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate30, (int) '#');
        int int33 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean41 = spreadsheetDate35.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39, (int) '#');
        int int42 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean44 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.util.Date date45 = spreadsheetDate13.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries30.addChangeListener(seriesChangeListener33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class38);
//        timeSeries39.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries43.removeAgedItems(true);
//        timeSeries43.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.addAndOrUpdate(timeSeries43);
//        java.lang.Comparable comparable49 = timeSeries48.getKey();
//        timeSeries48.setRangeDescription("Value");
//        java.util.Collection collection52 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
//        long long57 = fixedMillisecond54.getMiddleMillisecond();
//        java.lang.Object obj58 = null;
//        boolean boolean59 = fixedMillisecond54.equals(obj58);
//        long long60 = fixedMillisecond54.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond54.previous();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond54.getLastMillisecond(calendar62);
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond54.getLastMillisecond(calendar64);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.util.Date date72 = day71.getStart();
//        int int73 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) day71);
//        boolean boolean76 = timeSeries75.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener77 = null;
//        timeSeries75.addPropertyChangeListener(propertyChangeListener77);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + "Overwritten values from:  " + "'", comparable49.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        timeSeries1.fireSeriesChanged();
//        java.lang.String str30 = timeSeries1.getRangeDescription();
//        java.lang.Comparable comparable31 = timeSeries1.getKey();
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 0L + "'", comparable31.equals(0L));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        long long5 = year2.getSerialIndex();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((int) (byte) 10, 9999);
        int int16 = year2.compareTo((java.lang.Object) timeSeries15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries4.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        long long27 = fixedMillisecond24.getMiddleMillisecond();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = fixedMillisecond24.equals(obj28);
//        long long30 = fixedMillisecond24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond24.previous();
//        java.util.Date date32 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getStart();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getStart();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date38);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38, timeZone41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date34, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date32, timeZone41);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getStart();
//        int int52 = timeSeries49.getIndex((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day50.previous();
//        int int54 = year44.compareTo((java.lang.Object) regularTimePeriod53);
//        java.lang.Number number55 = null;
//        try {
//            timeSeries4.add(regularTimePeriod53, number55, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int19 = timeSeries18.getMaximumItemCount();
        timeSeries18.fireSeriesChanged();
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries4.addAndOrUpdate(timeSeries18);
        timeSeries4.setRangeDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str4 = seriesException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) '#');
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean27 = spreadsheetDate21.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33, (int) '#');
        boolean boolean36 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean47 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate45, (int) '#');
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = null;
        try {
            boolean boolean53 = spreadsheetDate1.isInRange(serialDate49, serialDate51, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.Year year10 = month8.getYear();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        long long13 = year10.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries15.removeAgedItems(true);
        timeSeries15.setMaximumItemCount((int) 'a');
        long long20 = timeSeries15.getMaximumItemAge();
        timeSeries15.setRangeDescription("hi!");
        java.lang.Class class23 = timeSeries15.getTimePeriodClass();
        java.lang.Class class24 = null;
        java.lang.Class class25 = null;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getStart();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date27, timeZone28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date27, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date34, timeZone37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date34, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date27, timeZone39);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long13, class23);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class23);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        timeSeries14.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries14.addAndOrUpdate(timeSeries18);
        timeSeries18.removeAgedItems(false);
        boolean boolean26 = month9.equals((java.lang.Object) false);
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setMaximumItemCount((int) (byte) 10);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
//        java.lang.String str34 = timeSeries22.getDomainDescription();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year36 = month35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getStart();
//        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
//        java.lang.String str54 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year56 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
//        int int60 = year56.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.util.Date date64 = day63.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
//        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
//        timeSeries8.add(timeSeriesDataItem62, true);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries71.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int76 = timeSeries75.getMaximumItemCount();
//        timeSeries75.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries71.addAndOrUpdate(timeSeries75);
//        java.lang.String str79 = timeSeries71.getDescription();
//        java.lang.Object obj80 = timeSeries71.clone();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries8.addAndOrUpdate(timeSeries71);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        java.util.Date date83 = day82.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond(date83);
//        long long85 = fixedMillisecond84.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = fixedMillisecond84.previous();
//        java.util.Calendar calendar87 = null;
//        fixedMillisecond84.peg(calendar87);
//        try {
//            timeSeries81.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, (double) 1577865599999L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2147483647 + "'", int76 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertNull(str79);
//        org.junit.Assert.assertNotNull(obj80);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560150000000L + "'", long85 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
        java.lang.String str34 = timeSeries22.getDomainDescription();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
        java.lang.String str54 = timeSeries42.getDomainDescription();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year56 = month55.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
        int int60 = year56.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        java.util.Date date64 = day63.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
        timeSeries8.add(timeSeriesDataItem62, true);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries71.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int76 = timeSeries75.getMaximumItemCount();
        timeSeries75.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries71.addAndOrUpdate(timeSeries75);
        java.lang.String str79 = timeSeries71.getDescription();
        java.lang.Object obj80 = timeSeries71.clone();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries8.addAndOrUpdate(timeSeries71);
        try {
            timeSeries81.update(7, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2147483647 + "'", int76 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(obj80);
        org.junit.Assert.assertNotNull(timeSeries81);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.fireSeriesChanged();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getStart();
//        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        long long14 = day10.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 13);
//        java.util.Collection collection17 = timeSeries1.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(collection17);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        long long6 = day4.getSerialIndex();
//        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day4);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
//        timeSeries1.removeAgedItems((-1L), true);
//        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source= ]");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(number7);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        java.lang.String str21 = timeSeries4.getRangeDescription();
//        timeSeries4.setMaximumItemAge((long) (byte) 10);
//        timeSeries4.setRangeDescription("3-February-1900");
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        int int22 = year18.getYear();
        long long23 = year18.getSerialIndex();
        java.util.Date date24 = year18.getEnd();
        int int25 = year18.getYear();
        long long26 = year18.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year18.next();
        java.lang.String str28 = year18.toString();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        java.lang.String str16 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getMiddleMillisecond();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class25);
//        timeSeries26.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries30.removeAgedItems(true);
//        timeSeries30.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries26.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.util.Date date37 = day36.getStart();
//        long long38 = day36.getSerialIndex();
//        java.lang.String str39 = day36.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day36);
//        timeSeries26.setKey((java.lang.Comparable) "3-February-1900");
//        java.lang.Class class43 = timeSeries26.getTimePeriodClass();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        long long45 = month44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 1560150000000L);
//        int int48 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) month44);
//        java.lang.String str49 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries51.removeAgedItems(true);
//        timeSeries51.setMaximumItemCount((int) 'a');
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class59);
//        timeSeries60.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries64.removeAgedItems(true);
//        timeSeries64.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries60.addAndOrUpdate(timeSeries64);
//        timeSeries64.removeAgedItems(false);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        java.util.Date date73 = day72.getStart();
//        long long74 = day72.getSerialIndex();
//        java.lang.String str75 = day72.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day72, (java.lang.Number) 10.0f);
//        java.lang.Number number78 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) day72);
//        long long79 = day72.getFirstMillisecond();
//        timeSeries8.setKey((java.lang.Comparable) long79);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Value" + "'", str49.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 43626L + "'", long74 == 43626L);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "10-June-2019" + "'", str75.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertNull(number78);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560150000000L + "'", long79 == 1560150000000L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int8 = timeSeries7.getMaximumItemCount();
        timeSeries7.setMaximumItemAge((long) 2);
        java.util.List list11 = timeSeries7.getItems();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        timeSeries7.add(regularTimePeriod14, (java.lang.Number) 24234L);
        int int17 = month0.compareTo((java.lang.Object) 24234L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getLastMillisecond();
        int int4 = month0.getMonth();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int6 = timeSeries5.getMaximumItemCount();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries10.setNotify(true);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class16);
//        timeSeries17.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.addAndOrUpdate(timeSeries21);
//        timeSeries21.removeAgedItems(false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.util.Date date30 = day29.getStart();
//        long long31 = day29.getSerialIndex();
//        java.lang.String str32 = day29.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        long long38 = fixedMillisecond37.getSerialIndex();
//        java.util.Date date39 = fixedMillisecond37.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond37.previous();
//        int int41 = timeSeries21.getIndex(regularTimePeriod40);
//        timeSeries10.delete(regularTimePeriod40);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries8.addAndOrUpdate(timeSeries10);
//        boolean boolean44 = timeSeries8.getNotify();
//        timeSeries8.fireSeriesChanged();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries8.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560150000000L + "'", long38 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.Object obj9 = null;
        boolean boolean10 = fixedMillisecond5.equals(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
        java.util.Collection collection14 = timeSeries1.getTimePeriods();
        timeSeries1.setDomainDescription("October");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) '#');
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        int int20 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int21 = spreadsheetDate1.toSerial();
        int int22 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=a]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean15 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21, (int) '#');
        boolean boolean24 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean32 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate30, (int) '#');
        boolean boolean33 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int36 = spreadsheetDate35.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int39 = spreadsheetDate38.getDayOfMonth();
        boolean boolean40 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean49 = spreadsheetDate43.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate47, (int) '#');
        spreadsheetDate47.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate47.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean61 = spreadsheetDate55.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate59, (int) '#');
        spreadsheetDate59.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean71 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, (org.jfree.data.time.SerialDate) spreadsheetDate69, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean79 = spreadsheetDate73.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate75, (org.jfree.data.time.SerialDate) spreadsheetDate77, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean87 = spreadsheetDate81.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate83, (org.jfree.data.time.SerialDate) spreadsheetDate85, (int) '#');
        boolean boolean88 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate73, (org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean89 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate59, (org.jfree.data.time.SerialDate) spreadsheetDate81);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean91 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        int int22 = year18.getYear();
        long long23 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year18.previous();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean15 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21, (int) '#');
        boolean boolean24 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean34 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate32, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean42 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean50 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate48, (int) '#');
        boolean boolean51 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean52 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean61 = spreadsheetDate55.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate59, (int) '#');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean70 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate66, (org.jfree.data.time.SerialDate) spreadsheetDate68, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean78 = spreadsheetDate72.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate74, (org.jfree.data.time.SerialDate) spreadsheetDate76, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate84 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean86 = spreadsheetDate80.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate82, (org.jfree.data.time.SerialDate) spreadsheetDate84, (int) '#');
        boolean boolean87 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate72, (org.jfree.data.time.SerialDate) spreadsheetDate80);
        boolean boolean89 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate72, (int) (short) 10);
        int int90 = spreadsheetDate57.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 3 + "'", int90 == 3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate6, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean24 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate22, (int) '#');
        boolean boolean25 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean33 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, (int) '#');
        boolean boolean34 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean42 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean50 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate48, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean58 = spreadsheetDate52.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate56, (int) '#');
        boolean boolean59 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate44, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean69 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, (org.jfree.data.time.SerialDate) spreadsheetDate67, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean77 = spreadsheetDate71.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate73, (org.jfree.data.time.SerialDate) spreadsheetDate75, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean85 = spreadsheetDate79.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate81, (org.jfree.data.time.SerialDate) spreadsheetDate83, (int) '#');
        boolean boolean86 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate71, (org.jfree.data.time.SerialDate) spreadsheetDate79);
        boolean boolean87 = spreadsheetDate52.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate61, (org.jfree.data.time.SerialDate) spreadsheetDate79);
        org.jfree.data.time.SerialDate serialDate88 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.addYears(1900, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate89);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        int int17 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 100);
        java.lang.String str21 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year23 = month22.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries1.add(timeSeriesDataItem24, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem24.getPeriod();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        int int12 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        int int21 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int25 = spreadsheetDate24.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean33 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, (int) '#');
        int int34 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean42 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean50 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate48, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean58 = spreadsheetDate52.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate56, (int) '#');
        boolean boolean59 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate44, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean61 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        long long13 = timeSeries8.getMaximumItemAge();
//        timeSeries8.setRangeDescription("hi!");
//        java.lang.Class class16 = timeSeries8.getTimePeriodClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "3-February-1900", "2019", class16);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = month19.getYear();
//        long long22 = year21.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class27);
//        timeSeries28.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries32.removeAgedItems(true);
//        timeSeries32.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries28.addAndOrUpdate(timeSeries32);
//        timeSeries32.removeAgedItems(false);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getStart();
//        long long42 = day40.getSerialIndex();
//        java.lang.String str43 = day40.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 10.0f);
//        int int46 = year21.compareTo((java.lang.Object) timeSeries32);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.util.Date date48 = day47.getStart();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.Year year51 = month50.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 5);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class57);
//        timeSeries58.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries62.removeAgedItems(true);
//        timeSeries62.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.addAndOrUpdate(timeSeries62);
//        timeSeries62.removeAgedItems(false);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.util.Date date71 = day70.getStart();
//        long long72 = day70.getSerialIndex();
//        java.lang.String str73 = day70.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day70, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day70.next();
//        int int77 = day70.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day70.previous();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month50, (org.jfree.data.time.RegularTimePeriod) day70);
//        int int80 = day70.getMonth();
//        java.lang.String str81 = day70.toString();
//        java.util.Calendar calendar82 = null;
//        try {
//            day70.peg(calendar82);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 43626L + "'", long72 == 43626L);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "10-June-2019" + "'", str73.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 6 + "'", int80 == 6);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "10-June-2019" + "'", str81.equals("10-June-2019"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        java.util.Collection collection9 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        timeSeries4.setRangeDescription("10-June-2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        long long27 = fixedMillisecond24.getMiddleMillisecond();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = fixedMillisecond24.equals(obj28);
//        long long30 = fixedMillisecond24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond24.previous();
//        java.util.Date date32 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getStart();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getStart();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date38);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38, timeZone41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date34, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date32, timeZone41);
//        boolean boolean45 = timeSeries4.equals((java.lang.Object) year44);
//        java.lang.String str46 = timeSeries4.getDomainDescription();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setMaximumItemCount((int) (short) 0);
//        java.lang.String str21 = timeSeries4.getDescription();
//        java.lang.Class class22 = timeSeries4.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNull(class22);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setMaximumItemCount((int) (byte) 10);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
//        java.lang.String str34 = timeSeries22.getDomainDescription();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year36 = month35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getStart();
//        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
//        java.lang.String str54 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year56 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
//        int int60 = year56.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.util.Date date64 = day63.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
//        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
//        timeSeries8.add(timeSeriesDataItem62, true);
//        timeSeries8.setDomainDescription("Nearest");
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.util.Date date78 = day77.getStart();
//        int int79 = timeSeries76.getIndex((org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day77.next();
//        int int81 = day77.getDayOfMonth();
//        java.util.Date date82 = day77.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day77.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = day77.previous();
//        long long85 = day77.getLastMillisecond();
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
//        long long87 = month86.getFirstMillisecond();
//        org.jfree.data.time.Year year88 = month86.getYear();
//        int int89 = month86.getMonth();
//        int int90 = month86.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day77, (org.jfree.data.time.RegularTimePeriod) month86);
//        org.jfree.data.time.TimeSeries timeSeries92 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day77);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560236399999L + "'", long85 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1559372400000L + "'", long87 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 6 + "'", int90 == 6);
//        org.junit.Assert.assertNotNull(timeSeries91);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        long long3 = year2.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        timeSeries8.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries12.removeAgedItems(true);
//        timeSeries12.setMaximumItemCount((int) 'a');
//        long long17 = timeSeries12.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries12);
//        timeSeries12.setDomainDescription("");
//        int int21 = year2.compareTo((java.lang.Object) timeSeries12);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getStart();
//        int int29 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day27.next();
//        int int31 = day27.getDayOfMonth();
//        java.util.Date date32 = day27.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Year year34 = month33.getYear();
//        long long35 = month33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 10L);
//        try {
//            timeSeries12.add(timeSeriesDataItem37);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        long long13 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getStart();
//        long long17 = day15.getSerialIndex();
//        java.lang.String str18 = day15.toString();
//        int int19 = day15.getDayOfMonth();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 1561964399999L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        long long10 = day8.getSerialIndex();
//        int int11 = day8.getYear();
//        org.jfree.data.time.SerialDate serialDate12 = day8.getSerialDate();
//        boolean boolean13 = spreadsheetDate5.isOnOrAfter(serialDate12);
//        int int14 = spreadsheetDate5.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        boolean boolean50 = spreadsheetDate17.isAfter(serialDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int53 = spreadsheetDate52.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean61 = spreadsheetDate55.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate59, (int) '#');
        int int62 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean70 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate66, (org.jfree.data.time.SerialDate) spreadsheetDate68, (int) '#');
        int int71 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate64);
        boolean boolean72 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        try {
            org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate17.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getFirstMillisecond();
        org.jfree.data.time.Year year3 = month1.getYear();
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 10, year3);
        long long8 = year3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "May" + "'", str1.equals("May"));
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setMaximumItemCount((int) (short) 0);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class24);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getStart();
//        int int33 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day31.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 100);
//        java.lang.String str37 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year39 = month38.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year39.next();
//        long long43 = year39.getFirstMillisecond();
//        int int44 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
//        java.util.Calendar calendar45 = null;
//        try {
//            long long46 = year39.getFirstMillisecond(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 2019, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        boolean boolean22 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean32 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate30, (int) '#');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate33);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate34);
        int int36 = spreadsheetDate9.compare(serialDate34);
        int int37 = spreadsheetDate9.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-3) + "'", int36 == (-3));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 35 + "'", int37 == 35);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        timeSeries30.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        long long38 = fixedMillisecond37.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond37.previous();
//        long long40 = fixedMillisecond37.getLastMillisecond();
//        long long41 = fixedMillisecond37.getMiddleMillisecond();
//        int int42 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class46);
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.util.Date date54 = day53.getStart();
//        int int55 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day53.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 100);
//        java.lang.String str59 = timeSeries47.getDomainDescription();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year61 = month60.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year61);
//        java.lang.Number number63 = timeSeriesDataItem62.getValue();
//        java.lang.Object obj64 = timeSeriesDataItem62.clone();
//        timeSeries30.add(timeSeriesDataItem62);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries67.removeAgedItems(true);
//        timeSeries67.setMaximumItemCount((int) 'a');
//        long long72 = timeSeries67.getMaximumItemAge();
//        timeSeries67.setRangeDescription("hi!");
//        java.lang.Class class75 = timeSeries67.getTimePeriodClass();
//        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize(class75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.util.Date date78 = day77.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond(date78);
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance(date78);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        java.util.Date date82 = day81.getStart();
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date82);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        java.util.Date date86 = day85.getStart();
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date86);
//        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date86);
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date86, timeZone89);
//        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month(date82, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date78, timeZone89);
//        java.util.Date date93 = regularTimePeriod92.getEnd();
//        java.lang.Number number94 = timeSeries30.getValue(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560150000000L + "'", long38 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 100 + "'", number63.equals(100));
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class75);
//        org.junit.Assert.assertNotNull(class76);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 100 + "'", number94.equals(100));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        long long7 = timeSeries4.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.removeChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getTime();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3, timeZone6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1, timeZone6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.Year year11 = month9.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.previous();
        long long14 = year11.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries16.removeAgedItems(true);
        timeSeries16.setMaximumItemCount((int) 'a');
        long long21 = timeSeries16.getMaximumItemAge();
        timeSeries16.setRangeDescription("hi!");
        java.lang.Class class24 = timeSeries16.getTimePeriodClass();
        java.lang.Class class25 = null;
        java.lang.Class class26 = null;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date28, timeZone29);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date28, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date28);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date35);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date35, timeZone38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date35, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone40);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long14, class24);
        java.lang.Class class45 = null;
        java.lang.Class class46 = null;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        java.util.Date date48 = day47.getStart();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date48, timeZone49);
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date48, timeZone51);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        java.util.Date date55 = day54.getStart();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        java.util.Date date59 = day58.getStart();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date59);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date59, timeZone62);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date55, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date48, timeZone62);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date1, timeZone62);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        int int32 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 100);
        java.lang.String str36 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.next();
        int int42 = year38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (double) 11);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getStart();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        java.util.Date date50 = day49.getStart();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month55.next();
        boolean boolean57 = year38.equals((java.lang.Object) month55);
        int int58 = year38.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year38.next();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.Object obj9 = null;
        boolean boolean10 = fixedMillisecond5.equals(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getMiddleMillisecond();
        java.lang.String str4 = month0.toString();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Year year7 = month5.getYear();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        long long10 = year7.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries12.removeAgedItems(true);
        timeSeries12.setMaximumItemCount((int) 'a');
        long long17 = timeSeries12.getMaximumItemAge();
        timeSeries12.setRangeDescription("hi!");
        java.lang.Class class20 = timeSeries12.getTimePeriodClass();
        java.lang.Class class21 = null;
        java.lang.Class class22 = null;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getStart();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date24, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31, timeZone34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date31, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone36);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class20);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, class41);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(class41);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class6);
        timeSeries7.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries11.removeAgedItems(true);
        timeSeries11.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries7.addAndOrUpdate(timeSeries11);
        boolean boolean17 = timeSeries7.getNotify();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.Year year20 = month18.getYear();
        long long21 = year20.getLastMillisecond();
        int int22 = year20.getYear();
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        int int24 = month0.compareTo((java.lang.Object) year20);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        int int4 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean12 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        spreadsheetDate18.setDescription("hi!");
        boolean boolean23 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int26 = spreadsheetDate25.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean34 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate32, (int) '#');
        int int35 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean36 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        try {
            org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        java.lang.String str16 = timeSeries8.getRangeDescription();
        timeSeries8.setMaximumItemCount(11);
        timeSeries8.clear();
        java.util.List list20 = timeSeries8.getItems();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertNotNull(list20);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        long long6 = fixedMillisecond2.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        long long11 = fixedMillisecond8.getMiddleMillisecond();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = fixedMillisecond8.equals(obj12);
//        long long14 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.previous();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond8.getLastMillisecond(calendar16);
//        boolean boolean18 = fixedMillisecond2.equals((java.lang.Object) long17);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, 97, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        boolean boolean50 = spreadsheetDate17.isAfter(serialDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean60 = spreadsheetDate54.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, (org.jfree.data.time.SerialDate) spreadsheetDate58, (int) '#');
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate61);
        boolean boolean63 = spreadsheetDate17.isAfter(serialDate62);
        serialDate62.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-28800000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=2,startDay=8,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=3,endMonth=10,endDay=1,endDayOfWeek=1,endTime=7200000,endTimeMode=0]]]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) throwableArray12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date1, timeZone11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone11);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        long long6 = day4.getSerialIndex();
//        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day4);
//        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=a]");
//        boolean boolean10 = timeSeries1.isEmpty();
//        timeSeries1.setMaximumItemCount(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
//        long long17 = fixedMillisecond14.getMiddleMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond14.getLastMillisecond(calendar18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem(regularTimePeriod20);
//        java.lang.Comparable comparable22 = timeSeries1.getKey();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getFirstMillisecond();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        long long26 = year25.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class31);
//        timeSeries32.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries36.removeAgedItems(true);
//        timeSeries36.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.addAndOrUpdate(timeSeries36);
//        timeSeries36.removeAgedItems(false);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.util.Date date45 = day44.getStart();
//        long long46 = day44.getSerialIndex();
//        java.lang.String str47 = day44.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) 10.0f);
//        int int50 = year25.compareTo((java.lang.Object) timeSeries36);
//        int int51 = year25.getYear();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year25, (double) 1577865599999L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 0L + "'", comparable22.equals(0L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10-June-2019" + "'", str47.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond2.peg(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond2.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
        java.lang.String str34 = timeSeries22.getDomainDescription();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
        java.lang.String str54 = timeSeries42.getDomainDescription();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year56 = month55.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
        int int60 = year56.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        java.util.Date date64 = day63.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
        timeSeries8.add(timeSeriesDataItem62, true);
        int int70 = timeSeries8.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date1);
//        int int12 = day11.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) 0, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        long long30 = month29.getFirstMillisecond();
//        long long31 = month29.getLastMillisecond();
//        java.util.Date date32 = month29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        boolean boolean35 = timeSeries1.equals((java.lang.Object) date32);
//        java.lang.String str36 = timeSeries1.getDomainDescription();
//        timeSeries1.setNotify(false);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day25);
        boolean boolean28 = year18.equals((java.lang.Object) timeSeries24);
        java.util.Date date29 = year18.getStart();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = month0.equals(obj1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
//        int int5 = month0.compareTo((java.lang.Object) 1560668399999L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        long long10 = fixedMillisecond8.getSerialIndex();
//        int int11 = month0.compareTo((java.lang.Object) long10);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        java.util.Date date10 = day5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getLastMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day5.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        java.lang.String str16 = timeSeries8.getRangeDescription();
        timeSeries8.setMaximumItemCount(11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries8.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        int int12 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean28 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean36 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate34, (int) '#');
        boolean boolean37 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(10, serialDate38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        int int16 = timeSeries8.getItemCount();
        timeSeries8.setMaximumItemCount(0);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        int int31 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 100);
        java.lang.String str35 = timeSeries23.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year37 = month36.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class42);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        java.util.Date date50 = day49.getStart();
        int int51 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day49.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 100);
        java.lang.String str55 = timeSeries43.getDomainDescription();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year57 = month56.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) year57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year57.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year57.next();
        int int61 = year57.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year57, (double) 11);
        timeSeries8.add(timeSeriesDataItem63, true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
        timeSeries8.removeChangeListener(seriesChangeListener66);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
        org.junit.Assert.assertNotNull(year57);
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        int int4 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date12, timeZone18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date12);
        boolean boolean23 = month10.equals((java.lang.Object) serialDate22);
        java.lang.String str24 = month10.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "December 1969" + "'", str24.equals("December 1969"));
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond2.getFirstMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond2.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        int int22 = day16.getDayOfMonth();
//        int int23 = day16.getDayOfMonth();
//        int int24 = day16.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Nearest");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        java.lang.String str8 = spreadsheetDate1.getDescription();
        java.util.Date date9 = spreadsheetDate1.toDate();
        int int10 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        long long15 = fixedMillisecond12.getMiddleMillisecond();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond12.getLastMillisecond(calendar16);
        try {
            int int18 = spreadsheetDate1.compareTo((java.lang.Object) long17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        timeSeries8.setDomainDescription("10-June-2019");
        java.lang.String str18 = timeSeries8.getDomainDescription();
        timeSeries8.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        boolean boolean21 = timeSeries8.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries13.setRangeDescription("3-February-1900");
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        long long20 = fixedMillisecond17.getMiddleMillisecond();
        java.util.Calendar calendar21 = null;
        fixedMillisecond17.peg(calendar21);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond17.getLastMillisecond(calendar23);
        long long25 = fixedMillisecond17.getSerialIndex();
        int int26 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        int int22 = year18.getYear();
        long long23 = year18.getFirstMillisecond();
        java.util.Date date24 = year18.getEnd();
        int int26 = year18.compareTo((java.lang.Object) 1560236399999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) ' ');
//        int int10 = day0.compareTo((java.lang.Object) seriesChangeEvent9);
//        int int11 = day0.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.lang.String str7 = fixedMillisecond1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        long long13 = fixedMillisecond10.getMiddleMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = fixedMillisecond10.equals(obj14);
        long long16 = fixedMillisecond10.getSerialIndex();
        boolean boolean17 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        long long13 = timeSeries8.getMaximumItemAge();
//        timeSeries8.setRangeDescription("hi!");
//        java.lang.Class class16 = timeSeries8.getTimePeriodClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "3-February-1900", "2019", class16);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = month19.getYear();
//        long long22 = year21.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class27);
//        timeSeries28.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries32.removeAgedItems(true);
//        timeSeries32.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries28.addAndOrUpdate(timeSeries32);
//        timeSeries32.removeAgedItems(false);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getStart();
//        long long42 = day40.getSerialIndex();
//        java.lang.String str43 = day40.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 10.0f);
//        int int46 = year21.compareTo((java.lang.Object) timeSeries32);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.util.Date date48 = day47.getStart();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.Year year51 = month50.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 5);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class57);
//        timeSeries58.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries62.removeAgedItems(true);
//        timeSeries62.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.addAndOrUpdate(timeSeries62);
//        timeSeries62.removeAgedItems(false);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.util.Date date71 = day70.getStart();
//        long long72 = day70.getSerialIndex();
//        java.lang.String str73 = day70.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day70, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day70.next();
//        int int77 = day70.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day70.previous();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month50, (org.jfree.data.time.RegularTimePeriod) day70);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        java.util.Date date81 = day80.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(date81);
//        long long83 = fixedMillisecond82.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond82.previous();
//        long long85 = fixedMillisecond82.getLastMillisecond();
//        long long86 = fixedMillisecond82.getFirstMillisecond();
//        java.util.Date date87 = fixedMillisecond82.getTime();
//        long long88 = fixedMillisecond82.getMiddleMillisecond();
//        long long89 = fixedMillisecond82.getFirstMillisecond();
//        java.util.Calendar calendar90 = null;
//        long long91 = fixedMillisecond82.getMiddleMillisecond(calendar90);
//        try {
//            timeSeries18.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond82, (java.lang.Number) 1546329600000L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 43626L + "'", long72 == 43626L);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "10-June-2019" + "'", str73.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560150000000L + "'", long83 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560150000000L + "'", long85 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560150000000L + "'", long86 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560150000000L + "'", long88 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1560150000000L + "'", long89 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560150000000L + "'", long91 == 1560150000000L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (byte) 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        java.lang.Class class21 = timeSeries4.getTimePeriodClass();
//        java.lang.Object obj22 = timeSeries4.clone();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        int int25 = month23.compareTo((java.lang.Object) 4);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getStart();
//        int int33 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        long long35 = day31.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate36 = day31.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day31.previous();
//        int int38 = month23.compareTo((java.lang.Object) day31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        int int5 = year1.getYear();
        long long6 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        timeSeries4.setRangeDescription("10-June-2019");
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        timeSeries27.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries31.removeAgedItems(true);
//        timeSeries31.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.addAndOrUpdate(timeSeries31);
//        timeSeries31.removeAgedItems(false);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getStart();
//        long long41 = day39.getSerialIndex();
//        java.lang.String str42 = day39.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.util.Date date46 = day45.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        long long48 = fixedMillisecond47.getSerialIndex();
//        java.util.Date date49 = fixedMillisecond47.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond47.previous();
//        int int51 = timeSeries31.getIndex(regularTimePeriod50);
//        timeSeries31.removeAgedItems(false);
//        java.util.Collection collection54 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries4.createCopy(0, (int) 'a');
//        boolean boolean58 = timeSeries4.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener59);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560150000000L + "'", long48 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(collection54);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        java.lang.String str3 = month0.toString();
        int int4 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        long long3 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
//        timeSeries9.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries13.removeAgedItems(true);
//        timeSeries13.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.addAndOrUpdate(timeSeries13);
//        timeSeries13.removeAgedItems(false);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        long long23 = day21.getSerialIndex();
//        java.lang.String str24 = day21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 10.0f);
//        int int27 = year2.compareTo((java.lang.Object) timeSeries13);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
//        org.jfree.data.time.Year year32 = month31.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 5);
//        long long35 = month31.getFirstMillisecond();
//        long long36 = month31.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        int int17 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 100);
        java.lang.String str21 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year23 = month22.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries1.add(timeSeriesDataItem24, true);
        timeSeriesDataItem24.setValue((java.lang.Number) 1900);
        java.lang.Number number29 = timeSeriesDataItem24.getValue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1900 + "'", number29.equals(1900));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        long long6 = day4.getSerialIndex();
//        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day4);
//        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=a]");
//        boolean boolean10 = timeSeries1.isEmpty();
//        timeSeries1.setMaximumItemCount(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
//        long long17 = fixedMillisecond14.getMiddleMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond14.getLastMillisecond(calendar18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem(regularTimePeriod20);
//        java.lang.Comparable comparable22 = timeSeries1.getKey();
//        java.lang.String str23 = timeSeries1.getDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 0L + "'", comparable22.equals(0L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, (int) '#');
        int int12 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        int int21 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int25 = spreadsheetDate24.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean33 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, (int) '#');
        int int34 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        boolean boolean37 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate38 = serialDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        try {
            org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        timeSeries8.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries12.removeAgedItems(true);
//        timeSeries12.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries8.addAndOrUpdate(timeSeries12);
//        timeSeries12.removeAgedItems(false);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        long long22 = day20.getSerialIndex();
//        java.lang.String str23 = day20.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        long long29 = fixedMillisecond28.getSerialIndex();
//        java.util.Date date30 = fixedMillisecond28.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.previous();
//        int int32 = timeSeries12.getIndex(regularTimePeriod31);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int35 = timeSeries34.getMaximumItemCount();
//        java.util.Collection collection36 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries34.addChangeListener(seriesChangeListener37);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class42);
//        timeSeries43.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries47.removeAgedItems(true);
//        timeSeries47.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries43.addAndOrUpdate(timeSeries47);
//        java.lang.Comparable comparable53 = timeSeries52.getKey();
//        timeSeries52.setRangeDescription("Value");
//        java.util.Collection collection56 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond58.getLastMillisecond(calendar59);
//        long long61 = fixedMillisecond58.getMiddleMillisecond();
//        java.lang.Object obj62 = null;
//        boolean boolean63 = fixedMillisecond58.equals(obj62);
//        long long64 = fixedMillisecond58.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond58.previous();
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond58.getLastMillisecond(calendar66);
//        java.util.Calendar calendar68 = null;
//        long long69 = fixedMillisecond58.getLastMillisecond(calendar68);
//        java.lang.Class class73 = null;
//        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        java.util.Date date76 = day75.getStart();
//        int int77 = timeSeries74.getIndex((org.jfree.data.time.RegularTimePeriod) day75);
//        org.jfree.data.time.SerialDate serialDate78 = day75.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (org.jfree.data.time.RegularTimePeriod) day75);
//        boolean boolean80 = year0.equals((java.lang.Object) fixedMillisecond58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + "Overwritten values from:  " + "'", comparable53.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getFirstMillisecond();
        org.jfree.data.time.Year year3 = month1.getYear();
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 10, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) (short) 0);
        timeSeries1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        long long11 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getLastMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.previous();
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries4.createCopy((int) (byte) 10, 9999);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        timeSeries14.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setMaximumItemCount((int) 'a');
        long long23 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.addAndOrUpdate(timeSeries18);
        boolean boolean26 = timeSeries9.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.util.Date date48 = spreadsheetDate17.toDate();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries50.removeAgedItems(true);
        timeSeries50.setMaximumItemCount((int) 'a');
        long long55 = timeSeries50.getMaximumItemAge();
        timeSeries50.setRangeDescription("hi!");
        java.lang.Class class58 = timeSeries50.getTimePeriodClass();
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize(class58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        java.util.Date date61 = day60.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date61);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        java.util.Date date65 = day64.getStart();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date65);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        java.util.Date date69 = day68.getStart();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date69);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date69, timeZone72);
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date65, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date61, timeZone72);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date48, timeZone72);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9223372036854775807L + "'", long55 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int6 = timeSeries5.getMaximumItemCount();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
//        timeSeries13.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries17.removeAgedItems(true);
//        timeSeries17.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        long long25 = day23.getSerialIndex();
//        java.lang.String str26 = day23.toString();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day23);
//        timeSeries13.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getFirstMillisecond();
//        org.jfree.data.time.Year year32 = month30.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries13.addOrUpdate(regularTimePeriod33, (java.lang.Number) 11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries8.getDataItem(regularTimePeriod33);
//        java.util.Date date37 = regularTimePeriod33.getEnd();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(date37);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Number number20 = timeSeriesDataItem19.getValue();
        java.lang.Object obj21 = timeSeriesDataItem19.clone();
        java.lang.Object obj22 = timeSeriesDataItem19.clone();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100 + "'", number20.equals(100));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        int int16 = timeSeries8.getItemCount();
        timeSeries8.setMaximumItemCount(0);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        int int31 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 100);
        java.lang.String str35 = timeSeries23.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year37 = month36.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class42);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        java.util.Date date50 = day49.getStart();
        int int51 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day49.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 100);
        java.lang.String str55 = timeSeries43.getDomainDescription();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year57 = month56.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) year57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year57.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year57.next();
        int int61 = year57.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year57, (double) 11);
        timeSeries8.add(timeSeriesDataItem63, true);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries67.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
        long long74 = fixedMillisecond71.getMiddleMillisecond();
        java.lang.Object obj75 = null;
        boolean boolean76 = fixedMillisecond71.equals(obj75);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries67.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (java.lang.Number) 0.0f);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
        java.util.Date date81 = day80.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(date81);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date81);
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate83);
        boolean boolean85 = fixedMillisecond71.equals((java.lang.Object) 5);
        java.util.Calendar calendar86 = null;
        fixedMillisecond71.peg(calendar86);
        try {
            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
        org.junit.Assert.assertNotNull(year57);
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries5.removeAgedItems(true);
        timeSeries5.setMaximumItemCount((int) 'a');
        long long10 = timeSeries5.getMaximumItemAge();
        timeSeries5.setRangeDescription("hi!");
        java.lang.Class class13 = timeSeries5.getTimePeriodClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int5 = spreadsheetDate4.getDayOfMonth();
        boolean boolean6 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean15 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13, (int) '#');
        spreadsheetDate13.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate13.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean27 = spreadsheetDate21.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) '#');
        spreadsheetDate25.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean53 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate49, (org.jfree.data.time.SerialDate) spreadsheetDate51, (int) '#');
        boolean boolean54 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate39, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean55 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int56 = spreadsheetDate25.toSerial();
        org.jfree.data.time.SerialDate serialDate57 = null;
        try {
            boolean boolean59 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate57, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 35 + "'", int56 == 35);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560149999999L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day25);
        boolean boolean28 = year18.equals((java.lang.Object) timeSeries24);
        long long29 = year18.getSerialIndex();
        long long30 = year18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.Class class0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3);
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.lang.String str7 = fixedMillisecond1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-3));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getStart();
//        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
//        int int14 = day10.getDayOfMonth();
//        java.util.Date date15 = day10.getEnd();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        org.jfree.data.time.Year year17 = month16.getYear();
//        java.util.Date date18 = year17.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 6);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        long long13 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.addAndOrUpdate(timeSeries8);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class18);
//        timeSeries19.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries23.removeAgedItems(true);
//        timeSeries23.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.addAndOrUpdate(timeSeries23);
//        timeSeries23.removeAgedItems(false);
//        timeSeries23.setDomainDescription("10-June-2019");
//        java.lang.String str33 = timeSeries23.getDomainDescription();
//        timeSeries23.removeAgedItems((long) 1900, true);
//        java.util.Collection collection37 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class41);
//        timeSeries42.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries46.removeAgedItems(true);
//        timeSeries46.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries42.addAndOrUpdate(timeSeries46);
//        timeSeries46.removeAgedItems(false);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.util.Date date55 = day54.getStart();
//        long long56 = day54.getSerialIndex();
//        java.lang.String str57 = day54.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.util.Date date61 = day60.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date61);
//        long long63 = fixedMillisecond62.getSerialIndex();
//        java.util.Date date64 = fixedMillisecond62.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond62.previous();
//        int int66 = timeSeries46.getIndex(regularTimePeriod65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = timeSeries46.getNextTimePeriod();
//        timeSeries23.add(regularTimePeriod67, (double) 11, true);
//        boolean boolean71 = timeSeries23.isEmpty();
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 43626L + "'", long56 == 43626L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560150000000L + "'", long63 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) (byte) 0);
//        java.lang.Object obj31 = timeSeriesDataItem30.clone();
//        java.lang.Object obj32 = timeSeriesDataItem30.clone();
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertNotNull(obj32);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        java.util.Date date12 = spreadsheetDate5.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getFollowingDayOfWeek(1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 2);
        java.util.List list5 = timeSeries1.getItems();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(list5);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) ' ');
//        int int10 = day0.compareTo((java.lang.Object) seriesChangeEvent9);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        java.util.List list16 = timeSeries8.getItems();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-459), (int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.setMaximumItemAge((long) (short) 0);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        long long7 = day5.getSerialIndex();
//        java.lang.String str8 = day5.toString();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day5, (double) 3);
//        int int11 = day5.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean9 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate7, (int) '#');
        spreadsheetDate7.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate7.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate19, (int) '#');
        spreadsheetDate19.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean31 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean39 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate37, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean47 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate45, (int) '#');
        boolean boolean48 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean49 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        boolean boolean52 = spreadsheetDate19.isAfter(serialDate51);
        boolean boolean53 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.Object obj54 = null;
        try {
            int int55 = spreadsheetDate1.compareTo(obj54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        long long9 = year8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
//        long long11 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries13.removeAgedItems(true);
//        timeSeries13.setMaximumItemCount((int) 'a');
//        long long18 = timeSeries13.getMaximumItemAge();
//        timeSeries13.setRangeDescription("hi!");
//        java.lang.Class class21 = timeSeries13.getTimePeriodClass();
//        java.lang.Class class22 = null;
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date25, timeZone28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date25);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getStart();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date32, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date25, timeZone37);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, class21);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class42);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(class42);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        long long3 = month0.getLastMillisecond();
        long long4 = month0.getSerialIndex();
        long long5 = month0.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
        timeSeries8.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries12.removeAgedItems(true);
        timeSeries12.setMaximumItemCount((int) 'a');
        long long17 = timeSeries12.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries12);
        timeSeries12.setDomainDescription("");
        int int21 = year2.compareTo((java.lang.Object) timeSeries12);
        int int22 = year2.getYear();
        java.lang.String str23 = year2.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getLastMillisecond(calendar5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        java.lang.String str2 = timeSeries1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Date date2 = day0.getStart();
        int int3 = day0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560149999999L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        java.util.Date date10 = day5.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Year year12 = month11.getYear();
//        long long13 = month11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 10L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, 8.0d);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class4);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        int int13 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 100);
        java.lang.String str17 = timeSeries5.getDomainDescription();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year19 = month18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.next();
        int int23 = year19.getYear();
        long long24 = year19.getSerialIndex();
        java.util.Date date25 = year19.getEnd();
        int int26 = year19.getYear();
        long long27 = year19.getSerialIndex();
        try {
            org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) ' ', year19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        int int7 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        long long6 = timeSeries1.getMaximumItemAge();
        timeSeries1.setRangeDescription("hi!");
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.lang.Class class10 = null;
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date13, timeZone16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date13, timeZone25);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date30, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date30, timeZone35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date13, timeZone35);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone35);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond2.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = year4.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        int int22 = year18.getYear();
        long long23 = year18.getSerialIndex();
        java.util.Date date24 = year18.getEnd();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        org.jfree.data.time.Year year27 = month25.getYear();
        boolean boolean28 = year18.equals((java.lang.Object) year27);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year27.getMiddleMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int5 = spreadsheetDate4.getDayOfMonth();
        boolean boolean6 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            int int8 = spreadsheetDate1.compareTo((java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        long long24 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond21.getLastMillisecond(calendar25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long26);
        boolean boolean28 = timeSeriesDataItem19.equals((java.lang.Object) long26);
        java.lang.Number number29 = timeSeriesDataItem19.getValue();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100 + "'", number29.equals(100));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod22, (double) 8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        int int27 = spreadsheetDate26.getDayOfMonth();
//        int int28 = spreadsheetDate26.getDayOfWeek();
//        boolean boolean29 = timeSeriesDataItem24.equals((java.lang.Object) int28);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.util.Date date0 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries2.removeAgedItems(true);
        timeSeries2.setMaximumItemCount((int) 'a');
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.setRangeDescription("hi!");
        java.lang.Class class10 = timeSeries2.getTimePeriodClass();
        java.lang.Class class11 = null;
        java.lang.Class class12 = null;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date21, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date21, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone26);
        try {
            org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date0, timeZone26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond1.peg(calendar11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.Object obj9 = null;
        boolean boolean10 = fixedMillisecond5.equals(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
        java.lang.String str14 = regularTimePeriod13.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str14.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = null;
        try {
            timeSeries21.add(timeSeriesDataItem22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean18 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, (int) '#');
        boolean boolean20 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate16, 100);
        java.lang.String str21 = spreadsheetDate16.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(9, (org.jfree.data.time.SerialDate) spreadsheetDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries30.addChangeListener(seriesChangeListener33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class38);
//        timeSeries39.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries43.removeAgedItems(true);
//        timeSeries43.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.addAndOrUpdate(timeSeries43);
//        java.lang.Comparable comparable49 = timeSeries48.getKey();
//        timeSeries48.setRangeDescription("Value");
//        java.util.Collection collection52 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
//        long long57 = fixedMillisecond54.getMiddleMillisecond();
//        java.lang.Object obj58 = null;
//        boolean boolean59 = fixedMillisecond54.equals(obj58);
//        long long60 = fixedMillisecond54.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond54.previous();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond54.getLastMillisecond(calendar62);
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond54.getLastMillisecond(calendar64);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.util.Date date72 = day71.getStart();
//        int int73 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
//        long long77 = month76.getFirstMillisecond();
//        int int78 = month76.getYearValue();
//        org.jfree.data.time.Year year79 = month76.getYear();
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year79);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year79, (double) 4);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + "Overwritten values from:  " + "'", comparable49.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1559372400000L + "'", long77 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//        org.junit.Assert.assertNotNull(year79);
//        org.junit.Assert.assertNull(timeSeriesDataItem82);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December 1969");
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        java.util.Date date10 = day5.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month11);
//        java.lang.String str13 = month11.toString();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        java.lang.String str16 = timeSeries8.getRangeDescription();
        timeSeries8.setMaximumItemCount(11);
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date21, timeZone26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) 10.0f);
        int int31 = day28.getYear();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        long long2 = month1.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = month1.getYear();
//        long long4 = year3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
//        long long6 = year3.getFirstMillisecond();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 10, year3);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getStart();
//        int int15 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
//        int int17 = day13.getDayOfMonth();
//        java.util.Date date18 = day13.getEnd();
//        boolean boolean19 = year3.equals((java.lang.Object) day13);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = year3.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int6 = timeSeries5.getMaximumItemCount();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        long long12 = fixedMillisecond11.getSerialIndex();
//        java.util.Date date13 = fixedMillisecond11.getTime();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        int int22 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.next();
//        int int24 = day20.getDayOfMonth();
//        java.util.Date date25 = day20.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        org.jfree.data.time.Year year27 = month26.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (short) 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate39.getFollowingDayOfWeek(3);
        java.util.Date date50 = spreadsheetDate39.toDate();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(date50);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries13.createCopy((int) (byte) 10, 9999);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class22);
        timeSeries23.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries27.removeAgedItems(true);
        timeSeries27.setMaximumItemCount((int) 'a');
        long long32 = timeSeries27.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries23.addAndOrUpdate(timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries18.addAndOrUpdate(timeSeries27);
        int int35 = year8.compareTo((java.lang.Object) timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
        long long40 = fixedMillisecond37.getMiddleMillisecond();
        java.lang.Object obj41 = null;
        boolean boolean42 = fixedMillisecond37.equals(obj41);
        long long43 = fixedMillisecond37.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond37.previous();
        int int45 = timeSeries18.getIndex(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        int int32 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 100);
        java.lang.String str36 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.next();
        int int42 = year38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (double) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year38.next();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        long long16 = timeSeries8.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries8.removeAgedItems(false);
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        int int18 = timeSeries8.getItemCount();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        int int23 = year21.compareTo((java.lang.Object) (byte) -1);
        timeSeries8.setKey((java.lang.Comparable) int23);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Date date9 = fixedMillisecond1.getTime();
        long long10 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class14);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        int int23 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 100);
        java.lang.String str27 = timeSeries15.getDomainDescription();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year29 = month28.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class34);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        java.util.Date date42 = day41.getStart();
        int int43 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 100);
        java.lang.String str47 = timeSeries35.getDomainDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year49 = month48.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year49.next();
        int int53 = year49.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (double) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeriesDataItem55.getPeriod();
        int int57 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries4.createCopy((int) (byte) 10, 9999);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
        timeSeries14.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setMaximumItemCount((int) 'a');
        long long23 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.getDataItem(regularTimePeriod26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean12 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) '#');
        int int13 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate19, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        boolean boolean38 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, serialDate39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(5, serialDate39);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Object obj6 = null;
        boolean boolean7 = month5.equals(obj6);
        long long8 = month5.getLastMillisecond();
        long long9 = month5.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        long long14 = fixedMillisecond11.getMiddleMillisecond();
        java.lang.Object obj15 = null;
        boolean boolean16 = fixedMillisecond11.equals(obj15);
        long long17 = fixedMillisecond11.getLastMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.Year year20 = month18.getYear();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        long long23 = year20.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries25.removeAgedItems(true);
        timeSeries25.setMaximumItemCount((int) 'a');
        long long30 = timeSeries25.getMaximumItemAge();
        timeSeries25.setRangeDescription("hi!");
        java.lang.Class class33 = timeSeries25.getTimePeriodClass();
        java.lang.Class class34 = null;
        java.lang.Class class35 = null;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date37, timeZone38);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date37, timeZone40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        java.util.Date date44 = day43.getStart();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date44, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date37, timeZone49);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long23, class33);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11, class33);
        boolean boolean55 = month5.equals((java.lang.Object) class33);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, class33);
        java.lang.Class class60 = null;
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class60);
        timeSeries61.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries65.removeAgedItems(true);
        timeSeries65.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries61.addAndOrUpdate(timeSeries65);
        timeSeries65.removeAgedItems(false);
        timeSeries65.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries56.addAndOrUpdate(timeSeries65);
        int int76 = month0.compareTo((java.lang.Object) timeSeries56);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int2 = timeSeries1.getMaximumItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        long long6 = day4.getSerialIndex();
//        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day4);
//        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=a]");
//        boolean boolean10 = timeSeries1.isEmpty();
//        timeSeries1.setMaximumItemCount(8);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class16);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        int int25 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 100);
//        java.lang.String str29 = timeSeries17.getDomainDescription();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year31 = month30.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.previous();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
//        int int35 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.Year year13 = month11.getYear();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, year13);
        int int18 = fixedMillisecond1.compareTo((java.lang.Object) month17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month17.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) '#');
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        boolean boolean14 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        spreadsheetDate1.setDescription("Overwritten values from:  ");
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class20);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        int int29 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 100);
        java.lang.String str33 = timeSeries21.getDomainDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year35 = month34.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class40);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        java.util.Date date48 = day47.getStart();
        int int49 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day47.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (java.lang.Number) 100);
        java.lang.String str53 = timeSeries41.getDomainDescription();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year55 = month54.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year55.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year55.next();
        int int59 = year55.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (double) 11);
        try {
            int int62 = spreadsheetDate1.compareTo((java.lang.Object) year55);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        long long30 = month29.getFirstMillisecond();
//        long long31 = month29.getLastMillisecond();
//        java.util.Date date32 = month29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        boolean boolean35 = timeSeries1.equals((java.lang.Object) date32);
//        java.lang.String str36 = timeSeries1.getDomainDescription();
//        java.lang.Class class37 = timeSeries1.getTimePeriodClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        int int9 = day5.getDayOfMonth();
//        java.util.Date date10 = day5.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Year year12 = month11.getYear();
//        long long13 = month11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 10L);
//        java.lang.Number number16 = timeSeriesDataItem15.getValue();
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
//        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10L + "'", number16.equals(10L));
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        java.lang.String str8 = spreadsheetDate1.getDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int13 = spreadsheetDate12.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate19, (int) '#');
        int int22 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean30 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28, (int) '#');
        int int31 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.lang.String str33 = serialDate32.getDescription();
        boolean boolean34 = spreadsheetDate1.isOn(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.String str19 = timeSeries4.getDescription();
//        int int20 = timeSeries4.getItemCount();
//        timeSeries4.setMaximumItemCount(31);
//        timeSeries4.setMaximumItemAge(0L);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        boolean boolean14 = timeSeries4.getNotify();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getFirstMillisecond();
        org.jfree.data.time.Year year17 = month15.getYear();
        long long18 = year17.getLastMillisecond();
        int int19 = year17.getYear();
        java.lang.Number number20 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.previous();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries13.createCopy((int) (byte) 10, 9999);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class22);
        timeSeries23.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries27.removeAgedItems(true);
        timeSeries27.setMaximumItemCount((int) 'a');
        long long32 = timeSeries27.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries23.addAndOrUpdate(timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries18.addAndOrUpdate(timeSeries27);
        int int35 = year8.compareTo((java.lang.Object) timeSeries18);
        long long36 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year8.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries30.addChangeListener(seriesChangeListener33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class38);
//        timeSeries39.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries43.removeAgedItems(true);
//        timeSeries43.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.addAndOrUpdate(timeSeries43);
//        java.lang.Comparable comparable49 = timeSeries48.getKey();
//        timeSeries48.setRangeDescription("Value");
//        java.util.Collection collection52 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
//        long long57 = fixedMillisecond54.getMiddleMillisecond();
//        java.lang.Object obj58 = null;
//        boolean boolean59 = fixedMillisecond54.equals(obj58);
//        long long60 = fixedMillisecond54.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond54.previous();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond54.getLastMillisecond(calendar62);
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond54.getLastMillisecond(calendar64);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.util.Date date72 = day71.getStart();
//        int int73 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) day71);
//        int int76 = day71.getMonth();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + "Overwritten values from:  " + "'", comparable49.equals("Overwritten values from:  "));
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 6 + "'", int76 == 6);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setMaximumItemCount((int) (byte) 10);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
//        java.lang.String str34 = timeSeries22.getDomainDescription();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year36 = month35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getStart();
//        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
//        java.lang.String str54 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year56 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
//        int int60 = year56.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.util.Date date64 = day63.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
//        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
//        timeSeries8.add(timeSeriesDataItem62, true);
//        timeSeries8.setDomainDescription("Nearest");
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.util.Date date78 = day77.getStart();
//        int int79 = timeSeries76.getIndex((org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day77.next();
//        int int81 = day77.getDayOfMonth();
//        java.util.Date date82 = day77.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day77.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = day77.previous();
//        long long85 = day77.getLastMillisecond();
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
//        long long87 = month86.getFirstMillisecond();
//        org.jfree.data.time.Year year88 = month86.getYear();
//        int int89 = month86.getMonth();
//        int int90 = month86.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day77, (org.jfree.data.time.RegularTimePeriod) month86);
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day();
//        java.util.Date date93 = day92.getStart();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day92);
//        int int95 = day92.getYear();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560236399999L + "'", long85 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1559372400000L + "'", long87 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 6 + "'", int90 == 6);
//        org.junit.Assert.assertNotNull(timeSeries91);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 2019 + "'", int95 == 2019);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.addChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        int int22 = year18.getYear();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year18.getMiddleMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int31 = timeSeries30.getMaximumItemCount();
//        java.util.Collection collection32 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        timeSeries30.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        long long38 = fixedMillisecond37.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond37.previous();
//        long long40 = fixedMillisecond37.getLastMillisecond();
//        long long41 = fixedMillisecond37.getMiddleMillisecond();
//        int int42 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class46);
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.util.Date date54 = day53.getStart();
//        int int55 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day53.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 100);
//        java.lang.String str59 = timeSeries47.getDomainDescription();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year61 = month60.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year61);
//        java.lang.Number number63 = timeSeriesDataItem62.getValue();
//        java.lang.Object obj64 = timeSeriesDataItem62.clone();
//        timeSeries30.add(timeSeriesDataItem62);
//        org.jfree.data.general.SeriesException seriesException67 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.String str68 = seriesException67.toString();
//        java.lang.Throwable[] throwableArray69 = seriesException67.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException71 = new org.jfree.data.general.SeriesException("");
//        seriesException67.addSuppressed((java.lang.Throwable) seriesException71);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("");
//        seriesException67.addSuppressed((java.lang.Throwable) timePeriodFormatException74);
//        java.lang.Throwable[] throwableArray76 = timePeriodFormatException74.getSuppressed();
//        boolean boolean77 = timeSeriesDataItem62.equals((java.lang.Object) throwableArray76);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560150000000L + "'", long38 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 100 + "'", number63.equals(100));
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str68.equals("org.jfree.data.general.SeriesException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray69);
//        org.junit.Assert.assertNotNull(throwableArray76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        int int22 = year18.getYear();
        long long23 = year18.getSerialIndex();
        java.util.Date date24 = year18.getEnd();
        int int25 = year18.getYear();
        long long26 = year18.getSerialIndex();
        int int27 = year18.getYear();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1, timeZone6);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries13.createCopy((int) (byte) 10, 9999);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class22);
        timeSeries23.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries27.removeAgedItems(true);
        timeSeries27.setMaximumItemCount((int) 'a');
        long long32 = timeSeries27.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries23.addAndOrUpdate(timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries18.addAndOrUpdate(timeSeries27);
        int int35 = year8.compareTo((java.lang.Object) timeSeries18);
        java.util.List list36 = timeSeries18.getItems();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean15 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21, (int) '#');
        boolean boolean24 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str25 = spreadsheetDate1.toString();
        java.lang.String str26 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3-February-1900" + "'", str25.equals("3-February-1900"));
        org.junit.Assert.assertNull(str26);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        long long13 = timeSeries8.getMaximumItemAge();
//        timeSeries8.setRangeDescription("hi!");
//        java.lang.Class class16 = timeSeries8.getTimePeriodClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "3-February-1900", "2019", class16);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = month19.getYear();
//        long long22 = year21.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class27);
//        timeSeries28.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries32.removeAgedItems(true);
//        timeSeries32.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries28.addAndOrUpdate(timeSeries32);
//        timeSeries32.removeAgedItems(false);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getStart();
//        long long42 = day40.getSerialIndex();
//        java.lang.String str43 = day40.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 10.0f);
//        int int46 = year21.compareTo((java.lang.Object) timeSeries32);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.util.Date date48 = day47.getStart();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.Year year51 = month50.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 5);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class57);
//        timeSeries58.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries62.removeAgedItems(true);
//        timeSeries62.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.addAndOrUpdate(timeSeries62);
//        timeSeries62.removeAgedItems(false);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.util.Date date71 = day70.getStart();
//        long long72 = day70.getSerialIndex();
//        java.lang.String str73 = day70.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day70, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day70.next();
//        int int77 = day70.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day70.previous();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month50, (org.jfree.data.time.RegularTimePeriod) day70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day70, (double) (byte) -1);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 43626L + "'", long72 == 43626L);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "10-June-2019" + "'", str73.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeSeries79);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        long long6 = timeSeries1.getMaximumItemAge();
        timeSeries1.setRangeDescription("hi!");
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((int) (byte) 10, 100);
        timeSeries12.fireSeriesChanged();
        java.lang.Object obj14 = timeSeries12.clone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        long long6 = timeSeries1.getMaximumItemAge();
        timeSeries1.setRangeDescription("hi!");
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.lang.Class class10 = null;
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date13, timeZone16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date13, timeZone25);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = regularTimePeriod28.getMiddleMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getSerialIndex();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        java.util.Date date6 = fixedMillisecond2.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getMiddleMillisecond();
        java.lang.String str4 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        long long6 = month0.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            month0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setMaximumItemCount((int) (byte) 10);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        int int30 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100);
//        java.lang.String str34 = timeSeries22.getDomainDescription();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year36 = month35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class41);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getStart();
//        int int50 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day48.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 100);
//        java.lang.String str54 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year56 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
//        int int60 = year56.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (double) 11);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.util.Date date64 = day63.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
//        int int67 = timeSeriesDataItem62.compareTo((java.lang.Object) date64);
//        timeSeries8.add(timeSeriesDataItem62, true);
//        timeSeries8.setDomainDescription("Nearest");
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.util.Date date78 = day77.getStart();
//        int int79 = timeSeries76.getIndex((org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day77.next();
//        int int81 = day77.getDayOfMonth();
//        java.util.Date date82 = day77.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day77.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = day77.previous();
//        long long85 = day77.getLastMillisecond();
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
//        long long87 = month86.getFirstMillisecond();
//        org.jfree.data.time.Year year88 = month86.getYear();
//        int int89 = month86.getMonth();
//        int int90 = month86.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day77, (org.jfree.data.time.RegularTimePeriod) month86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem94 = timeSeries8.addOrUpdate(regularTimePeriod92, (java.lang.Number) (-2204078400001L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560236399999L + "'", long85 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1559372400000L + "'", long87 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 6 + "'", int90 == 6);
//        org.junit.Assert.assertNotNull(timeSeries91);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test383");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.String str19 = timeSeries4.getDescription();
//        int int20 = timeSeries4.getItemCount();
//        java.lang.Class class21 = timeSeries4.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNull(class21);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        timeSeries4.setRangeDescription("10-June-2019");
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class26);
//        timeSeries27.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries31.removeAgedItems(true);
//        timeSeries31.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.addAndOrUpdate(timeSeries31);
//        timeSeries31.removeAgedItems(false);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getStart();
//        long long41 = day39.getSerialIndex();
//        java.lang.String str42 = day39.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.util.Date date46 = day45.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        long long48 = fixedMillisecond47.getSerialIndex();
//        java.util.Date date49 = fixedMillisecond47.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond47.previous();
//        int int51 = timeSeries31.getIndex(regularTimePeriod50);
//        timeSeries31.removeAgedItems(false);
//        java.util.Collection collection54 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries4.createCopy(0, (int) 'a');
//        java.beans.PropertyChangeListener propertyChangeListener58 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener58);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560150000000L + "'", long48 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(collection54);
//        org.junit.Assert.assertNotNull(timeSeries57);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        long long2 = month0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries4.removeAgedItems(true);
//        timeSeries4.setMaximumItemCount((int) 'a');
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class12);
//        timeSeries13.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries17.removeAgedItems(true);
//        timeSeries17.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
//        timeSeries17.removeAgedItems(false);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        long long27 = day25.getSerialIndex();
//        java.lang.String str28 = day25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 10.0f);
//        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        int int32 = month0.compareTo((java.lang.Object) number31);
//        long long33 = month0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1559372400000L + "'", long33 == 1559372400000L);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date1);
        java.lang.String str11 = year10.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year10.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
        long long7 = fixedMillisecond4.getMiddleMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = fixedMillisecond4.equals(obj8);
        long long10 = fixedMillisecond4.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.Year year13 = month11.getYear();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setMaximumItemCount((int) 'a');
        long long23 = timeSeries18.getMaximumItemAge();
        timeSeries18.setRangeDescription("hi!");
        java.lang.Class class26 = timeSeries18.getTimePeriodClass();
        java.lang.Class class27 = null;
        java.lang.Class class28 = null;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date30, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date37);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37, timeZone40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date37, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone42);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, class26);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, class26);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11, "org.jfree.data.time.TimePeriodFormatException: 2019", "org.jfree.data.general.SeriesException: hi!", class48);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class48);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        long long13 = fixedMillisecond10.getMiddleMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = fixedMillisecond10.equals(obj14);
        long long16 = fixedMillisecond10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond10.previous();
        java.util.Date date18 = fixedMillisecond10.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date24, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date20, timeZone27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date18, timeZone27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date4, timeZone27);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date1, timeZone27);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        long long20 = year18.getSerialIndex();
        java.lang.String str21 = year18.toString();
        long long22 = year18.getLastMillisecond();
        long long23 = year18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        long long30 = month29.getFirstMillisecond();
//        long long31 = month29.getLastMillisecond();
//        java.util.Date date32 = month29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        boolean boolean35 = timeSeries1.equals((java.lang.Object) date32);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries38 = timeSeries1.createCopy((int) (short) 100, 28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        int int7 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        long long9 = day5.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate10 = day5.getSerialDate();
//        java.lang.String str11 = serialDate10.toString();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str11);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        long long13 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.addAndOrUpdate(timeSeries8);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class18);
        timeSeries19.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries23.removeAgedItems(true);
        timeSeries23.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.addAndOrUpdate(timeSeries23);
        timeSeries23.removeAgedItems(false);
        timeSeries23.setDomainDescription("10-June-2019");
        java.lang.String str33 = timeSeries23.getDomainDescription();
        timeSeries23.removeAgedItems((long) 1900, true);
        java.util.Collection collection37 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries23.setMaximumItemAge((long) 1900);
        long long40 = timeSeries23.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1900L + "'", long40 == 1900L);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        long long30 = month29.getFirstMillisecond();
//        long long31 = month29.getLastMillisecond();
//        java.util.Date date32 = month29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        boolean boolean35 = timeSeries1.equals((java.lang.Object) date32);
//        java.lang.String str36 = timeSeries1.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries1.addChangeListener(seriesChangeListener37);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.util.Date date48 = spreadsheetDate17.toDate();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(date48);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate3.getFollowingDayOfWeek(5);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.Year year14 = month12.getYear();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        long long17 = year14.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries19.removeAgedItems(true);
        timeSeries19.setMaximumItemCount((int) 'a');
        long long24 = timeSeries19.getMaximumItemAge();
        timeSeries19.setRangeDescription("hi!");
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        java.lang.Class class28 = null;
        java.lang.Class class29 = null;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date31, timeZone34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.util.Date date38 = day37.getStart();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date38);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38, timeZone41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date38, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone43);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, class27);
        java.lang.Class class48 = null;
        java.lang.Class class49 = null;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.util.Date date51 = day50.getStart();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date51, timeZone52);
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date51, timeZone54);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date51);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getStart();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date58);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        java.util.Date date62 = day61.getStart();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date62);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date62, timeZone65);
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date58, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date51, timeZone65);
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, "", "ERROR : Relative To String", class27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int72 = spreadsheetDate71.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean80 = spreadsheetDate74.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate76, (org.jfree.data.time.SerialDate) spreadsheetDate78, (int) '#');
        int int81 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean89 = spreadsheetDate83.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate85, (org.jfree.data.time.SerialDate) spreadsheetDate87, (int) '#');
        int int90 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate83);
        org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate83.getFollowingDayOfWeek(3);
        timeSeries69.setKey((java.lang.Comparable) 3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 3 + "'", int72 == 3);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(serialDate92);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        int int12 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 100);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class23);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        int int32 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 100);
        java.lang.String str36 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.next();
        int int42 = year38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (double) 11);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getStart();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        java.util.Date date50 = day49.getStart();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month55.next();
        boolean boolean57 = year38.equals((java.lang.Object) month55);
        java.util.Calendar calendar58 = null;
        try {
            long long59 = year38.getFirstMillisecond(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1900);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1900 + "'", obj2.equals(1900));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        long long29 = day22.getFirstMillisecond();
//        java.util.Calendar calendar30 = null;
//        try {
//            long long31 = day22.getMiddleMillisecond(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean15 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21, (int) '#');
        boolean boolean24 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int27 = spreadsheetDate26.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33, (int) '#');
        int int36 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        boolean boolean39 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean50 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate48, (int) '#');
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addDays((int) '4', serialDate51);
        boolean boolean54 = spreadsheetDate26.isOn(serialDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean62 = spreadsheetDate56.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate60, (int) '#');
        java.lang.String str63 = spreadsheetDate56.getDescription();
        boolean boolean64 = spreadsheetDate17.isInRange(serialDate51, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate65 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int69 = spreadsheetDate68.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addDays((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate68);
        try {
            boolean boolean71 = spreadsheetDate17.isInRange(serialDate65, serialDate70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
        org.junit.Assert.assertNotNull(serialDate70);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        spreadsheetDate5.setDescription("hi!");
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) '#');
        spreadsheetDate17.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean37 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean45 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate43, (int) '#');
        boolean boolean46 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean47 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int48 = spreadsheetDate5.getMonth();
        java.lang.String str49 = spreadsheetDate5.getDescription();
        java.util.Date date50 = spreadsheetDate5.toDate();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertNotNull(date50);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class7);
        timeSeries8.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries12.removeAgedItems(true);
        timeSeries12.setMaximumItemCount((int) 'a');
        long long17 = timeSeries12.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries12);
        timeSeries12.setDomainDescription("");
        int int21 = year2.compareTo((java.lang.Object) timeSeries12);
        long long22 = year2.getSerialIndex();
        java.util.Date date23 = year2.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.String str5 = seriesException1.toString();
        java.lang.String str6 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test409");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        timeSeries8.removeAgedItems(false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries8.getDataItem(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.createCopy(0, 5);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) '#');
        java.lang.String str8 = spreadsheetDate1.getDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str10 = day9.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day9.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3-February-1900" + "'", str10.equals("3-February-1900"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
        timeSeries4.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries8.removeAgedItems(true);
        timeSeries8.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        timeSeries13.setRangeDescription("3-February-1900");
        timeSeries13.setDescription("hi!");
        java.util.List list18 = timeSeries13.getItems();
        boolean boolean19 = timeSeries13.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test414");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int3 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries6.removeAgedItems(true);
//        timeSeries6.setMaximumItemCount((int) 'a');
//        long long11 = timeSeries6.getMaximumItemAge();
//        timeSeries6.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener14);
//        timeSeries6.setMaximumItemCount((int) (byte) 10);
//        java.lang.Class class18 = timeSeries6.getTimePeriodClass();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class22);
//        timeSeries23.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries27.removeAgedItems(true);
//        timeSeries27.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.addAndOrUpdate(timeSeries27);
//        timeSeries27.removeAgedItems(false);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        long long37 = day35.getSerialIndex();
//        java.lang.String str38 = day35.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        long long44 = fixedMillisecond43.getSerialIndex();
//        java.util.Date date45 = fixedMillisecond43.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.previous();
//        int int47 = timeSeries27.getIndex(regularTimePeriod46);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        int int50 = timeSeries49.getMaximumItemCount();
//        java.util.Collection collection51 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries49);
//        timeSeries49.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.util.Date date55 = day54.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(date55);
//        long long57 = fixedMillisecond56.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond56.previous();
//        long long59 = fixedMillisecond56.getLastMillisecond();
//        long long60 = fixedMillisecond56.getMiddleMillisecond();
//        int int61 = timeSeries49.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class65);
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        java.util.Date date73 = day72.getStart();
//        int int74 = timeSeries71.getIndex((org.jfree.data.time.RegularTimePeriod) day72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day72.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day72, (java.lang.Number) 100);
//        java.lang.String str78 = timeSeries66.getDomainDescription();
//        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year80 = month79.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries66.getDataItem((org.jfree.data.time.RegularTimePeriod) year80);
//        java.lang.Number number82 = timeSeriesDataItem81.getValue();
//        java.lang.Object obj83 = timeSeriesDataItem81.clone();
//        timeSeries49.add(timeSeriesDataItem81);
//        timeSeries6.add(timeSeriesDataItem81);
//        boolean boolean86 = spreadsheetDate2.equals((java.lang.Object) timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560150000000L + "'", long44 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2147483647 + "'", int50 == 2147483647);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560150000000L + "'", long57 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560150000000L + "'", long59 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560150000000L + "'", long60 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "" + "'", str78.equals(""));
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + number82 + "' != '" + 100 + "'", number82.equals(100));
//        org.junit.Assert.assertNotNull(obj83);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Overwritten values from:  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int3 = spreadsheetDate2.getDayOfMonth();
        int int4 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean12 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, (int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, (int) '#');
        spreadsheetDate18.setDescription("hi!");
        boolean boolean23 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        int int26 = spreadsheetDate25.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean34 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate32, (int) '#');
        int int35 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean36 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        try {
            org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test418");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        timeSeries8.removeAgedItems(false);
//        java.lang.String str31 = timeSeries8.getDomainDescription();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(97);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test420");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        long long33 = fixedMillisecond30.getMiddleMillisecond();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = fixedMillisecond30.equals(obj34);
//        long long36 = fixedMillisecond30.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond30.previous();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond30.getLastMillisecond(calendar38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        long long41 = month40.getFirstMillisecond();
//        long long42 = month40.getLastMillisecond();
//        boolean boolean43 = fixedMillisecond30.equals((java.lang.Object) month40);
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1559372400000L + "'", long41 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1561964399999L + "'", long42 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test421");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        timeSeries1.setMaximumItemCount((int) 'a');
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class9);
//        timeSeries10.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries14.removeAgedItems(true);
//        timeSeries14.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.addAndOrUpdate(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        long long24 = day22.getSerialIndex();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        timeSeries1.fireSeriesChanged();
//        java.lang.String str30 = timeSeries1.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries1.addChangeListener(seriesChangeListener31);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        long long25 = fixedMillisecond24.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        int int28 = timeSeries8.getIndex(regularTimePeriod27);
//        java.lang.Number number30 = timeSeries8.getValue(0);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getStart();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date36, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date32, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month41, 0.0d);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10.0f + "'", number30.equals(10.0f));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test423");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.setNotify(true);
//        java.lang.Object obj4 = timeSeries1.clone();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "", "org.jfree.data.general.SeriesChangeEvent[source=a]", class8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getStart();
//        int int17 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 100);
//        java.lang.String str21 = timeSeries9.getDomainDescription();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year23 = month22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
//        timeSeries1.add(timeSeriesDataItem24, true);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class30);
//        timeSeries31.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries35.removeAgedItems(true);
//        timeSeries35.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.addAndOrUpdate(timeSeries35);
//        timeSeries35.removeAgedItems(false);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getStart();
//        long long45 = day43.getSerialIndex();
//        java.lang.String str46 = day43.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 10.0f);
//        java.lang.Class<?> wildcardClass49 = day43.getClass();
//        int int50 = timeSeriesDataItem24.compareTo((java.lang.Object) day43);
//        java.lang.String str51 = day43.toString();
//        long long52 = day43.getFirstMillisecond();
//        int int53 = day43.getMonth();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43626L + "'", long45 == 43626L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setMaximumItemCount((int) 'a');
        long long6 = timeSeries1.getMaximumItemAge();
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.removeChangeListener(seriesChangeListener9);
        timeSeries1.setMaximumItemCount((int) (byte) 10);
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy(0, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        long long3 = day0.getLastMillisecond();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class4);
        timeSeries5.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        timeSeries9.removeAgedItems(true);
        timeSeries9.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.addAndOrUpdate(timeSeries9);
        timeSeries9.removeAgedItems(false);
        boolean boolean17 = month0.equals((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month0.previous();
        int int19 = month0.getMonth();
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        timeSeries8.removeAgedItems(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        long long18 = day16.getSerialIndex();
//        java.lang.String str19 = day16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f);
//        int int22 = day16.getDayOfMonth();
//        int int23 = day16.getDayOfMonth();
//        java.lang.String str24 = day16.toString();
//        long long25 = day16.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test429");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "hi!", "hi!", class3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries8.removeAgedItems(true);
//        timeSeries8.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        long long16 = day14.getSerialIndex();
//        java.lang.String str17 = day14.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries4.setKey((java.lang.Comparable) "3-February-1900");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.addOrUpdate(regularTimePeriod24, (java.lang.Number) 11);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean29 = month27.equals((java.lang.Object) 4);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getStart();
//        long long32 = day30.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str34 = month27.toString();
//        long long35 = month27.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43626L + "'", long32 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//    }
//}

