import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        dateAxis2.setVerticalTickLabels(true);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "Category Plot");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range3, lengthConstraintType4, (-1.0d), range8, lengthConstraintType9);
        boolean boolean12 = range3.contains((double) (-1));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = ringPlot0.getLabelGenerator();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot14.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot22.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation23);
        categoryPlot5.setRangeAxisLocation(0, axisLocation21);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) (-1L), (float) 1L, textBlockAnchor4, (float) '4', (float) '#', (double) '4');
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot1.getOrientation();
        boolean boolean3 = xYPlot1.isRangeZoomable();
        java.awt.Color color4 = java.awt.Color.WHITE;
        xYPlot1.setDomainZeroBaselinePaint((java.awt.Paint) color4);
        float[] floatArray6 = null;
        float[] floatArray7 = color4.getRGBColorComponents(floatArray6);
        float[] floatArray8 = color0.getRGBColorComponents(floatArray7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(1.0f);
        java.lang.String str5 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "hi!");
        double double6 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) 1, (float) 0, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, 4.0d, (double) (-254));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = flowArrangement10.arrange(blockContainer11, graphics2D12, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "Rotation.CLOCKWISE", "ClassContext");
        java.lang.String str8 = chartEntity7.getShapeType();
        chartEntity7.setURLText("");
        chartEntity7.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "poly" + "'", str8.equals("poly"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double5 = ringPlot0.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        dateAxis8.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        java.lang.String str24 = categoryPlot22.getPlotType();
        categoryPlot22.setRangeCrosshairVisible(true);
        categoryPlot22.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot22.getRenderer();
        boolean boolean29 = color15.equals((java.lang.Object) categoryPlot22);
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color15);
        double double31 = ringPlot0.getMaximumExplodePercent();
        double double32 = ringPlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.14d + "'", double32 == 0.14d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.setRangeCrosshairVisible(false);
        boolean boolean9 = verticalAlignment0.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) "hi!", "");
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        double double23 = dateAxis19.getFixedDimension();
        dateAxis19.setVerticalTickLabels(true);
        java.awt.Shape shape26 = dateAxis19.getLeftArrow();
        java.awt.Paint paint27 = dateAxis19.getLabelPaint();
        categoryAxis3D12.setTickLabelPaint((java.lang.Comparable) 90.0d, paint27);
        int int29 = categoryPlot6.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D12);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        polarPlot4.setAngleGridlinePaint(paint5);
        boolean boolean7 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot4.zoomDomainAxes((double) (byte) 100, (double) 0, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = java.awt.Color.getColor("RectangleAnchor.LEFT", color7);
        boolean boolean9 = polarPlot4.equals((java.lang.Object) "RectangleAnchor.LEFT");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.lang.Object obj7 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        boolean boolean7 = xYPlot0.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRendererForDataset(xYDataset8);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color5);
        int int7 = color5.getGreen();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Paint paint3 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot6.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot6.datasetChanged(datasetChangeEvent8);
        java.awt.geom.Point2D point2D10 = xYPlot6.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot0.draw(graphics2D4, rectangle2D5, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getDomainMarkers((int) (short) 10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot5.render(graphics2D13, rectangle2D14, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        double double19 = numberAxis3D18.getFixedDimension();
        numberAxis3D18.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = ringPlot22.getLabelPadding();
        double double25 = rectangleInsets23.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date29 = dateAxis28.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        java.lang.String str32 = categoryPlot31.getPlotType();
        java.lang.String str33 = categoryPlot31.getPlotType();
        categoryPlot31.setRangeCrosshairVisible(true);
        boolean boolean36 = rectangleInsets23.equals((java.lang.Object) true);
        double double38 = rectangleInsets23.extendWidth(0.0d);
        numberAxis3D18.setLabelInsets(rectangleInsets23);
        boolean boolean40 = numberAxis3D18.isNegativeArrowVisible();
        int int41 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Category Plot" + "'", str32.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        float float1 = dateAxis0.getTickMarkInsideLength();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        boolean boolean4 = dateAxis0.equals((java.lang.Object) textLine3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        xYPlot0.setDomainCrosshairValue((double) 1, true);
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint4.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        categoryPlot16.clearDomainMarkers();
        java.lang.Object obj18 = categoryPlot16.clone();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = null;
        ringPlot0.setLabelShadowPaint(paint5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot0.setURLGenerator(pieURLGenerator7);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getRangeAxisEdge(10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        boolean boolean7 = dateAxis0.isAutoTickUnitSelection();
        dateAxis0.setLabel("Category Plot");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        boolean boolean16 = dateAxis12.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        float float18 = dateAxis17.getTickMarkInsideLength();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis17.getTickMarkPosition();
        dateAxis12.setTickMarkPosition(dateTickMarkPosition19);
        dateAxis0.setTickMarkPosition(dateTickMarkPosition19);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot0.getLabelPadding();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, 100, (-739));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.mapDatasetToRangeAxis(1, 10);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(8, xYDataset7);
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("ChartEntity: tooltip = Rotation.CLOCKWISE", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.mapDatasetToRangeAxis(1, 10);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(8, xYDataset7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot9.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        xYPlot9.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot9.zoomDomainAxes((double) 100, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot9.getOrientation();
        xYPlot0.setOrientation(plotOrientation17);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(plotOrientation17);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 0.14d, jFreeChart1, (int) (byte) -1, (int) (byte) -1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        java.awt.Paint paint10 = ringPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = ringPlot11.getDrawingSupplier();
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot11.setShadowPaint(paint13);
        ringPlot0.setLabelOutlinePaint(paint13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot0.getLabelPadding();
        java.awt.Paint paint17 = ringPlot0.getBackgroundPaint();
        java.awt.Font font18 = ringPlot0.getLabelFont();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot8.getSeriesRenderingOrder();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder9);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (byte) 1, (double) (short) 0, (float) ' ', 0.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        ringPlot0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Class<?> wildcardClass1 = unitType0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot2.getRendererForDataset(xYDataset5);
        java.lang.Object obj7 = null;
        boolean boolean8 = xYPlot2.equals(obj7);
        boolean boolean9 = xYPlot2.isRangeZoomable();
        boolean boolean10 = unitType0.equals((java.lang.Object) xYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot11.getLabelPadding();
        double double14 = rectangleInsets12.calculateBottomOutset(0.0d);
        java.awt.Font font16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        java.lang.String str24 = categoryPlot22.getPlotType();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font16, (org.jfree.chart.plot.Plot) categoryPlot22, false);
        boolean boolean29 = jFreeChart28.isNotify();
        java.awt.Image image30 = jFreeChart28.getBackgroundImage();
        boolean boolean31 = rectangleInsets12.equals((java.lang.Object) jFreeChart28);
        xYPlot2.setAxisOffset(rectangleInsets12);
        xYPlot2.clearRangeAxes();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(image30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("ClassContext");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        double double9 = dateAxis5.getUpperMargin();
        java.awt.Shape shape10 = dateAxis5.getLeftArrow();
        dateAxis0.setDownArrow(shape10);
        try {
            dateAxis0.setRange((double) 1.0f, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.lang.String str9 = categoryPlot8.getPlotType();
        java.lang.String str10 = categoryPlot8.getPlotType();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        jFreeChart14.removeLegend();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis0, jFreeChart14);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        ringPlot2.setURLGenerator(pieURLGenerator5);
        boolean boolean7 = textFragment1.equals((java.lang.Object) ringPlot2);
        java.awt.Paint paint8 = ringPlot2.getBaseSectionPaint();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot9.getOrientation();
        xYPlot9.configureRangeAxes();
        xYPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = ringPlot14.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = ringPlot14.getLegendLabelToolTipGenerator();
        java.awt.Image image17 = null;
        ringPlot14.setBackgroundImage(image17);
        java.awt.Paint paint19 = null;
        ringPlot14.setLabelShadowPaint(paint19);
        ringPlot14.setSeparatorsVisible(false);
        java.awt.Color color23 = java.awt.Color.magenta;
        ringPlot14.setBaseSectionPaint((java.awt.Paint) color23);
        java.awt.Stroke stroke25 = ringPlot14.getSeparatorStroke();
        xYPlot9.setDomainGridlineStroke(stroke25);
        ringPlot2.setBaseSectionOutlineStroke(stroke25);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = ringPlot5.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLegendLabelToolTipGenerator();
        java.awt.Image image8 = null;
        ringPlot5.setBackgroundImage(image8);
        java.awt.Paint paint10 = null;
        ringPlot5.setLabelShadowPaint(paint10);
        ringPlot5.setSeparatorsVisible(false);
        java.awt.Color color14 = java.awt.Color.magenta;
        ringPlot5.setBaseSectionPaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = ringPlot5.getSeparatorStroke();
        xYPlot0.setDomainGridlineStroke(stroke16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot0.getDomainAxisEdge(255);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        double double11 = dateAxis7.getFixedDimension();
        org.jfree.data.Range range12 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Paint paint13 = polarPlot4.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Font font8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        java.util.List list22 = jFreeChart20.getSubtitles();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        try {
            java.awt.image.BufferedImage bufferedImage26 = jFreeChart20.createBufferedImage((int) (byte) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        boolean boolean7 = dateAxis0.isAutoTickUnitSelection();
        dateAxis0.setLabel("Category Plot");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        dateAxis0.setMinimumDate(date11);
        boolean boolean13 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        double double7 = piePlot6.getShadowXOffset();
        java.awt.Font font8 = piePlot6.getLabelFont();
        polarPlot4.setNoDataMessageFont(font8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getShadowXOffset();
        java.awt.Font font2 = piePlot0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset3 = piePlot0.getDataset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color6 = color5.brighter();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers((int) (byte) 100, layer9);
        xYPlot0.clearDomainMarkers((-254));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        ringPlot0.setMaximumLabelWidth((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot0.getSimpleLabelOffset();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date16 = dateAxis15.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot18.getRangeAxisForDataset((int) (byte) 1);
        boolean boolean21 = rectangleInsets12.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat9 = null;
        dateAxis2.setDateFormatOverride(dateFormat9);
        try {
            dateAxis2.setRange((double) 8, 0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        boolean boolean7 = dateAxis2.isPositiveArrowVisible();
        dateAxis2.setRange(0.0d, (double) 8);
        java.lang.String str11 = dateAxis2.getLabelURL();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        boolean boolean6 = polarPlot4.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        java.awt.Image image15 = jFreeChart13.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            jFreeChart13.handleClick((int) (short) -1, (int) '#', chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getDomainMarkers((int) (short) 10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot5.render(graphics2D13, rectangle2D14, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = ringPlot19.getDrawingSupplier();
        float float21 = ringPlot19.getBackgroundImageAlpha();
        double double22 = ringPlot19.getInnerSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        ringPlot19.setDataset(pieDataset23);
        java.awt.Font font25 = ringPlot19.getLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint26);
        categoryPlot5.setOutlinePaint(paint26);
        org.jfree.chart.plot.Plot plot29 = categoryPlot5.getRootPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        ringPlot1.setSectionDepth(100.0d);
        boolean boolean7 = ringPlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        java.util.List list15 = jFreeChart13.getSubtitles();
        org.jfree.chart.plot.Plot plot16 = jFreeChart13.getPlot();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        polarPlot4.setAngleGridlinePaint(paint5);
        boolean boolean7 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset8 = polarPlot4.getDataset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("java.awt.Color[r=255,g=255,b=255]", "TextBlockAnchor.CENTER_LEFT");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot5.getRenderer();
        int int12 = categoryPlot5.getDomainAxisCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.lang.Object obj4 = plotChangeEvent3.getSource();
        org.jfree.chart.plot.Plot plot5 = plotChangeEvent3.getPlot();
        org.jfree.chart.plot.Plot plot6 = plotChangeEvent3.getPlot();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = null;
        ringPlot0.setLabelShadowPaint(paint5);
        boolean boolean7 = ringPlot0.getIgnoreZeroValues();
        java.awt.Font font9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.lang.String str16 = categoryPlot15.getPlotType();
        java.lang.String str17 = categoryPlot15.getPlotType();
        categoryPlot15.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        boolean boolean22 = jFreeChart21.isNotify();
        jFreeChart21.setTextAntiAlias(false);
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font26);
        textTitle27.setWidth((double) (byte) 10);
        textTitle27.setURLText("");
        jFreeChart21.removeSubtitle((org.jfree.chart.title.Title) textTitle27);
        jFreeChart21.removeLegend();
        ringPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart21);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot1.getLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot1.getLabelPadding();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setSeparatorsVisible(false);
        org.jfree.chart.util.Rotation rotation7 = ringPlot4.getDirection();
        double double8 = rotation7.getFactor();
        ringPlot1.setDirection(rotation7);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double6 = ringPlot0.getExplodePercent((java.lang.Comparable) 100L);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot0.setURLGenerator(pieURLGenerator7);
        boolean boolean9 = ringPlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (-254), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        dateAxis2.setAutoRange(true);
        java.awt.Shape shape6 = dateAxis2.getDownArrow();
        dateAxis2.setInverted(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit9);
        boolean boolean11 = strokeMap0.containsKey((java.lang.Comparable) date10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot11.setRenderer(categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot11.getRangeMarkers(100, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot11.getDomainMarkers(layer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot11.getDomainAxisEdge((int) (byte) 100);
        try {
            java.util.List list24 = numberAxis3D0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "", "java.awt.Color[r=255,g=255,b=255]", image3, "ClassContext", "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=255,b=255]");
        projectInfo7.addOptionalLibrary("{0}");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot5.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot16.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot16.datasetChanged(datasetChangeEvent18);
        java.awt.geom.Point2D point2D20 = xYPlot16.getQuadrantOrigin();
        categoryPlot5.zoomRangeAxes((double) 10L, (double) 10.0f, plotRenderingInfo15, point2D20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D25.configure();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date30 = dateAxis29.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        dateAxis29.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat36 = null;
        dateAxis29.setDateFormatOverride(dateFormat36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D25, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer38);
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryPlot5.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        ringPlot0.setIgnoreNullValues(false);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        ringPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        ringPlot0.setLabelLinkMargin(0.14d);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Class<?> wildcardClass3 = unitType2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass3);
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Class<?> wildcardClass8 = unitType7.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("ChartEntity: tooltip = Rotation.CLOCKWISE", (java.lang.Class) wildcardClass8);
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.CENTER_LEFT", (java.lang.Class) wildcardClass8);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(uRL4);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleLabelsVisible();
        java.awt.Paint paint6 = polarPlot4.getAngleGridlinePaint();
        org.jfree.chart.axis.TickUnit tickUnit7 = polarPlot4.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(tickUnit7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        boolean boolean7 = xYPlot0.isRangeZoomable();
        xYPlot0.setNoDataMessage("hi!");
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.lang.String str9 = categoryPlot8.getPlotType();
        java.lang.String str10 = categoryPlot8.getPlotType();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        jFreeChart14.setTextAntiAlias(true);
        boolean boolean17 = blockContainer0.equals((java.lang.Object) true);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            blockContainer0.draw(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.lang.String str9 = categoryPlot8.getPlotType();
        java.lang.String str10 = categoryPlot8.getPlotType();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        jFreeChart14.setTextAntiAlias(true);
        boolean boolean17 = blockContainer0.equals((java.lang.Object) true);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot18.getRendererForDataset(xYDataset21);
        xYPlot18.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot18.setBackgroundAlpha((float) '4');
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = ringPlot28.getDrawingSupplier();
        float float30 = ringPlot28.getBackgroundImageAlpha();
        ringPlot28.setIgnoreNullValues(false);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        ringPlot28.drawBackgroundImage(graphics2D33, rectangle2D34);
        boolean boolean36 = xYPlot18.equals((java.lang.Object) ringPlot28);
        boolean boolean37 = blockContainer0.equals((java.lang.Object) boolean36);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getRangeMarkers((int) ' ', layer6);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.zoom((double) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = ringPlot14.getDrawingSupplier();
        java.awt.Paint paint16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setShadowPaint(paint16);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint16);
        categoryPlot5.setDomainGridlinePaint(paint16);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date23 = dateAxis22.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.lang.String str26 = categoryPlot25.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.Stroke stroke29 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot25.getLegendItems();
        categoryPlot5.setFixedLegendItems(legendItemCollection32);
        boolean boolean34 = categoryPlot5.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        multiplePiePlot0.setLimit(10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot0.setDataset(categoryDataset4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = multiplePiePlot0.getDataset();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        categoryPlot14.setRangeCrosshairVisible(false);
        categoryPlot14.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot14.getRangeMarkers(layer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot14.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot25.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.geom.Point2D point2D29 = xYPlot25.getQuadrantOrigin();
        categoryPlot14.zoomRangeAxes((double) 10L, (double) 10.0f, plotRenderingInfo24, point2D29);
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            multiplePiePlot0.draw(graphics2D7, rectangle2D8, point2D29, plotState31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart13.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            java.awt.image.BufferedImage bufferedImage21 = jFreeChart13.createBufferedImage((int) (short) -1, (-254), chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (-254) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot6.getOrientation();
        boolean boolean8 = xYPlot6.isRangeZoomable();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getRangeMarkers(0, layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean15 = numberAxis3D14.getAutoRangeIncludesZero();
        xYPlot6.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = ringPlot17.getLabelPadding();
        double double20 = rectangleInsets18.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        java.lang.String str27 = categoryPlot26.getPlotType();
        java.lang.String str28 = categoryPlot26.getPlotType();
        categoryPlot26.setRangeCrosshairVisible(true);
        boolean boolean31 = rectangleInsets18.equals((java.lang.Object) true);
        double double33 = rectangleInsets18.extendWidth(0.0d);
        numberAxis3D14.setLabelInsets(rectangleInsets18);
        try {
            java.lang.Object obj35 = legendTitle3.draw(graphics2D4, rectangle2D5, (java.lang.Object) rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        float float1 = dateAxis0.getTickMarkInsideLength();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        java.awt.Color color3 = java.awt.Color.GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        xYPlot0.setRangeCrosshairValue((double) '#');
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextBlockAnchor.CENTER_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextBlockAnchor.CENTER_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        categoryPlot5.clearRangeMarkers((int) (byte) 10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        double double18 = dateAxis14.getFixedDimension();
        dateAxis14.setVerticalTickLabels(true);
        java.awt.Shape shape21 = dateAxis14.getLeftArrow();
        dateAxis14.setAutoRange(false);
        dateAxis14.setAutoRange(false);
        org.jfree.data.Range range26 = categoryPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        float float27 = dateAxis14.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = null;
        ringPlot0.setLabelShadowPaint(paint5);
        boolean boolean7 = ringPlot0.getIgnoreZeroValues();
        boolean boolean8 = ringPlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot5.getDataset();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryDataset7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Class<?> wildcardClass4 = unitType3.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("ChartEntity: tooltip = Rotation.CLOCKWISE", (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.CENTER_LEFT", (java.lang.Class) wildcardClass4);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResource("java.awt.Color[r=255,g=255,b=255]", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(uRL6);
        org.junit.Assert.assertNull(uRL7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        try {
            categoryPlot5.setRenderer((-739), categoryItemRenderer12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = ringPlot0.getLabelPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setLabelOutlinePaint(paint3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.data.Range range8 = dateAxis5.getRange();
        dateAxis5.setTickMarksVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis5.setTickMarkPaint(paint11);
        boolean boolean13 = ringPlot0.equals((java.lang.Object) dateAxis5);
        boolean boolean14 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range3, (double) (byte) -1);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) (byte) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand(range7, (double) (short) 1, (double) (byte) 1);
        double double11 = range10.getLength();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Rotation.CLOCKWISE");
        java.lang.String str2 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.CLOCKWISE" + "'", str2.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot0.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace12, false);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        dateAxis2.setAutoRange(true);
        java.awt.Shape shape6 = dateAxis2.getDownArrow();
        dateAxis2.setInverted(true);
        boolean boolean9 = dateAxis2.isAutoTickUnitSelection();
        dateAxis2.setLabel("Category Plot");
        java.awt.Color color12 = java.awt.Color.CYAN;
        dateAxis2.setLabelPaint((java.awt.Paint) color12);
        objectList0.set((int) (short) 10, (java.lang.Object) color12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.mapDatasetToRangeAxis(1, 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleLabelsVisible();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.TickUnit tickUnit8 = polarPlot4.getAngleTickUnit();
        java.lang.String str9 = polarPlot4.getPlotType();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(tickUnit8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        double double6 = polarPlot4.getMaxRadius();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        boolean boolean13 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot5.getRangeAxisLocation(15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer15 };
        categoryPlot7.setRenderers(categoryItemRendererArray16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = ringPlot18.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLegendLabelToolTipGenerator();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot18);
        java.lang.Object obj22 = plotChangeEvent21.getSource();
        org.jfree.chart.plot.Plot plot23 = plotChangeEvent21.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent21.setType(chartChangeEventType24);
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.mapDatasetToRangeAxis(1, 10);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(8, xYDataset7);
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot0.setBackgroundAlpha((float) '4');
        java.awt.Stroke stroke10 = xYPlot0.getDomainGridlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            xYPlot0.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.String str17 = categoryAxis3D2.getLabel();
        categoryAxis3D2.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) 10L, range6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        categoryPlot13.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date23 = dateAxis22.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        double double26 = dateAxis22.getFixedDimension();
        dateAxis22.setVerticalTickLabels(true);
        java.awt.Shape shape29 = dateAxis22.getLeftArrow();
        dateAxis22.setAutoRange(false);
        dateAxis22.setAutoRange(false);
        org.jfree.data.Range range34 = categoryPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date37 = dateAxis36.getMaximumDate();
        org.jfree.data.Range range38 = dateAxis36.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range43 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range38, lengthConstraintType39, (-1.0d), range43, lengthConstraintType44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date48 = dateAxis47.getMaximumDate();
        org.jfree.data.Range range49 = dateAxis47.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType50 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range54 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType55 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range49, lengthConstraintType50, (-1.0d), range54, lengthConstraintType55);
        org.jfree.data.Range range57 = org.jfree.data.Range.combine(range43, range54);
        dateAxis22.setRange(range57);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = rectangleConstraint7.toRangeHeight(range57);
        double double61 = range57.constrain((double) ' ');
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(lengthConstraintType50);
        org.junit.Assert.assertNotNull(lengthConstraintType55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = color0.equals((java.lang.Object) jFreeChartResources1);
        java.util.Locale locale3 = jFreeChartResources1.getLocale();
        try {
            java.lang.String str5 = jFreeChartResources1.getString("Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Rotation.CLOCKWISE");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray6 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray7 = color1.getComponents(floatArray6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot8.getOrientation();
        boolean boolean10 = xYPlot8.isRangeZoomable();
        java.awt.Color color11 = java.awt.Color.WHITE;
        xYPlot8.setDomainZeroBaselinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = ringPlot13.getDrawingSupplier();
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setShadowPaint(paint15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        dateAxis17.setAutoRange(true);
        java.awt.Shape shape21 = dateAxis17.getDownArrow();
        dateAxis17.setInverted(true);
        boolean boolean24 = dateAxis17.isAutoTickUnitSelection();
        dateAxis17.setLabel("Category Plot");
        java.awt.Color color27 = java.awt.Color.CYAN;
        dateAxis17.setLabelPaint((java.awt.Paint) color27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color31 = color30.brighter();
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color1, color11, paint15, color27, color29, color31 };
        java.awt.Paint[] paintArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray36 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray36);
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double5 = ringPlot0.getLabelLinkMargin();
        java.awt.Paint paint6 = ringPlot0.getBaseSectionOutlinePaint();
        double double7 = ringPlot0.getMaximumExplodePercent();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0E-8d, plotRenderingInfo2, point2D3, true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range4, (double) (byte) -1);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (byte) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range6, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.data.Range range14 = dateAxis12.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range14, lengthConstraintType15, (-1.0d), range19, lengthConstraintType20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.data.Range range25 = dateAxis23.getRange();
        double double27 = range25.constrain(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range6, lengthConstraintType20, 2.0d, range25, lengthConstraintType28);
        org.jfree.data.Range range32 = org.jfree.data.Range.expand(range6, (double) (byte) 0, (double) 10.0f);
        double double33 = range32.getLowerBound();
        boolean boolean36 = range32.intersects(0.0d, (double) '#');
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "ClassContext", "TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str5 = basicProjectInfo4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ClassContext" + "'", str5.equals("ClassContext"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot0.setSeparatorStroke(stroke3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot8.setSeparatorStroke(stroke11);
        ringPlot5.setSeparatorStroke(stroke11);
        java.awt.Stroke stroke14 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot15.getLabelPadding();
        double double18 = rectangleInsets16.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date22 = dateAxis21.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.lang.String str25 = categoryPlot24.getPlotType();
        java.lang.String str26 = categoryPlot24.getPlotType();
        categoryPlot24.setRangeCrosshairVisible(true);
        boolean boolean29 = rectangleInsets16.equals((java.lang.Object) true);
        double double31 = rectangleInsets16.extendWidth(0.0d);
        double double33 = rectangleInsets16.calculateRightOutset((double) (short) 1);
        ringPlot5.setInsets(rectangleInsets16, false);
        ringPlot0.setInsets(rectangleInsets16, false);
        ringPlot0.setMaximumLabelWidth((double) '#');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, false);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot11.getOrientation();
        boolean boolean13 = xYPlot11.isRangeZoomable();
        java.awt.Color color14 = java.awt.Color.WHITE;
        xYPlot11.setDomainZeroBaselinePaint((java.awt.Paint) color14);
        java.lang.String str16 = color14.toString();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        double double24 = dateAxis20.getUpperMargin();
        int int25 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date28 = dateAxis27.getMaximumDate();
        dateAxis27.setAutoRange(true);
        java.awt.Shape shape31 = dateAxis27.getDownArrow();
        dateAxis27.setInverted(true);
        java.util.Date date34 = dateAxis27.getMaximumDate();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        double double36 = numberAxis3D35.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, xYItemRenderer37);
        boolean boolean39 = numberAxis3D35.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D35);
        java.awt.Color color41 = java.awt.Color.CYAN;
        int int42 = color41.getTransparency();
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color41);
        java.awt.Stroke stroke44 = xYPlot0.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = null;
        boolean boolean50 = xYPlot0.render(graphics2D45, rectangle2D46, 0, plotRenderingInfo48, crosshairState49);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=255]"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = rotation3.getFactor();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean6 = rotation3.equals((java.lang.Object) dateTickUnit5);
        java.lang.String str7 = rotation3.toString();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Rotation.CLOCKWISE" + "'", str7.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) (-1L), (float) 1L, textBlockAnchor4, (float) '4', (float) '#', (double) '4');
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str14 = textBlockAnchor13.toString();
        textBlock0.draw(graphics2D10, (float) (-739), 0.0f, textBlockAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str14.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        java.awt.Paint paint10 = ringPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = ringPlot11.getDrawingSupplier();
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot11.setShadowPaint(paint13);
        ringPlot0.setLabelOutlinePaint(paint13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot0.getLabelPadding();
        double double18 = rectangleInsets16.extendWidth(1.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes(4.0d, plotRenderingInfo8, point2D9);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getRangeMarkers(layer11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = null;
        ringPlot0.setLabelShadowPaint(paint5);
        ringPlot0.setSeparatorsVisible(false);
        double double9 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setNotify(true);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = xYPlot19.getOrientation();
        boolean boolean21 = xYPlot19.isRangeZoomable();
        java.awt.Color color22 = java.awt.Color.WHITE;
        xYPlot19.setDomainZeroBaselinePaint((java.awt.Paint) color22);
        float[] floatArray24 = null;
        float[] floatArray25 = color22.getRGBColorComponents(floatArray24);
        jFreeChart13.setBackgroundPaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range3, lengthConstraintType4, (-1.0d), range8, lengthConstraintType9);
        java.lang.String str11 = lengthConstraintType9.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "LengthConstraintType.NONE" + "'", str11.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        int int14 = jFreeChart13.getSubtitleCount();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!", font16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        jFreeChart13.addSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle17.getMargin();
        double double22 = rectangleInsets20.calculateBottomOutset(4.0d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        dateAxis2.setVerticalTickLabels(true);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        java.text.DateFormat dateFormat10 = dateAxis2.getDateFormatOverride();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        double double6 = rectangleInsets3.calculateTopInset((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) 1, (float) 0, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str11 = textBlockAnchor10.toString();
        java.awt.Shape shape15 = textBlock0.calculateBounds(graphics2D7, (float) 0, 1.0f, textBlockAnchor10, 0.0f, (float) (byte) 1, (double) (-1.0f));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textBlock0.getLineAlignment();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!", font20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=255]", font20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio(1.0f);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = ringPlot27.getDrawingSupplier();
        float float29 = ringPlot27.getBackgroundImageAlpha();
        ringPlot27.setIgnoreNullValues(true);
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot27.setSectionOutlinePaint((java.lang.Comparable) 100, paint33);
        boolean boolean35 = categoryAxis3D24.equals((java.lang.Object) paint33);
        textBlock0.addLine("Category Plot", font20, paint33);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str11.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        multiplePiePlot0.setLimit(10.0d);
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint5 = jFreeChart4.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Paint paint7 = textTitle2.getBackgroundPaint();
        java.lang.String str8 = textTitle2.getText();
        org.jfree.chart.text.TextBlock textBlock9 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock9.draw(graphics2D10, (float) 1, (float) 0, textBlockAnchor13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textBlock9.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, 4.0d, (double) (-254));
        textTitle2.setTextAlignment(horizontalAlignment15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean2 = dateAxis1.isAutoTickUnitSelection();
        java.text.DateFormat dateFormat3 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        double double18 = dateAxis14.getFixedDimension();
        dateAxis14.setVerticalTickLabels(true);
        java.awt.Shape shape21 = dateAxis14.getLeftArrow();
        dateAxis14.setAutoRange(false);
        dateAxis14.setAutoRange(false);
        org.jfree.data.Range range26 = categoryPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.util.List list27 = categoryPlot5.getCategories();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date33 = dateAxis32.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.lang.String str36 = categoryPlot35.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent37);
        java.awt.Stroke stroke39 = categoryPlot35.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date41 = dateAxis40.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier47 = ringPlot46.getDrawingSupplier();
        java.awt.Paint paint48 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot46.setShadowPaint(paint48);
        org.jfree.chart.block.BlockBorder blockBorder50 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint48);
        dateAxis40.setTickLabelPaint(paint48);
        categoryPlot35.setBackgroundPaint(paint48);
        boolean boolean53 = categoryPlot35.isRangeGridlinesVisible();
        categoryPlot35.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = xYPlot57.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent59 = null;
        xYPlot57.datasetChanged(datasetChangeEvent59);
        java.awt.geom.Point2D point2D61 = xYPlot57.getQuadrantOrigin();
        categoryPlot35.zoomDomainAxes((double) (byte) -1, plotRenderingInfo56, point2D61);
        org.jfree.chart.plot.PlotState plotState63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            categoryPlot5.draw(graphics2D28, rectangle2D29, point2D61, plotState63, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(list27);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(drawingSupplier47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(point2D61);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.CENTER_LEFT", "Category Plot", "ClassContext", "hi!", "ClassContext");
        basicProjectInfo7.setInfo("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        basicProjectInfo7.setCopyright("TextBlockAnchor.CENTER_LEFT");
        boolean boolean12 = textFragment1.equals((java.lang.Object) basicProjectInfo7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("poly", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        xYPlot0.setWeight(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYPlot0.rendererChanged(rendererChangeEvent5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot8.setSeparatorStroke(stroke11);
        ringPlot5.setSeparatorStroke(stroke11);
        java.awt.Stroke stroke14 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot15.getLabelPadding();
        double double18 = rectangleInsets16.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date22 = dateAxis21.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.lang.String str25 = categoryPlot24.getPlotType();
        java.lang.String str26 = categoryPlot24.getPlotType();
        categoryPlot24.setRangeCrosshairVisible(true);
        boolean boolean29 = rectangleInsets16.equals((java.lang.Object) true);
        double double31 = rectangleInsets16.extendWidth(0.0d);
        double double33 = rectangleInsets16.calculateRightOutset((double) (short) 1);
        ringPlot5.setInsets(rectangleInsets16, false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator36 = ringPlot5.getLegendLabelGenerator();
        ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator36);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator36);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setInnerSeparatorExtension((double) (-1.0f));
        boolean boolean6 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double6 = ringPlot0.getExplodePercent((java.lang.Comparable) 100L);
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setOutlinePaint(paint7);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getDomainMarkers((int) (short) 10, layer11);
        boolean boolean13 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot5.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        ringPlot3.setURLGenerator(pieURLGenerator6);
        boolean boolean8 = ringPlot0.equals((java.lang.Object) ringPlot3);
        double double9 = ringPlot3.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.14d + "'", double9 == 0.14d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxisForDataset((int) (byte) 1);
        valueAxis7.resizeRange((double) (byte) 10, 1.0E-8d);
        valueAxis7.setFixedAutoRange((double) 0L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(valueAxis7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = ringPlot11.getDrawingSupplier();
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot11.setShadowPaint(paint13);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint13);
        dateAxis5.setTickLabelPaint(paint13);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("ThreadContext", font2, paint13);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean9 = textAnchor7.equals((java.lang.Object) dateTickUnit8);
        java.util.Date date10 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        multiplePiePlot0.setLimit(10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot0.setDataset(categoryDataset4);
        java.lang.String str6 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        org.jfree.chart.LegendItem legendItem13 = null;
        legendItemCollection12.add(legendItem13);
        int int15 = legendItemCollection12.getItemCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundAlpha((float) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot5.getDomainAxisEdge();
        int int11 = categoryPlot5.getWeight();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = ringPlot6.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot6.getLegendLabelToolTipGenerator();
        java.awt.Image image9 = null;
        ringPlot6.setBackgroundImage(image9);
        double double11 = ringPlot6.getLabelLinkMargin();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 0, plotRenderingInfo13);
        piePlotState14.setPieWRadius((double) (short) 100);
        piePlotState14.setPieCenterX(0.14d);
        double double19 = piePlotState14.getTotal();
        org.junit.Assert.assertNull(pieDataset3);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(piePlotState14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double[] doubleArray6 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray11 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray16 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray21 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray26 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray31 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Rotation.CLOCKWISE", "Rotation.CLOCKWISE", doubleArray32);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 5.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = xYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Paint paint7 = ringPlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        boolean boolean13 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = ringPlot15.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = ringPlot15.getLegendLabelToolTipGenerator();
        java.awt.Image image18 = null;
        ringPlot15.setBackgroundImage(image18);
        double double20 = ringPlot15.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        dateAxis23.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis23.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date35 = dateAxis34.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer36);
        java.lang.String str38 = categoryPlot37.getPlotType();
        java.lang.String str39 = categoryPlot37.getPlotType();
        categoryPlot37.setRangeCrosshairVisible(true);
        categoryPlot37.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot37.getRenderer();
        boolean boolean44 = color30.equals((java.lang.Object) categoryPlot37);
        ringPlot15.setLabelLinkPaint((java.awt.Paint) color30);
        java.awt.Color color46 = java.awt.Color.getColor("", color30);
        java.awt.Color color47 = color30.brighter();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color47);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot5.getLegendItems();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent50);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.025d + "'", double20 == 0.025d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Category Plot" + "'", str38.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Category Plot" + "'", str39.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(legendItemCollection49);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.CENTER_LEFT", "Category Plot", "ClassContext", "hi!", "ClassContext");
        basicProjectInfo5.setInfo("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("RectangleAnchor.LEFT", font2);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        multiplePiePlot0.setLimit(10.0d);
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle5 = jFreeChart4.getTitle();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(textTitle5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.zoom((double) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = ringPlot14.getDrawingSupplier();
        java.awt.Paint paint16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setShadowPaint(paint16);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint16);
        categoryPlot5.setDomainGridlinePaint(paint16);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date23 = dateAxis22.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.lang.String str26 = categoryPlot25.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.Stroke stroke29 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot25.getLegendItems();
        categoryPlot5.setFixedLegendItems(legendItemCollection32);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = ringPlot34.getLabelPadding();
        categoryPlot5.setAxisOffset(rectangleInsets35);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str1 = blockContainer0.getID();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.zoom((double) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = ringPlot14.getDrawingSupplier();
        java.awt.Paint paint16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setShadowPaint(paint16);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint16);
        categoryPlot5.setDomainGridlinePaint(paint16);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date23 = dateAxis22.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.lang.String str26 = categoryPlot25.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.Stroke stroke29 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot25.getLegendItems();
        categoryPlot5.setFixedLegendItems(legendItemCollection32);
        java.lang.Object obj34 = legendItemCollection32.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle2.setVerticalAlignment(verticalAlignment5);
        double double7 = textTitle2.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double[] doubleArray6 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray11 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray16 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray21 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray26 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray31 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Rotation.CLOCKWISE", "Rotation.CLOCKWISE", doubleArray32);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        double double35 = range34.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 200.0d + "'", double35 == 200.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        double double7 = ringPlot0.getInteriorGap();
        double double8 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.lang.String str17 = categoryAxis3D2.getLabel();
        double double18 = categoryAxis3D2.getLowerMargin();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color6 = color5.brighter();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot0.rendererChanged(rendererChangeEvent8);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot3.getRendererForDataset(xYDataset6);
        java.lang.Object obj8 = null;
        boolean boolean9 = xYPlot3.equals(obj8);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot3.getDataset();
        java.awt.Stroke stroke11 = xYPlot3.getRangeGridlineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke11);
        double double13 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        int int15 = xYPlot0.getIndexOf(xYItemRenderer14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        java.lang.String str6 = polarPlot4.getPlotType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedDimension();
        numberAxis3D7.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot11.getLabelPadding();
        double double14 = rectangleInsets12.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.lang.String str21 = categoryPlot20.getPlotType();
        java.lang.String str22 = categoryPlot20.getPlotType();
        categoryPlot20.setRangeCrosshairVisible(true);
        boolean boolean25 = rectangleInsets12.equals((java.lang.Object) true);
        double double27 = rectangleInsets12.extendWidth(0.0d);
        numberAxis3D7.setLabelInsets(rectangleInsets12);
        boolean boolean29 = numberAxis3D7.isNegativeArrowVisible();
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Polar Plot" + "'", str6.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot5.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(sortOrder9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot4.setSeparatorStroke(stroke7);
        ringPlot1.setSeparatorStroke(stroke7);
        java.awt.Paint paint10 = ringPlot1.getShadowPaint();
        java.awt.Paint paint11 = ringPlot1.getNoDataMessagePaint();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = ringPlot12.getDrawingSupplier();
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot12.setShadowPaint(paint14);
        ringPlot1.setLabelOutlinePaint(paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = ringPlot1.getLabelPadding();
        java.awt.Paint paint18 = ringPlot1.getBackgroundPaint();
        boolean boolean19 = blockBorder0.equals((java.lang.Object) ringPlot1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        double double18 = dateAxis14.getFixedDimension();
        dateAxis14.setVerticalTickLabels(true);
        java.awt.Shape shape21 = dateAxis14.getLeftArrow();
        dateAxis14.setAutoRange(false);
        dateAxis14.setAutoRange(false);
        org.jfree.data.Range range26 = categoryPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot5.setRenderer(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getDomainMarkers(layer6);
        int int8 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = ringPlot6.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot6.getLegendLabelToolTipGenerator();
        java.awt.Image image9 = null;
        ringPlot6.setBackgroundImage(image9);
        double double11 = ringPlot6.getLabelLinkMargin();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 0, plotRenderingInfo13);
        double double15 = piePlotState14.getTotal();
        org.junit.Assert.assertNull(pieDataset3);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(piePlotState14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.zoom((double) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = ringPlot14.getDrawingSupplier();
        java.awt.Paint paint16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setShadowPaint(paint16);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint16);
        categoryPlot5.setDomainGridlinePaint(paint16);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date23 = dateAxis22.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.lang.String str26 = categoryPlot25.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.Stroke stroke29 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot25.getLegendItems();
        categoryPlot5.setFixedLegendItems(legendItemCollection32);
        org.jfree.chart.LegendItem legendItem34 = null;
        legendItemCollection32.add(legendItem34);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(legendItemCollection32);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot0.setSeparatorStroke(stroke3);
        boolean boolean5 = ringPlot0.getSectionOutlinesVisible();
        java.awt.Font font7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        boolean boolean20 = jFreeChart19.isNotify();
        java.awt.Image image21 = jFreeChart19.getBackgroundImage();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart19.getLegend();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) ringPlot0, jFreeChart19, 10, (int) '4');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(image21);
        org.junit.Assert.assertNull(legendTitle22);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = ringPlot9.getDrawingSupplier();
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot9.setShadowPaint(paint11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint11);
        dateAxis3.setTickLabelPaint(paint11);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) paint11);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date17 = dateAxis16.getMaximumDate();
        dateAxis16.setAutoRange(true);
        java.awt.Shape shape20 = dateAxis16.getDownArrow();
        boolean boolean21 = ringPlot0.equals((java.lang.Object) dateAxis16);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setLabelToolTip("ClassContext");
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date28 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        double double31 = dateAxis27.getUpperMargin();
        java.awt.Shape shape32 = dateAxis27.getLeftArrow();
        dateAxis22.setDownArrow(shape32);
        dateAxis16.setUpArrow(shape32);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        java.awt.Stroke stroke4 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.clearRangeMarkers((int) (short) 0);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Category Plot");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot4.setURLGenerator(pieURLGenerator7);
        boolean boolean9 = textFragment3.equals((java.lang.Object) ringPlot4);
        textLine1.removeFragment(textFragment3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 90.0d, (double) (byte) 1, (double) 10L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent16);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRange(true);
        java.awt.Shape shape5 = dateAxis1.getDownArrow();
        dateAxis1.setInverted(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot13.getSeriesRenderingOrder();
        xYPlot12.setSeriesRenderingOrder(seriesRenderingOrder14);
        xYPlot12.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = ringPlot18.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLegendLabelToolTipGenerator();
        java.awt.Image image21 = null;
        ringPlot18.setBackgroundImage(image21);
        double double23 = ringPlot18.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date27 = dateAxis26.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        dateAxis26.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date38 = dateAxis37.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        java.lang.String str41 = categoryPlot40.getPlotType();
        java.lang.String str42 = categoryPlot40.getPlotType();
        categoryPlot40.setRangeCrosshairVisible(true);
        categoryPlot40.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot40.getRenderer();
        boolean boolean47 = color33.equals((java.lang.Object) categoryPlot40);
        ringPlot18.setLabelLinkPaint((java.awt.Paint) color33);
        boolean boolean49 = xYPlot12.equals((java.lang.Object) color33);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot12.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.025d + "'", double23 == 0.025d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D3.configure();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        dateAxis7.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat14 = null;
        dateAxis7.setDateFormatOverride(dateFormat14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        categoryAxis3D3.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        dateAxis20.setAutoRange(true);
        java.awt.Shape shape24 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer25);
        double double27 = categoryAxis3D3.getLabelAngle();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot5.getRangeAxisEdge((int) (short) -1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot5.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        jFreeChart13.removeLegend();
        int int15 = jFreeChart13.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart13.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        boolean boolean23 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot5.zoomDomainAxes(0.0d, (double) (short) 10, plotRenderingInfo26, point2D27);
        boolean boolean29 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = xYPlot31.getOrientation();
        boolean boolean33 = xYPlot31.isRangeZoomable();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot31.getRangeMarkers(0, layer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot31.getDomainAxisLocation((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date42 = dateAxis41.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis41, categoryItemRenderer43);
        java.lang.String str45 = categoryPlot44.getPlotType();
        java.lang.String str46 = categoryPlot44.getPlotType();
        categoryPlot44.setRangeCrosshairVisible(true);
        categoryPlot44.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot44.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = xYPlot52.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation51, plotOrientation53);
        xYPlot31.setDomainAxisLocation(axisLocation51);
        categoryPlot5.setDomainAxisLocation((int) (short) 10, axisLocation51);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Category Plot" + "'", str45.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Category Plot" + "'", str46.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperMargin();
        dateAxis2.configure();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat9 = null;
        dateAxis2.setDateFormatOverride(dateFormat9);
        double double11 = dateAxis2.getUpperBound();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot12.getRendererForDataset(xYDataset15);
        xYPlot12.mapDatasetToDomainAxis((-739), (int) '#');
        xYPlot12.setDomainCrosshairVisible(true);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        boolean boolean23 = xYPlot12.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 51.0d + "'", double11 == 51.0d);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Font font8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        java.util.List list22 = jFreeChart20.getSubtitles();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        java.awt.Paint paint24 = textTitle2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint8 = multiplePiePlot7.getAggregatedItemsPaint();
        multiplePiePlot7.setLimit(10.0d);
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot7.getPieChart();
        boolean boolean12 = blockBorder6.equals((java.lang.Object) multiplePiePlot7);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        int int14 = jFreeChart13.getSubtitleCount();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!", font16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        jFreeChart13.addSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart13.createBufferedImage(0, (int) '4', chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (52) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.clearSubtitles();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart13.getTitle();
        java.lang.String str19 = textTitle18.getToolTipText();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot4.getLabelPadding();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        boolean boolean18 = rectangleInsets5.equals((java.lang.Object) true);
        double double20 = rectangleInsets5.extendWidth(0.0d);
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        boolean boolean22 = numberAxis3D0.isNegativeArrowVisible();
        java.text.NumberFormat numberFormat23 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color26 = color25.brighter();
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = ringPlot28.getDrawingSupplier();
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot28.setShadowPaint(paint30);
        numberAxis3D0.setAxisLinePaint(paint30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle19.setWidth((double) (byte) 10);
        textTitle19.setURLText("");
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        textTitle19.setPaint(paint25);
        java.lang.Object obj27 = textTitle19.clone();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getDomainMarkers((int) (short) 10, layer11);
        boolean boolean13 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 1.0f);
        try {
            boolean boolean16 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(200.0d, (java.awt.Paint) color1, stroke2, paint3, stroke4, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        java.awt.Paint paint4 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        java.awt.Paint paint10 = ringPlot0.getNoDataMessagePaint();
        java.awt.Paint paint11 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot0.getLabelPadding();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date10 = dateAxis9.getMaximumDate();
        dateAxis9.setAutoRange(true);
        java.awt.Shape shape13 = dateAxis9.getDownArrow();
        dateAxis9.setInverted(true);
        boolean boolean16 = dateAxis9.isAutoTickUnitSelection();
        dateAxis9.setLabel("Category Plot");
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis9.setAxisLinePaint(paint19);
        ringPlot0.setSectionPaint((java.lang.Comparable) 0.5f, paint19);
        double double22 = ringPlot0.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        polarPlot4.setAngleGridlinePaint(paint5);
        boolean boolean7 = polarPlot4.isRadiusGridlinesVisible();
        java.lang.String str8 = polarPlot4.getPlotType();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot5.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date16 = dateAxis15.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        double double19 = dateAxis15.getFixedDimension();
        dateAxis15.setVerticalTickLabels(true);
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        double[] doubleArray30 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray35 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray40 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray45 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray50 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[] doubleArray55 = new double[] { 100.0d, 100.0f, 0.0d, (byte) 10 };
        double[][] doubleArray56 = new double[][] { doubleArray30, doubleArray35, doubleArray40, doubleArray45, doubleArray50, doubleArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Rotation.CLOCKWISE", "Rotation.CLOCKWISE", doubleArray56);
        categoryPlot5.setDataset(0, categoryDataset57);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date62 = dateAxis61.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, (org.jfree.chart.axis.ValueAxis) dateAxis61, categoryItemRenderer63);
        java.lang.String str65 = categoryPlot64.getPlotType();
        java.lang.String str66 = categoryPlot64.getPlotType();
        categoryPlot64.setRangeCrosshairVisible(true);
        categoryPlot64.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation71 = categoryPlot64.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = xYPlot72.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation71, plotOrientation73);
        categoryPlot5.setOrientation(plotOrientation73);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Category Plot" + "'", str65.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Category Plot" + "'", str66.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot0.setBackgroundAlpha((float) '4');
        java.awt.Stroke stroke10 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.lang.String str9 = categoryPlot8.getPlotType();
        java.lang.String str10 = categoryPlot8.getPlotType();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        jFreeChart14.setTextAntiAlias(true);
        boolean boolean17 = blockContainer0.equals((java.lang.Object) true);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        textTitle20.setWidth((double) (byte) 10);
        textTitle20.setHeight((double) (byte) 100);
        textTitle20.setExpandToFitSpace(false);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle20);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D7.configure();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        dateAxis11.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat18 = null;
        dateAxis11.setDateFormatOverride(dateFormat18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        dateAxis11.resizeRange((double) (-1L), 1.0E-5d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot30.setDomainCrosshairStroke(stroke31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot30.getRangeAxisEdge((-12517568));
        try {
            java.util.List list35 = dateAxis11.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot5.setRenderer(categoryItemRenderer13, true);
        java.lang.String str16 = categoryPlot5.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot5.setDomainAxis(categoryAxis17);
        categoryAxis17.setMaximumCategoryLabelLines(255);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getDomainAxisLocation((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        categoryPlot13.setRangeCrosshairVisible(false);
        categoryPlot13.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot13.setAnchorValue((double) (short) 0, false);
        boolean boolean21 = categoryPlot13.isDomainZoomable();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = ringPlot23.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = ringPlot23.getLegendLabelToolTipGenerator();
        java.awt.Image image26 = null;
        ringPlot23.setBackgroundImage(image26);
        double double28 = ringPlot23.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date32 = dateAxis31.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        dateAxis31.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis31.setTickLabelPaint((java.awt.Paint) color38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date43 = dateAxis42.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer44);
        java.lang.String str46 = categoryPlot45.getPlotType();
        java.lang.String str47 = categoryPlot45.getPlotType();
        categoryPlot45.setRangeCrosshairVisible(true);
        categoryPlot45.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot45.getRenderer();
        boolean boolean52 = color38.equals((java.lang.Object) categoryPlot45);
        ringPlot23.setLabelLinkPaint((java.awt.Paint) color38);
        java.awt.Color color54 = java.awt.Color.getColor("", color38);
        java.awt.Color color55 = color38.brighter();
        categoryPlot13.setRangeCrosshairPaint((java.awt.Paint) color55);
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot13.getLegendItems();
        categoryPlot13.clearDomainMarkers();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot13);
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNull(pieSectionLabelGenerator25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.025d + "'", double28 == 0.025d);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Category Plot" + "'", str46.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Category Plot" + "'", str47.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(legendItemCollection57);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot7.getOrientation();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        java.awt.Color color10 = java.awt.Color.WHITE;
        xYPlot7.setDomainZeroBaselinePaint((java.awt.Paint) color10);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        boolean boolean14 = color10.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Paint paint7 = ringPlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setExplodePercent((java.lang.Comparable) "TextAnchor.HALF_ASCENT_RIGHT", (double) (short) 10);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        boolean boolean3 = numberAxis3D0.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D0.getMarkerBand();
        boolean boolean5 = numberAxis3D0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        java.lang.String str5 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset2, (java.lang.Comparable) date4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "", "java.awt.Color[r=255,g=255,b=255]", image3, "ClassContext", "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=255,b=255]");
        projectInfo7.setLicenceText("RectangleAnchor.LEFT");
        projectInfo7.setLicenceText("ThreadContext");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeIncludesZero();
        numberAxis3D0.setAutoRangeMinimumSize(90.0d, true);
        numberAxis3D0.setLabelToolTip("");
        numberAxis3D0.setUpperMargin(1.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double5 = ringPlot0.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        dateAxis8.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        java.lang.String str24 = categoryPlot22.getPlotType();
        categoryPlot22.setRangeCrosshairVisible(true);
        categoryPlot22.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot22.getRenderer();
        boolean boolean29 = color15.equals((java.lang.Object) categoryPlot22);
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color15);
        double double31 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        xYPlot32.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot32.getRendererForDataset(xYDataset35);
        xYPlot32.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot32.setBackgroundAlpha((float) '4');
        java.awt.Stroke stroke42 = xYPlot32.getDomainGridlineStroke();
        ringPlot0.setBaseSectionOutlineStroke(stroke42);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer36);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        org.jfree.chart.LegendItem legendItem13 = null;
        legendItemCollection12.add(legendItem13);
        java.lang.Object obj15 = legendItemCollection12.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Rotation.CLOCKWISE");
        textLine0.addFragment(textFragment2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "LengthConstraintType.NONE", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot4.getLabelPadding();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        boolean boolean18 = rectangleInsets5.equals((java.lang.Object) true);
        double double20 = rectangleInsets5.extendWidth(0.0d);
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        numberAxis3D0.setAutoRangeStickyZero(true);
        numberAxis3D0.setTickLabelsVisible(false);
        java.lang.String str26 = numberAxis3D0.getLabel();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date34 = dateAxis33.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        java.lang.String str37 = categoryPlot36.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = null;
        categoryPlot36.datasetChanged(datasetChangeEvent38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot36.setRenderer(categoryItemRenderer40);
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot36.getRangeMarkers(100, layer43);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot36.getDomainMarkers(layer45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot36.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            org.jfree.chart.axis.AxisState axisState50 = numberAxis3D0.draw(graphics2D27, 3.0d, rectangle2D29, rectangle2D30, rectangleEdge48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Category Plot" + "'", str37.equals("Category Plot"));
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setHeight((double) (byte) 100);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle2.draw(graphics2D7, rectangle2D8);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, false);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot11.getOrientation();
        boolean boolean13 = xYPlot11.isRangeZoomable();
        java.awt.Color color14 = java.awt.Color.WHITE;
        xYPlot11.setDomainZeroBaselinePaint((java.awt.Paint) color14);
        java.lang.String str16 = color14.toString();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        double double24 = dateAxis20.getUpperMargin();
        int int25 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date27 = dateAxis26.getMaximumDate();
        org.jfree.data.Range range28 = dateAxis26.getRange();
        org.jfree.data.Range range29 = dateAxis26.getRange();
        dateAxis26.setTickMarksVisible(true);
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis26.setTickMarkPaint(paint32);
        org.jfree.chart.axis.Timeline timeline34 = dateAxis26.getTimeline();
        dateAxis20.setTimeline(timeline34);
        dateAxis20.setTickMarkOutsideLength((float) (short) 1);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=255]"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(timeline34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 10, (float) 8, 0.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot1.getOrientation();
        boolean boolean3 = xYPlot1.isRangeZoomable();
        java.awt.Color color4 = java.awt.Color.WHITE;
        xYPlot1.setDomainZeroBaselinePaint((java.awt.Paint) color4);
        float[] floatArray6 = null;
        float[] floatArray7 = color4.getRGBComponents(floatArray6);
        float[] floatArray8 = color0.getRGBComponents(floatArray6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRange(true);
        java.awt.Shape shape5 = dateAxis1.getDownArrow();
        dateAxis1.setInverted(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot13.getSeriesRenderingOrder();
        xYPlot12.setSeriesRenderingOrder(seriesRenderingOrder14);
        xYPlot12.clearAnnotations();
        xYPlot12.clearAnnotations();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        dateAxis2.setVerticalTickLabels(true);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot10.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        xYPlot10.datasetChanged(datasetChangeEvent12);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        categoryPlot7.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot7.getDomainMarkers((int) (short) 10, layer13);
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        boolean boolean16 = numberAxis3D0.isAutoRange();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        ringPlot17.setSeparatorsVisible(false);
        java.awt.Shape shape20 = ringPlot17.getLegendItemShape();
        numberAxis3D0.setDownArrow(shape20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        boolean boolean7 = dateAxis0.isAutoTickUnitSelection();
        dateAxis0.setLabel("Category Plot");
        java.awt.Color color10 = java.awt.Color.CYAN;
        dateAxis0.setLabelPaint((java.awt.Paint) color10);
        float[] floatArray12 = null;
        float[] floatArray13 = color10.getColorComponents(floatArray12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.lang.String str9 = categoryPlot8.getPlotType();
        java.lang.String str10 = categoryPlot8.getPlotType();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        jFreeChart14.setTextAntiAlias(true);
        boolean boolean17 = blockContainer0.equals((java.lang.Object) true);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font19, (java.awt.Paint) color20);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("");
        textLine21.addFragment(textFragment23);
        boolean boolean25 = blockContainer0.equals((java.lang.Object) textLine21);
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement26);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) (byte) 10, 0.0d, (double) (byte) -1);
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getRight();
        valueMarker1.setLabelOffset(rectangleInsets6);
        java.awt.Paint paint10 = valueMarker1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D7.configure();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        dateAxis11.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat18 = null;
        dateAxis11.setDateFormatOverride(dateFormat18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        dateAxis11.resizeRange((double) (-1L), 1.0E-5d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer25);
        java.awt.Paint paint27 = dateAxis11.getTickMarkPaint();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.awt.Color color18 = java.awt.Color.white;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray24 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray25 = color19.getComponents(floatArray24);
        float[] floatArray26 = color18.getRGBComponents(floatArray25);
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) (-1.0d), (java.awt.Paint) color18);
        categoryAxis3D2.setCategoryMargin((double) (short) -1);
        float float30 = categoryAxis3D2.getMaximumCategoryLabelWidthRatio();
        categoryAxis3D2.addCategoryLabelToolTip((java.lang.Comparable) "hi!", "ChartEntity: tooltip = Rotation.CLOCKWISE");
        categoryAxis3D2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "{0}");
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot0.getOrientation();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean9 = numberAxis3D8.getAutoRangeIncludesZero();
        xYPlot0.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = jFreeChart13.getCategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot15.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(categoryPlot15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        categoryPlot7.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot7.getDomainMarkers((int) (short) 10, layer13);
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot18.getOrientation();
        boolean boolean20 = xYPlot18.isRangeZoomable();
        java.awt.Color color21 = java.awt.Color.WHITE;
        xYPlot18.setDomainZeroBaselinePaint((java.awt.Paint) color21);
        java.awt.Paint paint23 = xYPlot18.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date26 = dateAxis25.getMaximumDate();
        xYPlot18.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis25, false);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = xYPlot29.getOrientation();
        boolean boolean31 = xYPlot29.isRangeZoomable();
        java.awt.Color color32 = java.awt.Color.WHITE;
        xYPlot29.setDomainZeroBaselinePaint((java.awt.Paint) color32);
        java.lang.String str34 = color32.toString();
        xYPlot18.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date39 = dateAxis38.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer40);
        categoryPlot41.setRangeCrosshairVisible(false);
        categoryPlot41.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot41.getRangeMarkers(layer46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot41.getDomainAxisEdge();
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = ringPlot49.getLabelPadding();
        double double52 = rectangleInsets50.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date56 = dateAxis55.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis55, categoryItemRenderer57);
        java.lang.String str59 = categoryPlot58.getPlotType();
        java.lang.String str60 = categoryPlot58.getPlotType();
        categoryPlot58.setRangeCrosshairVisible(true);
        boolean boolean63 = rectangleInsets50.equals((java.lang.Object) true);
        double double65 = rectangleInsets50.extendWidth(0.0d);
        categoryPlot41.setAxisOffset(rectangleInsets50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = xYPlot70.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent72 = null;
        xYPlot70.datasetChanged(datasetChangeEvent72);
        java.awt.geom.Point2D point2D74 = xYPlot70.getQuadrantOrigin();
        categoryPlot41.zoomRangeAxes(0.05d, 0.0d, plotRenderingInfo69, point2D74);
        xYPlot18.setQuadrantOrigin(point2D74);
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo17, point2D74);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str34.equals("java.awt.Color[r=255,g=255,b=255]"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.0d + "'", double52 == 2.0d);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Category Plot" + "'", str59.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Category Plot" + "'", str60.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 4.0d + "'", double65 == 4.0d);
        org.junit.Assert.assertNotNull(plotOrientation71);
        org.junit.Assert.assertNotNull(point2D74);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomInset((double) 1L);
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) 1, (float) 0, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, 4.0d, (double) (-254));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block12 = null;
        blockContainer11.add(block12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint17.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D19 = flowArrangement10.arrange(blockContainer11, graphics2D14, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = ' ';
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Class<?> wildcardClass1 = unitType0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot2.getRendererForDataset(xYDataset5);
        java.lang.Object obj7 = null;
        boolean boolean8 = xYPlot2.equals(obj7);
        boolean boolean9 = xYPlot2.isRangeZoomable();
        boolean boolean10 = unitType0.equals((java.lang.Object) xYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot11.getLabelPadding();
        double double14 = rectangleInsets12.calculateBottomOutset(0.0d);
        java.awt.Font font16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        java.lang.String str24 = categoryPlot22.getPlotType();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font16, (org.jfree.chart.plot.Plot) categoryPlot22, false);
        boolean boolean29 = jFreeChart28.isNotify();
        java.awt.Image image30 = jFreeChart28.getBackgroundImage();
        boolean boolean31 = rectangleInsets12.equals((java.lang.Object) jFreeChart28);
        xYPlot2.setAxisOffset(rectangleInsets12);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot2.getDomainAxisEdge((int) (byte) 100);
        int int35 = xYPlot2.getBackgroundImageAlignment();
        java.lang.Object obj36 = xYPlot2.clone();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(image30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", graphics2D1, 0.14d, 100.0f, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        textTitle5.setWidth((double) (byte) 10);
        textTitle5.setURLText("");
        java.awt.Font font11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.lang.String str18 = categoryPlot17.getPlotType();
        java.lang.String str19 = categoryPlot17.getPlotType();
        categoryPlot17.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) categoryPlot17, false);
        java.awt.RenderingHints renderingHints24 = jFreeChart23.getRenderingHints();
        java.util.List list25 = jFreeChart23.getSubtitles();
        textTitle5.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        boolean boolean27 = textTitle5.getNotify();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date29 = dateAxis28.getMaximumDate();
        org.jfree.data.Range range30 = dateAxis28.getRange();
        org.jfree.data.Range range31 = dateAxis28.getRange();
        dateAxis28.setTickMarksVisible(true);
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis28.setTickMarkPaint(paint34);
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        ringPlot36.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot();
        ringPlot39.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot39.setSeparatorStroke(stroke42);
        ringPlot36.setSeparatorStroke(stroke42);
        java.awt.Paint paint45 = ringPlot36.getShadowPaint();
        java.awt.Paint paint46 = ringPlot36.getNoDataMessagePaint();
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = ringPlot47.getDrawingSupplier();
        java.awt.Paint paint49 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot47.setShadowPaint(paint49);
        ringPlot36.setLabelOutlinePaint(paint49);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = ringPlot36.getLabelPadding();
        dateAxis28.setLabelInsets(rectangleInsets52);
        textTitle5.setPadding(rectangleInsets52);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle5);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(drawingSupplier48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot5.setRenderer(categoryItemRenderer13, true);
        boolean boolean16 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot5.getDomainAxis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(categoryAxis18);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double5 = ringPlot0.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        dateAxis8.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        java.lang.String str24 = categoryPlot22.getPlotType();
        categoryPlot22.setRangeCrosshairVisible(true);
        categoryPlot22.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot22.getRenderer();
        boolean boolean29 = color15.equals((java.lang.Object) categoryPlot22);
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color15);
        double double31 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator32 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator32);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent13);
        boolean boolean15 = categoryPlot11.isDomainGridlinesVisible();
        java.awt.Font font17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.lang.String str24 = categoryPlot23.getPlotType();
        java.lang.String str25 = categoryPlot23.getPlotType();
        categoryPlot23.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font17, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        boolean boolean30 = jFreeChart29.isNotify();
        jFreeChart29.setTextAntiAlias(false);
        jFreeChart29.setBackgroundImageAlignment(0);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean15, jFreeChart29);
        java.awt.Paint paint36 = jFreeChart29.getBackgroundPaint();
        xYPlot0.setDomainZeroBaselinePaint(paint36);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16777216) + "'", int1 == (-16777216));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 1, 0.0f, (float) 100L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        java.lang.String str24 = categoryPlot22.getPlotType();
        categoryPlot22.setRangeCrosshairVisible(true);
        categoryPlot22.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot22.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = xYPlot30.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation29, plotOrientation31);
        categoryPlot5.setDomainAxisLocation((int) '#', axisLocation29, true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        java.awt.Color color8 = color5.darker();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-12517568), 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Paint paint7 = textTitle2.getBackgroundPaint();
        textTitle2.setMargin((double) 100.0f, (double) (-1), (double) 100.0f, (double) '#');
        textTitle2.setWidth((double) 0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) (byte) 10, 0.0d, (double) (byte) -1);
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getRight();
        valueMarker1.setLabelOffset(rectangleInsets6);
        java.awt.Stroke stroke10 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = ringPlot10.getDrawingSupplier();
        java.awt.Paint paint12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot10.setShadowPaint(paint12);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint12);
        dateAxis4.setTickLabelPaint(paint12);
        boolean boolean16 = ringPlot1.equals((java.lang.Object) paint12);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        dateAxis17.setAutoRange(true);
        java.awt.Shape shape21 = dateAxis17.getDownArrow();
        boolean boolean22 = ringPlot1.equals((java.lang.Object) dateAxis17);
        boolean boolean23 = textAnchor0.equals((java.lang.Object) ringPlot1);
        boolean boolean24 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        double double5 = ringPlot1.getSectionDepth();
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray12 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray13 = color7.getComponents(floatArray12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = xYPlot14.getOrientation();
        boolean boolean16 = xYPlot14.isRangeZoomable();
        java.awt.Color color17 = java.awt.Color.WHITE;
        xYPlot14.setDomainZeroBaselinePaint((java.awt.Paint) color17);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = ringPlot19.getDrawingSupplier();
        java.awt.Paint paint21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot19.setShadowPaint(paint21);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        dateAxis23.setAutoRange(true);
        java.awt.Shape shape27 = dateAxis23.getDownArrow();
        dateAxis23.setInverted(true);
        boolean boolean30 = dateAxis23.isAutoTickUnitSelection();
        dateAxis23.setLabel("Category Plot");
        java.awt.Color color33 = java.awt.Color.CYAN;
        dateAxis23.setLabelPaint((java.awt.Paint) color33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color37 = color36.brighter();
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color7, color17, paint21, color33, color35, color37 };
        java.awt.Paint[] paintArray39 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray38, paintArray39, strokeArray40, strokeArray41, shapeArray42);
        java.awt.Paint paint44 = defaultDrawingSupplier43.getNextOutlinePaint();
        ringPlot1.setShadowPaint(paint44);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(paintArray39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.mapDatasetToDomainAxis((-739), (int) '#');
        xYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot0.getRangeAxisLocation((int) '#');
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 1.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) (byte) 10, 0.0d, (double) (byte) -1);
        double double20 = rectangleInsets19.getTop();
        double double21 = rectangleInsets19.getRight();
        valueMarker14.setLabelOffset(rectangleInsets19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio(1.0f);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = ringPlot27.getDrawingSupplier();
        float float29 = ringPlot27.getBackgroundImageAlpha();
        ringPlot27.setIgnoreNullValues(true);
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot27.setSectionOutlinePaint((java.lang.Comparable) 100, paint33);
        boolean boolean35 = categoryAxis3D24.equals((java.lang.Object) paint33);
        valueMarker14.setPaint(paint33);
        org.jfree.chart.util.Layer layer37 = null;
        xYPlot0.addRangeMarker((-739), (org.jfree.chart.plot.Marker) valueMarker14, layer37);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        org.jfree.chart.axis.Timeline timeline17 = null;
        dateAxis6.setTimeline(timeline17);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        xYPlot0.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        xYPlot0.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot5.getRangeMarkers(100, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot5.getDomainMarkers(layer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str18 = rectangleEdge17.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleEdge.TOP" + "'", str18.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Stroke stroke9 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = ringPlot10.getLabelPadding();
        double double13 = rectangleInsets11.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date17 = dateAxis16.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.lang.String str20 = categoryPlot19.getPlotType();
        java.lang.String str21 = categoryPlot19.getPlotType();
        categoryPlot19.setRangeCrosshairVisible(true);
        boolean boolean24 = rectangleInsets11.equals((java.lang.Object) true);
        double double26 = rectangleInsets11.extendWidth(0.0d);
        double double28 = rectangleInsets11.calculateRightOutset((double) (short) 1);
        ringPlot0.setInsets(rectangleInsets11, false);
        double double32 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets11.createInsetRectangle(rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Category Plot" + "'", str20.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        double double18 = dateAxis14.getFixedDimension();
        dateAxis14.setVerticalTickLabels(true);
        java.awt.Shape shape21 = dateAxis14.getLeftArrow();
        dateAxis14.setAutoRange(false);
        dateAxis14.setAutoRange(false);
        org.jfree.data.Range range26 = categoryPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        try {
            dateAxis14.setRange((double) 0L, (double) (-739));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = ringPlot6.getDrawingSupplier();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setShadowPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint8);
        dateAxis0.setTickLabelPaint(paint8);
        java.lang.Object obj12 = dateAxis0.clone();
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        dateAxis14.setAutoRange(true);
        java.awt.Shape shape18 = dateAxis14.getDownArrow();
        dateAxis14.setInverted(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis14.calculateHighestVisibleTickValue(dateTickUnit21);
        java.util.Date date23 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit21);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot0.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo8, point2D9, true);
        xYPlot0.setDomainZeroBaselineVisible(true);
        xYPlot0.setWeight((-254));
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot5);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D14.configure();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date19 = dateAxis18.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        dateAxis18.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat25 = null;
        dateAxis18.setDateFormatOverride(dateFormat25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        java.awt.Color color30 = java.awt.Color.white;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray36 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray37 = color31.getComponents(floatArray36);
        float[] floatArray38 = color30.getRGBComponents(floatArray37);
        categoryAxis3D14.setTickLabelPaint((java.lang.Comparable) (-1.0d), (java.awt.Paint) color30);
        categoryPlot5.setDomainGridlinePaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        xYPlot0.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes((double) 100, plotRenderingInfo5, point2D6);
        java.awt.Paint paint8 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot0.getRangeAxisLocation((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot11.getRendererForDataset(xYDataset14);
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot11.equals(obj16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot11.getDataset();
        java.awt.Stroke stroke19 = xYPlot11.getRangeGridlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke19);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        java.awt.Image image4 = ringPlot0.getBackgroundImage();
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color8 = color7.darker();
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range3, lengthConstraintType4, (-1.0d), range8, lengthConstraintType9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.data.Range range14 = dateAxis12.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range14, lengthConstraintType15, (-1.0d), range19, lengthConstraintType20);
        org.jfree.data.Range range22 = org.jfree.data.Range.combine(range8, range19);
        double double23 = range19.getLength();
        boolean boolean25 = range19.contains((double) (-16777216));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot0.setSeparatorStroke(stroke3);
        boolean boolean5 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.chart.plot.Plot plot6 = ringPlot0.getRootPlot();
        double double7 = ringPlot0.getMaximumLabelWidth();
        ringPlot0.setPieIndex((-1));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = ringPlot6.getDrawingSupplier();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setShadowPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint8);
        dateAxis0.setTickLabelPaint(paint8);
        java.lang.Object obj12 = dateAxis0.clone();
        dateAxis0.configure();
        org.jfree.data.Range range14 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date16 = dateAxis15.getMaximumDate();
        dateAxis15.setAutoRange(true);
        java.awt.Shape shape19 = dateAxis15.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape19, "Rotation.CLOCKWISE", "ClassContext");
        dateAxis0.setLeftArrow(shape19);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color5);
        double double8 = rectangleInsets3.calculateBottomOutset(4.0d);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets3.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedRangeAxisSpace();
        org.jfree.chart.plot.Plot plot11 = categoryPlot5.getParent();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.data.Range range9 = dateAxis7.getRange();
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range10, (double) (byte) -1);
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (double) (byte) 0);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range12, (double) (byte) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint4.toRangeWidth(range12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot5.getRangeMarkers(100, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot5.getDomainMarkers(layer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot5.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        double double11 = dateAxis7.getFixedDimension();
        org.jfree.data.Range range12 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D15.configure();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        dateAxis19.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat26 = null;
        dateAxis19.setDateFormatOverride(dateFormat26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        dateAxis19.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date33 = dateAxis32.getMaximumDate();
        dateAxis32.setAutoRange(true);
        java.awt.Shape shape36 = dateAxis32.getDownArrow();
        dateAxis19.setDownArrow(shape36);
        dateAxis19.setRangeAboutValue((-1.0d), 0.0d);
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRange(true);
        java.awt.Shape shape5 = dateAxis1.getDownArrow();
        dateAxis1.setInverted(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer11);
        xYPlot12.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date20 = dateAxis19.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        categoryPlot22.setRangeCrosshairVisible(false);
        categoryPlot22.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot22.getRangeMarkers(layer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot22.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = xYPlot33.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot33.datasetChanged(datasetChangeEvent35);
        java.awt.geom.Point2D point2D37 = xYPlot33.getQuadrantOrigin();
        categoryPlot22.zoomRangeAxes((double) 10L, (double) 10.0f, plotRenderingInfo32, point2D37);
        try {
            xYPlot12.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D37, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 0, (float) 100L, 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-668) + "'", int3 == (-668));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat9 = null;
        dateAxis2.setDateFormatOverride(dateFormat9);
        double double11 = dateAxis2.getUpperBound();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot12.getRendererForDataset(xYDataset15);
        xYPlot12.mapDatasetToDomainAxis((-739), (int) '#');
        xYPlot12.setDomainCrosshairVisible(true);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot12.getDomainMarkers(layer23);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = ringPlot25.getDrawingSupplier();
        java.awt.Paint paint27 = ringPlot25.getLabelPaint();
        java.awt.Paint paint28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot25.setLabelOutlinePaint(paint28);
        xYPlot12.setDomainZeroBaselinePaint(paint28);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 51.0d + "'", double11 == 51.0d);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(8);
        pieLabelDistributor1.clear();
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxisForDataset((int) (byte) 1);
        java.lang.Object obj8 = categoryPlot5.clone();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot5.getAxisOffset();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(valueAxis7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot5.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot16.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot16.datasetChanged(datasetChangeEvent18);
        java.awt.geom.Point2D point2D20 = xYPlot16.getQuadrantOrigin();
        categoryPlot5.zoomRangeAxes((double) 10L, (double) 10.0f, plotRenderingInfo15, point2D20);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = null;
        try {
            categoryPlot5.addDomainMarker(categoryMarker22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(point2D20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.CrosshairState crosshairState15 = null;
        boolean boolean16 = xYPlot0.render(graphics2D11, rectangle2D12, 0, plotRenderingInfo14, crosshairState15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot17.getRendererForDataset(xYDataset20);
        java.lang.Object obj22 = null;
        boolean boolean23 = xYPlot17.equals(obj22);
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot17.getDataset();
        java.awt.Stroke stroke25 = xYPlot17.getRangeGridlineStroke();
        xYPlot0.setDomainGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleEdge.TOP", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot0.getOrientation();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean9 = numberAxis3D8.getAutoRangeIncludesZero();
        xYPlot0.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleLabelsVisible();
        java.awt.Paint paint6 = polarPlot4.getAngleGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot7.getRendererForDataset(xYDataset10);
        java.lang.Object obj12 = null;
        boolean boolean13 = xYPlot7.equals(obj12);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot7.getDataset();
        java.awt.Stroke stroke15 = xYPlot7.getRangeGridlineStroke();
        polarPlot4.setRadiusGridlineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot5.getRangeAxisEdge(1);
        int int15 = categoryPlot5.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        try {
            categoryPlot5.setRenderer((-739), categoryItemRenderer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = dateAxis2.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        float float8 = dateAxis7.getTickMarkInsideLength();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis7.getTickMarkPosition();
        dateAxis2.setTickMarkPosition(dateTickMarkPosition9);
        java.awt.Paint paint11 = null;
        try {
            dateAxis2.setTickLabelPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 'a', (float) (short) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeIncludesZero();
        numberAxis3D0.setAutoRangeMinimumSize(90.0d, true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot14.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot22.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = numberAxis3D0.draw(graphics2D5, (double) (short) 100, rectangle2D7, rectangle2D8, rectangleEdge24, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent9);
        boolean boolean11 = lineBorder0.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot12.drawDomainTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color18 = color17.brighter();
        xYPlot12.setDomainZeroBaselinePaint((java.awt.Paint) color17);
        boolean boolean20 = lineBorder0.equals((java.lang.Object) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder0.getInsets();
        double double23 = rectangleInsets21.calculateRightOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot5.getRowRenderingOrder();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedDimension();
        boolean boolean17 = numberAxis3D15.isVerticalTickLabels();
        try {
            categoryPlot5.setRangeAxis((-668), (org.jfree.chart.axis.ValueAxis) numberAxis3D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = ringPlot6.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot6.getLegendLabelToolTipGenerator();
        java.awt.Image image9 = null;
        ringPlot6.setBackgroundImage(image9);
        double double11 = ringPlot6.getLabelLinkMargin();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 0, plotRenderingInfo13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        float float17 = dateAxis16.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer18);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        polarPlot19.setAngleGridlinePaint(paint20);
        ringPlot0.setSeparatorPaint(paint20);
        java.awt.Stroke stroke23 = ringPlot0.getLabelLinkStroke();
        org.junit.Assert.assertNull(pieDataset3);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(piePlotState14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Font font8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        java.util.List list22 = jFreeChart20.getSubtitles();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        boolean boolean24 = textTitle2.getNotify();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date26 = dateAxis25.getMaximumDate();
        org.jfree.data.Range range27 = dateAxis25.getRange();
        org.jfree.data.Range range28 = dateAxis25.getRange();
        dateAxis25.setTickMarksVisible(true);
        java.awt.Paint paint31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis25.setTickMarkPaint(paint31);
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        ringPlot33.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        ringPlot36.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot36.setSeparatorStroke(stroke39);
        ringPlot33.setSeparatorStroke(stroke39);
        java.awt.Paint paint42 = ringPlot33.getShadowPaint();
        java.awt.Paint paint43 = ringPlot33.getNoDataMessagePaint();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = ringPlot44.getDrawingSupplier();
        java.awt.Paint paint46 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot44.setShadowPaint(paint46);
        ringPlot33.setLabelOutlinePaint(paint46);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = ringPlot33.getLabelPadding();
        dateAxis25.setLabelInsets(rectangleInsets49);
        textTitle2.setPadding(rectangleInsets49);
        double double53 = rectangleInsets49.calculateBottomOutset((double) (short) 1);
        double double54 = rectangleInsets49.getLeft();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.0d + "'", double53 == 2.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        categoryPlot9.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot9.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot9.getDomainMarkers((int) (short) 10, layer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        boolean boolean21 = categoryPlot9.render(graphics2D17, rectangle2D18, (int) (byte) 10, plotRenderingInfo20);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = ringPlot23.getDrawingSupplier();
        float float25 = ringPlot23.getBackgroundImageAlpha();
        double double26 = ringPlot23.getInnerSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        ringPlot23.setDataset(pieDataset27);
        java.awt.Font font29 = ringPlot23.getLabelFont();
        java.awt.Paint paint30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font29, paint30);
        categoryPlot9.setOutlinePaint(paint30);
        ringPlot0.setLabelShadowPaint(paint30);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(textBlock31);
    }
}

