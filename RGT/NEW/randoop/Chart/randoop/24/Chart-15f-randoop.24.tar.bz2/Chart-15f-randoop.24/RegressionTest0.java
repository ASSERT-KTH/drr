import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (byte) 0, (double) (short) 1, (double) 100.0f, (double) 1.0f, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (short) -1, 0.0d, (double) (byte) 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = null;
        try {
            dateAxis0.setLabelFont(font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 1.0f, (float) (short) 100, (double) (short) 1, (float) '4', (float) 10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 10, 0.0f, textAnchor4, (double) ' ', 100.0f, (float) 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Category Plot", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { (short) 0, (short) 100, '#', 10, 10.0f, (-1) };
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, 0.0f, (float) 100, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            boolean boolean26 = categoryPlot5.removeRangeMarker((int) '4', marker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.setRangeCrosshairVisible(false);
        boolean boolean9 = verticalAlignment0.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setForegroundAlpha((float) (byte) 0);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D0.draw(graphics2D2, 100.0d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Category Plot");
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        try {
            org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        try {
            org.jfree.chart.title.Title title15 = jFreeChart13.getSubtitle((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.util.List list14 = null;
        try {
            jFreeChart13.setSubtitles(list14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color1 = java.awt.Color.getColor("Category Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            categoryPlot5.setRangeAxisLocation(0, axisLocation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets1.createInsetRectangle(rectangle2D4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.event.ChartChangeListener chartChangeListener15 = null;
        try {
            jFreeChart13.removeChangeListener(chartChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            jFreeChart13.draw(graphics2D15, rectangle2D16, point2D17, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = ringPlot6.getDrawingSupplier();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setShadowPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint8);
        dateAxis0.setTickLabelPaint(paint8);
        org.jfree.data.Range range12 = null;
        try {
            dateAxis0.setRange(range12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        float[] floatArray4 = new float[] { (short) 100 };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (byte) 10, (-1), 1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot5.getRangeMarkers(100, layer12);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot5.getFixedLegendItems();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(legendItemCollection14);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes(4.0d, plotRenderingInfo8, point2D9);
        java.awt.Image image11 = categoryPlot5.getBackgroundImage();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot5.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        dateAxis2.setAutoRange(false);
        dateAxis2.setRangeWithMargins(0.0d, (double) (short) 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Point2D point2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart13.draw(graphics2D14, rectangle2D15, point2D16, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxisForDataset((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(valueAxis7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        try {
            org.jfree.chart.plot.XYPlot xYPlot19 = jFreeChart13.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers(0, layer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            xYPlot0.handleClick((int) (byte) 1, (int) (short) 100, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = xYPlot0.removeRangeMarker(marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), (float) ' ', (float) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-739) + "'", int3 == (-739));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 0, 0, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.Marker marker3 = null;
        try {
            xYPlot0.addDomainMarker(marker3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            boolean boolean10 = categoryPlot5.removeDomainMarker((int) (short) 100, marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.SortOrder sortOrder12 = null;
        try {
            categoryPlot5.setRowRenderingOrder(sortOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers(0, layer4);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            xYPlot0.addRangeMarker((-1), marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        java.awt.Image image4 = ringPlot0.getBackgroundImage();
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Paint paint7 = ringPlot0.getSectionPaint(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(datasetGroup5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener14 = null;
        try {
            jFreeChart13.addChangeListener(chartChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.lang.Object obj1 = null;
        boolean boolean2 = blockBorder0.equals(obj1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.chart.util.Size2D size2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = rectangleConstraint4.calculateConstrainedSize(size2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        try {
            int int14 = categoryPlot5.getDomainAxisIndex(categoryAxis13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis3D0.getMarkerBand();
        numberAxis3D0.configure();
        org.junit.Assert.assertNull(markerAxisBand1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart13.createBufferedImage((int) (short) 0, (int) 'a', chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.Marker marker3 = null;
        try {
            xYPlot0.addRangeMarker(marker3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot7.getRangeAxisForDataset((int) (byte) 1);
        valueAxis9.resizeRange((double) (byte) 10, 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis9, categoryItemRenderer13);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener17 = null;
        try {
            jFreeChart13.removeChangeListener(chartChangeListener17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean13 = categoryPlot5.removeDomainMarker((int) 'a', marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        double double6 = rectangleInsets3.calculateRightOutset(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        try {
            boolean boolean3 = xYPlot0.removeDomainMarker(marker1, layer2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        try {
            org.jfree.chart.title.Title title16 = jFreeChart13.getSubtitle((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot5.setDomainAxisLocation(100, axisLocation9);
        java.lang.String str11 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        try {
            categoryPlot5.zoomRangeAxes((double) (-739), plotRenderingInfo13, point2D14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        dateAxis0.centerRange((double) (-1.0f));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range3, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, 0.0d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.data.Range range12 = new org.jfree.data.Range((double) (byte) -1, 0.0d);
        boolean boolean13 = categoryPlot5.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType4 = null;
        try {
            numberAxis3D0.setRangeType(rangeType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        try {
            categoryPlot5.addDomainMarker(categoryMarker11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.lang.String str10 = categoryPlot9.getPlotType();
        java.lang.String str11 = categoryPlot9.getPlotType();
        categoryPlot9.setRangeCrosshairVisible(true);
        boolean boolean14 = rectangleInsets1.equals((java.lang.Object) true);
        double double16 = rectangleInsets1.extendWidth(0.0d);
        double double18 = rectangleInsets1.calculateRightOutset((double) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets1.createOutsetRectangle(rectangle2D19, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { (byte) 0, dateTickUnit1, (-1), 0.0d, 100 };
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { (byte) 100, (-1L) };
        double[][] doubleArray9 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray8, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        dateAxis6.setAutoRange(true);
        java.awt.Shape shape10 = dateAxis6.getDownArrow();
        dateAxis6.setInverted(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        try {
            dateAxis0.setRange(date13, date15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.clearRangeMarkers((int) (short) -1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem14 = legendItemCollection12.get((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = ringPlot0.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            ringPlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) (short) 0, (float) (byte) 100, 1.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        boolean boolean7 = dateAxis0.isAutoTickUnitSelection();
        dateAxis0.setLabel("Category Plot");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        dateAxis10.setAutoRange(true);
        java.awt.Shape shape14 = dateAxis10.getDownArrow();
        dateAxis10.setInverted(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date19 = dateAxis18.getMaximumDate();
        try {
            dateAxis0.setRange(date17, date19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            xYPlot0.addRangeMarker(marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        double double5 = ringPlot1.getSectionDepth();
        boolean boolean6 = ringPlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        boolean boolean23 = categoryPlot5.isRangeCrosshairVisible();
        double double24 = categoryPlot5.getAnchorValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot5.setDomainAxisLocation(axisLocation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot4.getDrawingSupplier();
        java.awt.Paint paint6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot4.setShadowPaint(paint6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint6);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10);
        java.lang.Object obj5 = null;
        boolean boolean6 = range2.equals(obj5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            boolean boolean9 = categoryPlot5.removeDomainMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            ringPlot0.setLabelPadding(rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        ringPlot2.setURLGenerator(pieURLGenerator5);
        java.awt.Color color7 = java.awt.Color.green;
        ringPlot2.setLabelOutlinePaint((java.awt.Paint) color7);
        try {
            org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), (double) 0, (double) (byte) 100, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10.0f, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1.0f));
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle2.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        ringPlot0.setMaximumLabelWidth((-1.0d));
        double double5 = ringPlot0.getStartAngle();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean9 = xYPlot0.removeDomainMarker((int) '#', marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        categoryPlot5.clearDomainMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.lang.String str21 = categoryPlot20.getPlotType();
        java.lang.String str22 = categoryPlot20.getPlotType();
        categoryPlot20.setRangeCrosshairVisible(true);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot20.getDomainAxisLocation((int) '4');
        try {
            categoryPlot5.setRangeAxisLocation((-739), axisLocation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer10);
        categoryPlot5.clearRangeMarkers((int) (short) 10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        ringPlot0.setLabelFont(font5);
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Category Plot", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(1.0f);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        categoryPlot13.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot13.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = xYPlot21.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = categoryAxis3D1.draw(graphics2D4, (double) 100L, rectangle2D6, rectangle2D7, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) (-1L), (float) 1L, textBlockAnchor4, (float) '4', (float) '#', (double) '4');
        java.lang.String str9 = textBlockAnchor4.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str9.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation2 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.CENTER_LEFT", graphics2D1, (float) (byte) -1, (float) 0, textAnchor4, 51.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) '4', xYItemRenderer5);
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        int int23 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) 10, plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot5.getDomainAxisLocation((int) (short) 0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        try {
            xYPlot0.setQuadrantPaint(100, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Font font8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        java.util.List list22 = jFreeChart20.getSubtitles();
        xYPlot0.drawDomainTickBands(graphics2D5, rectangle2D6, list22);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot4.getLabelPadding();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        boolean boolean18 = rectangleInsets5.equals((java.lang.Object) true);
        double double20 = rectangleInsets5.extendWidth(0.0d);
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        boolean boolean22 = numberAxis3D0.isNegativeArrowVisible();
        numberAxis3D0.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot8.setSeparatorStroke(stroke11);
        ringPlot5.setSeparatorStroke(stroke11);
        java.awt.Paint paint14 = ringPlot5.getShadowPaint();
        java.awt.Paint paint15 = ringPlot5.getNoDataMessagePaint();
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.CENTER_LEFT", font2, paint15, (float) 10L, textMeasurer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        boolean boolean23 = categoryPlot5.isRangeGridlinesVisible();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot5.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(axisSpace25);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        xYPlot0.clearRangeMarkers((int) (byte) 10);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot0.getLabelPadding();
        boolean boolean8 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = ringPlot5.getDrawingSupplier();
        ringPlot0.setDrawingSupplier(drawingSupplier6);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        dateAxis2.setVerticalTickLabels(true);
        boolean boolean9 = dateAxis2.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        try {
            ringPlot1.setLegendLabelGenerator(pieSectionLabelGenerator2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        double double12 = categoryPlot5.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, false);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot11.getOrientation();
        boolean boolean13 = xYPlot11.isRangeZoomable();
        java.awt.Color color14 = java.awt.Color.WHITE;
        xYPlot11.setDomainZeroBaselinePaint((java.awt.Paint) color14);
        java.lang.String str16 = color14.toString();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color14);
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart13.createBufferedImage((-739), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-739) and height (32) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        boolean boolean7 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            boolean boolean9 = xYPlot0.removeRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        boolean boolean6 = dateAxis0.isHiddenValue((long) (short) 10);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.lang.String str16 = categoryPlot15.getPlotType();
        java.lang.String str17 = categoryPlot15.getPlotType();
        categoryPlot15.setRangeCrosshairVisible(true);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot15.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = xYPlot23.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation24);
        try {
            java.util.List list26 = dateAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        java.lang.String str27 = categoryPlot26.getPlotType();
        java.lang.String str28 = categoryPlot26.getPlotType();
        categoryPlot26.setRangeCrosshairVisible(true);
        categoryPlot26.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot26.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = xYPlot34.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            org.jfree.chart.axis.AxisState axisState39 = categoryAxis3D2.draw(graphics2D17, 0.0d, rectangle2D19, rectangle2D20, rectangleEdge36, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockBorder6.equals(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot10.getOrientation();
        boolean boolean12 = xYPlot10.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot10.getDomainAxisEdge((-739));
        try {
            java.util.List list15 = dateAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        java.awt.Image image19 = jFreeChart13.getBackgroundImage();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = null;
        try {
            jFreeChart13.titleChanged(titleChangeEvent20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRangeMinimumSize(2.0d);
        dateAxis0.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean14);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range3, lengthConstraintType4, (-1.0d), range8, lengthConstraintType9);
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range3, (double) 0.5f);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setHeight((double) (byte) 100);
        java.awt.Font font7 = textTitle2.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer8 = new org.jfree.chart.text.G2TextMeasurer(graphics2D7);
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.CENTER_LEFT", font2, paint5, (-1.0f), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) 1, (float) 0, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        boolean boolean8 = horizontalAlignment6.equals((java.lang.Object) "ClassContext");
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            xYPlot0.addDomainMarker((int) '4', marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot0.getLabelPadding();
        int int8 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range10 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range5, lengthConstraintType6, (-1.0d), range10, lengthConstraintType11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.data.Range range16 = dateAxis14.getRange();
        org.jfree.data.Range range17 = dateAxis14.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range1, lengthConstraintType6, (double) '#', range17, lengthConstraintType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        int int14 = jFreeChart13.getSubtitleCount();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = null;
        try {
            jFreeChart13.titleChanged(titleChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Category Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.getAntiAlias();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Paint paint5 = ringPlot0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.clearDomainAxes();
        boolean boolean8 = categoryPlot5.isDomainZoomable();
        java.awt.Paint paint9 = null;
        try {
            categoryPlot5.setDomainGridlinePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) false, font2);
        categoryAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        jFreeChart13.setBorderVisible(true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart13.getLegend();
        jFreeChart13.setTextAntiAlias(true);
        jFreeChart13.fireChartChanged();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.CENTER_LEFT", "Category Plot", "ClassContext", "hi!", "ClassContext");
        java.lang.String str6 = basicProjectInfo5.getName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str6.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(4.0d, (double) (short) -1, plotRenderingInfo9, point2D10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            boolean boolean13 = categoryPlot5.removeAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot5.getRangeAxisEdge(1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D18.configure();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date23 = dateAxis22.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat29 = null;
        dateAxis22.setDateFormatOverride(dateFormat29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer31);
        try {
            categoryPlot5.setDomainAxis((-1), (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.Range range3 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.data.Range range8 = dateAxis5.getRange();
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range8, (double) (byte) -1);
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) (byte) 0);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range10, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date17 = dateAxis16.getMaximumDate();
        org.jfree.data.Range range18 = dateAxis16.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range18, lengthConstraintType19, (-1.0d), range23, lengthConstraintType24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date28 = dateAxis27.getMaximumDate();
        org.jfree.data.Range range29 = dateAxis27.getRange();
        double double31 = range29.constrain(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType32 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range10, lengthConstraintType24, 2.0d, range29, lengthConstraintType32);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date37 = dateAxis36.getMaximumDate();
        org.jfree.data.Range range38 = dateAxis36.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range43 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range38, lengthConstraintType39, (-1.0d), range43, lengthConstraintType44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date48 = dateAxis47.getMaximumDate();
        org.jfree.data.Range range49 = dateAxis47.getRange();
        org.jfree.data.Range range50 = dateAxis47.getRange();
        org.jfree.data.Range range52 = org.jfree.data.Range.shift(range50, (double) (byte) -1);
        org.jfree.data.Range range54 = org.jfree.data.Range.expandToInclude(range52, (double) (byte) 0);
        org.jfree.data.Range range56 = org.jfree.data.Range.shift(range52, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date59 = dateAxis58.getMaximumDate();
        org.jfree.data.Range range60 = dateAxis58.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType61 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range65 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType66 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range60, lengthConstraintType61, (-1.0d), range65, lengthConstraintType66);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date70 = dateAxis69.getMaximumDate();
        org.jfree.data.Range range71 = dateAxis69.getRange();
        double double73 = range71.constrain(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType74 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint75 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range52, lengthConstraintType66, 2.0d, range71, lengthConstraintType74);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint76 = new org.jfree.chart.block.RectangleConstraint((double) 10L, range3, lengthConstraintType32, (double) (byte) -1, range43, lengthConstraintType74);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType32);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(lengthConstraintType61);
        org.junit.Assert.assertNotNull(lengthConstraintType66);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType74);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            categoryPlot5.setInsets(rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRange(true);
        java.awt.Shape shape5 = dateAxis1.getDownArrow();
        dateAxis1.setInverted(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean13 = textAnchor11.equals((java.lang.Object) dateTickUnit12);
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] { (-1L), date9, "TextBlockAnchor.CENTER_LEFT", boolean13 };
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        double[] doubleArray20 = new double[] { 10L, '4', (-1.0d), 0.0d };
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray14, comparableArray15, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        java.lang.String str4 = rotation3.toString();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Rotation.CLOCKWISE" + "'", str4.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        boolean boolean6 = dateAxis0.isHiddenValue((long) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date10 = dateAxis9.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.lang.String str13 = categoryPlot12.getPlotType();
        java.lang.String str14 = categoryPlot12.getPlotType();
        categoryPlot12.setRangeCrosshairVisible(true);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        java.lang.Object obj13 = legendItemCollection12.clone();
        java.util.Iterator iterator14 = legendItemCollection12.iterator();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(iterator14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, false);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot11.getOrientation();
        boolean boolean13 = xYPlot11.isRangeZoomable();
        java.awt.Color color14 = java.awt.Color.WHITE;
        xYPlot11.setDomainZeroBaselinePaint((java.awt.Paint) color14);
        java.lang.String str16 = color14.toString();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        double double24 = dateAxis20.getUpperMargin();
        int int25 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            xYPlot0.addRangeMarker(marker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=255]"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (byte) 1);
        try {
            dateAxis1.zoomRange(51.0d, (double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (51.0) <= upper (15.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        ringPlot2.setURLGenerator(pieURLGenerator5);
        boolean boolean7 = textFragment1.equals((java.lang.Object) ringPlot2);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            textFragment1.draw(graphics2D8, (float) (byte) 10, (float) '#', textAnchor11, (float) (byte) -1, (float) 10, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        boolean boolean11 = categoryPlot5.isRangeCrosshairLockedOnData();
        java.awt.Paint paint12 = categoryPlot5.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.removeLegend();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.mapDatasetToDomainAxis((-739), (int) '#');
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot14.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot22.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation23);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Paint paint7 = textTitle2.getBackgroundPaint();
        textTitle2.setHeight((double) (short) 1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        categoryPlot5.clearDomainMarkers();
        int int14 = categoryPlot5.getRangeAxisCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        java.lang.Object obj13 = legendItemCollection12.clone();
        java.lang.Object obj14 = legendItemCollection12.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        dateAxis0.setFixedAutoRange(0.2d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot0.setBackgroundAlpha((float) '4');
        java.awt.Stroke stroke10 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis((int) (short) 10);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        ringPlot0.setMaximumLabelWidth((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot0.getSimpleLabelOffset();
        java.lang.Object obj13 = ringPlot0.clone();
        double double14 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = null;
        ringPlot0.setLabelShadowPaint(paint5);
        ringPlot0.setSeparatorsVisible(false);
        java.awt.Color color9 = java.awt.Color.magenta;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = ringPlot1.getDrawingSupplier();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setShadowPaint(paint3);
        java.awt.Image image5 = ringPlot1.getBackgroundImage();
        java.awt.Paint paint6 = ringPlot1.getShadowPaint();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        ringPlot7.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot10.setSeparatorStroke(stroke13);
        ringPlot7.setSeparatorStroke(stroke13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot16.getOrientation();
        xYPlot16.configureRangeAxes();
        java.awt.Color color19 = java.awt.Color.GRAY;
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean24 = dateAxis22.isHiddenValue((long) (byte) 1);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = ringPlot25.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = ringPlot25.getLegendLabelToolTipGenerator();
        java.awt.Image image28 = null;
        ringPlot25.setBackgroundImage(image28);
        java.awt.Paint paint30 = null;
        ringPlot25.setLabelShadowPaint(paint30);
        ringPlot25.setSeparatorsVisible(false);
        java.awt.Color color34 = java.awt.Color.magenta;
        ringPlot25.setBaseSectionPaint((java.awt.Paint) color34);
        java.awt.Stroke stroke36 = ringPlot25.getSeparatorStroke();
        dateAxis22.setTickMarkStroke(stroke36);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint6, stroke13, (java.awt.Paint) color19, stroke36, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNull(pieSectionLabelGenerator27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleAnchor.LEFT", 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) "hi!", "");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        double double12 = dateAxis8.getFixedDimension();
        dateAxis8.setVerticalTickLabels(true);
        java.awt.Shape shape15 = dateAxis8.getLeftArrow();
        java.awt.Paint paint16 = dateAxis8.getLabelPaint();
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 90.0d, paint16);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date26 = dateAxis25.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        java.lang.String str29 = categoryPlot28.getPlotType();
        java.lang.String str30 = categoryPlot28.getPlotType();
        categoryPlot28.setRangeCrosshairVisible(true);
        categoryPlot28.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot28.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = xYPlot36.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation35, plotOrientation37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge38);
        try {
            double double41 = categoryAxis3D1.getCategorySeriesMiddle((java.lang.Comparable) 1.0d, (java.lang.Comparable) dateTickUnit19, categoryDataset20, 0.0d, rectangle2D22, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot4.getLabelPadding();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        boolean boolean18 = rectangleInsets5.equals((java.lang.Object) true);
        double double20 = rectangleInsets5.extendWidth(0.0d);
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        numberAxis3D0.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            xYPlot0.addDomainMarker(marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot4.getLabelPadding();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        boolean boolean18 = rectangleInsets5.equals((java.lang.Object) true);
        double double20 = rectangleInsets5.extendWidth(0.0d);
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        boolean boolean22 = numberAxis3D0.isNegativeArrowVisible();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.axis.AxisState axisState29 = numberAxis3D0.draw(graphics2D23, 4.0d, rectangle2D25, rectangle2D26, rectangleEdge27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        ringPlot1.setSectionDepth(100.0d);
        boolean boolean7 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint9 = ringPlot1.getSectionPaint((java.lang.Comparable) 1.0E-5d);
        ringPlot1.setShadowYOffset(0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = color0.equals((java.lang.Object) jFreeChartResources1);
        try {
            java.lang.Object obj4 = jFreeChartResources1.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        java.awt.Image image19 = jFreeChart13.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart13.createBufferedImage(0, (int) (short) -1, (-1.0d), 0.0d, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot0.setBackgroundAlpha((float) '4');
        java.awt.Stroke stroke10 = xYPlot0.getDomainGridlineStroke();
        int int11 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedDimension();
        numberAxis3D3.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = ringPlot7.getLabelPadding();
        double double10 = rectangleInsets8.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date14 = dateAxis13.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.lang.String str17 = categoryPlot16.getPlotType();
        java.lang.String str18 = categoryPlot16.getPlotType();
        categoryPlot16.setRangeCrosshairVisible(true);
        boolean boolean21 = rectangleInsets8.equals((java.lang.Object) true);
        double double23 = rectangleInsets8.extendWidth(0.0d);
        numberAxis3D3.setLabelInsets(rectangleInsets8);
        boolean boolean25 = numberAxis3D3.isNegativeArrowVisible();
        java.text.NumberFormat numberFormat26 = null;
        numberAxis3D3.setNumberFormatOverride(numberFormat26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color29 = color28.brighter();
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color28);
        ringPlot0.setBackgroundPaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) (byte) 10, 0.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        int int23 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) 10, plotRenderingInfo26, point2D27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date34 = dateAxis33.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        categoryPlot36.setRangeCrosshairVisible(false);
        categoryPlot36.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot36.getRangeMarkers(layer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot36.getDomainAxisEdge();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = ringPlot44.getLabelPadding();
        double double47 = rectangleInsets45.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date51 = dateAxis50.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer52);
        java.lang.String str54 = categoryPlot53.getPlotType();
        java.lang.String str55 = categoryPlot53.getPlotType();
        categoryPlot53.setRangeCrosshairVisible(true);
        boolean boolean58 = rectangleInsets45.equals((java.lang.Object) true);
        double double60 = rectangleInsets45.extendWidth(0.0d);
        categoryPlot36.setAxisOffset(rectangleInsets45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation66 = xYPlot65.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent67 = null;
        xYPlot65.datasetChanged(datasetChangeEvent67);
        java.awt.geom.Point2D point2D69 = xYPlot65.getQuadrantOrigin();
        categoryPlot36.zoomRangeAxes(0.05d, 0.0d, plotRenderingInfo64, point2D69);
        org.jfree.chart.plot.PlotState plotState71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        try {
            categoryPlot5.draw(graphics2D29, rectangle2D30, point2D69, plotState71, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Category Plot" + "'", str54.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Category Plot" + "'", str55.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 4.0d + "'", double60 == 4.0d);
        org.junit.Assert.assertNotNull(plotOrientation66);
        org.junit.Assert.assertNotNull(point2D69);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) "hi!", "");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        double double12 = dateAxis8.getFixedDimension();
        dateAxis8.setVerticalTickLabels(true);
        java.awt.Shape shape15 = dateAxis8.getLeftArrow();
        java.awt.Paint paint16 = dateAxis8.getLabelPaint();
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 90.0d, paint16);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = ringPlot19.getDrawingSupplier();
        float float21 = ringPlot19.getBackgroundImageAlpha();
        double double22 = ringPlot19.getInnerSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        ringPlot19.setDataset(pieDataset23);
        java.awt.Font font25 = ringPlot19.getLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint26);
        categoryAxis3D1.setTickLabelPaint(paint26);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        java.lang.String str13 = categoryPlot11.getPlotType();
        categoryPlot11.setRangeCrosshairVisible(true);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot11.getDomainAxisLocation((int) '4');
        xYPlot0.setRangeAxisLocation(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        boolean boolean4 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRenderer();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomInset((double) 1L);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        int int23 = categoryPlot5.getDomainAxisCount();
        java.awt.Font font25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date29 = dateAxis28.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        java.lang.String str32 = categoryPlot31.getPlotType();
        java.lang.String str33 = categoryPlot31.getPlotType();
        categoryPlot31.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("", font25, (org.jfree.chart.plot.Plot) categoryPlot31, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot31.getDatasetRenderingOrder();
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder38);
        boolean boolean40 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot5.getDomainMarkers(layer41);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Category Plot" + "'", str32.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "Rotation.CLOCKWISE", "ClassContext");
        java.lang.String str8 = chartEntity7.getShapeType();
        java.lang.String str9 = chartEntity7.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "poly" + "'", str8.equals("poly"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartEntity: tooltip = Rotation.CLOCKWISE" + "'", str9.equals("ChartEntity: tooltip = Rotation.CLOCKWISE"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        boolean boolean7 = dateAxis0.isAutoTickUnitSelection();
        dateAxis0.setLabel("Category Plot");
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis0.setAxisLinePaint(paint10);
        java.util.TimeZone timeZone12 = null;
        try {
            dateAxis0.setTimeZone(timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) (byte) 10, 0.0d, (double) (byte) -1);
        double double6 = rectangleInsets4.calculateBottomOutset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) "hi!", "");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        double double12 = dateAxis8.getFixedDimension();
        dateAxis8.setVerticalTickLabels(true);
        java.awt.Shape shape15 = dateAxis8.getLeftArrow();
        java.awt.Paint paint16 = dateAxis8.getLabelPaint();
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 90.0d, paint16);
        categoryAxis3D1.setMaximumCategoryLabelLines((int) '4');
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        java.util.List list15 = jFreeChart13.getSubtitles();
        jFreeChart13.setTitle("");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart13.handleClick(0, 0, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getDomainAxisLocation((int) (short) 0);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getRangeAxis();
        java.awt.Font font10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date14 = dateAxis13.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.lang.String str17 = categoryPlot16.getPlotType();
        java.lang.String str18 = categoryPlot16.getPlotType();
        categoryPlot16.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) categoryPlot16, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot16.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder23);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot0.getRangeAxisForDataset((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot5.setRenderer(categoryItemRenderer13, true);
        java.lang.String str16 = categoryPlot5.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot5.setDomainAxis(categoryAxis17);
        float float19 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot5.zoomRangeAxes((double) 100, (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = ringPlot17.getDrawingSupplier();
        categoryPlot5.setDrawingSupplier(drawingSupplier18);
        categoryPlot5.setRangeCrosshairValue((double) '4', false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = rotation3.getFactor();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean6 = rotation3.equals((java.lang.Object) dateTickUnit5);
        double double7 = rotation3.getFactor();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Category Plot" + "'", str0.equals("Category Plot"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot5.setRenderer(categoryItemRenderer13, true);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot5.addRangeMarker(marker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        java.awt.Paint paint10 = ringPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = ringPlot11.getDrawingSupplier();
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot11.setShadowPaint(paint13);
        ringPlot0.setLabelOutlinePaint(paint13);
        ringPlot0.setOuterSeparatorExtension(90.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge((-739));
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color6 = color5.brighter();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        categoryPlot13.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot13.getDomainAxisLocation((int) '4');
        xYPlot0.setRangeAxisLocation(axisLocation20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        ringPlot2.setURLGenerator(pieURLGenerator5);
        boolean boolean7 = textFragment1.equals((java.lang.Object) ringPlot2);
        java.awt.Font font8 = textFragment1.getFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            textFragment1.draw(graphics2D9, 0.0f, (float) (short) 0, textAnchor12, (float) (-1L), (float) 10L, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot4.getLabelPadding();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        boolean boolean18 = rectangleInsets5.equals((java.lang.Object) true);
        double double20 = rectangleInsets5.extendWidth(0.0d);
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        org.jfree.data.RangeType rangeType22 = null;
        try {
            numberAxis3D0.setRangeType(rangeType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        ringPlot3.setURLGenerator(pieURLGenerator6);
        boolean boolean8 = ringPlot0.equals((java.lang.Object) ringPlot3);
        java.awt.Paint paint9 = ringPlot0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        dateAxis0.setInverted(true);
        double double7 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis0.java2DToValue((double) 0.5f, rectangle2D9, rectangleEdge10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-9.223372036854776E18d) + "'", double11 == (-9.223372036854776E18d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.awt.Color color18 = java.awt.Color.white;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray24 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray25 = color19.getComponents(floatArray24);
        float[] floatArray26 = color18.getRGBComponents(floatArray25);
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) (-1.0d), (java.awt.Paint) color18);
        categoryAxis3D2.setCategoryMargin((double) (short) -1);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date34 = dateAxis33.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        java.lang.String str37 = categoryPlot36.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = null;
        categoryPlot36.datasetChanged(datasetChangeEvent38);
        java.awt.Stroke stroke40 = categoryPlot36.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date42 = dateAxis41.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = ringPlot47.getDrawingSupplier();
        java.awt.Paint paint49 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot47.setShadowPaint(paint49);
        org.jfree.chart.block.BlockBorder blockBorder51 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint49);
        dateAxis41.setTickLabelPaint(paint49);
        categoryPlot36.setBackgroundPaint(paint49);
        boolean boolean54 = categoryPlot36.isRangeGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date59 = dateAxis58.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, categoryItemRenderer60);
        java.lang.String str62 = categoryPlot61.getPlotType();
        java.lang.String str63 = categoryPlot61.getPlotType();
        categoryPlot61.setRangeCrosshairVisible(true);
        categoryPlot61.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot61.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation70 = xYPlot69.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation68, plotOrientation70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge71);
        org.jfree.chart.axis.AxisSpace axisSpace73 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace74 = categoryAxis3D2.reserveSpace(graphics2D30, (org.jfree.chart.plot.Plot) categoryPlot36, rectangle2D55, rectangleEdge72, axisSpace73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Category Plot" + "'", str37.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(drawingSupplier48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Category Plot" + "'", str62.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Category Plot" + "'", str63.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertNotNull(plotOrientation70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setHeight((double) (byte) 100);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle2.draw(graphics2D9, rectangle2D10);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeIncludesZero();
        numberAxis3D0.setLowerMargin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        ringPlot0.setMaximumLabelWidth((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot0.getSimpleLabelOffset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        ringPlot0.datasetChanged(datasetChangeEvent13);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        try {
            numberAxis0.zoomRange((double) 0.5f, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.5) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray6 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray7 = color1.getComponents(floatArray6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot8.getOrientation();
        boolean boolean10 = xYPlot8.isRangeZoomable();
        java.awt.Color color11 = java.awt.Color.WHITE;
        xYPlot8.setDomainZeroBaselinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = ringPlot13.getDrawingSupplier();
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setShadowPaint(paint15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        dateAxis17.setAutoRange(true);
        java.awt.Shape shape21 = dateAxis17.getDownArrow();
        dateAxis17.setInverted(true);
        boolean boolean24 = dateAxis17.isAutoTickUnitSelection();
        dateAxis17.setLabel("Category Plot");
        java.awt.Color color27 = java.awt.Color.CYAN;
        dateAxis17.setLabelPaint((java.awt.Paint) color27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color31 = color30.brighter();
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color1, color11, paint15, color27, color29, color31 };
        java.awt.Paint[] paintArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray36 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray36);
        try {
            java.awt.Shape shape38 = defaultDrawingSupplier37.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.data.Range range4 = dateAxis2.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle0.arrange(graphics2D1, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        float float1 = dateAxis0.getTickMarkInsideLength();
        java.lang.Object obj2 = dateAxis0.clone();
        org.jfree.data.Range range3 = dateAxis0.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        xYPlot0.datasetChanged(datasetChangeEvent2);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            boolean boolean8 = xYPlot0.removeRangeMarker((int) (short) 0, marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(point2D4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        boolean boolean9 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) (byte) 10, 0.0d, (double) (byte) -1);
        double double15 = rectangleInsets14.getTop();
        categoryPlot5.setInsets(rectangleInsets14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomOutset(0.0d);
        java.awt.Font font5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        java.lang.String str13 = categoryPlot11.getPlotType();
        categoryPlot11.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        boolean boolean18 = jFreeChart17.isNotify();
        java.awt.Image image19 = jFreeChart17.getBackgroundImage();
        boolean boolean20 = rectangleInsets1.equals((java.lang.Object) jFreeChart17);
        java.lang.String str21 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str21.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot1);
        jFreeChart6.setAntiAlias(true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.getAutoRangeIncludesZero();
        numberAxis3D0.setUpperBound((double) 10L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        ringPlot1.setSectionDepth(100.0d);
        boolean boolean7 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint9 = ringPlot1.getSectionPaint((java.lang.Comparable) 1.0E-5d);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = ringPlot10.getDrawingSupplier();
        float float12 = ringPlot10.getBackgroundImageAlpha();
        ringPlot10.setIgnoreNullValues(true);
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot10.setSectionOutlinePaint((java.lang.Comparable) 100, paint16);
        ringPlot1.setShadowPaint(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        int int23 = categoryPlot5.getDomainAxisCount();
        java.awt.Font font25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date29 = dateAxis28.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        java.lang.String str32 = categoryPlot31.getPlotType();
        java.lang.String str33 = categoryPlot31.getPlotType();
        categoryPlot31.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("", font25, (org.jfree.chart.plot.Plot) categoryPlot31, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot31.getDatasetRenderingOrder();
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot5.getDomainAxisForDataset((int) (short) 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Category Plot" + "'", str32.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNull(categoryAxis41);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range4, (double) (byte) -1);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (byte) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range6, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.data.Range range14 = dateAxis12.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range14, lengthConstraintType15, (-1.0d), range19, lengthConstraintType20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.data.Range range25 = dateAxis23.getRange();
        double double27 = range25.constrain(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range6, lengthConstraintType20, 2.0d, range25, lengthConstraintType28);
        org.jfree.data.Range range32 = org.jfree.data.Range.expand(range6, (double) (byte) 0, (double) 10.0f);
        boolean boolean35 = range6.intersects((double) (short) 1, 51.0d);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("poly", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str1.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        try {
            xYPlot0.handleClick((int) ' ', 0, plotRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle2.getFrame();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleAnchor.LEFT", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Paint paint7 = textTitle2.getBackgroundPaint();
        java.awt.Font font8 = textTitle2.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle19.setWidth((double) (byte) 10);
        textTitle19.setURLText("");
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        double double25 = textTitle19.getHeight();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 100.0f, 0.0f, textAnchor4, 51.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        categoryPlot5.clearDomainMarkers();
        org.jfree.chart.plot.Marker marker14 = null;
        try {
            categoryPlot5.addRangeMarker(marker14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) 1, (float) 0, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str11 = textBlockAnchor10.toString();
        java.awt.Shape shape15 = textBlock0.calculateBounds(graphics2D7, (float) 0, 1.0f, textBlockAnchor10, 0.0f, (float) (byte) 1, (double) (-1.0f));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str21 = textBlockAnchor20.toString();
        java.lang.String str22 = textBlockAnchor20.toString();
        textBlock0.draw(graphics2D17, (float) (byte) 10, (float) 1, textBlockAnchor20);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str11.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str21.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str22.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = null;
        ringPlot0.setLabelShadowPaint(paint5);
        ringPlot0.setSeparatorsVisible(false);
        java.awt.Color color9 = java.awt.Color.magenta;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color9);
        ringPlot0.setCircular(false, true);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent9);
        boolean boolean11 = lineBorder0.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            boolean boolean13 = categoryPlot6.removeDomainMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.mapDatasetToRangeAxis(1, 10);
        java.awt.Paint paint6 = xYPlot0.getBackgroundPaint();
        java.awt.Paint paint7 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "Category Plot", "TextBlockAnchor.CENTER_LEFT", "ClassContext");
        basicProjectInfo5.setVersion("java.awt.Color[r=255,g=255,b=255]");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font5, (java.awt.Paint) color6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 0, 0.0d, (double) (short) 100, (java.awt.Paint) color6);
        java.awt.Paint paint9 = blockBorder8.getPaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = jFreeChart13.getCategoryPlot();
        jFreeChart13.fireChartChanged();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(categoryPlot15);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("");
        textLine3.addFragment(textFragment5);
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textFragment5.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            boolean boolean6 = xYPlot0.removeRangeMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot5.getDomainAxisLocation((int) '4');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        java.util.List list15 = jFreeChart13.getSubtitles();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        categoryPlot23.setRangeCrosshairVisible(false);
        categoryPlot23.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot23.getRangeMarkers(layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot23.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = xYPlot34.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        xYPlot34.datasetChanged(datasetChangeEvent36);
        java.awt.geom.Point2D point2D38 = xYPlot34.getQuadrantOrigin();
        categoryPlot23.zoomRangeAxes((double) 10L, (double) 10.0f, plotRenderingInfo33, point2D38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        try {
            jFreeChart13.draw(graphics2D16, rectangle2D17, point2D38, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(point2D38);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.Plot plot6 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        categoryAxis3D2.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = null;
        try {
            categoryAxis3D2.setCategoryLabelPositions(categoryLabelPositions19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D3.configure();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        dateAxis7.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat14 = null;
        dateAxis7.setDateFormatOverride(dateFormat14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        categoryAxis3D3.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        dateAxis20.setAutoRange(true);
        java.awt.Shape shape24 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer25);
        float float27 = categoryAxis3D3.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot7.getOrientation();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        java.awt.Color color10 = java.awt.Color.WHITE;
        xYPlot7.setDomainZeroBaselinePaint((java.awt.Paint) color10);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot0.getRangeAxisLocation((int) (byte) 1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        ringPlot0.setIgnoreNullValues(false);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        ringPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.lang.Comparable comparable8 = null;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            ringPlot0.setSectionOutlineStroke(comparable8, stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes(4.0d, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot5.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        jFreeChart13.setTextAntiAlias(true);
        jFreeChart13.setNotify(false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "", "java.awt.Color[r=255,g=255,b=255]", image3, "ClassContext", "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=255,b=255]");
        projectInfo7.setLicenceText("RectangleAnchor.LEFT");
        projectInfo7.setLicenceText("");
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.setTickMarksVisible(true);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        java.lang.String str15 = categoryPlot13.getPlotType();
        categoryPlot13.setRangeCrosshairVisible(true);
        categoryPlot13.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot13.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = xYPlot21.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation22);
        boolean boolean25 = rectangleEdge23.equals((java.lang.Object) 10.0f);
        try {
            double double26 = dateAxis0.valueToJava2D((double) (short) 100, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.mapDatasetToRangeAxis(1, 10);
        java.awt.Paint paint6 = xYPlot0.getBackgroundPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(10, xYItemRenderer8);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot5.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot5.getDomainAxisForDataset(8);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(1.0f);
        java.lang.String str5 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomOutset(0.0d);
        java.awt.Font font5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        java.lang.String str13 = categoryPlot11.getPlotType();
        categoryPlot11.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        boolean boolean18 = jFreeChart17.isNotify();
        java.awt.Image image19 = jFreeChart17.getBackgroundImage();
        boolean boolean20 = rectangleInsets1.equals((java.lang.Object) jFreeChart17);
        jFreeChart17.removeLegend();
        jFreeChart17.setBackgroundImageAlignment(15);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.data.Range range10 = dateAxis8.getRange();
        org.jfree.data.Range range11 = dateAxis8.getRange();
        dateAxis8.setAutoRangeMinimumSize((double) 10.0f, true);
        try {
            xYPlot0.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "", "java.awt.Color[r=255,g=255,b=255]", image3, "ClassContext", "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=255,b=255]");
        projectInfo7.setVersion("java.awt.Color[r=255,g=255,b=255]");
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.setBackgroundAlpha((float) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge();
        try {
            double double12 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = ringPlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot1.getLegendLabelToolTipGenerator();
        java.awt.Image image4 = null;
        ringPlot1.setBackgroundImage(image4);
        double double6 = ringPlot1.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date10 = dateAxis9.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        dateAxis9.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.lang.String str24 = categoryPlot23.getPlotType();
        java.lang.String str25 = categoryPlot23.getPlotType();
        categoryPlot23.setRangeCrosshairVisible(true);
        categoryPlot23.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot23.getRenderer();
        boolean boolean30 = color16.equals((java.lang.Object) categoryPlot23);
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color16);
        java.awt.Color color32 = java.awt.Color.getColor("", color16);
        java.awt.Color color33 = color32.darker();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range3, (double) (byte) -1);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) (byte) 0);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range7, (double) 15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-12517568) + "'", int2 == (-12517568));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot5.setRenderer(categoryItemRenderer13, true);
        java.lang.String str16 = categoryPlot5.getPlotType();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot5.setRenderer(categoryItemRenderer17, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setURLText("");
        java.awt.Font font8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.lang.String str16 = categoryPlot14.getPlotType();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        java.util.List list22 = jFreeChart20.getSubtitles();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        textTitle2.setHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot2.getLabelPadding();
        ringPlot1.setInsets(rectangleInsets3);
        ringPlot1.setSectionDepth(100.0d);
        boolean boolean7 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint9 = ringPlot1.getSectionPaint((java.lang.Comparable) 1.0E-5d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = ringPlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord12 = abstractPieLabelDistributor10.getPieLabelRecord(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getDomainAxisLocation((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getRangeAxisLocation(0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        ringPlot0.setCircular(true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        jFreeChart13.removeLegend();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart13.addProgressListener(chartProgressListener15);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        java.awt.Image image4 = ringPlot0.getBackgroundImage();
        java.awt.Paint paint5 = ringPlot0.getShadowPaint();
        java.lang.String str6 = ringPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockFrame blockFrame7 = textTitle2.getFrame();
        java.lang.String str8 = textTitle2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        java.lang.Object obj13 = null;
        boolean boolean14 = legendItemCollection12.equals(obj13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.mapDatasetToDomainAxis((-739), (int) '#');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        try {
            xYPlot0.setRenderer((int) (byte) -1, xYItemRenderer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.data.Range range9 = dateAxis6.getRange();
        dateAxis6.setTickMarksVisible(true);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis6.setTickMarkPaint(paint12);
        org.jfree.chart.axis.Timeline timeline14 = dateAxis6.getTimeline();
        dateAxis0.setTimeline(timeline14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(timeline14);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot3.setSeparatorStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        java.awt.Stroke stroke9 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint10 = ringPlot0.getLabelLinkPaint();
        double double11 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-5d + "'", double11 == 1.0E-5d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range4, (double) (byte) -1);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (byte) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range6, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.data.Range range14 = dateAxis12.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range19 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range14, lengthConstraintType15, (-1.0d), range19, lengthConstraintType20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.data.Range range25 = dateAxis23.getRange();
        double double27 = range25.constrain(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range6, lengthConstraintType20, 2.0d, range25, lengthConstraintType28);
        org.jfree.data.Range range32 = org.jfree.data.Range.expand(range6, (double) (byte) 0, (double) 10.0f);
        java.lang.Class<?> wildcardClass33 = range6.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) "hi!", "");
        double double5 = categoryAxis3D1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.2d, 51.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date17 = dateAxis16.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        categoryPlot19.setRangeCrosshairVisible(false);
        categoryPlot19.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot19.getRangeMarkers(layer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = ringPlot27.getLabelPadding();
        double double30 = rectangleInsets28.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date34 = dateAxis33.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        java.lang.String str37 = categoryPlot36.getPlotType();
        java.lang.String str38 = categoryPlot36.getPlotType();
        categoryPlot36.setRangeCrosshairVisible(true);
        boolean boolean41 = rectangleInsets28.equals((java.lang.Object) true);
        double double43 = rectangleInsets28.extendWidth(0.0d);
        categoryPlot19.setAxisOffset(rectangleInsets28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = xYPlot48.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        xYPlot48.datasetChanged(datasetChangeEvent50);
        java.awt.geom.Point2D point2D52 = xYPlot48.getQuadrantOrigin();
        categoryPlot19.zoomRangeAxes(0.05d, 0.0d, plotRenderingInfo47, point2D52);
        categoryPlot5.zoomDomainAxes((double) 15, plotRenderingInfo13, point2D52, false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Category Plot" + "'", str37.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Category Plot" + "'", str38.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(point2D52);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Rotation.CLOCKWISE", graphics2D1, (float) '4', (float) 100, (double) (byte) 100, (float) (-739), 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        java.lang.String str13 = categoryPlot11.getPlotType();
        categoryPlot11.setRangeCrosshairVisible(true);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot11.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = xYPlot19.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation20);
        xYPlot0.setRangeAxisLocation(axisLocation18, false);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray6 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray7 = color1.getComponents(floatArray6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot8.getOrientation();
        boolean boolean10 = xYPlot8.isRangeZoomable();
        java.awt.Color color11 = java.awt.Color.WHITE;
        xYPlot8.setDomainZeroBaselinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = ringPlot13.getDrawingSupplier();
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setShadowPaint(paint15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        dateAxis17.setAutoRange(true);
        java.awt.Shape shape21 = dateAxis17.getDownArrow();
        dateAxis17.setInverted(true);
        boolean boolean24 = dateAxis17.isAutoTickUnitSelection();
        dateAxis17.setLabel("Category Plot");
        java.awt.Color color27 = java.awt.Color.CYAN;
        dateAxis17.setLabelPaint((java.awt.Paint) color27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color31 = color30.brighter();
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color1, color11, paint15, color27, color29, color31 };
        java.awt.Paint[] paintArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray36 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray36);
        java.awt.Paint paint38 = defaultDrawingSupplier37.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        waferMapPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot5.setDomainAxisLocation(100, axisLocation9);
        java.lang.String str11 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        try {
            categoryPlot5.addDomainMarker(categoryMarker12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Category Plot");
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        boolean boolean3 = ringPlot0.isCircular();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        categoryPlot17.setRangeCrosshairVisible(false);
        categoryPlot17.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot17.getRangeMarkers(layer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot17.getDomainAxisEdge();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = ringPlot25.getLabelPadding();
        double double28 = rectangleInsets26.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date32 = dateAxis31.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.lang.String str35 = categoryPlot34.getPlotType();
        java.lang.String str36 = categoryPlot34.getPlotType();
        categoryPlot34.setRangeCrosshairVisible(true);
        boolean boolean39 = rectangleInsets26.equals((java.lang.Object) true);
        double double41 = rectangleInsets26.extendWidth(0.0d);
        categoryPlot17.setAxisOffset(rectangleInsets26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = xYPlot46.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = null;
        xYPlot46.datasetChanged(datasetChangeEvent48);
        java.awt.geom.Point2D point2D50 = xYPlot46.getQuadrantOrigin();
        categoryPlot17.zoomRangeAxes(0.05d, 0.0d, plotRenderingInfo45, point2D50);
        try {
            categoryPlot5.zoomRangeAxes((double) (-1L), plotRenderingInfo11, point2D50, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        org.jfree.chart.util.Rotation rotation4 = ringPlot0.getDirection();
        double double5 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D2.configure();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        dateAxis6.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat13 = null;
        dateAxis6.setDateFormatOverride(dateFormat13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        categoryAxis3D2.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        categoryAxis3D2.setCategoryLabelPositionOffset((int) (byte) -1);
        java.lang.Comparable comparable21 = null;
        try {
            java.lang.String str22 = categoryAxis3D2.getCategoryLabelToolTip(comparable21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot5.getRangeMarkers(100, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot5.getDomainMarkers(layer14);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            boolean boolean17 = categoryPlot5.removeAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        org.jfree.chart.LegendItem legendItem13 = null;
        legendItemCollection12.add(legendItem13);
        org.jfree.chart.LegendItem legendItem15 = null;
        legendItemCollection12.add(legendItem15);
        org.jfree.chart.LegendItem legendItem18 = legendItemCollection12.get((int) (short) 0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNull(legendItem18);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleLabelsVisible();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color6);
        int int8 = polarPlot4.getSeriesCount();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.Point point9 = polarPlot4.translateValueThetaRadiusToJava2D((double) 10, 1.0E-5d, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = color0.equals((java.lang.Object) jFreeChartResources1);
        java.util.Locale locale3 = jFreeChartResources1.getLocale();
        boolean boolean5 = jFreeChartResources1.containsKey("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", graphics2D1, (double) 0L, (float) 8, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setURLGenerator(pieURLGenerator3);
        java.awt.Color color5 = java.awt.Color.green;
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot0.getLabelPadding();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot8.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        xYPlot8.datasetChanged(datasetChangeEvent10);
        java.awt.geom.Point2D point2D12 = xYPlot8.getQuadrantOrigin();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot8);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "Category Plot", "TextBlockAnchor.CENTER_LEFT", "ClassContext");
        java.lang.String str6 = basicProjectInfo5.getInfo();
        basicProjectInfo5.setName("Rotation.CLOCKWISE");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        java.awt.Paint paint3 = null;
        ringPlot0.setLabelOutlinePaint(paint3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis2.setTickUnit(dateTickUnit11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Class<?> wildcardClass3 = unitType2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResource("ChartEntity: tooltip = Rotation.CLOCKWISE", (java.lang.Class) wildcardClass3);
        java.lang.Class class5 = null;
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("poly", (java.lang.Class) wildcardClass3, class5);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        categoryPlot5.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder16 = null;
        try {
            categoryPlot5.setColumnRenderingOrder(sortOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        boolean boolean7 = dateAxis2.isPositiveArrowVisible();
        dateAxis2.setRange(0.0d, (double) 8);
        dateAxis2.resizeRange(0.0d, 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        jFreeChart13.setTextAntiAlias(true);
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        textTitle18.setWidth((double) (byte) 10);
        textTitle18.setURLText("");
        textTitle18.setID("RectangleAnchor.LEFT");
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date29 = dateAxis28.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        categoryPlot31.setRangeCrosshairVisible(false);
        categoryPlot31.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot31.setAnchorValue((double) (short) 0, false);
        categoryPlot31.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot31.getRangeAxisEdge((int) (byte) 1);
        textTitle18.setPosition(rectangleEdge41);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("");
        textLine3.addFragment(textFragment5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            float float9 = textFragment5.calculateBaselineOffset(graphics2D7, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot5.isOutlineVisible();
        boolean boolean13 = categoryPlot5.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Font font4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.lang.String str11 = categoryPlot10.getPlotType();
        java.lang.String str12 = categoryPlot10.getPlotType();
        categoryPlot10.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) categoryPlot10, false);
        boolean boolean17 = jFreeChart16.isNotify();
        java.awt.Image image18 = jFreeChart16.getBackgroundImage();
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart16.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        java.awt.image.BufferedImage bufferedImage23 = jFreeChart16.createBufferedImage((int) ' ', 100, chartRenderingInfo22);
        org.jfree.chart.ui.ProjectInfo projectInfo27 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "TextAnchor.HALF_ASCENT_RIGHT", (java.awt.Image) bufferedImage23, "TextBlockAnchor.CENTER_LEFT", "poly", "poly");
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(bufferedImage23);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = ringPlot9.getDrawingSupplier();
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot9.setShadowPaint(paint11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint11);
        dateAxis3.setTickLabelPaint(paint11);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) paint11);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date17 = dateAxis16.getMaximumDate();
        dateAxis16.setAutoRange(true);
        java.awt.Shape shape20 = dateAxis16.getDownArrow();
        boolean boolean21 = ringPlot0.equals((java.lang.Object) dateAxis16);
        org.jfree.data.general.DatasetGroup datasetGroup22 = ringPlot0.getDatasetGroup();
        java.awt.Image image23 = ringPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNull(image23);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot1.getOrientation();
        boolean boolean3 = xYPlot1.isRangeZoomable();
        java.awt.Color color4 = java.awt.Color.WHITE;
        xYPlot1.setDomainZeroBaselinePaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = xYPlot1.getDomainTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        xYPlot1.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer14);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        jFreeChart13.setTextAntiAlias(true);
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        textTitle18.setWidth((double) (byte) 10);
        textTitle18.setURLText("");
        textTitle18.setID("RectangleAnchor.LEFT");
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj29 = textTitle18.draw(graphics2D26, rectangle2D27, (java.lang.Object) categoryPlot28);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(obj29);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10);
        double double5 = rectangleConstraint4.getWidth();
        java.lang.String str6 = rectangleConstraint4.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]" + "'", str6.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Category Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) dateTickUnit6);
        try {
            textLine1.draw(graphics2D2, 0.0f, 0.0f, textAnchor5, (float) 10L, 100.0f, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer15 };
        categoryPlot7.setRenderers(categoryItemRendererArray16);
        boolean boolean18 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        categoryAxis3D23.configure();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date28 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        dateAxis27.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat34 = null;
        dateAxis27.setDateFormatOverride(dateFormat34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer36);
        categoryAxis3D23.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date41 = dateAxis40.getMaximumDate();
        dateAxis40.setAutoRange(true);
        java.awt.Shape shape44 = dateAxis40.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer45);
        java.lang.Object obj47 = categoryAxis3D23.clone();
        categoryPlot7.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle19.setWidth((double) (byte) 10);
        textTitle19.setURLText("");
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = ringPlot25.getLabelPadding();
        double double28 = rectangleInsets26.calculateBottomOutset(0.0d);
        textTitle19.setPadding(rectangleInsets26);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets26.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType31, lengthAdjustmentType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getDomainMarkers((int) (short) 10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot5.render(graphics2D13, rectangle2D14, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = ringPlot19.getDrawingSupplier();
        float float21 = ringPlot19.getBackgroundImageAlpha();
        double double22 = ringPlot19.getInnerSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        ringPlot19.setDataset(pieDataset23);
        java.awt.Font font25 = ringPlot19.getLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint26);
        categoryPlot5.setOutlinePaint(paint26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date31 = dateAxis30.getMaximumDate();
        dateAxis30.setAutoRange(true);
        java.awt.Shape shape34 = dateAxis30.getDownArrow();
        dateAxis30.setInverted(true);
        java.util.Date date37 = dateAxis30.getMaximumDate();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        double double39 = numberAxis3D38.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, xYItemRenderer40);
        java.awt.Font font42 = dateAxis30.getTickLabelFont();
        int int43 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        float[] floatArray7 = new float[] { (-1), (short) 1, 10, 0L };
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) (short) 100, 0, 1, floatArray7);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedDimension();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        boolean boolean3 = numberAxis3D0.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D0.getMarkerBand();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent9);
        boolean boolean11 = lineBorder0.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot12.drawDomainTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color18 = color17.brighter();
        xYPlot12.setDomainZeroBaselinePaint((java.awt.Paint) color17);
        boolean boolean20 = lineBorder0.equals((java.lang.Object) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder0.getInsets();
        java.awt.Stroke stroke22 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        jFreeChart13.setAntiAlias(false);
        org.jfree.chart.plot.Plot plot17 = jFreeChart13.getPlot();
        jFreeChart13.setBackgroundImageAlignment((int) (short) 100);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(plot17);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        double double3 = textTitle2.getContentYOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer10);
        categoryPlot5.clearAnnotations();
        categoryPlot5.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        try {
            categoryPlot5.setRangeAxisLocation((int) (short) -1, axisLocation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.setTickMarksVisible(true);
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        dateAxis0.setTickMarkPaint(paint6);
        org.jfree.chart.axis.Timeline timeline8 = dateAxis0.getTimeline();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.HALF_ASCENT_RIGHT", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "", "Category Plot", "ChartEntity: tooltip = Rotation.CLOCKWISE");
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        java.lang.String str7 = categoryPlot5.getPlotType();
        categoryPlot5.setRangeCrosshairVisible(true);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot5.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = categoryPlot5.removeRangeMarker((int) (byte) 1, marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart13.getLegend();
        java.awt.Font font21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date25 = dateAxis24.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        java.lang.String str28 = categoryPlot27.getPlotType();
        java.lang.String str29 = categoryPlot27.getPlotType();
        categoryPlot27.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", font21, (org.jfree.chart.plot.Plot) categoryPlot27, false);
        boolean boolean34 = jFreeChart33.isNotify();
        java.awt.Image image35 = jFreeChart33.getBackgroundImage();
        org.jfree.chart.title.LegendTitle legendTitle36 = jFreeChart33.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = null;
        java.awt.image.BufferedImage bufferedImage40 = jFreeChart33.createBufferedImage((int) ' ', 100, chartRenderingInfo39);
        jFreeChart13.setBackgroundImage((java.awt.Image) bufferedImage40);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(image35);
        org.junit.Assert.assertNull(legendTitle36);
        org.junit.Assert.assertNotNull(bufferedImage40);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getFixedDimension();
        dateAxis2.setVerticalTickLabels(true);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot10.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        xYPlot10.datasetChanged(datasetChangeEvent12);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        java.awt.Shape shape15 = dateAxis2.getDownArrow();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "Rotation.CLOCKWISE", "ClassContext");
        chartEntity7.setURLText("{0}");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.WHITE;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        dateAxis6.setAutoRange(true);
        java.awt.Shape shape10 = dateAxis6.getDownArrow();
        dateAxis6.setInverted(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer16);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot17);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.data.Range range8 = dateAxis5.getRange();
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range8, (double) (byte) -1);
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range2, range10);
        boolean boolean15 = range2.contains(0.025d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot5.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.plot.Marker marker14 = null;
        try {
            boolean boolean15 = categoryPlot5.removeDomainMarker(marker14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = jFreeChart13.getCategoryPlot();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            jFreeChart13.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(categoryPlot15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray6 = new float[] { (-1L), 100, 0L, 10L };
        float[] floatArray7 = color1.getComponents(floatArray6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot8.getOrientation();
        boolean boolean10 = xYPlot8.isRangeZoomable();
        java.awt.Color color11 = java.awt.Color.WHITE;
        xYPlot8.setDomainZeroBaselinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = ringPlot13.getDrawingSupplier();
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setShadowPaint(paint15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date18 = dateAxis17.getMaximumDate();
        dateAxis17.setAutoRange(true);
        java.awt.Shape shape21 = dateAxis17.getDownArrow();
        dateAxis17.setInverted(true);
        boolean boolean24 = dateAxis17.isAutoTickUnitSelection();
        dateAxis17.setLabel("Category Plot");
        java.awt.Color color27 = java.awt.Color.CYAN;
        dateAxis17.setLabelPaint((java.awt.Paint) color27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color31 = color30.brighter();
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color1, color11, paint15, color27, color29, color31 };
        java.awt.Paint[] paintArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray36 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray36);
        java.awt.Paint paint38 = defaultDrawingSupplier37.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        boolean boolean6 = dateAxis0.isHiddenValue((long) (short) 10);
        try {
            dateAxis0.setRangeAboutValue(0.025d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.525) <= upper (-0.475).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        boolean boolean13 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = ringPlot15.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = ringPlot15.getLegendLabelToolTipGenerator();
        java.awt.Image image18 = null;
        ringPlot15.setBackgroundImage(image18);
        double double20 = ringPlot15.getLabelLinkMargin();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date24 = dateAxis23.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        dateAxis23.setRangeAboutValue((double) 1, (double) (short) 100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        dateAxis23.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date35 = dateAxis34.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer36);
        java.lang.String str38 = categoryPlot37.getPlotType();
        java.lang.String str39 = categoryPlot37.getPlotType();
        categoryPlot37.setRangeCrosshairVisible(true);
        categoryPlot37.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot37.getRenderer();
        boolean boolean44 = color30.equals((java.lang.Object) categoryPlot37);
        ringPlot15.setLabelLinkPaint((java.awt.Paint) color30);
        java.awt.Color color46 = java.awt.Color.getColor("", color30);
        java.awt.Color color47 = color30.brighter();
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color47);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot5.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        xYPlot50.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = xYPlot50.getRendererForDataset(xYDataset53);
        xYPlot50.mapDatasetToDomainAxis((-739), (int) '#');
        xYPlot50.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot50.getRangeAxisLocation((int) '#');
        categoryPlot5.setRangeAxisLocation(axisLocation61);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.025d + "'", double20 == 0.025d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Category Plot" + "'", str38.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Category Plot" + "'", str39.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(legendItemCollection49);
        org.junit.Assert.assertNull(xYItemRenderer54);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date16 = dateAxis15.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        java.lang.String str19 = categoryPlot18.getPlotType();
        java.lang.String str20 = categoryPlot18.getPlotType();
        categoryPlot18.setRangeCrosshairVisible(true);
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot18.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = xYPlot26.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation27);
        try {
            categoryPlot5.setRangeAxisLocation((int) (short) -1, axisLocation25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Category Plot" + "'", str20.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        categoryPlot5.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot5.setAnchorValue((double) (short) 0, false);
        categoryPlot5.clearDomainMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = null;
        try {
            categoryPlot5.setAxisOffset(rectangleInsets14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setRangeCrosshairValue((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot5.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = categoryPlot5.removeDomainMarker(marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getDomainMarkers(layer6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date9 = dateAxis8.getMaximumDate();
        org.jfree.data.Range range10 = dateAxis8.getRange();
        org.jfree.data.Range range11 = dateAxis8.getRange();
        org.jfree.chart.axis.Timeline timeline12 = null;
        dateAxis8.setTimeline(timeline12);
        java.awt.Paint paint14 = dateAxis8.getTickMarkPaint();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        jFreeChart13.setTextAntiAlias(false);
        jFreeChart13.setBackgroundImageAlignment(0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener19 = null;
        jFreeChart13.removeProgressListener(chartProgressListener19);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        java.awt.Image image4 = ringPlot0.getBackgroundImage();
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        ringPlot11.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot11.setSeparatorStroke(stroke14);
        ringPlot8.setSeparatorStroke(stroke14);
        java.awt.Paint paint17 = ringPlot8.getShadowPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.PiePlotState piePlotState20 = ringPlot0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) ringPlot8, (java.lang.Integer) (-1), plotRenderingInfo19);
        ringPlot8.setOuterSeparatorExtension((double) ' ');
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(piePlotState20);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, (double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range3, lengthConstraintType4, (-1.0d), range8, lengthConstraintType9);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis0.setMarkerBand(markerAxisBand1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        dateAxis5.setRangeAboutValue((double) 1, (double) (short) 100);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5 };
        xYPlot0.setRangeAxes(valueAxisArray12);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(valueAxisArray12);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        xYPlot0.configureRangeAxes();
        java.awt.Color color3 = java.awt.Color.GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        xYPlot0.setWeight((int) ' ');
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.setWeight(15);
        float float4 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        java.awt.Image image3 = null;
        ringPlot0.setBackgroundImage(image3);
        double double6 = ringPlot0.getExplodePercent((java.lang.Comparable) 100L);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot0.setURLGenerator(pieURLGenerator7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = ringPlot0.getLabelPadding();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(0, layer4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot0.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) 10L, range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint7.toUnconstrainedWidth();
        org.jfree.data.Range range9 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeWidth(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = xYPlot0.getOrientation();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder2 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setRangeAboutValue((double) 1, (double) (short) 100);
        java.text.DateFormat dateFormat9 = null;
        dateAxis2.setDateFormatOverride(dateFormat9);
        double double11 = dateAxis2.getUpperBound();
        boolean boolean12 = dateAxis2.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date14 = dateAxis13.getMaximumDate();
        dateAxis13.setAutoRange(true);
        java.awt.Shape shape17 = dateAxis13.getDownArrow();
        dateAxis13.setInverted(true);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        ringPlot21.setSeparatorsVisible(false);
        java.awt.Shape shape24 = ringPlot21.getLegendItemShape();
        dateAxis13.setUpArrow(shape24);
        dateAxis2.setRightArrow(shape24);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 51.0d + "'", double11 == 51.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = ringPlot9.getDrawingSupplier();
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot9.setShadowPaint(paint11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint11);
        dateAxis3.setTickLabelPaint(paint11);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) paint11);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date17 = dateAxis16.getMaximumDate();
        dateAxis16.setAutoRange(true);
        java.awt.Shape shape20 = dateAxis16.getDownArrow();
        boolean boolean21 = ringPlot0.equals((java.lang.Object) dateAxis16);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator22);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date11 = dateAxis10.getMaximumDate();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot16.getDrawingSupplier();
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setShadowPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) (short) 10, (double) 1, (double) (byte) 100, paint18);
        dateAxis10.setTickLabelPaint(paint18);
        categoryPlot5.setBackgroundPaint(paint18);
        boolean boolean23 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot5.zoomDomainAxes(0.0d, (double) (short) 10, plotRenderingInfo26, point2D27);
        boolean boolean29 = categoryPlot5.isRangeGridlinesVisible();
        categoryPlot5.setWeight((-1));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        jFreeChart13.removeLegend();
        int int15 = jFreeChart13.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            java.awt.image.BufferedImage bufferedImage20 = jFreeChart13.createBufferedImage((int) (byte) -1, (-1), 0, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setShadowPaint(paint2);
        java.awt.Image image4 = ringPlot0.getBackgroundImage();
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setShadowYOffset((double) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        ringPlot11.setShadowYOffset((double) (byte) 100);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot11.setSeparatorStroke(stroke14);
        ringPlot8.setSeparatorStroke(stroke14);
        java.awt.Paint paint17 = ringPlot8.getShadowPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.PiePlotState piePlotState20 = ringPlot0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) ringPlot8, (java.lang.Integer) (-1), plotRenderingInfo19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        ringPlot8.setDataset(pieDataset21);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(piePlotState20);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot5.setRenderer(categoryItemRenderer9);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot5);
        java.awt.Stroke stroke12 = categoryPlot5.getDomainGridlineStroke();
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(8);
        java.lang.String str2 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        categoryPlot14.setRangeCrosshairVisible(false);
        categoryPlot14.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot14.getRangeMarkers(layer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot14.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot25.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.geom.Point2D point2D29 = xYPlot25.getQuadrantOrigin();
        categoryPlot14.zoomRangeAxes((double) 10L, (double) 10.0f, plotRenderingInfo24, point2D29);
        polarPlot4.zoomDomainAxes(0.0d, (double) 0, plotRenderingInfo8, point2D29);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color7 = java.awt.Color.getColor("RectangleAnchor.LEFT", color6);
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("RectangleAnchor.LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.LEFT");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        xYPlot0.setBackgroundAlpha((float) '4');
        java.awt.Stroke stroke10 = xYPlot0.getDomainGridlineStroke();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((-254));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -254 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        boolean boolean6 = dateAxis2.isPositiveArrowVisible();
        java.lang.Object obj7 = dateAxis2.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        double double5 = textTitle2.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle2.getPosition();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxisForDataset((int) (byte) 1);
        java.lang.Object obj8 = categoryPlot5.clone();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot5.addRangeMarker((int) ' ', marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(valueAxis7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Category Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0d, (float) 2, (float) (-739));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateBottomInset((double) 1L);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.lang.String str10 = categoryPlot9.getPlotType();
        java.lang.String str11 = categoryPlot9.getPlotType();
        categoryPlot9.setRangeCrosshairVisible(true);
        boolean boolean14 = rectangleInsets1.equals((java.lang.Object) true);
        double double16 = rectangleInsets1.extendWidth(0.0d);
        double double18 = rectangleInsets1.calculateLeftOutset((double) (short) 0);
        java.lang.String str19 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock0.draw(graphics2D1, (float) 1, (float) 0, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str11 = textBlockAnchor10.toString();
        java.awt.Shape shape15 = textBlock0.calculateBounds(graphics2D7, (float) 0, 1.0f, textBlockAnchor10, 0.0f, (float) (byte) 1, (double) (-1.0f));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        categoryPlot23.setRangeCrosshairVisible(false);
        boolean boolean26 = verticalAlignment17.equals((java.lang.Object) categoryPlot23);
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment16, verticalAlignment17, (double) (-739), (double) (-254));
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str11.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRendererForDataset(xYDataset3);
        xYPlot0.mapDatasetToDomainAxis((-739), (int) '#');
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers((-254), layer9);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.CENTER_LEFT", "Category Plot", "ClassContext", "hi!", "ClassContext");
        basicProjectInfo5.setInfo("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        basicProjectInfo5.setCopyright("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo5.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ringPlot0.getDrawingSupplier();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 100, paint6);
        ringPlot0.setMinimumArcAngleToDraw(90.0d);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Font font1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.lang.String str8 = categoryPlot7.getPlotType();
        java.lang.String str9 = categoryPlot7.getPlotType();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        boolean boolean14 = jFreeChart13.isNotify();
        java.awt.Image image15 = jFreeChart13.getBackgroundImage();
        jFreeChart13.removeLegend();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMaximumDate();
        dateAxis0.setAutoRange(true);
        java.awt.Shape shape4 = dateAxis0.getDownArrow();
        boolean boolean6 = dateAxis0.isHiddenValue((long) (short) 10);
        java.lang.String str7 = dateAxis0.getLabelURL();
        double double8 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot5.getDomainMarkers((int) (short) 10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot5.render(graphics2D13, rectangle2D14, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = ringPlot19.getDrawingSupplier();
        float float21 = ringPlot19.getBackgroundImageAlpha();
        double double22 = ringPlot19.getInnerSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        ringPlot19.setDataset(pieDataset23);
        java.awt.Font font25 = ringPlot19.getLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint26);
        categoryPlot5.setOutlinePaint(paint26);
        org.jfree.chart.plot.Plot plot29 = categoryPlot5.getRootPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot5.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(plot29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setWidth((double) (byte) 10);
        textTitle2.setHeight((double) (byte) 100);
        textTitle2.setExpandToFitSpace(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date10 = dateAxis9.getMaximumDate();
        org.jfree.data.Range range11 = dateAxis9.getRange();
        org.jfree.data.Range range12 = dateAxis9.getRange();
        org.jfree.chart.axis.Timeline timeline13 = null;
        dateAxis9.setTimeline(timeline13);
        java.awt.Paint paint15 = dateAxis9.getTickMarkPaint();
        textTitle2.setPaint(paint15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint15);
    }
}

