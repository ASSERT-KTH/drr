import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 2.0f, 4.0d);
        boolean boolean4 = dateAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color8);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        xYPlot0.setForegroundAlpha((float) 1560452399999L);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 15);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape5 = dateAxis4.getDownArrow();
//        java.awt.Paint paint6 = dateAxis4.getAxisLinePaint();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
//        boolean boolean8 = dateAxis4.isInverted();
//        java.util.TimeZone timeZone9 = dateAxis4.getTimeZone();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone9);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(shape5);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertNotNull(dateTickUnit7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(timeZone9);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        java.awt.Color color5 = java.awt.Color.ORANGE;
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke7 = categoryMarker3.getStroke();
        java.awt.Font font8 = categoryMarker3.getLabelFont();
        java.awt.Paint paint9 = categoryMarker3.getPaint();
        java.awt.Stroke stroke10 = categoryMarker3.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(500, xYItemRenderer8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot0.getIndexOf(xYItemRenderer10);
        java.awt.Stroke stroke12 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint13 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot0.getDataset((int) (short) 0);
        xYPlot0.clearRangeMarkers((int) '4');
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNull(xYDataset14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot20.setDataset(10, categoryDataset24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace26);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        xYPlot30.markerChanged(markerChangeEvent31);
        java.awt.Image image33 = xYPlot30.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot30.getRangeAxis();
        java.awt.Color color36 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color36, stroke37);
        java.awt.Paint paint39 = categoryMarker38.getLabelPaint();
        xYPlot30.setDomainGridlinePaint(paint39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot30.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        dateAxis42.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape46 = dateAxis42.getLeftArrow();
        boolean boolean47 = axisLocation41.equals((java.lang.Object) dateAxis42);
        org.jfree.chart.axis.AxisLocation axisLocation48 = axisLocation41.getOpposite();
        categoryPlot20.setDomainAxisLocation(0, axisLocation48, true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image33);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Paint paint12 = dateAxis10.getLabelPaint();
        dateAxis0.setTickLabelPaint(paint12);
        org.jfree.chart.plot.Plot plot14 = dateAxis0.getPlot();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        xYPlot0.setForegroundAlpha(0.0f);
        xYPlot0.setBackgroundAlpha((float) 0L);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot0.getFixedLegendItems();
        java.lang.Object obj9 = xYPlot0.clone();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryMarker15.getLabelOffset();
        double double18 = rectangleInsets16.trimHeight(0.0d);
        xYPlot0.setAxisOffset(rectangleInsets16);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        xYPlot20.setDomainAxisLocation((int) (short) 10, axisLocation25);
        int int27 = xYPlot20.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot20.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot29.markerChanged(markerChangeEvent30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot29.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        xYPlot29.drawAnnotations(graphics2D33, rectangle2D34, plotRenderingInfo35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.util.List list39 = null;
        xYPlot29.drawRangeTickBands(graphics2D37, rectangle2D38, list39);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot29.setRangeGridlineStroke(stroke41);
        xYPlot20.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType45 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean46 = lengthAdjustmentType44.equals((java.lang.Object) unitType45);
        java.awt.Color color48 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color48, stroke49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryMarker50.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent53 = null;
        xYPlot52.markerChanged(markerChangeEvent53);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder55 = xYPlot52.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        xYPlot52.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder59 = xYPlot52.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        xYPlot60.markerChanged(markerChangeEvent61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot60.zoomDomainAxes((double) 0, plotRenderingInfo64, point2D65, false);
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot60.setDomainCrosshairPaint((java.awt.Paint) color68);
        xYPlot52.setRangeGridlinePaint((java.awt.Paint) color68);
        categoryMarker50.setPaint((java.awt.Paint) color68);
        boolean boolean72 = unitType45.equals((java.lang.Object) categoryMarker50);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker50.setLabelOffsetType(lengthAdjustmentType73);
        org.jfree.chart.util.Layer layer75 = null;
        boolean boolean76 = xYPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker50, layer75);
        boolean boolean77 = xYPlot0.equals((java.lang.Object) xYPlot20);
        boolean boolean78 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        try {
            xYPlot0.setRenderer((-14336), xYItemRenderer80, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-6.0d) + "'", double18 == (-6.0d));
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType44);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(seriesRenderingOrder55);
        org.junit.Assert.assertNotNull(datasetRenderingOrder59);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        try {
            categoryPlot20.setRangeAxisLocation(axisLocation34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        java.util.List list25 = categoryPlot20.getCategoriesForAxis(categoryAxis24);
        java.awt.Stroke stroke26 = categoryPlot20.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray28 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer27 };
        categoryPlot20.setRenderers(categoryItemRendererArray28);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo32, point2D33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(categoryItemRendererArray28);
        org.junit.Assert.assertNull(legendItemCollection30);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        java.awt.Font font3 = dateAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Stroke stroke40 = categoryPlot20.getDomainGridlineStroke();
        boolean boolean41 = categoryPlot20.isDomainZoomable();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(500, xYItemRenderer8);
        java.awt.Paint paint10 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 100);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker33 = null;
        boolean boolean34 = categoryPlot20.removeDomainMarker(marker33);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        xYPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        xYPlot39.markerChanged(markerChangeEvent40);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder42 = xYPlot39.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        xYPlot39.drawAnnotations(graphics2D43, rectangle2D44, plotRenderingInfo45);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.util.List list49 = null;
        xYPlot39.drawRangeTickBands(graphics2D47, rectangle2D48, list49);
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot39.setRangeGridlineStroke(stroke51);
        xYPlot36.setDomainZeroBaselineStroke(stroke51);
        org.jfree.chart.plot.IntervalMarker intervalMarker57 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot36.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker57, layer58, true);
        java.util.Collection collection61 = categoryPlot20.getDomainMarkers(6, layer58);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder42);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection61);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        boolean boolean11 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        double double12 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getRangeAxisEdge(0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        xYPlot4.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot11.setOutlineStroke(stroke15);
        boolean boolean17 = dateAxis9.hasListener((java.util.EventListener) xYPlot11);
        dateAxis9.setRange((double) '#', (double) 100L);
        dateAxis9.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange23, false, true);
        boolean boolean27 = dateAxis9.isTickMarksVisible();
        java.lang.String str28 = dateAxis9.getLabel();
        boolean boolean29 = day0.equals((java.lang.Object) str28);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str28.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(10, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        categoryPlot20.drawBackgroundImage(graphics2D26, rectangle2D27);
        categoryPlot20.setAnchorValue((double) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot20.getIndexOf(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape4 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Paint paint7 = dateAxis5.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis5.getTickUnit();
        java.awt.Stroke stroke9 = dateAxis5.getTickMarkStroke();
        dateAxis5.setAutoRange(true);
        org.jfree.data.Range range12 = dateAxis5.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range12);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        boolean boolean20 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        double double23 = dateAxis21.getUpperBound();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer24);
        int int26 = xYPlot25.getDomainAxisCount();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot25.datasetChanged(datasetChangeEvent27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        categoryPlot20.mapDatasetToRangeAxis(11, 9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot0.getDataset((int) (short) 0);
        org.jfree.chart.plot.Plot plot15 = null;
        xYPlot0.setParent(plot15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNull(xYDataset14);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        boolean boolean20 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        double double23 = dateAxis21.getUpperBound();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        xYPlot25.setNoDataMessagePaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        java.awt.Stroke stroke9 = dateAxis0.getAxisLineStroke();
        java.awt.Stroke stroke10 = dateAxis0.getAxisLineStroke();
        boolean boolean11 = dateAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        xYPlot4.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot11.setOutlineStroke(stroke15);
        boolean boolean17 = dateAxis9.hasListener((java.util.EventListener) xYPlot11);
        dateAxis9.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer23);
        categoryPlot24.clearRangeAxes();
        boolean boolean26 = categoryPlot24.isOutlineVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot24.render(graphics2D38, rectangle2D39, 0, plotRenderingInfo41, crosshairState42);
        boolean boolean44 = xYPlot24.isRangeCrosshairVisible();
        java.awt.Color color47 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color47, stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = xYPlot24.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker49, layer51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer54);
        categoryPlot20.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        categoryPlot20.setRenderer(categoryItemRenderer57);
        java.lang.String str59 = categoryPlot20.getPlotType();
        boolean boolean60 = categoryPlot20.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Category Plot" + "'", str59.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        float[] floatArray4 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray5 = color0.getColorComponents(floatArray4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets6.extendHeight(0.0d);
        boolean boolean9 = color0.equals((java.lang.Object) rectangleInsets6);
        float[] floatArray16 = new float[] { (byte) -1, 2, 8, 10.0f, 1560495599999L, 1560495599999L };
        float[] floatArray17 = color0.getComponents(floatArray16);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.0d + "'", double8 == 6.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(10, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        categoryPlot20.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot20.getDataRange(valueAxis29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj32 = null;
        boolean boolean33 = datasetRenderingOrder31.equals(obj32);
        categoryPlot20.setDatasetRenderingOrder(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot20.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot20.setRenderer(categoryItemRenderer47);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot20.getLegendItems();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(legendItemCollection49);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setLowerMargin(0.0d);
        double double13 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (short) 10, (double) 1L, (double) (short) 10);
        double double7 = rectangleInsets5.extendWidth((-1.0d));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 19.0d + "'", double7 == 19.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape16 = dateAxis12.getLeftArrow();
        boolean boolean17 = axisLocation11.equals((java.lang.Object) dateAxis12);
        dateAxis12.setAutoRangeMinimumSize((double) 12, false);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot13.zoomDomainAxes((double) 0, plotRenderingInfo17, point2D18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color21);
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color21);
        categoryMarker3.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryMarker3.getLabelOffset();
        double double26 = rectangleInsets25.getTop();
        double double27 = rectangleInsets25.getLeft();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getLegendItems();
        xYPlot0.mapDatasetToRangeAxis(8, 9);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        java.awt.Stroke stroke20 = dateAxis16.getTickMarkStroke();
        dateAxis16.setAutoRange(true);
        dateAxis16.setLowerMargin(16.0d);
        java.util.Date date25 = dateAxis16.getMinimumDate();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot0.mapDatasetToRangeAxis(255, 255);
        boolean boolean30 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        double double22 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setForegroundAlpha(0.0f);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.Plot plot7 = null;
        dateAxis5.setPlot(plot7);
        dateAxis5.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        java.awt.Color color5 = java.awt.Color.ORANGE;
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot7.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot7.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        java.awt.Color color20 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color20, stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryMarker22.getLabelOffset();
        double double25 = rectangleInsets23.trimHeight(0.0d);
        xYPlot7.setAxisOffset(rectangleInsets23);
        categoryMarker3.setLabelOffset(rectangleInsets23);
        double double29 = rectangleInsets23.calculateRightOutset((double) 3);
        double double31 = rectangleInsets23.calculateTopOutset(35.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-6.0d) + "'", double25 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        dateAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        java.awt.Color color8 = java.awt.Color.RED;
//        java.awt.Color color9 = color8.brighter();
//        objectList1.set(1, (java.lang.Object) color8);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP;
//        int int12 = objectList1.indexOf((java.lang.Object) rectangleAnchor11);
//        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
//        xYPlot13.markerChanged(markerChangeEvent14);
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
//        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
//        xYPlot13.setDomainAxisLocation((int) (short) 10, axisLocation18);
//        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
//        xYPlot20.markerChanged(markerChangeEvent21);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
//        java.awt.geom.Point2D point2D25 = null;
//        xYPlot20.zoomDomainAxes((double) 0, plotRenderingInfo24, point2D25, false);
//        boolean boolean28 = xYPlot13.equals((java.lang.Object) false);
//        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape30 = dateAxis29.getDownArrow();
//        java.awt.Paint paint31 = dateAxis29.getAxisLinePaint();
//        int int32 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
//        org.jfree.chart.util.Layer layer33 = null;
//        java.util.Collection collection34 = xYPlot13.getDomainMarkers(layer33);
//        xYPlot13.clearDomainMarkers();
//        java.awt.Color color36 = java.awt.Color.pink;
//        java.awt.Color color38 = java.awt.Color.ORANGE;
//        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color38, stroke39);
//        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryMarker40.getLabelOffset();
//        boolean boolean42 = color36.equals((java.lang.Object) rectangleInsets41);
//        double double43 = rectangleInsets41.getTop();
//        xYPlot13.setAxisOffset(rectangleInsets41);
//        boolean boolean45 = objectList1.equals((java.lang.Object) rectangleInsets41);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(color8);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(rectangleAnchor11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(shape30);
//        org.junit.Assert.assertNotNull(paint31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNull(collection34);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertNotNull(color38);
//        org.junit.Assert.assertNotNull(stroke39);
//        org.junit.Assert.assertNotNull(rectangleInsets41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 3.0d + "'", double43 == 3.0d);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke10, stroke11 };
        java.awt.Shape[] shapeArray13 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray9, strokeArray12, shapeArray13);
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray15, strokeArray16, shapeArray17);
        java.lang.Object obj19 = defaultDrawingSupplier18.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(obj19);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        long long7 = day2.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day2.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape1 = dateAxis0.getDownArrow();
//        java.text.DateFormat dateFormat2 = null;
//        dateAxis0.setDateFormatOverride(dateFormat2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
//        long long8 = day4.getMiddleMillisecond();
//        long long9 = day4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        boolean boolean11 = dateAxis0.equals((java.lang.Object) regularTimePeriod10);
//        org.junit.Assert.assertNotNull(shape1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        org.jfree.data.Range range7 = dateAxis0.getDefaultAutoRange();
        java.awt.Shape shape8 = dateAxis0.getUpArrow();
        java.awt.Paint paint9 = dateAxis0.getTickMarkPaint();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis11.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
        numberAxis11.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat20 = numberAxis11.getNumberFormatOverride();
        float float21 = numberAxis11.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        xYPlot23.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        xYPlot30.markerChanged(markerChangeEvent31);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder33 = xYPlot30.getSeriesRenderingOrder();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot30.setOutlineStroke(stroke34);
        boolean boolean36 = dateAxis28.hasListener((java.util.EventListener) xYPlot30);
        java.awt.Font font37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis28.setLabelFont(font37);
        dateAxis22.setTickLabelFont(font37);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis41.configure();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape44 = dateAxis43.getDownArrow();
        java.awt.Paint paint45 = dateAxis43.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis43.getTickUnit();
        java.awt.Stroke stroke47 = dateAxis43.getTickMarkStroke();
        dateAxis43.setAutoRange(true);
        dateAxis43.setLowerMargin(16.0d);
        java.util.Date date52 = dateAxis43.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape54 = dateAxis53.getDownArrow();
        dateAxis43.setRightArrow(shape54);
        numberAxis41.setUpArrow(shape54);
        dateAxis22.setDownArrow(shape54);
        numberAxis11.setLeftArrow(shape54);
        dateAxis0.setUpArrow(shape54);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(numberFormat20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(shape54);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        java.util.Date date10 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis11.setRange((org.jfree.data.Range) dateRange12);
        dateAxis0.setRange((org.jfree.data.Range) dateRange12, false, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateRange12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.util.Date date5 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(xYItemRenderer6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot0.getDomainAxisEdge(11);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryMarker5.getLabelOffset();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) categoryMarker5);
        java.lang.String str8 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SortOrder.DESCENDING" + "'", str8.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        xYPlot0.zoom((double) (-1));
        java.awt.Stroke stroke15 = null;
        try {
            xYPlot0.setRangeCrosshairStroke(stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot20.getDomainAxis();
        double double35 = categoryPlot20.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color38 = java.awt.Color.RED;
        java.awt.Color color39 = color38.brighter();
        int int40 = color39.getBlue();
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color39);
        java.lang.String str42 = color39.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str42.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        java.awt.Paint paint23 = dateAxis21.getAxisLinePaint();
        dateAxis21.setPositiveArrowVisible(false);
        int int26 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        try {
            categoryPlot20.setRangeAxisLocation(0, axisLocation29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
//        xYPlot9.markerChanged(markerChangeEvent10);
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
//        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
//        xYPlot9.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis14);
//        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
//        xYPlot16.markerChanged(markerChangeEvent17);
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot16.getSeriesRenderingOrder();
//        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        xYPlot16.setOutlineStroke(stroke20);
//        boolean boolean22 = dateAxis14.hasListener((java.util.EventListener) xYPlot16);
//        dateAxis14.setRange((double) '#', (double) 100L);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer26);
//        java.awt.Paint paint28 = categoryPlot27.getRangeGridlinePaint();
//        categoryPlot27.setRangeGridlinesVisible(false);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
//        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
//        categoryPlot27.zoomRangeAxes((double) 7, plotRenderingInfo32, point2D35, false);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray38 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot27.setRenderers(categoryItemRendererArray38);
//        java.awt.Paint paint40 = categoryPlot27.getRangeGridlinePaint();
//        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        categoryPlot27.setRangeGridlineStroke(stroke41);
//        int int43 = day0.compareTo((java.lang.Object) categoryPlot27);
//        categoryPlot27.setRangeCrosshairLockedOnData(false);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
//        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(paint28);
//        org.junit.Assert.assertNotNull(point2D35);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray38);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertNotNull(stroke41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        org.jfree.chart.plot.Plot plot14 = xYPlot7.getParent();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = xYPlot18.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        xYPlot18.drawAnnotations(graphics2D22, rectangle2D23, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot18.drawRangeTickBands(graphics2D26, rectangle2D27, list28);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot18.setRangeGridlineStroke(stroke30);
        xYPlot15.setDomainZeroBaselineStroke(stroke30);
        xYPlot7.setRangeCrosshairStroke(stroke30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot7.zoomDomainAxes((double) (short) -1, (double) (-1), plotRenderingInfo36, point2D37);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        double double2 = dateAxis0.getUpperBound();
        dateAxis0.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot5.setDomainAxisLocation((int) (short) 10, axisLocation10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot5.getRendererForDataset(xYDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = numberAxis17.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        xYPlot5.drawRangeTickBands(graphics2D14, rectangle2D15, list22);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.Paint paint25 = xYPlot5.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot20.setRenderer((int) (byte) 100, categoryItemRenderer22);
        categoryPlot20.clearRangeMarkers();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        java.awt.Paint paint34 = dateAxis32.getAxisLinePaint();
        dateAxis32.setPositiveArrowVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        xYPlot37.markerChanged(markerChangeEvent38);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder40 = xYPlot37.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        xYPlot37.drawAnnotations(graphics2D41, rectangle2D42, plotRenderingInfo43);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.util.List list47 = null;
        xYPlot37.drawRangeTickBands(graphics2D45, rectangle2D46, list47);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot37.setRangeGridlineStroke(stroke49);
        org.jfree.chart.plot.Plot plot51 = xYPlot37.getRootPlot();
        dateAxis32.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot37);
        java.awt.Paint paint53 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot37.setDomainZeroBaselinePaint(paint53);
        boolean boolean55 = categoryPlot20.equals((java.lang.Object) xYPlot37);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder40);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(plot51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        categoryPlot20.zoomRangeAxes((double) 7, plotRenderingInfo25, point2D28, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray31);
        java.awt.Paint paint33 = categoryPlot20.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot20.getRangeAxis((-16777216));
        java.lang.String str36 = categoryPlot20.getPlotType();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryMarker25.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.chart.JFreeChart jFreeChart31 = markerChangeEvent30.getChart();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(jFreeChart31);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setWeight((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot20.setDataset(2019, categoryDataset25);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color29, stroke30);
        java.awt.Paint paint32 = categoryMarker31.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot33.markerChanged(markerChangeEvent34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        xYPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder39 = xYPlot36.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        xYPlot36.drawAnnotations(graphics2D40, rectangle2D41, plotRenderingInfo42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot36.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot36.setRangeGridlineStroke(stroke48);
        xYPlot33.setDomainZeroBaselineStroke(stroke48);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot33.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker54, layer55, true);
        categoryPlot20.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker31, layer55, false);
        java.awt.Paint paint60 = categoryMarker31.getOutlinePaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str1.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        xYPlot3.markerChanged(markerChangeEvent4);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = xYPlot3.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        xYPlot3.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = xYPlot3.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot3.setRangeGridlineStroke(stroke11);
        java.awt.Color color13 = java.awt.Color.white;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = xYPlot17.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        xYPlot17.drawAnnotations(graphics2D21, rectangle2D22, plotRenderingInfo23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.util.List list27 = null;
        xYPlot17.drawRangeTickBands(graphics2D25, rectangle2D26, list27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot17.setRangeGridlineStroke(stroke29);
        xYPlot14.setDomainZeroBaselineStroke(stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot14.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker35, layer36, true);
        java.awt.Stroke stroke39 = intervalMarker35.getStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 0.0f, paint2, stroke11, (java.awt.Paint) color13, stroke39, (float) (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = numberAxis26.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        numberAxis26.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType35 = numberAxis26.getRangeType();
        org.jfree.data.RangeType rangeType36 = numberAxis26.getRangeType();
        categoryPlot20.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis26.setMarkerBand(markerAxisBand39);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rangeType35);
        org.junit.Assert.assertNotNull(rangeType36);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = numberAxis17.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        numberAxis17.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat26 = numberAxis17.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType27 = numberAxis17.getRangeType();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(numberFormat26);
        org.junit.Assert.assertNotNull(rangeType27);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint10 = xYPlot0.getDomainTickBandPaint();
        java.awt.Color color11 = java.awt.Color.black;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        boolean boolean13 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        double double2 = dateAxis0.getUpperBound();
        dateAxis0.setAutoRangeMinimumSize(3.0d);
        dateAxis0.setFixedDimension((double) (-52));
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        java.awt.Image image18 = xYPlot15.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot15.getRangeAxis();
        java.awt.Color color21 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = categoryMarker23.getLabelPaint();
        xYPlot15.setDomainGridlinePaint(paint24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot15.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape31 = dateAxis27.getLeftArrow();
        boolean boolean32 = axisLocation26.equals((java.lang.Object) dateAxis27);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color33);
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.JFreeChart jFreeChart36 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor35, jFreeChart36);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = chartChangeEvent37.getType();
        chartChangeEvent34.setType(chartChangeEventType38);
        boolean boolean40 = axisLocation26.equals((java.lang.Object) chartChangeEventType38);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shapeArray12, jFreeChart14, chartChangeEventType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getFixedLegendItems();
        float float8 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        xYPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        dateAxis0.setRightArrow(shape7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange9, true, true);
        dateAxis0.setAutoRange(false);
        java.awt.Shape shape15 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        boolean boolean20 = dateAxis16.isInverted();
        java.util.TimeZone timeZone21 = dateAxis16.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        dateAxis16.setRightArrow(shape23);
        org.jfree.data.time.DateRange dateRange25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRange((org.jfree.data.Range) dateRange25, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange25, false, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(dateRange25);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot20.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot20.getDataset();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNull(categoryDataset25);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer(1);
        int int12 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        java.awt.Paint paint5 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot20.setDataset(10, categoryDataset24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace26);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = categoryPlot20.getOrientation();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation28);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis6.setLabelFont(font15);
        dateAxis0.setTickLabelFont(font15);
        org.jfree.data.Range range18 = null;
        try {
            dateAxis0.setRange(range18, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        java.util.Date date10 = dateAxis0.getMinimumDate();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke11);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot20.getDatasetRenderingOrder();
        categoryPlot20.setRangeCrosshairValue((double) 1L, false);
        categoryPlot20.setWeight((int) (byte) -1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setWeight((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot20.setDataset(2019, categoryDataset25);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color29, stroke30);
        java.awt.Paint paint32 = categoryMarker31.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot33.markerChanged(markerChangeEvent34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        xYPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder39 = xYPlot36.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        xYPlot36.drawAnnotations(graphics2D40, rectangle2D41, plotRenderingInfo42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot36.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot36.setRangeGridlineStroke(stroke48);
        xYPlot33.setDomainZeroBaselineStroke(stroke48);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot33.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker54, layer55, true);
        categoryPlot20.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker31, layer55, false);
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace60, false);
        boolean boolean63 = categoryPlot20.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        java.lang.Object obj15 = defaultDrawingSupplier13.clone();
        java.awt.Stroke stroke16 = defaultDrawingSupplier13.getNextStroke();
        java.awt.Stroke stroke17 = defaultDrawingSupplier13.getNextStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot0.setOrientation(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot0.getDomainAxisLocation();
        java.lang.Object obj12 = xYPlot0.clone();
        int int13 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        double double5 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = categoryMarker11.getLabelPaint();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        categoryMarker11.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot15.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot15.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        double double33 = rectangleInsets31.trimHeight(0.0d);
        xYPlot15.setAxisOffset(rectangleInsets31);
        categoryMarker11.setLabelOffset(rectangleInsets31);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker11, layer36, true);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot0.getRendererForDataset(xYDataset39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        java.util.List list47 = numberAxis42.refreshTicks(graphics2D43, axisState44, rectangle2D45, rectangleEdge46);
        numberAxis42.setAutoRangeMinimumSize((double) (byte) 100, false);
        numberAxis42.configure();
        boolean boolean52 = numberAxis42.getAutoRangeStickyZero();
        int int53 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis42);
        numberAxis42.setRangeAboutValue(38.0d, (double) 3);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-6.0d) + "'", double33 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(xYItemRenderer40);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        java.awt.Color color8 = java.awt.Color.RED;
//        java.awt.Color color9 = color8.brighter();
//        objectList1.set(1, (java.lang.Object) color8);
//        int int11 = color8.getBlue();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(color8);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        double double22 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        int int7 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape5);
        dateAxis0.setRangeAboutValue((double) 0.0f, (double) ' ');
        float float10 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        java.awt.Color color5 = java.awt.Color.ORANGE;
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        java.awt.color.ColorSpace colorSpace7 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        boolean boolean16 = color14.equals((java.lang.Object) (byte) -1);
        float[] floatArray21 = new float[] { 1560495599999L, ' ', '4', (short) 100 };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        float[] floatArray23 = java.awt.Color.RGBtoHSB(3, 9, 9, floatArray21);
        float[] floatArray24 = java.awt.Color.RGBtoHSB(0, 6, (int) 'a', floatArray21);
        try {
            float[] floatArray25 = color5.getComponents(colorSpace7, floatArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape4 = dateAxis0.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Paint paint12 = dateAxis10.getLabelPaint();
        dateAxis0.setLabelPaint(paint12);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        xYPlot0.zoom((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange16);
        int int18 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis19.getStandardTickUnits();
        dateAxis19.setTickLabelsVisible(true);
        java.awt.Font font23 = dateAxis19.getTickLabelFont();
        dateAxis19.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint26 = dateAxis19.getAxisLinePaint();
        java.awt.Shape shape27 = dateAxis19.getDownArrow();
        org.jfree.chart.axis.Timeline timeline28 = dateAxis19.getTimeline();
        dateAxis15.setTimeline(timeline28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(timeline28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        java.awt.Paint paint23 = dateAxis21.getAxisLinePaint();
        dateAxis21.setPositiveArrowVisible(false);
        int int26 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str27 = categoryPlot20.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot20.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        xYPlot0.zoom((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange16);
        int int18 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range19, false, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot20.getDomainAxis();
        java.awt.Color color36 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color36, stroke37);
        categoryPlot20.addDomainMarker(categoryMarker38);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        xYPlot41.markerChanged(markerChangeEvent42);
        java.lang.Object obj44 = xYPlot41.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot41.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot41.getDomainAxisLocation();
        try {
            categoryPlot20.setDomainAxisLocation((-14336), axisLocation46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        xYPlot0.clearDomainMarkers();
        float float10 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        xYPlot0.addChangeListener(plotChangeListener5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation(192);
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation10 = axisLocation8.getOpposite();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", dataset5);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getRangeAxisEdge();
        xYPlot0.mapDatasetToRangeAxis((int) 'a', 6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = null;
        xYPlot0.setDomainTickBandPaint(paint9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        java.lang.String str3 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Paint paint20 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = xYPlot0.getDrawingSupplier();
        java.awt.Paint paint22 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        xYPlot26.markerChanged(markerChangeEvent27);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder29 = xYPlot26.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        xYPlot26.drawAnnotations(graphics2D30, rectangle2D31, plotRenderingInfo32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.util.List list36 = null;
        xYPlot26.drawRangeTickBands(graphics2D34, rectangle2D35, list36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot26.setRangeGridlineStroke(stroke38);
        xYPlot23.setDomainZeroBaselineStroke(stroke38);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder29);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis5.setTimeline(timeline7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        xYPlot9.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot16.getSeriesRenderingOrder();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setOutlineStroke(stroke20);
        boolean boolean22 = dateAxis14.hasListener((java.util.EventListener) xYPlot16);
        dateAxis14.setRange((double) '#', (double) 100L);
        dateAxis14.setUpperBound((double) (-1));
        java.lang.String str28 = dateAxis14.getLabelURL();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot29.markerChanged(markerChangeEvent30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot29.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        xYPlot29.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis34);
        java.awt.Paint paint36 = dateAxis34.getLabelPaint();
        dateAxis34.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis34.getTickUnit();
        java.util.Date date40 = dateAxis14.calculateHighestVisibleTickValue(dateTickUnit39);
        dateAxis5.setMinimumDate(date40);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(xYDataset10);
        xYPlot0.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot16.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        xYPlot16.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot23.setOutlineStroke(stroke27);
        boolean boolean29 = dateAxis21.hasListener((java.util.EventListener) xYPlot23);
        dateAxis21.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer33);
        java.awt.Paint paint35 = categoryPlot34.getRangeGridlinePaint();
        boolean boolean36 = categoryPlot34.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot34.getRowRenderingOrder();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent38 = null;
        categoryPlot34.axisChanged(axisChangeEvent38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot34.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(9, axisLocation40);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        dateAxis0.setRightArrow(shape7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange9, true, true);
        dateAxis0.setAutoRange(false);
        java.awt.Shape shape15 = dateAxis0.getLeftArrow();
        dateAxis0.setFixedAutoRange((double) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot20.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot20.setRenderer(categoryItemRenderer47);
        boolean boolean49 = categoryPlot20.isRangeCrosshairVisible();
        int int50 = categoryPlot20.getDatasetCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.ABSOLUTE", 192);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.awt.Color color9 = java.awt.Color.pink;
        java.awt.Color color11 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color11, stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryMarker13.getLabelOffset();
        boolean boolean15 = color9.equals((java.lang.Object) rectangleInsets14);
        double double16 = rectangleInsets14.getTop();
        dateAxis0.setLabelInsets(rectangleInsets14);
        boolean boolean18 = dateAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        xYPlot0.setOutlineVisible(true);
        boolean boolean14 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        java.lang.Object obj11 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot9.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot9.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot9.setRangeGridlineStroke(stroke21);
        xYPlot0.setRangeCrosshairStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker30.setLabelOffsetType(lengthAdjustmentType53);
        org.jfree.chart.util.Layer layer55 = null;
        boolean boolean56 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer55);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation57 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        java.awt.Image image23 = xYPlot20.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot20.getRangeAxis();
        java.awt.Color color26 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color26, stroke27);
        java.awt.Paint paint29 = categoryMarker28.getLabelPaint();
        xYPlot20.setDomainGridlinePaint(paint29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot20.setOutlinePaint((java.awt.Paint) color31);
        int int33 = color31.getBlue();
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder35);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        java.text.DateFormat dateFormat39 = null;
        dateAxis37.setDateFormatOverride(dateFormat39);
        org.jfree.chart.axis.Timeline timeline41 = null;
        dateAxis37.setTimeline(timeline41);
        dateAxis37.setPositiveArrowVisible(false);
        boolean boolean45 = seriesRenderingOrder35.equals((java.lang.Object) dateAxis37);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition46 = null;
        try {
            dateAxis37.setTickMarkPosition(dateTickMarkPosition46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke5, stroke6, stroke7, stroke8, stroke9 };
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke11, stroke12 };
        java.awt.Shape[] shapeArray14 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray4, strokeArray10, strokeArray13, shapeArray14);
        java.lang.Class<?> wildcardClass16 = paintArray3.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        try {
            java.util.EventListener[] eventListenerArray19 = valueMarker1.getListeners(class17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Millisecond; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        dateAxis0.zoomRange(2.0d, 35.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 8, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
//        xYPlot0.markerChanged(markerChangeEvent1);
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
//        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
//        boolean boolean8 = dateAxis5.isTickLabelsVisible();
//        dateAxis5.setAutoRange(false);
//        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis5.setTickLabelFont(font11);
//        java.awt.Paint paint13 = dateAxis5.getAxisLinePaint();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        long long16 = day14.getSerialIndex();
//        java.util.Date date17 = day14.getEnd();
//        dateAxis5.setMaximumDate(date17);
//        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
//        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
//        xYPlot21.markerChanged(markerChangeEvent22);
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
//        xYPlot21.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis26);
//        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
//        xYPlot28.markerChanged(markerChangeEvent29);
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = xYPlot28.getSeriesRenderingOrder();
//        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        xYPlot28.setOutlineStroke(stroke32);
//        boolean boolean34 = dateAxis26.hasListener((java.util.EventListener) xYPlot28);
//        dateAxis26.setRange((double) '#', (double) 100L);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer38);
//        java.awt.Paint paint40 = categoryPlot39.getRangeGridlinePaint();
//        boolean boolean41 = categoryPlot39.isDomainZoomable();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
//        categoryPlot39.setRenderer(1, categoryItemRenderer43);
//        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
//        categoryPlot39.setFixedDomainAxisSpace(axisSpace45, false);
//        java.awt.Stroke stroke48 = categoryPlot39.getRangeGridlineStroke();
//        dateAxis5.setAxisLineStroke(stroke48);
//        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(font11);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
//        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
//        org.junit.Assert.assertNotNull(stroke32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(stroke48);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot14.getSeriesRenderingOrder();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setOutlineStroke(stroke18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot14.getDomainMarkers(100, layer21);
        dateAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot14);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        xYPlot14.drawAnnotations(graphics2D24, rectangle2D25, plotRenderingInfo26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.awt.Color color9 = java.awt.Color.pink;
        java.awt.Color color11 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color11, stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryMarker13.getLabelOffset();
        boolean boolean15 = color9.equals((java.lang.Object) rectangleInsets14);
        double double16 = rectangleInsets14.getTop();
        dateAxis0.setLabelInsets(rectangleInsets14);
        dateAxis0.zoomRange(0.0d, (double) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        int int29 = xYPlot0.getSeriesCount();
        java.lang.String str30 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        categoryPlot20.addDomainMarker(categoryMarker30);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent56 = null;
        xYPlot55.markerChanged(markerChangeEvent56);
        java.awt.Image image58 = xYPlot55.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis59 = xYPlot55.getRangeAxis();
        java.awt.Color color61 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color61, stroke62);
        java.awt.Paint paint64 = categoryMarker63.getLabelPaint();
        xYPlot55.setDomainGridlinePaint(paint64);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot55.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis();
        dateAxis67.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape71 = dateAxis67.getLeftArrow();
        boolean boolean72 = axisLocation66.equals((java.lang.Object) dateAxis67);
        org.jfree.chart.axis.AxisLocation axisLocation73 = axisLocation66.getOpposite();
        categoryPlot20.setRangeAxisLocation((int) (byte) 10, axisLocation66, true);
        org.jfree.chart.axis.AxisLocation axisLocation76 = axisLocation66.getOpposite();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(image58);
        org.junit.Assert.assertNull(valueAxis59);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(axisLocation73);
        org.junit.Assert.assertNotNull(axisLocation76);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot20.setRenderer(1, categoryItemRenderer24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace26, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot20.setRenderer(categoryItemRenderer29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        categoryPlot20.setDataset((int) (short) 1, categoryDataset32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        boolean boolean9 = dateAxis0.isTickLabelsVisible();
        java.awt.Font font10 = dateAxis0.getTickLabelFont();
        dateAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.text.DateFormat dateFormat2 = null;
        dateAxis0.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        xYPlot6.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint13 = dateAxis11.getLabelPaint();
        boolean boolean14 = dateAxis11.isTickLabelsVisible();
        dateAxis11.setAutoRange(false);
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis11.setTickLabelFont(font17);
        boolean boolean19 = dateAxis0.equals((java.lang.Object) dateAxis11);
        boolean boolean20 = dateAxis0.isTickMarksVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.extendHeight(0.0d);
        double double4 = rectangleInsets0.trimHeight((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 94.0d + "'", double4 == 94.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        dateAxis5.setAutoRange(false);
        double double11 = dateAxis5.getLowerBound();
        java.awt.Shape shape12 = dateAxis5.getUpArrow();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        java.awt.Image image4 = xYPlot1.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot1.getRangeAxis();
        java.awt.Color color7 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color7, stroke8);
        java.awt.Paint paint10 = categoryMarker9.getLabelPaint();
        xYPlot1.setDomainGridlinePaint(paint10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot1.setOutlinePaint((java.awt.Paint) color12);
        int int14 = color12.getBlue();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = xYPlot17.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        xYPlot17.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot24.setOutlineStroke(stroke28);
        boolean boolean30 = dateAxis22.hasListener((java.util.EventListener) xYPlot24);
        dateAxis22.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer34);
        java.awt.Paint paint36 = categoryPlot35.getRangeGridlinePaint();
        boolean boolean37 = categoryPlot35.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot35.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        java.util.List list40 = categoryPlot35.getCategoriesForAxis(categoryAxis39);
        java.awt.Stroke stroke41 = categoryPlot35.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color12, stroke41);
        java.awt.Paint paint43 = categoryMarker42.getPaint();
        boolean boolean44 = categoryMarker42.getDrawAsLine();
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape16 = dateAxis12.getLeftArrow();
        boolean boolean17 = axisLocation11.equals((java.lang.Object) dateAxis12);
        boolean boolean18 = dateAxis12.isVisible();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getDomainMarkers(layer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace25);
        categoryPlot20.clearRangeAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot20.getRangeMarkers(layer45);
        categoryPlot20.configureDomainAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot20.getFixedLegendItems();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(legendItemCollection34);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = rectangleAnchor1.equals((java.lang.Object) color2);
        java.lang.String str4 = rectangleAnchor1.toString();
        try {
            java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.LEFT" + "'", str4.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        java.lang.String str20 = dateAxis6.getLabelURL();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        xYPlot21.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Paint paint28 = dateAxis26.getLabelPaint();
        dateAxis26.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis26.getTickUnit();
        java.util.Date date32 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit31);
        java.lang.String str33 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) date32);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        xYPlot37.markerChanged(markerChangeEvent38);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder40 = xYPlot37.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        xYPlot37.setDomainAxisLocation((int) (short) 10, axisLocation42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot37.getRangeAxisEdge(7);
        try {
            double double46 = categoryAxis0.getCategoryEnd(11, 500, rectangle2D36, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder40);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        java.lang.String str20 = dateAxis6.getLabelURL();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        xYPlot21.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Paint paint28 = dateAxis26.getLabelPaint();
        dateAxis26.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis26.getTickUnit();
        java.util.Date date32 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit31);
        java.lang.String str33 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) date32);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        xYPlot39.markerChanged(markerChangeEvent40);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder42 = xYPlot39.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        xYPlot39.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis44);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        xYPlot46.markerChanged(markerChangeEvent47);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder49 = xYPlot46.getSeriesRenderingOrder();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot46.setOutlineStroke(stroke50);
        boolean boolean52 = dateAxis44.hasListener((java.util.EventListener) xYPlot46);
        dateAxis44.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer56);
        java.awt.Paint paint58 = categoryPlot57.getRangeGridlinePaint();
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot57.setRangeGridlineStroke(stroke59);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent62 = null;
        xYPlot61.markerChanged(markerChangeEvent62);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder64 = xYPlot61.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        xYPlot61.drawAnnotations(graphics2D65, rectangle2D66, plotRenderingInfo67);
        java.awt.Graphics2D graphics2D69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.util.List list71 = null;
        xYPlot61.drawRangeTickBands(graphics2D69, rectangle2D70, list71);
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot61.setRangeGridlineStroke(stroke73);
        categoryPlot57.setRangeGridlineStroke(stroke73);
        org.jfree.chart.axis.AxisLocation axisLocation76 = categoryPlot57.getRangeAxisLocation();
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot57.setDomainGridlinePaint((java.awt.Paint) color77);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot57.setRangeAxisLocation(axisLocation79, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = categoryPlot57.getDomainAxisEdge((int) (byte) 0);
        try {
            double double84 = categoryAxis0.getCategoryEnd((-16777216), 3, rectangle2D36, rectangleEdge83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder42);
        org.junit.Assert.assertNotNull(seriesRenderingOrder49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(seriesRenderingOrder64);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(rectangleEdge83);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.5f, (float) 1L, (float) 10L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        boolean boolean20 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        double double23 = dateAxis21.getUpperBound();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer24);
        boolean boolean26 = xYPlot25.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot25.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = null;
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor31);
        xYPlot25.zoomDomainAxes((-5.0d), plotRenderingInfo29, point2D32, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(valueAxis27);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot24.render(graphics2D38, rectangle2D39, 0, plotRenderingInfo41, crosshairState42);
        boolean boolean44 = xYPlot24.isRangeCrosshairVisible();
        java.awt.Color color47 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color47, stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = xYPlot24.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker49, layer51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer54);
        categoryPlot20.setAnchorValue((-6.0d));
        categoryPlot20.configureRangeAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        double double6 = rectangleInsets4.trimHeight(0.0d);
        java.lang.String str7 = rectangleInsets4.toString();
        double double9 = rectangleInsets4.calculateTopInset((double) 1560409200000L);
        double double11 = rectangleInsets4.calculateLeftOutset((double) 7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.0d) + "'", double6 == (-6.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str7.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.Timeline timeline9 = dateAxis0.getTimeline();
        double double10 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(timeline9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot20.getRangeAxis(11);
        org.jfree.chart.plot.Plot plot33 = categoryPlot20.getParent();
        categoryPlot20.clearRangeAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNull(plot33);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = categoryMarker11.getLabelPaint();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        categoryMarker11.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot15.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot15.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        double double33 = rectangleInsets31.trimHeight(0.0d);
        xYPlot15.setAxisOffset(rectangleInsets31);
        categoryMarker11.setLabelOffset(rectangleInsets31);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker11, layer36, true);
        float float39 = categoryMarker11.getAlpha();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-6.0d) + "'", double33 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setPositiveArrowVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        xYPlot5.drawAnnotations(graphics2D9, rectangle2D10, plotRenderingInfo11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot5.drawRangeTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke17);
        org.jfree.chart.plot.Plot plot19 = xYPlot5.getRootPlot();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot5.getDomainAxisEdge(6);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        java.awt.Color color6 = java.awt.Color.gray;
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        xYPlot13.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setOutlineStroke(stroke24);
        boolean boolean26 = dateAxis18.hasListener((java.util.EventListener) xYPlot20);
        dateAxis18.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer30);
        java.awt.Paint paint32 = categoryPlot31.getRangeGridlinePaint();
        java.awt.Color color35 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color35, stroke36);
        java.awt.Paint paint38 = categoryMarker37.getLabelPaint();
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot31.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker37, layer39);
        boolean boolean41 = categoryPlot31.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot31.getRangeAxis(11);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot31.setRangeAxisLocation(axisLocation44, false);
        boolean boolean47 = intervalMarker10.equals((java.lang.Object) false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer48 = intervalMarker10.getGradientPaintTransformer();
        java.awt.Stroke stroke49 = intervalMarker10.getOutlineStroke();
        java.awt.Color color51 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color51, stroke52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = categoryMarker53.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent56 = null;
        xYPlot55.markerChanged(markerChangeEvent56);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder58 = xYPlot55.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
        xYPlot55.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis60);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder62 = xYPlot55.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = null;
        xYPlot63.markerChanged(markerChangeEvent64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        xYPlot63.zoomDomainAxes((double) 0, plotRenderingInfo67, point2D68, false);
        java.awt.Color color71 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot63.setDomainCrosshairPaint((java.awt.Paint) color71);
        xYPlot55.setRangeGridlinePaint((java.awt.Paint) color71);
        categoryMarker53.setPaint((java.awt.Paint) color71);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = categoryMarker53.getLabelOffset();
        double double77 = rectangleInsets75.calculateRightInset((double) 43629L);
        intervalMarker10.setLabelOffset(rectangleInsets75);
        dateAxis0.setLabelInsets(rectangleInsets75);
        double double80 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(seriesRenderingOrder58);
        org.junit.Assert.assertNotNull(datasetRenderingOrder62);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 3.0d + "'", double77 == 3.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        xYPlot8.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot15.setOutlineStroke(stroke19);
        boolean boolean21 = dateAxis13.hasListener((java.util.EventListener) xYPlot15);
        dateAxis13.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeGridlinePaint();
        categoryPlot26.setWeight((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot26.setDataset(2019, categoryDataset31);
        java.awt.Color color35 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color35, stroke36);
        java.awt.Paint paint38 = categoryMarker37.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        xYPlot39.markerChanged(markerChangeEvent40);
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = null;
        xYPlot42.markerChanged(markerChangeEvent43);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = xYPlot42.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot42.drawAnnotations(graphics2D46, rectangle2D47, plotRenderingInfo48);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.util.List list52 = null;
        xYPlot42.drawRangeTickBands(graphics2D50, rectangle2D51, list52);
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot42.setRangeGridlineStroke(stroke54);
        xYPlot39.setDomainZeroBaselineStroke(stroke54);
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot39.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker60, layer61, true);
        categoryPlot26.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker37, layer61, false);
        java.util.Collection collection66 = xYPlot0.getDomainMarkers(layer61);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNull(collection66);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.util.TimeZone timeZone7 = dateAxis5.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        dateAxis8.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Stroke stroke13 = dateAxis8.getAxisLineStroke();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis8.getTickMarkPosition();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis8.setAxisLineStroke(stroke15);
        dateAxis5.setAxisLineStroke(stroke15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = xYPlot18.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        xYPlot18.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        xYPlot25.markerChanged(markerChangeEvent26);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = xYPlot25.getSeriesRenderingOrder();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot25.setOutlineStroke(stroke29);
        boolean boolean31 = dateAxis23.hasListener((java.util.EventListener) xYPlot25);
        dateAxis23.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer35);
        java.awt.Paint paint37 = categoryPlot36.getRangeGridlinePaint();
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot36.setRangeGridlineStroke(stroke38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = xYPlot40.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        xYPlot40.drawAnnotations(graphics2D44, rectangle2D45, plotRenderingInfo46);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.util.List list50 = null;
        xYPlot40.drawRangeTickBands(graphics2D48, rectangle2D49, list50);
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot40.setRangeGridlineStroke(stroke52);
        categoryPlot36.setRangeGridlineStroke(stroke52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot36.getRangeAxisLocation();
        java.awt.Stroke stroke56 = categoryPlot36.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker(16.0d, (java.awt.Paint) color15, stroke56);
        boolean boolean58 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker57);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(seriesRenderingOrder43);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = chartChangeEvent15.getType();
        org.jfree.chart.JFreeChart jFreeChart17 = chartChangeEvent15.getChart();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNull(jFreeChart17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape5);
        dateAxis0.setRangeAboutValue((double) 6, (double) 2);
        dateAxis0.setFixedAutoRange((double) 0.0f);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        dateAxis5.setAutoRange(false);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setTickLabelFont(font11);
        boolean boolean13 = dateAxis5.isTickMarksVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Stroke stroke5 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis0.getTickMarkPosition();
        float float7 = dateAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Paint paint3 = dateAxis1.getAxisLinePaint();
        dateAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot6.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot6.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot6.setRangeGridlineStroke(stroke18);
        org.jfree.chart.plot.Plot plot20 = xYPlot6.getRootPlot();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        xYPlot22.markerChanged(markerChangeEvent23);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder25 = xYPlot22.getSeriesRenderingOrder();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setOutlineStroke(stroke26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot22.getDomainMarkers(100, layer29);
        java.awt.Paint paint31 = xYPlot22.getDomainCrosshairPaint();
        xYPlot6.setDomainZeroBaselinePaint(paint31);
        boolean boolean33 = unitType0.equals((java.lang.Object) paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, (double) (-1L), 94.0d, 17.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot20.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot20.setRenderer(categoryItemRenderer47);
        int int49 = categoryPlot20.getDatasetCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        xYPlot0.clearDomainMarkers();
        java.awt.Color color23 = java.awt.Color.pink;
        java.awt.Color color25 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryMarker27.getLabelOffset();
        boolean boolean29 = color23.equals((java.lang.Object) rectangleInsets28);
        double double30 = rectangleInsets28.getTop();
        xYPlot0.setAxisOffset(rectangleInsets28);
        double double32 = rectangleInsets28.getTop();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        int int34 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace35, true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        dateAxis0.setRightArrow(shape11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        dateAxis0.setDownArrow(shape14);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Paint paint20 = xYPlot0.getDomainTickBandPaint();
        int int21 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(10, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        categoryPlot20.drawBackgroundImage(graphics2D26, rectangle2D27);
        categoryPlot20.setAnchorValue((double) 100);
        java.awt.Color color31 = java.awt.Color.black;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = categoryMarker11.getLabelPaint();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        categoryMarker11.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot15.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot15.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        double double33 = rectangleInsets31.trimHeight(0.0d);
        xYPlot15.setAxisOffset(rectangleInsets31);
        categoryMarker11.setLabelOffset(rectangleInsets31);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker11, layer36, true);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        xYPlot41.markerChanged(markerChangeEvent42);
        java.awt.Image image44 = xYPlot41.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot41.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        int int47 = xYPlot41.getIndexOf(xYItemRenderer46);
        org.jfree.data.general.DatasetGroup datasetGroup48 = xYPlot41.getDatasetGroup();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot41);
        xYPlot0.notifyListeners(plotChangeEvent49);
        org.jfree.chart.JFreeChart jFreeChart51 = null;
        plotChangeEvent49.setChart(jFreeChart51);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-6.0d) + "'", double33 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(image44);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(datasetGroup48);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        java.awt.Paint paint29 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke30 = xYPlot0.getRangeCrosshairStroke();
        java.awt.Font font31 = null;
        try {
            xYPlot0.setNoDataMessageFont(font31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        numberAxis1.configure();
        boolean boolean11 = numberAxis1.getAutoRangeStickyZero();
        java.lang.Object obj12 = numberAxis1.clone();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis1.setMarkerBand(markerAxisBand13);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke9, stroke10, stroke11, stroke12, stroke13 };
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke15, stroke16 };
        java.awt.Shape[] shapeArray18 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray7, paintArray8, strokeArray14, strokeArray17, shapeArray18);
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextOutlinePaint();
        java.awt.Stroke stroke21 = defaultDrawingSupplier19.getNextStroke();
        java.awt.Paint paint22 = defaultDrawingSupplier19.getNextPaint();
        xYPlot0.setRangeTickBandPaint(paint22);
        java.awt.Image image24 = null;
        xYPlot0.setBackgroundImage(image24);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        org.jfree.data.Range range12 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot4.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot4.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot4.setRangeGridlineStroke(stroke16);
        xYPlot1.setDomainZeroBaselineStroke(stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot1.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        intervalMarker22.setLabelAnchor(rectangleAnchor26);
        try {
            java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot20.render(graphics2D21, rectangle2D22, 1, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        boolean boolean30 = categoryPlot20.render(graphics2D26, rectangle2D27, (int) (short) 1, plotRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(categoryItemRenderer31);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation33 = null;
        try {
            categoryPlot20.addAnnotation(categoryAnnotation33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot20.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.plot.Plot plot14 = xYPlot0.getRootPlot();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        java.lang.Object obj18 = xYPlot15.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot15.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot15.getDataset(100);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryMarker26.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        xYPlot28.markerChanged(markerChangeEvent29);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = xYPlot28.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        xYPlot28.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = xYPlot28.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        xYPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        xYPlot36.zoomDomainAxes((double) 0, plotRenderingInfo40, point2D41, false);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot36.setDomainCrosshairPaint((java.awt.Paint) color44);
        xYPlot28.setRangeGridlinePaint((java.awt.Paint) color44);
        categoryMarker26.setPaint((java.awt.Paint) color44);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryMarker26.getLabelOffset();
        org.jfree.chart.util.Layer layer49 = null;
        boolean boolean51 = xYPlot15.removeRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker26, layer49, true);
        xYPlot15.setBackgroundAlpha((float) (-14336));
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = xYPlot15.getOrientation();
        xYPlot0.setOrientation(plotOrientation54);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(plotOrientation54);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        xYPlot0.clearDomainMarkers();
        int int23 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        xYPlot0.setDomainAxis(100, valueAxis25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        numberAxis1.setRangeWithMargins((-6.0d), 4.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot24.setDomainAxisLocation((int) (short) 10, axisLocation29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot24.getRangeAxisEdge(7);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot33.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo36, point2D37);
        boolean boolean39 = xYPlot33.isDomainGridlinesVisible();
        java.awt.Color color40 = java.awt.Color.BLACK;
        xYPlot33.setDomainCrosshairPaint((java.awt.Paint) color40);
        xYPlot24.setDomainZeroBaselinePaint((java.awt.Paint) color40);
        boolean boolean43 = sortOrder23.equals((java.lang.Object) xYPlot24);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        xYPlot45.markerChanged(markerChangeEvent46);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        xYPlot48.markerChanged(markerChangeEvent49);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder51 = xYPlot48.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        xYPlot48.drawAnnotations(graphics2D52, rectangle2D53, plotRenderingInfo54);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.util.List list58 = null;
        xYPlot48.drawRangeTickBands(graphics2D56, rectangle2D57, list58);
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot48.setRangeGridlineStroke(stroke60);
        xYPlot45.setDomainZeroBaselineStroke(stroke60);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer67 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot45.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker66, layer67, true);
        java.util.Collection collection70 = xYPlot24.getDomainMarkers((-16777216), layer67);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder51);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(layer67);
        org.junit.Assert.assertNull(collection70);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        boolean boolean23 = categoryPlot20.isRangeCrosshairVisible();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setDomainGridlineStroke(stroke24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace26, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        categoryPlot20.addDomainMarker(categoryMarker30);
        categoryPlot20.setAnchorValue(0.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot20.getRenderer();
        org.jfree.chart.plot.Marker marker34 = null;
        boolean boolean35 = categoryPlot20.removeDomainMarker(marker34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace4 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape9 = dateAxis5.getLeftArrow();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setLowerMargin(0.0d);
        numberAxis1.resizeRange(0.0d, 0.0d);
        java.lang.String str16 = numberAxis1.getLabelToolTip();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        xYPlot23.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        xYPlot30.markerChanged(markerChangeEvent31);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder33 = xYPlot30.getSeriesRenderingOrder();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot30.setOutlineStroke(stroke34);
        boolean boolean36 = dateAxis28.hasListener((java.util.EventListener) xYPlot30);
        dateAxis28.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer40);
        java.awt.Paint paint42 = categoryPlot41.getRangeGridlinePaint();
        categoryPlot41.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor48);
        categoryPlot41.zoomRangeAxes((double) 7, plotRenderingInfo46, point2D49, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray52 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot41.setRenderers(categoryItemRendererArray52);
        java.awt.Paint paint54 = categoryPlot41.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        try {
            org.jfree.chart.axis.AxisState axisState57 = numberAxis1.draw(graphics2D17, 0.0d, rectangle2D19, rectangle2D20, rectangleEdge55, plotRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(categoryItemRendererArray52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRendererForDataset(xYDataset7);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        xYPlot13.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setOutlineStroke(stroke24);
        boolean boolean26 = dateAxis18.hasListener((java.util.EventListener) xYPlot20);
        dateAxis18.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer30);
        java.awt.Paint paint32 = categoryPlot31.getRangeGridlinePaint();
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot31.setRangeGridlineStroke(stroke33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        xYPlot35.markerChanged(markerChangeEvent36);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder38 = xYPlot35.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        xYPlot35.drawAnnotations(graphics2D39, rectangle2D40, plotRenderingInfo41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.util.List list45 = null;
        xYPlot35.drawRangeTickBands(graphics2D43, rectangle2D44, list45);
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot35.setRangeGridlineStroke(stroke47);
        categoryPlot31.setRangeGridlineStroke(stroke47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot31.getRangeAxisLocation();
        java.awt.Stroke stroke51 = categoryPlot31.getDomainGridlineStroke();
        xYPlot0.setRangeGridlineStroke(stroke51);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        xYPlot0.zoom((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange16);
        int int18 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        dateAxis15.setFixedDimension(0.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        float float11 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot20.render(graphics2D21, rectangle2D22, 1, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        boolean boolean30 = categoryPlot20.render(graphics2D26, rectangle2D27, (int) (short) 1, plotRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot20.getIndexOf(categoryItemRenderer31);
        boolean boolean33 = categoryPlot20.isRangeCrosshairLockedOnData();
        java.awt.Paint paint34 = categoryPlot20.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeCrosshairStroke(stroke23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot24.render(graphics2D38, rectangle2D39, 0, plotRenderingInfo41, crosshairState42);
        boolean boolean44 = xYPlot24.isRangeCrosshairVisible();
        java.awt.Color color47 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color47, stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = xYPlot24.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker49, layer51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer54);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent56 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker49);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot20.setRenderer(1, categoryItemRenderer24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace26, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot20.setRenderer(categoryItemRenderer29);
        categoryPlot20.clearDomainMarkers((int) (byte) 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.Plot plot10 = xYPlot0.getParent();
        try {
            float float11 = plot10.getForegroundAlpha();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) unitType1);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        xYPlot8.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot8.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot16.zoomDomainAxes((double) 0, plotRenderingInfo20, point2D21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color24);
        xYPlot8.setRangeGridlinePaint((java.awt.Paint) color24);
        categoryMarker6.setPaint((java.awt.Paint) color24);
        boolean boolean28 = unitType1.equals((java.lang.Object) categoryMarker6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker6.setLabelOffsetType(lengthAdjustmentType29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker6.getLabelOffset();
        double double32 = rectangleInsets31.getTop();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        categoryPlot20.mapDatasetToRangeAxis(500, (int) (byte) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot20.setRenderer(10, categoryItemRenderer35, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot20.setDataset(10, categoryDataset24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis29.configure();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        java.awt.Paint paint33 = dateAxis31.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis31.getTickUnit();
        java.awt.Stroke stroke35 = dateAxis31.getTickMarkStroke();
        dateAxis31.setAutoRange(true);
        dateAxis31.setLowerMargin(16.0d);
        java.util.Date date40 = dateAxis31.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape42 = dateAxis41.getDownArrow();
        dateAxis31.setRightArrow(shape42);
        numberAxis29.setUpArrow(shape42);
        org.jfree.data.Range range45 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.lang.Object obj46 = numberAxis29.clone();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomDomainAxes(4.0d, (double) 2.0f, plotRenderingInfo7, point2D8);
        int int10 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        java.lang.String str20 = dateAxis6.getLabelURL();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        xYPlot21.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Paint paint28 = dateAxis26.getLabelPaint();
        dateAxis26.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis26.getTickUnit();
        java.util.Date date32 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit31);
        java.lang.String str33 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) date32);
        java.awt.Paint paint35 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 192);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot8.zoomDomainAxes((double) 0, plotRenderingInfo12, point2D13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot8.setDomainCrosshairPaint((java.awt.Paint) color16);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color16);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        float[] floatArray23 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray24 = color19.getColorComponents(floatArray23);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color19);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        xYPlot30.markerChanged(markerChangeEvent31);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder33 = xYPlot30.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        xYPlot30.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = null;
        xYPlot42.markerChanged(markerChangeEvent43);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = xYPlot42.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        xYPlot42.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot49.getSeriesRenderingOrder();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot49.setOutlineStroke(stroke53);
        boolean boolean55 = dateAxis47.hasListener((java.util.EventListener) xYPlot49);
        dateAxis47.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer59);
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        boolean boolean65 = categoryPlot60.render(graphics2D61, rectangle2D62, 1, plotRenderingInfo64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = null;
        java.awt.geom.Point2D point2D71 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D69, rectangleAnchor70);
        categoryPlot60.zoomRangeAxes((double) 7, (double) '4', plotRenderingInfo68, point2D71);
        xYPlot30.zoomRangeAxes((double) (short) 0, (double) 100.0f, plotRenderingInfo39, point2D71);
        xYPlot0.zoomRangeAxes((double) (byte) 100, (-5.0d), plotRenderingInfo29, point2D71);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        xYPlot0.setDomainAxis(0, valueAxis76, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(point2D71);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        categoryPlot20.clearAnnotations();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        xYPlot0.clearDomainMarkers();
        java.awt.Color color23 = java.awt.Color.pink;
        java.awt.Color color25 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryMarker27.getLabelOffset();
        boolean boolean29 = color23.equals((java.lang.Object) rectangleInsets28);
        double double30 = rectangleInsets28.getTop();
        xYPlot0.setAxisOffset(rectangleInsets28);
        double double33 = rectangleInsets28.trimHeight((double) 255);
        double double35 = rectangleInsets28.trimWidth((double) 1);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets28.createInsetRectangle(rectangle2D36, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 249.0d + "'", double33 == 249.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-5.0d) + "'", double35 == (-5.0d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.lang.Object obj7 = null;
        boolean boolean8 = numberAxis1.equals(obj7);
        numberAxis1.configure();
        java.awt.Paint paint10 = numberAxis1.getAxisLinePaint();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        xYPlot11.setDomainAxisLocation((int) (short) 10, axisLocation16);
        int int18 = xYPlot11.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot11.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        xYPlot20.drawAnnotations(graphics2D24, rectangle2D25, plotRenderingInfo26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.util.List list30 = null;
        xYPlot20.drawRangeTickBands(graphics2D28, rectangle2D29, list30);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot20.setRangeGridlineStroke(stroke32);
        xYPlot11.setRangeCrosshairStroke(stroke32);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType36 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean37 = lengthAdjustmentType35.equals((java.lang.Object) unitType36);
        java.awt.Color color39 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color39, stroke40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryMarker41.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        xYPlot43.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder46 = xYPlot43.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        xYPlot43.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = xYPlot43.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent52 = null;
        xYPlot51.markerChanged(markerChangeEvent52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        xYPlot51.zoomDomainAxes((double) 0, plotRenderingInfo55, point2D56, false);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot51.setDomainCrosshairPaint((java.awt.Paint) color59);
        xYPlot43.setRangeGridlinePaint((java.awt.Paint) color59);
        categoryMarker41.setPaint((java.awt.Paint) color59);
        boolean boolean63 = unitType36.equals((java.lang.Object) categoryMarker41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker41.setLabelOffsetType(lengthAdjustmentType64);
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean67 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker41, layer66);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        xYPlot11.setRenderer(3, xYItemRenderer69, true);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot11);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType35);
        org.junit.Assert.assertNotNull(unitType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(seriesRenderingOrder46);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        xYPlot5.drawAnnotations(graphics2D9, rectangle2D10, plotRenderingInfo11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot5.drawRangeTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke17);
        xYPlot0.setOutlineStroke(stroke17);
        float float20 = xYPlot0.getBackgroundImageAlpha();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        dateAxis0.setUpperMargin((double) (short) 10);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot4.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot4.getRenderer();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color14, stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryMarker16.getLabelOffset();
        boolean boolean18 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getLegendItems();
        xYPlot0.mapDatasetToRangeAxis(8, 9);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = xYPlot0.getRendererForDataset(xYDataset16);
        java.awt.Stroke stroke18 = xYPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot13.zoomDomainAxes((double) 0, plotRenderingInfo17, point2D18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color21);
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color21);
        categoryMarker3.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryMarker3.getLabelOffset();
        double double26 = rectangleInsets25.getTop();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            rectangleInsets25.trim(rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot5.setDomainAxisLocation((int) (short) 10, axisLocation10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot5.getFixedLegendItems();
        float float13 = xYPlot5.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot5.getDataset(1);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace16, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot5.getDomainAxisEdge();
        try {
            double double20 = categoryAxis0.getCategoryStart(2019, (int) (short) 100, rectangle2D4, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        boolean boolean10 = xYPlot0.isRangeCrosshairVisible();
        xYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = xYPlot0.getOrientation();
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot19.markerChanged(markerChangeEvent20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        xYPlot26.markerChanged(markerChangeEvent27);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder29 = xYPlot26.getSeriesRenderingOrder();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot26.setOutlineStroke(stroke30);
        boolean boolean32 = dateAxis24.hasListener((java.util.EventListener) xYPlot26);
        dateAxis24.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer36);
        java.awt.Paint paint38 = categoryPlot37.getRangeGridlinePaint();
        java.awt.Color color41 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color41, stroke42);
        java.awt.Paint paint44 = categoryMarker43.getLabelPaint();
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot37.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker43, layer45);
        boolean boolean47 = categoryPlot37.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis49 = categoryPlot37.getRangeAxis(11);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot37.setRangeAxisLocation(axisLocation50, false);
        boolean boolean53 = intervalMarker16.equals((java.lang.Object) false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer54 = intervalMarker16.getGradientPaintTransformer();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = intervalMarker16.getLabelAnchor();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker16);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer54);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        numberAxis1.configure();
        boolean boolean11 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Font font12 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke9, stroke10, stroke11, stroke12, stroke13 };
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke15, stroke16 };
        java.awt.Shape[] shapeArray18 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray7, paintArray8, strokeArray14, strokeArray17, shapeArray18);
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextOutlinePaint();
        java.awt.Stroke stroke21 = defaultDrawingSupplier19.getNextStroke();
        java.awt.Paint paint22 = defaultDrawingSupplier19.getNextPaint();
        xYPlot0.setRangeTickBandPaint(paint22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        xYPlot0.drawAnnotations(graphics2D24, rectangle2D25, plotRenderingInfo26);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        java.awt.Stroke stroke34 = categoryPlot20.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot20.getRenderer(10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(categoryItemRenderer36);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        categoryPlot20.addDomainMarker(categoryMarker30);
        categoryPlot20.setAnchorValue((-6.0d));
        java.awt.Paint paint56 = categoryPlot20.getRangeCrosshairPaint();
        categoryPlot20.configureDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder58 = categoryPlot20.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(datasetRenderingOrder58);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        java.util.List list25 = categoryPlot20.getCategoriesForAxis(categoryAxis24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace26);
        categoryPlot20.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot20.setRenderer(categoryItemRenderer29, true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getLegendItems();
        xYPlot0.mapDatasetToRangeAxis(8, 9);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setWeight((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot20.getRangeAxisLocation(1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace32);
        java.awt.Color color34 = java.awt.Color.BLACK;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color34);
        java.awt.Image image36 = null;
        categoryPlot20.setBackgroundImage(image36);
        boolean boolean38 = categoryPlot20.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot20.setRenderer((int) (byte) 100, categoryItemRenderer22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = categoryPlot20.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot20.getRangeAxisEdge((int) ' ');
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        double double21 = dateAxis7.getFixedAutoRange();
        try {
            dateAxis7.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot6.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot6.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot6.setRangeGridlineStroke(stroke18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.CrosshairState crosshairState24 = null;
        boolean boolean25 = xYPlot6.render(graphics2D20, rectangle2D21, 0, plotRenderingInfo23, crosshairState24);
        boolean boolean26 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color29, stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryMarker31.getLabelOffset();
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot6.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker31, layer33);
        java.awt.Paint paint35 = xYPlot6.getDomainGridlinePaint();
        xYPlot0.setRangeCrosshairPaint(paint35);
        java.awt.Paint paint37 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        dateAxis5.setAutoRange(false);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setTickLabelFont(font11);
        java.awt.Paint paint13 = dateAxis5.getAxisLinePaint();
        dateAxis5.setLabelURL("");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        java.lang.Object obj21 = xYPlot18.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot18.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot18.getDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot18.getDomainAxisEdge();
        try {
            double double26 = dateAxis5.java2DToValue((double) (-1L), rectangle2D17, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Stroke stroke40 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot20.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot20.setDomainAxis(10, categoryAxis44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace46, false);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace50 = categoryPlot20.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(legendItemCollection49);
        org.junit.Assert.assertNull(axisSpace50);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setLabelFont(font14);
        boolean boolean16 = dateAxis5.isInverted();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Color color3 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color3, stroke4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        xYPlot7.setDomainAxisLocation((int) (short) 10, axisLocation12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot14.zoomDomainAxes((double) 0, plotRenderingInfo18, point2D19, false);
        boolean boolean22 = xYPlot7.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        java.awt.Paint paint25 = dateAxis23.getAxisLinePaint();
        int int26 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        java.awt.Image image30 = xYPlot27.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot27.getRangeAxis();
        java.awt.Color color33 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color33, stroke34);
        java.awt.Paint paint36 = categoryMarker35.getLabelPaint();
        xYPlot27.setDomainGridlinePaint(paint36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot27.setOutlinePaint((java.awt.Paint) color38);
        int int40 = color38.getBlue();
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color38);
        java.awt.Color color42 = java.awt.Color.getColor("", color38);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        xYPlot43.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        xYPlot46.markerChanged(markerChangeEvent47);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder49 = xYPlot46.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        xYPlot46.drawAnnotations(graphics2D50, rectangle2D51, plotRenderingInfo52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        java.util.List list56 = null;
        xYPlot46.drawRangeTickBands(graphics2D54, rectangle2D55, list56);
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot46.setRangeGridlineStroke(stroke58);
        xYPlot43.setDomainZeroBaselineStroke(stroke58);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color42, stroke58, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(image30);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(seriesRenderingOrder49);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        xYPlot0.setForegroundAlpha(0.0f);
        xYPlot0.setBackgroundAlpha((float) 0L);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot0.getDomainMarkers(layer8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace10, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        boolean boolean11 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        double double12 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke13 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Paint paint14 = xYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        xYPlot25.markerChanged(markerChangeEvent26);
        java.awt.Image image28 = xYPlot25.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot25.getRangeAxis();
        java.awt.Color color31 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color31, stroke32);
        java.awt.Paint paint34 = categoryMarker33.getLabelPaint();
        xYPlot25.setDomainGridlinePaint(paint34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape41 = dateAxis37.getLeftArrow();
        boolean boolean42 = axisLocation36.equals((java.lang.Object) dateAxis37);
        categoryPlot20.setRangeAxisLocation((int) (short) 1, axisLocation36, true);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot20.getRangeAxisLocation((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot20.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(categoryAnchor47);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        categoryPlot20.zoomRangeAxes((double) 7, plotRenderingInfo25, point2D28, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray31);
        java.awt.Paint paint33 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setAnchorValue(94.0d, true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(10, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        categoryPlot20.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot20.getDataRange(valueAxis29);
        java.awt.Color color33 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color33, stroke34);
        java.awt.Paint paint36 = categoryMarker35.getLabelPaint();
        java.awt.Color color37 = java.awt.Color.ORANGE;
        categoryMarker35.setLabelPaint((java.awt.Paint) color37);
        java.awt.Stroke stroke39 = categoryMarker35.getStroke();
        java.awt.Font font40 = categoryMarker35.getLabelFont();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot20.removeRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker35, layer41);
        categoryPlot20.configureDomainAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot21.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo24, point2D25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder30 = xYPlot27.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot27.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.util.List list37 = null;
        xYPlot27.drawRangeTickBands(graphics2D35, rectangle2D36, list37);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot27.setRangeGridlineStroke(stroke39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = null;
        boolean boolean46 = xYPlot27.render(graphics2D41, rectangle2D42, 0, plotRenderingInfo44, crosshairState45);
        boolean boolean47 = xYPlot27.isRangeCrosshairVisible();
        java.awt.Color color50 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color50, stroke51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker52.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = xYPlot27.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker52, layer54);
        java.awt.Paint paint56 = xYPlot27.getDomainGridlinePaint();
        xYPlot21.setRangeCrosshairPaint(paint56);
        java.awt.Paint paint58 = xYPlot21.getRangeZeroBaselinePaint();
        categoryPlot20.setRangeCrosshairPaint(paint58);
        categoryPlot20.zoom(0.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setLowerMargin(0.0d);
        numberAxis1.setLabel("NO_CHANGE");
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot19.markerChanged(markerChangeEvent20);
        java.lang.Object obj22 = xYPlot19.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = xYPlot19.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot19.getDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot19.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            org.jfree.chart.axis.AxisState axisState28 = numberAxis1.draw(graphics2D15, 38.0d, rectangle2D17, rectangle2D18, rectangleEdge26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        categoryPlot20.setRangeCrosshairLockedOnData(false);
        categoryPlot20.setDrawSharedDomainAxis(false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot20.getRendererForDataset(categoryDataset27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNull(categoryItemRenderer28);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot20.setRenderer((int) (byte) 100, categoryItemRenderer22);
        int int24 = categoryPlot20.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        java.lang.String str20 = dateAxis6.getLabelURL();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        xYPlot21.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Paint paint28 = dateAxis26.getLabelPaint();
        dateAxis26.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis26.getTickUnit();
        java.util.Date date32 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit31);
        java.lang.String str33 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) date32);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0L, font35);
        int int37 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape4 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis0.getTickMarkPosition();
        dateAxis0.setUpperBound((double) (byte) 10);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = xYPlot0.getDatasetGroup();
        java.awt.Paint paint8 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Color color10 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color10, stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryMarker12.getLabelOffset();
        double double15 = rectangleInsets13.trimHeight(0.0d);
        java.lang.String str16 = rectangleInsets13.toString();
        xYPlot0.setInsets(rectangleInsets13, true);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-6.0d) + "'", double15 == (-6.0d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str16.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = xYPlot12.getSeriesRenderingOrder();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot12.setOutlineStroke(stroke16);
        boolean boolean18 = dateAxis10.hasListener((java.util.EventListener) xYPlot12);
        dateAxis10.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeGridlinePaint();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot23.setRangeGridlineStroke(stroke25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder30 = xYPlot27.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot27.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.util.List list37 = null;
        xYPlot27.drawRangeTickBands(graphics2D35, rectangle2D36, list37);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot27.setRangeGridlineStroke(stroke39);
        categoryPlot23.setRangeGridlineStroke(stroke39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot23.getRangeAxisLocation();
        java.awt.Stroke stroke43 = categoryPlot23.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(16.0d, (java.awt.Paint) color2, stroke43);
        valueMarker44.setValue((double) '#');
        boolean boolean47 = categoryAnchor0.equals((java.lang.Object) valueMarker44);
        try {
            valueMarker44.setAlpha((float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = dateAxis34.getDownArrow();
        java.awt.Paint paint36 = dateAxis34.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis34.getTickUnit();
        java.awt.Stroke stroke38 = dateAxis34.getTickMarkStroke();
        dateAxis34.setAutoRange(true);
        dateAxis34.setLowerMargin(16.0d);
        java.util.Date date43 = dateAxis34.getMinimumDate();
        java.util.Date date44 = dateAxis34.getMinimumDate();
        java.text.DateFormat dateFormat45 = dateAxis34.getDateFormatOverride();
        dateAxis34.resizeRange(35.0d, (double) 11);
        categoryPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(dateFormat45);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis0.setTimeline(timeline2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone4);
        try {
            dateAxis0.zoomRange((double) (short) -1, 2019.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        boolean boolean9 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot0.setRenderer(10, xYItemRenderer11, false);
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        xYPlot0.setRangeAxisLocation(15, axisLocation16);
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] { stroke21, stroke22, stroke23, stroke24, stroke25 };
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke27, stroke28 };
        java.awt.Shape[] shapeArray30 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray19, paintArray20, strokeArray26, strokeArray29, shapeArray30);
        java.awt.Paint paint32 = defaultDrawingSupplier31.getNextOutlinePaint();
        java.awt.Paint paint33 = defaultDrawingSupplier31.getNextPaint();
        xYPlot0.setRangeCrosshairPaint(paint33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot20.getRangeAxis(11);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation33, false);
        categoryPlot20.setWeight((int) (byte) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        categoryPlot20.setRenderer((int) (byte) 1, categoryItemRenderer39, false);
        java.awt.Paint paint42 = categoryPlot20.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace43);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.VERTICAL", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        boolean boolean23 = categoryPlot20.isRangeCrosshairVisible();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setDomainGridlineStroke(stroke24);
        double double26 = categoryPlot20.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        java.awt.Stroke stroke3 = dateAxis0.getAxisLineStroke();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.Range range5 = dateAxis0.getRange();
        dateAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot20.getRangeAxisLocation((-14336));
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.AxisState axisState29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        java.util.List list32 = numberAxis27.refreshTicks(graphics2D28, axisState29, rectangle2D30, rectangleEdge31);
        numberAxis27.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType36 = numberAxis27.getRangeType();
        org.jfree.data.RangeType rangeType37 = numberAxis27.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis27.setMarkerBand(markerAxisBand38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.AxisState axisState47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        java.util.List list50 = numberAxis45.refreshTicks(graphics2D46, axisState47, rectangle2D48, rectangleEdge49);
        numberAxis45.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType54 = numberAxis45.getRangeType();
        org.jfree.data.RangeType rangeType55 = numberAxis45.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis45.setMarkerBand(markerAxisBand56);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis41, numberAxis43, numberAxis45 };
        categoryPlot20.setRangeAxes(valueAxisArray58);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(rangeType36);
        org.junit.Assert.assertNotNull(rangeType37);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertNotNull(rangeType55);
        org.junit.Assert.assertNotNull(valueAxisArray58);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        xYPlot3.markerChanged(markerChangeEvent4);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = xYPlot3.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot3.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot3.setRangeGridlineStroke(stroke15);
        xYPlot0.setDomainZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        intervalMarker21.setLabelAnchor(rectangleAnchor25);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = null;
        intervalMarker21.setGradientPaintTransformer(gradientPaintTransformer27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot21.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo24, point2D25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder30 = xYPlot27.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot27.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.util.List list37 = null;
        xYPlot27.drawRangeTickBands(graphics2D35, rectangle2D36, list37);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot27.setRangeGridlineStroke(stroke39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = null;
        boolean boolean46 = xYPlot27.render(graphics2D41, rectangle2D42, 0, plotRenderingInfo44, crosshairState45);
        boolean boolean47 = xYPlot27.isRangeCrosshairVisible();
        java.awt.Color color50 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color50, stroke51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker52.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = xYPlot27.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker52, layer54);
        java.awt.Paint paint56 = xYPlot27.getDomainGridlinePaint();
        xYPlot21.setRangeCrosshairPaint(paint56);
        java.awt.Paint paint58 = xYPlot21.getRangeZeroBaselinePaint();
        categoryPlot20.setRangeCrosshairPaint(paint58);
        java.lang.String str60 = categoryPlot20.getNoDataMessage();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNull(str60);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        int int6 = xYPlot0.getWeight();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, (double) (byte) 0, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot20.render(graphics2D21, rectangle2D22, 1, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        boolean boolean30 = categoryPlot20.render(graphics2D26, rectangle2D27, (int) (short) 1, plotRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot20.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot20.setAxisOffset(rectangleInsets33);
        java.awt.Color color37 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color37, stroke38);
        java.awt.Paint paint40 = categoryMarker39.getLabelPaint();
        java.awt.Color color41 = java.awt.Color.ORANGE;
        categoryMarker39.setLabelPaint((java.awt.Paint) color41);
        java.awt.Stroke stroke43 = categoryMarker39.getStroke();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        xYPlot44.markerChanged(markerChangeEvent45);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        xYPlot47.markerChanged(markerChangeEvent48);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder50 = xYPlot47.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        xYPlot47.drawAnnotations(graphics2D51, rectangle2D52, plotRenderingInfo53);
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.util.List list57 = null;
        xYPlot47.drawRangeTickBands(graphics2D55, rectangle2D56, list57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot47.setRangeGridlineStroke(stroke59);
        xYPlot44.setDomainZeroBaselineStroke(stroke59);
        org.jfree.chart.plot.IntervalMarker intervalMarker65 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer66 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot44.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker65, layer66, true);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape70 = dateAxis69.getDownArrow();
        java.awt.Paint paint71 = dateAxis69.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit72 = dateAxis69.getTickUnit();
        dateAxis69.setVerticalTickLabels(false);
        boolean boolean75 = layer66.equals((java.lang.Object) dateAxis69);
        boolean boolean76 = categoryPlot20.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker39, layer66);
        java.awt.Stroke stroke77 = categoryPlot20.getDomainGridlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener78 = null;
        categoryPlot20.removeChangeListener(plotChangeListener78);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(seriesRenderingOrder50);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(layer66);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(dateTickUnit72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot20.setDataset(10, categoryDataset24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis29.configure();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        java.awt.Paint paint33 = dateAxis31.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis31.getTickUnit();
        java.awt.Stroke stroke35 = dateAxis31.getTickMarkStroke();
        dateAxis31.setAutoRange(true);
        dateAxis31.setLowerMargin(16.0d);
        java.util.Date date40 = dateAxis31.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape42 = dateAxis41.getDownArrow();
        dateAxis31.setRightArrow(shape42);
        numberAxis29.setUpArrow(shape42);
        org.jfree.data.Range range45 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis29);
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        categoryPlot20.setDomainAxisLocation(11, axisLocation47);
        categoryPlot20.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType42 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean43 = lengthAdjustmentType41.equals((java.lang.Object) unitType42);
        java.awt.Color color45 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color45, stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryMarker47.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot49.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        xYPlot49.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot49.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent58 = null;
        xYPlot57.markerChanged(markerChangeEvent58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        xYPlot57.zoomDomainAxes((double) 0, plotRenderingInfo61, point2D62, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot57.setDomainCrosshairPaint((java.awt.Paint) color65);
        xYPlot49.setRangeGridlinePaint((java.awt.Paint) color65);
        categoryMarker47.setPaint((java.awt.Paint) color65);
        boolean boolean69 = unitType42.equals((java.lang.Object) categoryMarker47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker47.setLabelOffsetType(lengthAdjustmentType70);
        org.jfree.chart.util.Layer layer72 = null;
        boolean boolean73 = categoryPlot20.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker47, layer72);
        int int74 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = categoryPlot20.getOrientation();
        java.awt.Stroke stroke76 = categoryPlot20.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        java.awt.Paint paint22 = dateAxis20.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        boolean boolean24 = dateAxis20.isInverted();
        java.util.TimeZone timeZone25 = dateAxis20.getTimeZone();
        java.awt.Color color26 = java.awt.Color.gray;
        dateAxis20.setLabelPaint((java.awt.Paint) color26);
        boolean boolean28 = dateAxis20.isAxisLineVisible();
        int int29 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        xYPlot39.markerChanged(markerChangeEvent40);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder42 = xYPlot39.getSeriesRenderingOrder();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot39.setOutlineStroke(stroke43);
        boolean boolean45 = dateAxis37.hasListener((java.util.EventListener) xYPlot39);
        dateAxis37.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer49);
        java.awt.Paint paint51 = categoryPlot50.getRangeGridlinePaint();
        dateAxis20.setPlot((org.jfree.chart.plot.Plot) categoryPlot50);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor53 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot50.setDomainGridlinePosition(categoryAnchor53);
        categoryPlot50.clearDomainMarkers(8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(seriesRenderingOrder42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(categoryAnchor53);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        boolean boolean23 = categoryPlot20.isRangeCrosshairVisible();
        java.awt.Paint paint24 = categoryPlot20.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = dateAxis26.getStandardTickUnits();
        double double28 = dateAxis26.getUpperBound();
        dateAxis26.setAutoRangeMinimumSize(3.0d);
        double double31 = dateAxis26.getFixedAutoRange();
        categoryPlot20.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis) dateAxis26, false);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRendererForDataset(xYDataset7);
        xYPlot0.setDomainZeroBaselineVisible(true);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot20.getRangeAxis(11);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation33, false);
        categoryPlot20.setWeight((int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot20.setDataset((int) 'a', categoryDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot20.getRangeAxisEdge((int) ' ');
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        boolean boolean47 = categoryPlot20.render(graphics2D43, rectangle2D44, 0, plotRenderingInfo46);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        java.awt.Image image9 = xYPlot6.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot6.getRangeAxis();
        java.awt.Color color12 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color12, stroke13);
        java.awt.Paint paint15 = categoryMarker14.getLabelPaint();
        xYPlot6.setDomainGridlinePaint(paint15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot6.setOutlinePaint((java.awt.Paint) color17);
        int int19 = color17.getBlue();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        xYPlot22.markerChanged(markerChangeEvent23);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder25 = xYPlot22.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        xYPlot22.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot29.markerChanged(markerChangeEvent30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot29.getSeriesRenderingOrder();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot29.setOutlineStroke(stroke33);
        boolean boolean35 = dateAxis27.hasListener((java.util.EventListener) xYPlot29);
        dateAxis27.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeGridlinePaint();
        boolean boolean42 = categoryPlot40.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot40.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        java.util.List list45 = categoryPlot40.getCategoriesForAxis(categoryAxis44);
        java.awt.Stroke stroke46 = categoryPlot40.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color17, stroke46);
        categoryMarker3.setPaint((java.awt.Paint) color17);
        categoryMarker3.setDrawAsLine(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        int int34 = categoryPlot20.getRangeAxisCount();
        categoryPlot20.configureDomainAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        int int7 = xYPlot0.getSeriesCount();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setLabelFont(font14);
        double double16 = dateAxis5.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape21 = dateAxis17.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.configure();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        java.awt.Paint paint28 = dateAxis26.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis26.getTickUnit();
        java.awt.Stroke stroke30 = dateAxis26.getTickMarkStroke();
        dateAxis26.setAutoRange(true);
        dateAxis26.setLowerMargin(16.0d);
        java.util.Date date35 = dateAxis26.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = dateAxis36.getDownArrow();
        dateAxis26.setRightArrow(shape37);
        numberAxis24.setUpArrow(shape37);
        dateAxis17.setDownArrow(shape37);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape42 = dateAxis41.getDownArrow();
        java.awt.Paint paint43 = dateAxis41.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = dateAxis41.getTickUnit();
        java.awt.Stroke stroke45 = dateAxis41.getTickMarkStroke();
        dateAxis41.setAutoRange(true);
        org.jfree.data.Range range48 = dateAxis41.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape50 = dateAxis49.getDownArrow();
        java.awt.Paint paint51 = dateAxis49.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis49.getTickUnit();
        java.util.Date date53 = dateAxis41.calculateLowestVisibleTickValue(dateTickUnit52);
        java.util.Date date54 = dateAxis17.calculateHighestVisibleTickValue(dateTickUnit52);
        java.util.Date date55 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit52);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(dateTickUnit44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
    }
}

