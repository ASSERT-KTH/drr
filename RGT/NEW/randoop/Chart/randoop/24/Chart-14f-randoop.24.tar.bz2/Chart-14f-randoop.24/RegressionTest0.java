import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, (int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) ' ', 100.0d, (double) 10, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Comparable comparable0 = null;
        java.awt.Color color1 = java.awt.Color.lightGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint3 = null;
        java.awt.Color color5 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color5, stroke6);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker(comparable0, (java.awt.Paint) color1, stroke2, paint3, stroke6, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        try {
            categoryMarker3.setAlpha((float) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color0 = java.awt.Color.RED;
        float[] floatArray3 = new float[] { 1.0f, 'a' };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        java.lang.Class class5 = null;
        try {
            java.util.EventListener[] eventListenerArray6 = categoryMarker3.getListeners(class5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset1);
        java.lang.Object obj3 = datasetChangeEvent2.getSource();
        org.jfree.data.general.Dataset dataset4 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100L + "'", obj3.equals(100L));
        org.junit.Assert.assertNull(dataset4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = categoryMarker5.getLabelPaint();
        org.jfree.chart.util.Layer layer7 = null;
        try {
            xYPlot0.addDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker5, layer7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) (short) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        chartChangeEvent1.setChart(jFreeChart2);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxis(10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        try {
            xYPlot0.setRangeAxis((int) (short) -1, valueAxis6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = null;
        try {
            dateAxis0.setLeftArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.lang.Comparable comparable4 = null;
        try {
            categoryMarker3.setKey(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.0d + "'", double2 == 17.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) 10);
        java.lang.String str3 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D4, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str3.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            xYPlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        java.lang.Object obj14 = dateAxis5.clone();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            xYPlot0.drawBackground(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            xYPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getRangeAxisEdge();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) 10);
        java.lang.String str3 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets0.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str3.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        xYPlot11.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.axis.AxisState axisState20 = dateAxis0.draw(graphics2D7, (double) 11, rectangle2D9, rectangle2D10, rectangleEdge18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            boolean boolean31 = xYPlot0.removeAnnotation(xYAnnotation29, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        double double6 = rectangleInsets4.trimHeight(0.0d);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.0d) + "'", double6 == (-6.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxis(10);
        xYPlot0.setWeight(500);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        xYPlot0.setForegroundAlpha(0.0f);
        xYPlot0.setBackgroundAlpha((float) 0L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot0.handleClick((int) (byte) 10, 0, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=255,g=175,b=175]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=255,g=175,b=175]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        try {
            categoryMarker3.setLabelAnchor(rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            xYPlot0.setQuadrantPaint(7, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (7) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        try {
            dateAxis5.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setLabelFont(font14);
        org.jfree.data.Range range16 = null;
        try {
            dateAxis5.setRangeWithMargins(range16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color2 = java.awt.Color.PINK;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        xYPlot3.markerChanged(markerChangeEvent4);
        java.awt.Image image6 = xYPlot3.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot3.getRangeAxis();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot8.drawAnnotations(graphics2D12, rectangle2D13, plotRenderingInfo14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot8.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot8.setRangeGridlineStroke(stroke20);
        xYPlot3.setOutlineStroke(stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, (-1.0d), (java.awt.Paint) color2, stroke20, (java.awt.Paint) color23, stroke36, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        xYPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryMarker4.getLabelOffset();
        boolean boolean6 = color0.equals((java.lang.Object) rectangleInsets5);
        java.awt.Color color7 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot8.drawAnnotations(graphics2D12, rectangle2D13, plotRenderingInfo14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot8.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Color color21 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color21, stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryMarker23.getLabelOffset();
        double double26 = rectangleInsets24.trimHeight(0.0d);
        xYPlot8.setAxisOffset(rectangleInsets24);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot29.markerChanged(markerChangeEvent30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot29.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        xYPlot29.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot29.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace38 = dateAxis5.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) xYPlot8, rectangle2D28, rectangleEdge36, axisSpace37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-6.0d) + "'", double26 == (-6.0d));
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        xYPlot7.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot7.getRangeAxisEdge();
        try {
            double double15 = dateAxis0.lengthToJava2D((double) 10.0f, rectangle2D6, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Color color4 = java.awt.Color.PINK;
        boolean boolean5 = rectangleAnchor3.equals((java.lang.Object) color4);
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 11, 16.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Paint paint3 = dateAxis1.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        boolean boolean5 = dateAxis1.isInverted();
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date0, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        java.awt.Color color5 = java.awt.Color.ORANGE;
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        int int7 = color5.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-14336) + "'", int7 == (-14336));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        try {
            dateAxis0.setRangeWithMargins(1.0d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot0.handleClick((int) (byte) 10, (-14336), plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.lang.String str4 = seriesRenderingOrder3.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str4.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis0.setTimeline(timeline3);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        try {
            xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker11, layer12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(500, xYItemRenderer8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot0.getIndexOf(xYItemRenderer10);
        java.awt.Stroke stroke12 = xYPlot0.getDomainGridlineStroke();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color14, stroke15);
        java.awt.Paint paint17 = categoryMarker16.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor18 = categoryMarker16.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot19.markerChanged(markerChangeEvent20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = xYPlot19.getDatasetRenderingOrder();
        categoryMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot19);
        org.jfree.chart.util.Layer layer28 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer28);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        boolean boolean5 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot13.zoomDomainAxes((double) 0, plotRenderingInfo17, point2D18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color21);
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color21);
        categoryMarker3.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        try {
            categoryMarker3.setLabelAnchor(rectangleAnchor26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis5.setAxisLineStroke(stroke17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("13-June-2019");
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            categoryPlot20.handleClick((int) '#', 0, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        numberAxis1.configure();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        xYPlot15.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = numberAxis1.draw(graphics2D11, 1.0d, rectangle2D13, rectangle2D14, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        try {
            int int25 = categoryPlot20.getDomainAxisIndex(categoryAxis24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        java.lang.Object obj15 = defaultDrawingSupplier13.clone();
        try {
            java.awt.Shape shape16 = defaultDrawingSupplier13.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        try {
            categoryPlot20.setDomainAxisLocation(0, axisLocation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset(100);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryMarker11.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        xYPlot13.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot13.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomDomainAxes((double) 0, plotRenderingInfo25, point2D26, false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color29);
        xYPlot13.setRangeGridlinePaint((java.awt.Paint) color29);
        categoryMarker11.setPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryMarker11.getLabelOffset();
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = xYPlot0.removeRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker11, layer34, true);
        xYPlot0.setBackgroundAlpha((float) (-14336));
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = null;
        try {
            xYPlot0.setOrientation(plotOrientation39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) ' ');
        double double4 = rectangleInsets0.calculateLeftOutset((double) 0L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = null;
        try {
            categoryPlot20.setRangeAxes(valueAxisArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot20.render(graphics2D21, rectangle2D22, 1, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot20.draw(graphics2D26, rectangle2D27, point2D28, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextOutlinePaint();
        java.awt.Stroke stroke15 = defaultDrawingSupplier13.getNextStroke();
        java.lang.Object obj16 = defaultDrawingSupplier13.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        try {
            categoryMarker3.setAlpha((float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean12 = xYPlot0.removeAnnotation(xYAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = numberAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            xYPlot0.draw(graphics2D13, rectangle2D14, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            categoryPlot20.setDomainAxisLocation(axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        xYPlot5.drawAnnotations(graphics2D9, rectangle2D10, plotRenderingInfo11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot5.drawRangeTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke17);
        xYPlot0.setOutlineStroke(stroke17);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot0.getDataset();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYDataset20);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Color color4 = java.awt.Color.PINK;
        boolean boolean5 = rectangleAnchor3.equals((java.lang.Object) color4);
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) (-14336), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        try {
            categoryMarker1.setAlpha((float) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace10, true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        try {
            dateAxis0.setRange(1.0E-8d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        try {
            dateAxis5.setRange(4.0d, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange19, false, true);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        java.lang.Object obj30 = xYPlot27.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot27.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            org.jfree.chart.axis.AxisState axisState33 = dateAxis5.draw(graphics2D23, 0.0d, rectangle2D25, rectangle2D26, rectangleEdge31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        dateAxis0.setUpperMargin((double) (short) 10);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis10.getTickUnit();
        java.awt.Stroke stroke14 = dateAxis10.getTickMarkStroke();
        dateAxis10.setAutoRange(true);
        dateAxis10.setLowerMargin(16.0d);
        java.util.Date date19 = dateAxis10.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        java.awt.Paint paint22 = dateAxis20.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        java.awt.Stroke stroke24 = dateAxis20.getTickMarkStroke();
        dateAxis20.setAutoRange(true);
        dateAxis20.setLowerMargin(16.0d);
        java.util.Date date29 = dateAxis20.getMinimumDate();
        try {
            dateAxis0.setRange(date19, date29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.extendWidth((double) 2019);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2019.0d + "'", double3 == 2019.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextOutlinePaint();
        java.awt.Stroke stroke15 = defaultDrawingSupplier13.getNextStroke();
        try {
            java.awt.Shape shape16 = defaultDrawingSupplier13.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        dateAxis0.zoomRange((double) 1, (double) 11);
        dateAxis0.resizeRange((double) (short) -1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean2 = objectList0.equals((java.lang.Object) chartChangeEventType1);
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setLabel("java.awt.Color[r=255,g=175,b=175]");
        java.awt.Font font19 = dateAxis5.getLabelFont();
        dateAxis5.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Paint paint20 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke21 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        java.awt.Color color6 = java.awt.Color.gray;
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = dateAxis0.isAxisLineVisible();
        try {
            dateAxis0.zoomRange((double) '#', (double) (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (-14336.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        numberAxis1.configure();
        boolean boolean11 = numberAxis1.getAutoRangeStickyZero();
        try {
            numberAxis1.zoomRange(17.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (17.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        int int29 = xYPlot0.getSeriesCount();
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeGridlinePaint(paint30);
        xYPlot0.clearRangeMarkers((int) (short) 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryMarker4.getLabelOffset();
        boolean boolean6 = color0.equals((java.lang.Object) rectangleInsets5);
        double double7 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Stroke stroke5 = dateAxis0.getAxisLineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        xYPlot9.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot9.getRangeAxisEdge();
        try {
            java.util.List list17 = dateAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot21.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.util.List list31 = null;
        xYPlot21.drawRangeTickBands(graphics2D29, rectangle2D30, list31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot21.getRangeMarkers(0, layer34);
        boolean boolean36 = dateAxis7.hasListener((java.util.EventListener) xYPlot21);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        float float5 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.color.ColorSpace colorSpace4 = null;
        java.awt.Color color5 = java.awt.Color.ORANGE;
        float[] floatArray9 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray10 = color5.getColorComponents(floatArray9);
        try {
            float[] floatArray11 = color1.getColorComponents(colorSpace4, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        xYPlot28.markerChanged(markerChangeEvent29);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = xYPlot28.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        xYPlot28.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        xYPlot35.markerChanged(markerChangeEvent36);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder38 = xYPlot35.getSeriesRenderingOrder();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot35.setOutlineStroke(stroke39);
        boolean boolean41 = dateAxis33.hasListener((java.util.EventListener) xYPlot35);
        dateAxis33.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer45);
        categoryPlot46.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        categoryPlot46.zoomDomainAxes(16.0d, plotRenderingInfo50, point2D53, true);
        org.jfree.chart.plot.PlotState plotState56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            categoryPlot20.draw(graphics2D24, rectangle2D25, point2D53, plotState56, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(point2D53);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        dateAxis0.setRangeAboutValue(0.05d, (double) 1.0f);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            boolean boolean11 = xYPlot0.removeAnnotation(xYAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker12, layer13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        java.awt.Color color32 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color32, stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryMarker34.getLabelOffset();
        org.jfree.chart.util.Layer layer36 = null;
        try {
            categoryPlot20.addDomainMarker((int) (byte) 100, categoryMarker34, layer36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        try {
            categoryPlot20.setRenderer((int) (byte) -1, categoryItemRenderer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        java.awt.Paint paint7 = dateAxis5.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis5.getTickUnit();
        java.awt.Stroke stroke9 = dateAxis5.getTickMarkStroke();
        dateAxis5.setAutoRange(true);
        dateAxis5.setLowerMargin(16.0d);
        java.util.Date date14 = dateAxis5.getMinimumDate();
        java.util.Date date15 = dateAxis5.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        java.awt.Stroke stroke20 = dateAxis16.getTickMarkStroke();
        dateAxis16.setAutoRange(true);
        dateAxis16.setLowerMargin(16.0d);
        java.util.Date date25 = dateAxis16.getMinimumDate();
        try {
            dateAxis0.setRange(date15, date25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = xYPlot12.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        xYPlot12.setDomainAxisLocation((int) (short) 10, axisLocation17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot12.getRangeAxisEdge(7);
        try {
            double double21 = numberAxis1.lengthToJava2D((double) 255, rectangle2D11, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryMarker4.getLabelOffset();
        boolean boolean6 = color0.equals((java.lang.Object) rectangleInsets5);
        double double7 = rectangleInsets5.getTop();
        double double9 = rectangleInsets5.extendWidth((double) ' ');
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 38.0d + "'", double9 == 38.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        xYPlot0.clearDomainMarkers();
        int int10 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        java.awt.Image image9 = null;
        xYPlot0.setBackgroundImage(image9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        boolean boolean5 = categoryMarker3.getDrawAsLine();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        java.awt.Image image9 = xYPlot6.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot6.getRangeAxis();
        java.awt.Color color12 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color12, stroke13);
        java.awt.Paint paint15 = categoryMarker14.getLabelPaint();
        xYPlot6.setDomainGridlinePaint(paint15);
        categoryMarker3.setOutlinePaint(paint15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        dateAxis0.setRangeAboutValue((double) 43629L, (double) 3);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot13.zoomDomainAxes((double) 0, plotRenderingInfo17, point2D18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color21);
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color21);
        categoryMarker3.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryMarker3.getLabelOffset();
        double double26 = rectangleInsets25.getTop();
        double double28 = rectangleInsets25.calculateBottomInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getFixedLegendItems();
        float float8 = xYPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot0.getDataset(1);
        try {
            xYPlot0.setBackgroundImageAlpha((float) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        float[] floatArray4 = new float[] { 10 };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (byte) 100, 1, 3, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getFixedLegendItems();
        float float8 = xYPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot0.getDataset(1);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color12, stroke13);
        java.awt.Paint paint15 = categoryMarker14.getLabelPaint();
        java.lang.Object obj16 = categoryMarker14.clone();
        org.jfree.chart.util.Layer layer17 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker14, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxis(10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker3.getLabelTextAnchor();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis6.getStandardTickUnits();
        dateAxis6.setTickLabelsVisible(true);
        java.awt.Font font10 = dateAxis6.getTickLabelFont();
        categoryMarker3.setLabelFont(font10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        dateAxis5.setAutoRange(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot12.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo15, point2D16);
        boolean boolean18 = xYPlot12.isDomainGridlinesVisible();
        xYPlot12.setDomainCrosshairLockedOnData(true);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        xYPlot22.markerChanged(markerChangeEvent23);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder25 = xYPlot22.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        xYPlot22.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot22.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace31 = dateAxis5.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) xYPlot12, rectangle2D21, rectangleEdge29, axisSpace30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder25);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        java.awt.Image image4 = null;
        xYPlot0.setBackgroundImage(image4);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setFixedAutoRange((double) (byte) -1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        java.awt.Stroke stroke34 = categoryPlot20.getRangeCrosshairStroke();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot20.setDomainGridlineStroke(stroke35);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        java.awt.Paint paint29 = xYPlot0.getDomainGridlinePaint();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            xYPlot0.drawOutline(graphics2D30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot0.addChangeListener(plotChangeListener21);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            boolean boolean25 = xYPlot0.removeAnnotation(xYAnnotation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        java.awt.Paint paint29 = xYPlot0.getDomainGridlinePaint();
        boolean boolean30 = xYPlot0.isDomainZoomable();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation31 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        float[] floatArray6 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray7 = color2.getColorComponents(floatArray6);
        try {
            float[] floatArray8 = color1.getComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        double double22 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint24 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setPositiveArrowVisible(false);
        double double5 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNull(dateFormat1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot9.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot9.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot9.setRangeGridlineStroke(stroke21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot9.render(graphics2D23, rectangle2D24, 0, plotRenderingInfo26, crosshairState27);
        boolean boolean29 = xYPlot9.isRangeCrosshairVisible();
        java.awt.Color color32 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color32, stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryMarker34.getLabelOffset();
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = xYPlot9.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker34, layer36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = categoryMarker34.getLabelOffset();
        boolean boolean39 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape5);
        dateAxis0.setRangeAboutValue((double) 6, (double) 2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit10, false, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickUnit10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        try {
            categoryMarker3.setAlpha(2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryMarker25.getLabelOffset();
        double double31 = rectangleInsets29.trimWidth(0.0d);
        java.lang.String str32 = rectangleInsets29.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-6.0d) + "'", double31 == (-6.0d));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str32.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        java.lang.String str8 = datasetRenderingOrder7.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str8.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        xYPlot7.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot14.getSeriesRenderingOrder();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setOutlineStroke(stroke18);
        boolean boolean20 = dateAxis12.hasListener((java.util.EventListener) xYPlot14);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis12.setLabelFont(font21);
        dateAxis0.setLabelFont(font21);
        dateAxis0.setRangeWithMargins((double) 1.0f, (double) 255);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot9.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot9.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot9.setRangeGridlineStroke(stroke21);
        xYPlot0.setRangeCrosshairStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker30.setLabelOffsetType(lengthAdjustmentType53);
        org.jfree.chart.util.Layer layer55 = null;
        boolean boolean56 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer55);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation57 = null;
        try {
            boolean boolean58 = xYPlot0.removeAnnotation(xYAnnotation57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot20.getDatasetRenderingOrder();
        java.util.List list33 = categoryPlot20.getAnnotations();
        boolean boolean34 = categoryPlot20.isRangeGridlinesVisible();
        double double35 = categoryPlot20.getAnchorValue();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis6.setLabelFont(font15);
        dateAxis0.setTickLabelFont(font15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0);
        java.awt.Stroke stroke19 = null;
        try {
            dateAxis0.setTickMarkStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font15);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape5);
        dateAxis0.setRangeAboutValue((double) 6, (double) 2);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot11.zoomDomainAxes((double) 0, plotRenderingInfo15, point2D16, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19);
        xYPlot11.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        xYPlot23.drawAnnotations(graphics2D27, rectangle2D28, plotRenderingInfo29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.util.List list33 = null;
        xYPlot23.drawRangeTickBands(graphics2D31, rectangle2D32, list33);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot23.setRangeGridlineStroke(stroke35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.CrosshairState crosshairState41 = null;
        boolean boolean42 = xYPlot23.render(graphics2D37, rectangle2D38, 0, plotRenderingInfo40, crosshairState41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot23.getDomainAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace46 = dateAxis0.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) xYPlot11, rectangle2D22, rectangleEdge44, axisSpace45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int3 = java.awt.Color.HSBtoRGB((float) 10L, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-52) + "'", int3 == (-52));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        java.lang.Object obj10 = null;
        boolean boolean11 = color8.equals(obj10);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean9 = lengthAdjustmentType7.equals((java.lang.Object) unitType8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 1.0f, (double) (byte) 10, 0.0d, (double) ' ');
        numberAxis1.setTickLabelInsets(rectangleInsets14);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = null;
        try {
            xYPlot0.setOrientation(plotOrientation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis6.setLabelFont(font15);
        dateAxis0.setTickLabelFont(font15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0);
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(dateRange19);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace10, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryMarker4.getLabelAnchor();
        try {
            java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot8.zoomDomainAxes((double) 0, plotRenderingInfo12, point2D13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot8.setDomainCrosshairPaint((java.awt.Paint) color16);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color16);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        float[] floatArray23 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray24 = color19.getColorComponents(floatArray23);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot0.getInsets();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        boolean boolean2 = dateAxis0.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) unitType1);
        java.lang.String str3 = unitType1.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.ABSOLUTE" + "'", str3.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        xYPlot3.markerChanged(markerChangeEvent4);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = xYPlot3.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot3.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot3.setRangeGridlineStroke(stroke15);
        xYPlot0.setDomainZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        double double25 = intervalMarker21.getStartValue();
        intervalMarker21.setStartValue((double) '4');
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day2.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        xYPlot0.clearRangeMarkers(2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot8.zoomDomainAxes((double) 0, plotRenderingInfo12, point2D13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot8.setDomainCrosshairPaint((java.awt.Paint) color16);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color16);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        float[] floatArray23 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray24 = color19.getColorComponents(floatArray23);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color19);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot0.getRangeAxisLocation();
        xYPlot0.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone5);
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date0, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.awt.Stroke stroke10 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        xYPlot9.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot16.getSeriesRenderingOrder();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setOutlineStroke(stroke20);
        boolean boolean22 = dateAxis14.hasListener((java.util.EventListener) xYPlot16);
        dateAxis14.setRange((double) '#', (double) 100L);
        dateAxis14.setLabel("java.awt.Color[r=255,g=175,b=175]");
        java.awt.Font font28 = dateAxis14.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        java.awt.Paint paint31 = dateAxis29.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        java.awt.Stroke stroke33 = dateAxis29.getTickMarkStroke();
        dateAxis29.setAutoRange(true);
        dateAxis29.setLowerMargin(16.0d);
        java.util.Date date38 = dateAxis29.getMinimumDate();
        java.util.Date date39 = dateAxis29.getMinimumDate();
        dateAxis14.setMaximumDate(date39);
        dateAxis5.setMaximumDate(date39);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryMarker25.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent30.setType(chartChangeEventType31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot20.getRenderer();
        categoryPlot20.setOutlineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            categoryPlot20.handleClick((int) (short) 1, 2, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNull(categoryItemRenderer33);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.lang.Object obj2 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Stroke stroke40 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot20.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot20.setDomainAxis(10, categoryAxis44);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot20.getDataset(10);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(categoryDataset47);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(10, categoryItemRenderer25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        long long7 = day2.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = categoryMarker11.getLabelPaint();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        categoryMarker11.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot15.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot15.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        double double33 = rectangleInsets31.trimHeight(0.0d);
        xYPlot15.setAxisOffset(rectangleInsets31);
        categoryMarker11.setLabelOffset(rectangleInsets31);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker11, layer36, true);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot0.getRendererForDataset(xYDataset39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        xYPlot45.markerChanged(markerChangeEvent46);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder48 = xYPlot45.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        xYPlot45.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis50);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent53 = null;
        xYPlot52.markerChanged(markerChangeEvent53);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder55 = xYPlot52.getSeriesRenderingOrder();
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot52.setOutlineStroke(stroke56);
        boolean boolean58 = dateAxis50.hasListener((java.util.EventListener) xYPlot52);
        dateAxis50.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer62);
        categoryPlot63.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = null;
        java.awt.geom.Point2D point2D70 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D68, rectangleAnchor69);
        categoryPlot63.zoomDomainAxes(16.0d, plotRenderingInfo67, point2D70, true);
        org.jfree.chart.plot.PlotState plotState73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        try {
            xYPlot0.draw(graphics2D41, rectangle2D42, point2D70, plotState73, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-6.0d) + "'", double33 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(xYItemRenderer40);
        org.junit.Assert.assertNotNull(seriesRenderingOrder48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(point2D70);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        xYPlot8.clearDomainMarkers(255);
        boolean boolean17 = rectangleInsets0.equals((java.lang.Object) 255);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            rectangleInsets0.trim(rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        boolean boolean3 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        xYPlot4.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot11.setOutlineStroke(stroke15);
        boolean boolean17 = dateAxis9.hasListener((java.util.EventListener) xYPlot11);
        dateAxis9.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer23);
        int int25 = categoryPlot24.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.lang.Object obj7 = null;
        boolean boolean8 = numberAxis1.equals(obj7);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(numberFormat9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        dateAxis5.setUpperBound((double) ' ');
        boolean boolean10 = dateAxis5.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot20.getDomainAxis((int) '#');
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryAxis32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRendererForDataset(xYDataset7);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setOutlinePaint((java.awt.Paint) color11);
        int int13 = color11.getGreen();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getDomainMarkers(layer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot20.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        boolean boolean2 = dateAxis0.isAutoRange();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRendererForDataset(xYDataset7);
        int int9 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        boolean boolean11 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        double double12 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.Marker marker13 = null;
        try {
            boolean boolean14 = xYPlot0.removeRangeMarker(marker13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        java.text.NumberFormat numberFormat10 = numberAxis1.getNumberFormatOverride();
        java.lang.Object obj11 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        categoryPlot20.zoomRangeAxes((double) 7, plotRenderingInfo25, point2D28, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray31);
        java.awt.Paint paint33 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            categoryPlot20.drawOutline(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        boolean boolean10 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot0.getDomainAxisLocation((-52));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        java.util.Date date10 = dateAxis0.getMinimumDate();
        dateAxis0.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        java.util.Date date10 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.Plot plot23 = categoryPlot20.getRootPlot();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plot23);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryMarker3.getLabelAnchor();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = categoryMarker8.getLabelAnchor();
        categoryMarker3.setLabelAnchor(rectangleAnchor9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getDomainMarkers(layer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis27.getStandardTickUnits();
        dateAxis27.setTickLabelsVisible(true);
        java.awt.Font font31 = dateAxis27.getTickLabelFont();
        categoryPlot20.setNoDataMessageFont(font31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        java.awt.Shape shape3 = dateAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis6.setLabelFont(font15);
        dateAxis0.setTickLabelFont(font15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0);
        java.text.DateFormat dateFormat19 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(dateFormat19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand1);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        java.awt.Image image5 = xYPlot2.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot2.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        int int8 = xYPlot2.getIndexOf(xYItemRenderer7);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color11, stroke12);
        java.awt.Paint paint14 = categoryMarker13.getLabelPaint();
        java.awt.Color color15 = java.awt.Color.ORANGE;
        categoryMarker13.setLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = xYPlot17.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        xYPlot17.drawAnnotations(graphics2D21, rectangle2D22, plotRenderingInfo23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.util.List list27 = null;
        xYPlot17.drawRangeTickBands(graphics2D25, rectangle2D26, list27);
        java.awt.Color color30 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color30, stroke31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryMarker32.getLabelOffset();
        double double35 = rectangleInsets33.trimHeight(0.0d);
        xYPlot17.setAxisOffset(rectangleInsets33);
        categoryMarker13.setLabelOffset(rectangleInsets33);
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot2.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker13, layer38, true);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot2.getRendererForDataset(xYDataset41);
        boolean boolean43 = categoryMarker1.equals((java.lang.Object) xYDataset41);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-6.0d) + "'", double35 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        float[] floatArray11 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray12 = color7.getColorComponents(floatArray11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double15 = rectangleInsets13.extendHeight(0.0d);
        boolean boolean16 = color7.equals((java.lang.Object) rectangleInsets13);
        xYPlot0.setInsets(rectangleInsets13, true);
        double double20 = rectangleInsets13.extendHeight((double) 11);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.0d + "'", double15 == 6.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 17.0d + "'", double20 == 17.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        java.awt.Color color6 = java.awt.Color.gray;
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = dateAxis0.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            dateAxis0.setTickLabelInsets(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.Plot plot10 = xYPlot0.getParent();
        xYPlot0.mapDatasetToDomainAxis(1, 7);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot20.getRangeAxis(11);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation33, false);
        categoryPlot20.setWeight((int) (byte) -1);
        categoryPlot20.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        boolean boolean20 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        double double23 = dateAxis21.getUpperBound();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer24);
        boolean boolean26 = xYPlot25.isDomainZeroBaselineVisible();
        boolean boolean27 = xYPlot25.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot9.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot9.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot9.setRangeGridlineStroke(stroke21);
        xYPlot0.setRangeCrosshairStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker30.setLabelOffsetType(lengthAdjustmentType53);
        org.jfree.chart.util.Layer layer55 = null;
        boolean boolean56 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = xYPlot0.getInsets();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType10 = numberAxis1.getRangeType();
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis1.valueToJava2D((double) ' ', rectangle2D13, rectangleEdge14);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.util.TimeZone timeZone8 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor3, jFreeChart4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent5.getType();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        xYPlot7.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot14.getSeriesRenderingOrder();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setOutlineStroke(stroke18);
        boolean boolean20 = dateAxis12.hasListener((java.util.EventListener) xYPlot14);
        dateAxis12.setRange((double) '#', (double) 100L);
        dateAxis12.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis12.setRangeWithMargins((org.jfree.data.Range) dateRange26, false, true);
        boolean boolean30 = dateAxis12.isTickMarksVisible();
        float float31 = dateAxis12.getTickMarkInsideLength();
        boolean boolean32 = chartChangeEventType6.equals((java.lang.Object) dateAxis12);
        chartChangeEvent2.setType(chartChangeEventType6);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setWeight((int) (byte) 1);
        categoryPlot20.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot20.setDomainAxis(categoryAxis26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color3 = java.awt.Color.getColor("", (int) (byte) 10);
        boolean boolean4 = color0.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        int int29 = xYPlot0.getSeriesCount();
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeGridlinePaint(paint30);
        java.awt.Stroke stroke32 = null;
        try {
            xYPlot0.setDomainZeroBaselineStroke(stroke32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryMarker25.getLabelOffset();
        double double31 = rectangleInsets29.extendWidth((double) 1L);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 7.0d + "'", double31 == 7.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint10 = xYPlot0.getDomainTickBandPaint();
        java.awt.Color color11 = java.awt.Color.black;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        float[] floatArray17 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray18 = color13.getColorComponents(floatArray17);
        try {
            float[] floatArray19 = color11.getRGBComponents(floatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot20.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        try {
            int int36 = categoryPlot20.getDomainAxisIndex(categoryAxis35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNull(categoryAxis34);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-16777216), 11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        dateAxis0.setVerticalTickLabels(false);
        boolean boolean6 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(500, xYItemRenderer8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot0.getIndexOf(xYItemRenderer10);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType42 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean43 = lengthAdjustmentType41.equals((java.lang.Object) unitType42);
        java.awt.Color color45 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color45, stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryMarker47.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot49.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        xYPlot49.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot49.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent58 = null;
        xYPlot57.markerChanged(markerChangeEvent58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        xYPlot57.zoomDomainAxes((double) 0, plotRenderingInfo61, point2D62, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot57.setDomainCrosshairPaint((java.awt.Paint) color65);
        xYPlot49.setRangeGridlinePaint((java.awt.Paint) color65);
        categoryMarker47.setPaint((java.awt.Paint) color65);
        boolean boolean69 = unitType42.equals((java.lang.Object) categoryMarker47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker47.setLabelOffsetType(lengthAdjustmentType70);
        org.jfree.chart.util.Layer layer72 = null;
        boolean boolean73 = categoryPlot20.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker47, layer72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
        try {
            int int75 = categoryPlot20.getDomainAxisIndex(categoryAxis74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        xYPlot0.setNoDataMessage("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        xYPlot5.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot13.zoomDomainAxes((double) 0, plotRenderingInfo17, point2D18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color21);
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color21);
        categoryMarker3.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryMarker3.getLabelOffset();
        double double27 = rectangleInsets25.calculateRightOutset((double) 6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor2, jFreeChart3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent4.getType();
        chartChangeEvent1.setType(chartChangeEventType5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot7.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot7.drawRangeTickBands(graphics2D15, rectangle2D16, list17);
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot7.setRangeGridlineStroke(stroke19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CrosshairState crosshairState25 = null;
        boolean boolean26 = xYPlot7.render(graphics2D21, rectangle2D22, 0, plotRenderingInfo24, crosshairState25);
        boolean boolean27 = chartChangeEventType5.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = categoryMarker11.getLabelPaint();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        categoryMarker11.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot15.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot15.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        double double33 = rectangleInsets31.trimHeight(0.0d);
        xYPlot15.setAxisOffset(rectangleInsets31);
        categoryMarker11.setLabelOffset(rectangleInsets31);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker11, layer36, true);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot0.getRendererForDataset(xYDataset39);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean42 = xYPlot0.removeAnnotation(xYAnnotation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-6.0d) + "'", double33 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(xYItemRenderer40);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        java.util.List list25 = categoryPlot20.getCategoriesForAxis(categoryAxis24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace26);
        categoryPlot20.clearRangeMarkers((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        try {
            categoryPlot20.setDomainAxisLocation((-52), axisLocation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        dateAxis5.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis5.getTickUnit();
        java.lang.String str11 = dateAxis5.getLabelURL();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setOutlinePaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int2 = objectList0.indexOf((java.lang.Object) 2019);
        java.lang.Object obj3 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setLabel("java.awt.Color[r=255,g=175,b=175]");
        java.awt.Font font19 = dateAxis5.getLabelFont();
        java.awt.Shape shape20 = null;
        try {
            dateAxis5.setUpArrow(shape20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        xYPlot0.zoom((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis15.setRange((org.jfree.data.Range) dateRange16);
        int int18 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Font font19 = dateAxis15.getLabelFont();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        boolean boolean8 = xYPlot0.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        xYPlot11.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = xYPlot18.getSeriesRenderingOrder();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot18.setOutlineStroke(stroke22);
        boolean boolean24 = dateAxis16.hasListener((java.util.EventListener) xYPlot18);
        dateAxis16.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getRangeGridlinePaint();
        java.awt.Color color33 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color33, stroke34);
        java.awt.Paint paint36 = categoryMarker35.getLabelPaint();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot29.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker35, layer37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot29.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = categoryPlot29.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryMarker15.getLabelOffset();
        double double18 = rectangleInsets16.trimHeight(0.0d);
        xYPlot0.setAxisOffset(rectangleInsets16);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        xYPlot22.markerChanged(markerChangeEvent23);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder25 = xYPlot22.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        xYPlot22.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot29.markerChanged(markerChangeEvent30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot29.getSeriesRenderingOrder();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot29.setOutlineStroke(stroke33);
        boolean boolean35 = dateAxis27.hasListener((java.util.EventListener) xYPlot29);
        dateAxis27.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeGridlinePaint();
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot40.setRangeGridlineStroke(stroke42);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        xYPlot44.markerChanged(markerChangeEvent45);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder47 = xYPlot44.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        xYPlot44.drawAnnotations(graphics2D48, rectangle2D49, plotRenderingInfo50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.util.List list54 = null;
        xYPlot44.drawRangeTickBands(graphics2D52, rectangle2D53, list54);
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot44.setRangeGridlineStroke(stroke56);
        categoryPlot40.setRangeGridlineStroke(stroke56);
        categoryPlot40.clearDomainMarkers((int) (byte) 100);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot40);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-6.0d) + "'", double18 == (-6.0d));
        org.junit.Assert.assertNotNull(seriesRenderingOrder25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(seriesRenderingOrder47);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot8.zoomDomainAxes((double) 0, plotRenderingInfo12, point2D13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot8.setDomainCrosshairPaint((java.awt.Paint) color16);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke19 = null;
        try {
            xYPlot0.setDomainGridlineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        boolean boolean10 = xYPlot0.isDomainZoomable();
        java.awt.Stroke stroke11 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        java.lang.Object obj15 = defaultDrawingSupplier13.clone();
        try {
            java.awt.Paint paint16 = defaultDrawingSupplier13.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(10, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        boolean boolean30 = categoryPlot20.render(graphics2D26, rectangle2D27, (int) (byte) 1, plotRenderingInfo29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        java.awt.Image image7 = xYPlot4.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot4.getRangeAxis();
        java.awt.Color color10 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = categoryMarker12.getLabelPaint();
        xYPlot4.setDomainGridlinePaint(paint13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot4.getDomainAxisLocation();
        boolean boolean16 = rectangleInsets3.equals((java.lang.Object) xYPlot4);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        org.jfree.chart.plot.Plot plot14 = xYPlot7.getParent();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = xYPlot18.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        xYPlot18.drawAnnotations(graphics2D22, rectangle2D23, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot18.drawRangeTickBands(graphics2D26, rectangle2D27, list28);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot18.setRangeGridlineStroke(stroke30);
        xYPlot15.setDomainZeroBaselineStroke(stroke30);
        xYPlot7.setRangeCrosshairStroke(stroke30);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot7.getDomainAxisForDataset(0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(valueAxis35);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType42 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean43 = lengthAdjustmentType41.equals((java.lang.Object) unitType42);
        java.awt.Color color45 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color45, stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryMarker47.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot49.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        xYPlot49.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot49.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent58 = null;
        xYPlot57.markerChanged(markerChangeEvent58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        xYPlot57.zoomDomainAxes((double) 0, plotRenderingInfo61, point2D62, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot57.setDomainCrosshairPaint((java.awt.Paint) color65);
        xYPlot49.setRangeGridlinePaint((java.awt.Paint) color65);
        categoryMarker47.setPaint((java.awt.Paint) color65);
        boolean boolean69 = unitType42.equals((java.lang.Object) categoryMarker47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker47.setLabelOffsetType(lengthAdjustmentType70);
        org.jfree.chart.util.Layer layer72 = null;
        boolean boolean73 = categoryPlot20.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker47, layer72);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot20.getRangeAxisLocation((int) (short) -1);
        boolean boolean76 = categoryPlot20.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent80 = null;
        xYPlot79.markerChanged(markerChangeEvent80);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder82 = xYPlot79.getSeriesRenderingOrder();
        java.awt.Stroke stroke83 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot79.setOutlineStroke(stroke83);
        org.jfree.chart.util.Layer layer86 = null;
        java.util.Collection collection87 = xYPlot79.getDomainMarkers(100, layer86);
        java.awt.Paint paint88 = xYPlot79.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        java.awt.geom.Rectangle2D rectangle2D92 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor93 = null;
        java.awt.geom.Point2D point2D94 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D92, rectangleAnchor93);
        xYPlot79.zoomRangeAxes((double) (byte) 0, 16.0d, plotRenderingInfo91, point2D94);
        org.jfree.chart.plot.PlotState plotState96 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo97 = null;
        try {
            categoryPlot20.draw(graphics2D77, rectangle2D78, point2D94, plotState96, plotRenderingInfo97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder82);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNull(collection87);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(point2D94);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setAxisLineVisible(false);
        dateAxis5.resizeRange((double) 500, (-6.0d));
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot20.getRangeAxis(11);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation33, false);
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot20.setRangeCrosshairPaint(paint36);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange19, false, true);
        java.util.Date date23 = dateAxis5.getMinimumDate();
        try {
            dateAxis5.setAutoRangeMinimumSize((double) (-52), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker3.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        xYPlot6.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot6.getDatasetRenderingOrder();
        categoryMarker3.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot6);
        java.awt.Font font15 = categoryMarker3.getLabelFont();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = categoryMarker3.getLabelOffsetType();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        java.awt.Paint paint19 = dateAxis17.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis17.getTickUnit();
        boolean boolean21 = dateAxis17.isInverted();
        java.util.TimeZone timeZone22 = dateAxis17.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        java.awt.Paint paint25 = dateAxis23.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        boolean boolean27 = dateAxis23.isInverted();
        java.util.TimeZone timeZone28 = dateAxis23.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        dateAxis23.setRightArrow(shape30);
        dateAxis17.setLeftArrow(shape30);
        boolean boolean33 = lengthAdjustmentType16.equals((java.lang.Object) shape30);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        java.awt.Image image4 = xYPlot1.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot1.getRangeAxis();
        java.awt.Color color7 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color7, stroke8);
        java.awt.Paint paint10 = categoryMarker9.getLabelPaint();
        xYPlot1.setDomainGridlinePaint(paint10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot1.setOutlinePaint((java.awt.Paint) color12);
        int int14 = color12.getBlue();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = xYPlot17.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        xYPlot17.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot24.setOutlineStroke(stroke28);
        boolean boolean30 = dateAxis22.hasListener((java.util.EventListener) xYPlot24);
        dateAxis22.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer34);
        java.awt.Paint paint36 = categoryPlot35.getRangeGridlinePaint();
        boolean boolean37 = categoryPlot35.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot35.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        java.util.List list40 = categoryPlot35.getCategoriesForAxis(categoryAxis39);
        java.awt.Stroke stroke41 = categoryPlot35.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color12, stroke41);
        java.awt.Paint paint43 = categoryMarker42.getPaint();
        categoryMarker42.setLabel("SeriesRenderingOrder.REVERSE");
        categoryMarker42.setLabel("SeriesRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        int int6 = xYPlot0.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        xYPlot11.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = xYPlot18.getSeriesRenderingOrder();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot18.setOutlineStroke(stroke22);
        boolean boolean24 = dateAxis16.hasListener((java.util.EventListener) xYPlot18);
        dateAxis16.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        categoryPlot29.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        categoryPlot29.zoomDomainAxes(16.0d, plotRenderingInfo33, point2D36, true);
        xYPlot0.zoomRangeAxes((double) 1560495599999L, plotRenderingInfo8, point2D36, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        boolean boolean43 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker42);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis2.setRange((org.jfree.data.Range) dateRange3);
        int int5 = objectList0.indexOf((java.lang.Object) dateRange3);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        try {
            int int32 = categoryPlot20.getDomainAxisIndex(categoryAxis31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        xYPlot5.markerChanged(markerChangeEvent6);
        java.awt.Image image8 = xYPlot5.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        xYPlot10.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot10.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.util.List list20 = null;
        xYPlot10.drawRangeTickBands(graphics2D18, rectangle2D19, list20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot10.setRangeGridlineStroke(stroke22);
        xYPlot5.setOutlineStroke(stroke22);
        boolean boolean25 = dateAxis0.hasListener((java.util.EventListener) xYPlot5);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot5.getRangeAxisForDataset(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        java.awt.Paint[] paintArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray32 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke33, stroke34, stroke35, stroke36, stroke37 };
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] { stroke39, stroke40 };
        java.awt.Shape[] shapeArray42 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, paintArray32, strokeArray38, strokeArray41, shapeArray42);
        java.lang.Class<?> wildcardClass44 = paintArray31.getClass();
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        java.util.Date date46 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape48 = dateAxis47.getDownArrow();
        java.awt.Paint paint49 = dateAxis47.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = dateAxis47.getTickUnit();
        boolean boolean51 = dateAxis47.isInverted();
        java.util.TimeZone timeZone52 = dateAxis47.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date46, timeZone52);
        try {
            java.util.EventListener[] eventListenerArray54 = categoryMarker26.getListeners((java.lang.Class) wildcardClass44);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [[Ljava.awt.Paint; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(dateTickUnit50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot20.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer(1);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets8.createOutsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        java.awt.Stroke stroke34 = categoryPlot20.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            categoryPlot20.handleClick(7, 192, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        boolean boolean10 = xYPlot0.isRangeCrosshairVisible();
        xYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot0.getRenderer(0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYItemRenderer14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setAxisLineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot19.markerChanged(markerChangeEvent20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Paint paint26 = dateAxis24.getLabelPaint();
        dateAxis24.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis24.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit29, true, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(dateTickUnit29);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot20.render(graphics2D21, rectangle2D22, 1, plotRenderingInfo24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        boolean boolean30 = categoryPlot20.render(graphics2D26, rectangle2D27, (int) (short) 1, plotRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot20.getIndexOf(categoryItemRenderer31);
        categoryPlot20.clearDomainMarkers();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = chartChangeEvent15.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        chartChangeEvent15.setType(chartChangeEventType17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        int int13 = color10.getAlpha();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker3.getLabelOffset();
        double double6 = rectangleInsets4.trimHeight(0.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.0d) + "'", double6 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) unitType1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) 1.0f, (double) (byte) 10, 0.0d, (double) ' ');
        double double9 = rectangleInsets7.trimHeight((double) 7);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets7.getUnitType();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.0d + "'", double9 == 6.0d);
        org.junit.Assert.assertNotNull(unitType10);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setUpperBound((double) (-1));
        boolean boolean20 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        double double23 = dateAxis21.getUpperBound();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer24);
        boolean boolean26 = xYPlot25.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation((int) (short) 100);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        categoryPlot20.setRangeCrosshairLockedOnData(false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot20.setRangeCrosshairPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setWeight((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot20.setDataset(2019, categoryDataset25);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color29, stroke30);
        java.awt.Paint paint32 = categoryMarker31.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot33.markerChanged(markerChangeEvent34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        xYPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder39 = xYPlot36.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        xYPlot36.drawAnnotations(graphics2D40, rectangle2D41, plotRenderingInfo42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot36.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot36.setRangeGridlineStroke(stroke48);
        xYPlot33.setDomainZeroBaselineStroke(stroke48);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot33.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker54, layer55, true);
        categoryPlot20.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker31, layer55, false);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        xYPlot60.markerChanged(markerChangeEvent61);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder63 = xYPlot60.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        xYPlot60.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis65);
        org.jfree.chart.axis.Timeline timeline67 = null;
        dateAxis65.setTimeline(timeline67);
        try {
            categoryPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertNotNull(seriesRenderingOrder63);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot6.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot6.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot6.setRangeGridlineStroke(stroke18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.CrosshairState crosshairState24 = null;
        boolean boolean25 = xYPlot6.render(graphics2D20, rectangle2D21, 0, plotRenderingInfo23, crosshairState24);
        boolean boolean26 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color29, stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryMarker31.getLabelOffset();
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot6.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker31, layer33);
        java.awt.Paint paint35 = xYPlot6.getDomainGridlinePaint();
        xYPlot0.setRangeCrosshairPaint(paint35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.CrosshairState crosshairState41 = null;
        boolean boolean42 = xYPlot0.render(graphics2D37, rectangle2D38, 2, plotRenderingInfo40, crosshairState41);
        java.awt.Paint paint43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint43);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint43);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        int int7 = day2.getYear();
//        long long8 = day2.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange19, false, true);
        boolean boolean23 = dateAxis5.isTickMarksVisible();
        java.awt.Stroke stroke24 = dateAxis5.getAxisLineStroke();
        java.awt.Shape shape25 = null;
        try {
            dateAxis5.setUpArrow(shape25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setLabelFont(font14);
        java.lang.Object obj16 = dateAxis5.clone();
        dateAxis5.setLabelURL("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        dateAxis5.setUpperBound((double) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis5.getTickUnit();
        boolean boolean11 = dateAxis5.isAutoRange();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        int int10 = xYPlot0.indexOf(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker12, layer13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = null;
        try {
            xYPlot0.setDomainAxes(valueAxisArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        java.awt.Image image19 = xYPlot16.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot16.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        int int22 = xYPlot16.getIndexOf(xYItemRenderer21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot16.setRenderer(500, xYItemRenderer24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        int int27 = xYPlot16.getIndexOf(xYItemRenderer26);
        java.awt.Stroke stroke28 = xYPlot16.getDomainGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType10 = numberAxis1.getRangeType();
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis1.setMarkerBand(markerAxisBand12);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertNotNull(rangeType11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getRGB();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray7 = new float[] { (-1L), (short) 10, (byte) 100 };
        float[] floatArray8 = color3.getColorComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace2, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16777216) + "'", int1 == (-16777216));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SeriesRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SeriesRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(500, xYItemRenderer8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot0.getIndexOf(xYItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        int int13 = xYPlot0.indexOf(xYDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        xYPlot0.removeChangeListener(plotChangeListener14);
        int int16 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape5);
        dateAxis0.setRangeAboutValue((double) 6, (double) 2);
        dateAxis0.setRangeAboutValue((double) '#', (double) 10L);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis5.setTimeline(timeline7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        dateAxis5.setLabelPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(xYDataset10);
        xYPlot0.configureDomainAxes();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(2019, xYDataset10);
        xYPlot0.setBackgroundImageAlignment(15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer(1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = null;
        try {
            xYPlot0.setAxisOffset(rectangleInsets12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        java.util.List list25 = categoryPlot20.getCategoriesForAxis(categoryAxis24);
        java.awt.Stroke stroke26 = categoryPlot20.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray28 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer27 };
        categoryPlot20.setRenderers(categoryItemRendererArray28);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            categoryPlot20.handleClick((-52), (int) (short) 100, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(categoryItemRendererArray28);
        org.junit.Assert.assertNull(legendItemCollection30);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getDomainAxisEdge();
        int int8 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        int int29 = xYPlot0.getSeriesCount();
        int int30 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace31 = xYPlot0.getFixedRangeAxisSpace();
        boolean boolean32 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange19, false, true);
        boolean boolean23 = dateAxis5.isTickMarksVisible();
        float float24 = dateAxis5.getTickMarkInsideLength();
        dateAxis5.setTickMarkOutsideLength((float) (short) 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        dateAxis0.setUpperMargin((double) (short) 10);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        dateAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        xYPlot0.zoom((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = dateAxis15.getDownArrow();
        dateAxis15.setUpperMargin((double) (short) 10);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot19.markerChanged(markerChangeEvent20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot19.getSeriesRenderingOrder();
        java.awt.Paint paint23 = xYPlot19.getRangeZeroBaselinePaint();
        dateAxis15.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot19);
        java.awt.Color color27 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color27, stroke28);
        java.awt.Paint paint30 = categoryMarker29.getLabelPaint();
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = xYPlot19.removeRangeMarker(100, (org.jfree.chart.plot.Marker) categoryMarker29, layer31);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot0.markerChanged(markerChangeEvent33);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        xYPlot9.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot16.getSeriesRenderingOrder();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setOutlineStroke(stroke20);
        boolean boolean22 = dateAxis14.hasListener((java.util.EventListener) xYPlot16);
        dateAxis14.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeGridlinePaint();
        java.awt.Color color31 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color31, stroke32);
        java.awt.Paint paint34 = categoryMarker33.getLabelPaint();
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot27.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker33, layer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot27.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            org.jfree.chart.axis.AxisState axisState40 = numberAxis1.draw(graphics2D3, (double) 1560495599999L, rectangle2D5, rectangle2D6, rectangleEdge38, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot20.getDomainAxis();
        java.awt.Color color36 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color36, stroke37);
        categoryPlot20.addDomainMarker(categoryMarker38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        try {
            int int41 = categoryPlot20.getDomainAxisIndex(categoryAxis40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Stroke stroke40 = categoryPlot20.getDomainGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot20.getFixedLegendItems();
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(legendItemCollection41);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        categoryPlot20.clearRangeMarkers();
        int int24 = categoryPlot20.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        long long7 = day2.getSerialIndex();
//        long long8 = day2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Paint paint20 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = xYPlot0.getDrawingSupplier();
        java.awt.Paint paint22 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot0.getDomainAxisForDataset(0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        xYPlot0.clearDomainMarkers();
        int int23 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart25);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot0.removeDomainMarker(15, marker28, layer29, true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomDomainAxes(4.0d, (double) 2.0f, plotRenderingInfo7, point2D8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint10);
        java.awt.Color color12 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(xYDataset10);
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = xYPlot0.removeDomainMarker(marker13, layer14);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        categoryMarker25.setLabel("");
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        java.awt.Stroke stroke7 = dateAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        xYPlot0.zoomRangeAxes((double) 500, plotRenderingInfo9, point2D12, true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets16.trimWidth((double) ' ');
        xYPlot0.setAxisOffset(rectangleInsets16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 16.0d + "'", double18 == 16.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        dateAxis0.setRange((double) 8, (double) 1560495599999L);
        java.awt.Stroke stroke6 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(stroke6);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getDomainAxisEdge();
        java.lang.String str8 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot20.getRangeAxisLocation((-14336));
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = categoryPlot20.removeDomainMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker30, layer31, false);
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(2019, xYDataset10);
        java.awt.Paint paint12 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) unitType1);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        xYPlot8.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot8.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot16.zoomDomainAxes((double) 0, plotRenderingInfo20, point2D21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color24);
        xYPlot8.setRangeGridlinePaint((java.awt.Paint) color24);
        categoryMarker6.setPaint((java.awt.Paint) color24);
        boolean boolean28 = unitType1.equals((java.lang.Object) categoryMarker6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker6.setLabelOffsetType(lengthAdjustmentType29);
        java.lang.String str31 = lengthAdjustmentType29.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "NO_CHANGE" + "'", str31.equals("NO_CHANGE"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        java.awt.Paint paint5 = dateAxis3.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis3.getTickUnit();
        java.awt.Stroke stroke7 = dateAxis3.getTickMarkStroke();
        dateAxis3.setAutoRange(true);
        dateAxis3.setLowerMargin(16.0d);
        java.util.Date date12 = dateAxis3.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        dateAxis3.setRightArrow(shape14);
        numberAxis1.setUpArrow(shape14);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        java.awt.Paint paint4 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        java.awt.Stroke stroke6 = dateAxis2.getTickMarkStroke();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setLeftArrow(shape7);
        dateAxis0.setDownArrow(shape7);
        try {
            dateAxis0.setAutoRangeMinimumSize((double) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        dateAxis5.setAxisLineVisible(false);
        java.awt.Shape shape19 = dateAxis5.getDownArrow();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(100, layer7);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxis(0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        try {
            java.awt.Shape shape15 = defaultDrawingSupplier13.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        java.awt.Paint paint11 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker12, layer13);
        java.lang.Object obj15 = intervalMarker12.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        double double22 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot0.getOrientation();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot7.getSeriesRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setOutlineStroke(stroke11);
        boolean boolean13 = dateAxis5.hasListener((java.util.EventListener) xYPlot7);
        dateAxis5.setRange((double) '#', (double) 100L);
        boolean boolean17 = dateAxis5.isAutoRange();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot24.render(graphics2D38, rectangle2D39, 0, plotRenderingInfo41, crosshairState42);
        boolean boolean44 = xYPlot24.isRangeCrosshairVisible();
        java.awt.Color color47 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color47, stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = xYPlot24.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker49, layer51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer54);
        categoryMarker49.setDrawAsLine(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        dateAxis0.setUpperMargin((double) (short) 10);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        java.awt.Color color12 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color12, stroke13);
        java.awt.Paint paint15 = categoryMarker14.getLabelPaint();
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = xYPlot4.removeRangeMarker(100, (org.jfree.chart.plot.Marker) categoryMarker14, layer16);
        java.awt.Stroke stroke18 = xYPlot4.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        boolean boolean7 = xYPlot0.isSubplot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(xYItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 38.0d, (double) 0.5f, (double) 1.0f, (double) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset(100);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryMarker11.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        xYPlot13.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot13.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomDomainAxes((double) 0, plotRenderingInfo25, point2D26, false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color29);
        xYPlot13.setRangeGridlinePaint((java.awt.Paint) color29);
        categoryMarker11.setPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryMarker11.getLabelOffset();
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = xYPlot0.removeRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker11, layer34, true);
        xYPlot0.setBackgroundAlpha((float) (-14336));
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = xYPlot0.getOrientation();
        java.lang.String str40 = plotOrientation39.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PlotOrientation.VERTICAL" + "'", str40.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryMarker15.getLabelOffset();
        double double18 = rectangleInsets16.trimHeight(0.0d);
        xYPlot0.setAxisOffset(rectangleInsets16);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        xYPlot20.setDomainAxisLocation((int) (short) 10, axisLocation25);
        int int27 = xYPlot20.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot20.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot29.markerChanged(markerChangeEvent30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot29.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        xYPlot29.drawAnnotations(graphics2D33, rectangle2D34, plotRenderingInfo35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.util.List list39 = null;
        xYPlot29.drawRangeTickBands(graphics2D37, rectangle2D38, list39);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot29.setRangeGridlineStroke(stroke41);
        xYPlot20.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType45 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean46 = lengthAdjustmentType44.equals((java.lang.Object) unitType45);
        java.awt.Color color48 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color48, stroke49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryMarker50.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent53 = null;
        xYPlot52.markerChanged(markerChangeEvent53);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder55 = xYPlot52.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        xYPlot52.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder59 = xYPlot52.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        xYPlot60.markerChanged(markerChangeEvent61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot60.zoomDomainAxes((double) 0, plotRenderingInfo64, point2D65, false);
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot60.setDomainCrosshairPaint((java.awt.Paint) color68);
        xYPlot52.setRangeGridlinePaint((java.awt.Paint) color68);
        categoryMarker50.setPaint((java.awt.Paint) color68);
        boolean boolean72 = unitType45.equals((java.lang.Object) categoryMarker50);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker50.setLabelOffsetType(lengthAdjustmentType73);
        org.jfree.chart.util.Layer layer75 = null;
        boolean boolean76 = xYPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker50, layer75);
        boolean boolean77 = xYPlot0.equals((java.lang.Object) xYPlot20);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot20.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-6.0d) + "'", double18 == (-6.0d));
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType44);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(seriesRenderingOrder55);
        org.junit.Assert.assertNotNull(datasetRenderingOrder59);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot20.render(graphics2D21, rectangle2D22, 1, plotRenderingInfo24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = null;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor30);
        categoryPlot20.zoomRangeAxes((double) 7, (double) '4', plotRenderingInfo28, point2D31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        try {
            int int34 = categoryPlot20.getDomainAxisIndex(categoryAxis33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot24.render(graphics2D38, rectangle2D39, 0, plotRenderingInfo41, crosshairState42);
        boolean boolean44 = xYPlot24.isRangeCrosshairVisible();
        java.awt.Color color47 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color47, stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = xYPlot24.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker49, layer51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker49.getLabelOffset();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer54);
        categoryPlot20.setAnchorValue((-6.0d));
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        categoryPlot20.setDataset(8, categoryDataset59);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.text.DateFormat dateFormat2 = null;
        dateAxis0.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.zoomRange((double) 2.0f, 4.0d);
        java.awt.Shape shape10 = dateAxis6.getLeftArrow();
        dateAxis0.setLeftArrow(shape10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryMarker15.getLabelOffset();
        double double18 = rectangleInsets16.trimHeight(0.0d);
        xYPlot0.setAxisOffset(rectangleInsets16);
        java.awt.Paint paint20 = xYPlot0.getOutlinePaint();
        java.awt.Color color21 = java.awt.Color.blue;
        int int22 = color21.getBlue();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color21);
        float float24 = xYPlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-6.0d) + "'", double18 == (-6.0d));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace7, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot20.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot20.setRenderer(categoryItemRenderer47);
        boolean boolean49 = categoryPlot20.isRangeCrosshairVisible();
        boolean boolean50 = categoryPlot20.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        java.util.List list25 = categoryPlot20.getCategoriesForAxis(categoryAxis24);
        java.awt.Stroke stroke26 = categoryPlot20.getRangeGridlineStroke();
        java.awt.Stroke stroke27 = categoryPlot20.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot0.getRangeAxis(500);
        java.awt.geom.Point2D point2D18 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getDomainMarkers(layer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace25);
        int int27 = categoryPlot20.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        java.lang.String str4 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        xYPlot0.zoomRangeAxes((double) 500, plotRenderingInfo9, point2D12, true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = xYPlot0.getSeriesRenderingOrder();
        java.lang.String str16 = seriesRenderingOrder15.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str16.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 0, 10.0d, (double) 0, (double) 10.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        boolean boolean10 = xYPlot0.isRangeCrosshairVisible();
        xYPlot0.setRangeGridlinesVisible(true);
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker3.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        xYPlot6.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot6.getDatasetRenderingOrder();
        categoryMarker3.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        java.lang.String str24 = sortOrder23.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "SortOrder.ASCENDING" + "'", str24.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '4');
        boolean boolean11 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke4);
        int int6 = xYPlot0.getWeight();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        xYPlot8.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot15.setOutlineStroke(stroke19);
        boolean boolean21 = dateAxis13.hasListener((java.util.EventListener) xYPlot15);
        dateAxis13.setRange((double) '#', (double) 100L);
        dateAxis13.setAxisLineVisible(false);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        org.jfree.data.Range range7 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis8.getTickUnit();
        java.util.Date date12 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        dateAxis5.setAutoRange(false);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setTickLabelFont(font11);
        java.awt.Paint paint13 = dateAxis5.getAxisLinePaint();
        boolean boolean14 = dateAxis5.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetGroup datasetGroup1 = xYPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(datasetGroup1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        java.awt.Color color5 = java.awt.Color.ORANGE;
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        java.lang.Comparable comparable7 = categoryMarker3.getKey();
        categoryMarker3.setLabel("Category Plot");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 0L + "'", comparable7.equals(0L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot0.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot0.getDomainMarkers(layer20);
        xYPlot0.clearDomainMarkers();
        java.awt.Color color23 = java.awt.Color.pink;
        java.awt.Color color25 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryMarker27.getLabelOffset();
        boolean boolean29 = color23.equals((java.lang.Object) rectangleInsets28);
        double double30 = rectangleInsets28.getTop();
        xYPlot0.setAxisOffset(rectangleInsets28);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets28.createInsetRectangle(rectangle2D32, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset((int) '4');
        categoryPlot20.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot20.markerChanged(markerChangeEvent25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset22);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = null;
        try {
            categoryPlot20.setAxisOffset(rectangleInsets22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        categoryPlot20.axisChanged(axisChangeEvent24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot20.getDomainAxisLocation();
        categoryPlot20.setNoDataMessage("RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        boolean boolean8 = dateAxis5.isTickLabelsVisible();
        dateAxis5.setAutoRange(false);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setTickLabelFont(font11);
        java.awt.Paint paint13 = dateAxis5.getAxisLinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        java.awt.Paint paint16 = dateAxis14.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis14.getTickUnit();
        java.awt.Stroke stroke18 = dateAxis14.getTickMarkStroke();
        dateAxis14.setAutoRange(true);
        org.jfree.data.Range range21 = dateAxis14.getDefaultAutoRange();
        dateAxis5.setRange(range21);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis6.setLabelFont(font15);
        dateAxis0.setTickLabelFont(font15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0);
        java.lang.Object obj19 = chartChangeEvent18.getSource();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType42 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean43 = lengthAdjustmentType41.equals((java.lang.Object) unitType42);
        java.awt.Color color45 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color45, stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryMarker47.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot49.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        xYPlot49.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot49.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent58 = null;
        xYPlot57.markerChanged(markerChangeEvent58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        xYPlot57.zoomDomainAxes((double) 0, plotRenderingInfo61, point2D62, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot57.setDomainCrosshairPaint((java.awt.Paint) color65);
        xYPlot49.setRangeGridlinePaint((java.awt.Paint) color65);
        categoryMarker47.setPaint((java.awt.Paint) color65);
        boolean boolean69 = unitType42.equals((java.lang.Object) categoryMarker47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker47.setLabelOffsetType(lengthAdjustmentType70);
        org.jfree.chart.util.Layer layer72 = null;
        boolean boolean73 = categoryPlot20.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker47, layer72);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot20.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        java.awt.geom.Point2D point2D78 = null;
        try {
            categoryPlot20.zoomRangeAxes((double) ' ', plotRenderingInfo77, point2D78, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        java.awt.Paint paint3 = dateAxis1.getAxisLinePaint();
        dateAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot6.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot6.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot6.setRangeGridlineStroke(stroke18);
        org.jfree.chart.plot.Plot plot20 = xYPlot6.getRootPlot();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot6.setDomainZeroBaselinePaint(paint22);
        java.awt.Color color25 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color25, stroke26);
        java.awt.Paint paint28 = null;
        java.awt.Stroke stroke29 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "Category Plot", paint22, stroke26, paint28, stroke29, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot9.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot9.drawRangeTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot9.setRangeGridlineStroke(stroke21);
        xYPlot0.setRangeCrosshairStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker30.setLabelOffsetType(lengthAdjustmentType53);
        org.jfree.chart.util.Layer layer55 = null;
        boolean boolean56 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        xYPlot0.setRenderer(3, xYItemRenderer58, true);
        xYPlot0.mapDatasetToDomainAxis((int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot20.setRenderer(0, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot20.getBackgroundPaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryMarker5.getLabelOffset();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) categoryMarker5);
        java.awt.Paint paint8 = categoryMarker5.getOutlinePaint();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        boolean boolean5 = xYPlot0.isOutlineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRenderer();
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(xYItemRenderer6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        xYPlot1.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot8.setOutlineStroke(stroke12);
        boolean boolean14 = dateAxis6.hasListener((java.util.EventListener) xYPlot8);
        dateAxis6.setRange((double) '#', (double) 100L);
        dateAxis6.setLabel("java.awt.Color[r=255,g=175,b=175]");
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange20, false, true);
        boolean boolean24 = dateAxis6.isTickMarksVisible();
        float float25 = dateAxis6.getTickMarkInsideLength();
        java.awt.Shape shape26 = dateAxis6.getDownArrow();
        boolean boolean27 = categoryAnchor0.equals((java.lang.Object) dateAxis6);
        java.awt.Font font28 = dateAxis6.getLabelFont();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        xYPlot1.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot1.zoomDomainAxes((double) 0, plotRenderingInfo5, point2D6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = xYPlot12.getSeriesRenderingOrder();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot12.setOutlineStroke(stroke16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        xYPlot20.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder30 = xYPlot27.getSeriesRenderingOrder();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot27.setOutlineStroke(stroke31);
        boolean boolean33 = dateAxis25.hasListener((java.util.EventListener) xYPlot27);
        dateAxis25.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer37);
        java.awt.Paint paint39 = categoryPlot38.getRangeGridlinePaint();
        boolean boolean40 = categoryPlot38.isDomainZoomable();
        java.awt.Paint paint41 = categoryPlot38.getRangeGridlinePaint();
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (-1), (java.awt.Paint) color9, stroke16, paint41, stroke42, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        dateAxis0.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.lang.String str4 = categoryMarker3.getLabel();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryMarker3.getLabelOffset();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis6.getStandardTickUnits();
        dateAxis6.setTickLabelsVisible(true);
        java.awt.Font font10 = dateAxis6.getTickLabelFont();
        categoryMarker3.setLabelFont(font10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot20.zoomDomainAxes(16.0d, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot20.setRenderer(11, categoryItemRenderer31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot20.getDomainAxis();
        double double35 = categoryPlot20.getRangeCrosshairValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot20.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        boolean boolean42 = categoryPlot20.render(graphics2D38, rectangle2D39, (-52), plotRenderingInfo41);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color6, stroke7);
        java.awt.Paint paint9 = categoryMarker8.getLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot0.getDomainAxisLocation();
        xYPlot0.setDomainCrosshairValue(1.0E-8d);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.Timeline timeline9 = dateAxis0.getTimeline();
        dateAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(timeline9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = categoryMarker3.getLabelPaint();
        boolean boolean5 = categoryMarker3.getDrawAsLine();
        java.awt.Font font6 = categoryMarker3.getLabelFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        categoryPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = numberAxis26.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        numberAxis26.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType35 = numberAxis26.getRangeType();
        org.jfree.data.RangeType rangeType36 = numberAxis26.getRangeType();
        categoryPlot20.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        boolean boolean39 = numberAxis26.isPositiveArrowVisible();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            org.jfree.chart.axis.AxisState axisState46 = numberAxis26.draw(graphics2D40, (double) 100.0f, rectangle2D42, rectangle2D43, rectangleEdge44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rangeType35);
        org.junit.Assert.assertNotNull(rangeType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.Plot plot7 = null;
        dateAxis5.setPlot(plot7);
        dateAxis5.setVisible(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        int int29 = xYPlot0.getSeriesCount();
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeGridlinePaint(paint30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot0.zoomRangeAxes((double) (short) -1, plotRenderingInfo33, point2D34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        xYPlot4.markerChanged(markerChangeEvent5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        xYPlot4.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot11.setOutlineStroke(stroke15);
        boolean boolean17 = dateAxis9.hasListener((java.util.EventListener) xYPlot11);
        dateAxis9.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getRangeGridlinePaint();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot22.setRangeGridlineStroke(stroke24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        xYPlot26.markerChanged(markerChangeEvent27);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder29 = xYPlot26.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        xYPlot26.drawAnnotations(graphics2D30, rectangle2D31, plotRenderingInfo32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.util.List list36 = null;
        xYPlot26.drawRangeTickBands(graphics2D34, rectangle2D35, list36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot26.setRangeGridlineStroke(stroke38);
        categoryPlot22.setRangeGridlineStroke(stroke38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot22.getRangeAxisLocation();
        java.awt.Stroke stroke42 = categoryPlot22.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(16.0d, (java.awt.Paint) color1, stroke42);
        valueMarker43.setValue((double) '#');
        double double46 = valueMarker43.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(seriesRenderingOrder29);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 35.0d + "'", double46 == 35.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray8, strokeArray11, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextOutlinePaint();
        try {
            java.awt.Paint paint15 = defaultDrawingSupplier13.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawRangeTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = xYPlot0.render(graphics2D14, rectangle2D15, 0, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryMarker25.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        int int29 = xYPlot0.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot0.getRendererForDataset(xYDataset30);
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot0.setOutlinePaint(paint32);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 100, false);
        org.jfree.data.RangeType rangeType10 = numberAxis1.getRangeType();
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertNotNull(rangeType11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        java.awt.Stroke stroke9 = dateAxis0.getAxisLineStroke();
        java.lang.String str10 = dateAxis0.getLabel();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint7 = dateAxis5.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        xYPlot10.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot10.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        xYPlot10.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = xYPlot17.getSeriesRenderingOrder();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot17.setOutlineStroke(stroke21);
        boolean boolean23 = dateAxis15.hasListener((java.util.EventListener) xYPlot17);
        dateAxis15.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer27);
        java.awt.Paint paint29 = categoryPlot28.getRangeGridlinePaint();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot28.setRangeGridlineStroke(stroke30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        xYPlot32.drawAnnotations(graphics2D36, rectangle2D37, plotRenderingInfo38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.util.List list42 = null;
        xYPlot32.drawRangeTickBands(graphics2D40, rectangle2D41, list42);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot32.setRangeGridlineStroke(stroke44);
        categoryPlot28.setRangeGridlineStroke(stroke44);
        dateAxis5.setTickMarkStroke(stroke44);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = xYPlot0.equals((java.lang.Object) false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot0.getRangeAxis(500);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        int int6 = objectList1.indexOf((java.lang.Object) day2);
//        java.awt.Color color8 = java.awt.Color.RED;
//        java.awt.Color color9 = color8.brighter();
//        objectList1.set(1, (java.lang.Object) color8);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP;
//        int int12 = objectList1.indexOf((java.lang.Object) rectangleAnchor11);
//        java.lang.Object obj14 = objectList1.get((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(color8);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(rectangleAnchor11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNull(obj14);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        boolean boolean22 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot20.setRenderer(1, categoryItemRenderer24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot20.getAxisOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot20.setDomainGridlinePosition(categoryAnchor27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(categoryAnchor27);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo4, point2D5, false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(xYDataset10);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot16.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        xYPlot16.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot23.setOutlineStroke(stroke27);
        boolean boolean29 = dateAxis21.hasListener((java.util.EventListener) xYPlot23);
        dateAxis21.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        boolean boolean39 = categoryPlot34.render(graphics2D35, rectangle2D36, 1, plotRenderingInfo38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        boolean boolean44 = categoryPlot34.render(graphics2D40, rectangle2D41, (int) (short) 1, plotRenderingInfo43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        int int46 = categoryPlot34.getIndexOf(categoryItemRenderer45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot34.setAxisOffset(rectangleInsets47);
        java.awt.Color color51 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color51, stroke52);
        java.awt.Paint paint54 = categoryMarker53.getLabelPaint();
        java.awt.Color color55 = java.awt.Color.ORANGE;
        categoryMarker53.setLabelPaint((java.awt.Paint) color55);
        java.awt.Stroke stroke57 = categoryMarker53.getStroke();
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent59 = null;
        xYPlot58.markerChanged(markerChangeEvent59);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent62 = null;
        xYPlot61.markerChanged(markerChangeEvent62);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder64 = xYPlot61.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        xYPlot61.drawAnnotations(graphics2D65, rectangle2D66, plotRenderingInfo67);
        java.awt.Graphics2D graphics2D69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.util.List list71 = null;
        xYPlot61.drawRangeTickBands(graphics2D69, rectangle2D70, list71);
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot61.setRangeGridlineStroke(stroke73);
        xYPlot58.setDomainZeroBaselineStroke(stroke73);
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer80 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot58.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker79, layer80, true);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape84 = dateAxis83.getDownArrow();
        java.awt.Paint paint85 = dateAxis83.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit86 = dateAxis83.getTickUnit();
        dateAxis83.setVerticalTickLabels(false);
        boolean boolean89 = layer80.equals((java.lang.Object) dateAxis83);
        boolean boolean90 = categoryPlot34.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker53, layer80);
        java.util.Collection collection91 = xYPlot0.getDomainMarkers(layer80);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(seriesRenderingOrder64);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(layer80);
        org.junit.Assert.assertNotNull(shape84);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(dateTickUnit86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(collection91);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!", timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date9, timeZone11);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(10, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        boolean boolean30 = categoryPlot20.render(graphics2D26, rectangle2D27, (int) (byte) 1, plotRenderingInfo29);
        boolean boolean31 = categoryPlot20.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Stroke stroke40 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot20.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot20.setDomainAxis(10, categoryAxis44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace46, false);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        int int51 = categoryPlot20.getIndexOf(categoryItemRenderer50);
        java.awt.Paint paint52 = null;
        try {
            categoryPlot20.setRangeGridlinePaint(paint52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(legendItemCollection49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        xYPlot3.markerChanged(markerChangeEvent4);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = xYPlot3.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        xYPlot3.drawAnnotations(graphics2D7, rectangle2D8, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot3.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot3.setRangeGridlineStroke(stroke15);
        xYPlot0.setDomainZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100.0f, 0.05d);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        java.awt.Stroke stroke25 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.lang.String str11 = color10.toString();
        xYPlot0.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot0.getDataset((int) (short) 0);
        xYPlot0.clearDomainMarkers((-1));
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNull(xYDataset14);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Stroke stroke4 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoRange(true);
        dateAxis0.setLowerMargin(16.0d);
        java.util.Date date9 = dateAxis0.getMinimumDate();
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17 };
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        java.awt.Shape[] shapeArray22 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, paintArray12, strokeArray18, strokeArray21, shapeArray22);
        java.lang.Class<?> wildcardClass24 = paintArray11.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.util.Date date26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = dateAxis27.getDownArrow();
        java.awt.Paint paint29 = dateAxis27.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        boolean boolean31 = dateAxis27.isInverted();
        java.util.TimeZone timeZone32 = dateAxis27.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date26, timeZone32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date9, timeZone32);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot20.setRenderer(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.LEFT");
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color1, stroke2);
        java.lang.String str4 = categoryMarker3.getLabel();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryMarker3.getLabelOffset();
        double double7 = rectangleInsets5.calculateRightOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Color color24 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = categoryMarker26.getLabelPaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot20.removeDomainMarker(7, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace32);
        categoryPlot20.clearRangeAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        categoryPlot20.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType25 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean26 = lengthAdjustmentType24.equals((java.lang.Object) unitType25);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot32.markerChanged(markerChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        xYPlot40.markerChanged(markerChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomDomainAxes((double) 0, plotRenderingInfo44, point2D45, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setDomainCrosshairPaint((java.awt.Paint) color48);
        xYPlot32.setRangeGridlinePaint((java.awt.Paint) color48);
        categoryMarker30.setPaint((java.awt.Paint) color48);
        boolean boolean52 = unitType25.equals((java.lang.Object) categoryMarker30);
        categoryPlot20.addDomainMarker(categoryMarker30);
        categoryPlot20.setAnchorValue((-6.0d));
        categoryPlot20.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot20.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot20.setRenderer(categoryItemRenderer47);
        boolean boolean49 = categoryPlot20.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot20.getDomainAxis((int) (byte) 10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(categoryAxis51);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        boolean boolean9 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        xYPlot13.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        xYPlot20.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setOutlineStroke(stroke24);
        boolean boolean26 = dateAxis18.hasListener((java.util.EventListener) xYPlot20);
        dateAxis18.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer30);
        categoryPlot31.setAnchorValue((double) 100.0f);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot31.getRangeMarkers(10, layer35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        categoryPlot31.drawBackgroundImage(graphics2D37, rectangle2D38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.data.Range range41 = categoryPlot31.getDataRange(valueAxis40);
        java.awt.Color color44 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color44, stroke45);
        java.awt.Paint paint47 = categoryMarker46.getLabelPaint();
        java.awt.Color color48 = java.awt.Color.ORANGE;
        categoryMarker46.setLabelPaint((java.awt.Paint) color48);
        java.awt.Stroke stroke50 = categoryMarker46.getStroke();
        java.awt.Font font51 = categoryMarker46.getLabelFont();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean53 = categoryPlot31.removeRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker46, layer52);
        java.util.Collection collection54 = xYPlot0.getDomainMarkers(192, layer52);
        org.jfree.chart.axis.AxisSpace axisSpace55 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace55);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(collection54);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        boolean boolean4 = dateAxis0.isInverted();
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        java.awt.Color color6 = java.awt.Color.gray;
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = dateAxis0.isAxisLineVisible();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot14.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        xYPlot14.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot21.getSeriesRenderingOrder();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setOutlineStroke(stroke25);
        boolean boolean27 = dateAxis19.hasListener((java.util.EventListener) xYPlot21);
        dateAxis19.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer33);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        xYPlot36.markerChanged(markerChangeEvent37);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder39 = xYPlot36.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        xYPlot36.setDomainAxisLocation((int) (short) 10, axisLocation41);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = xYPlot36.getFixedLegendItems();
        float float44 = xYPlot36.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset46 = xYPlot36.getDataset(1);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        xYPlot36.setFixedDomainAxisSpace(axisSpace47, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot36.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace52 = dateAxis0.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) categoryPlot34, rectangle2D35, rectangleEdge50, axisSpace51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder39);
        org.junit.Assert.assertNull(legendItemCollection43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRangeWithMargins(range4);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color7, stroke8);
        java.awt.Paint paint10 = categoryMarker9.getLabelPaint();
        java.awt.Color color11 = java.awt.Color.ORANGE;
        categoryMarker9.setLabelPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = categoryMarker9.getStroke();
        dateAxis0.setTickMarkStroke(stroke13);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Image image3 = xYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        java.awt.Color color5 = java.awt.Color.orange;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = null;
        try {
            xYPlot0.setDomainGridlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        xYPlot2.markerChanged(markerChangeEvent3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        xYPlot2.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot9.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot9.setOutlineStroke(stroke13);
        boolean boolean15 = dateAxis7.hasListener((java.util.EventListener) xYPlot9);
        dateAxis7.setRange((double) '#', (double) 100L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot20.setRangeGridlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot24.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot20.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot20.getRangeAxisLocation();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.UnitType unitType42 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean43 = lengthAdjustmentType41.equals((java.lang.Object) unitType42);
        java.awt.Color color45 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color45, stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryMarker47.getLabelOffset();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot49.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        xYPlot49.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot49.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent58 = null;
        xYPlot57.markerChanged(markerChangeEvent58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        xYPlot57.zoomDomainAxes((double) 0, plotRenderingInfo61, point2D62, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot57.setDomainCrosshairPaint((java.awt.Paint) color65);
        xYPlot49.setRangeGridlinePaint((java.awt.Paint) color65);
        categoryMarker47.setPaint((java.awt.Paint) color65);
        boolean boolean69 = unitType42.equals((java.lang.Object) categoryMarker47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        categoryMarker47.setLabelOffsetType(lengthAdjustmentType70);
        org.jfree.chart.util.Layer layer72 = null;
        boolean boolean73 = categoryPlot20.removeDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker47, layer72);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot20.getRangeAxisLocation((int) (short) -1);
        java.awt.Paint paint76 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        try {
            categoryPlot20.drawBackground(graphics2D77, rectangle2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertNotNull(paint76);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo3, point2D4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        xYPlot6.markerChanged(markerChangeEvent7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot6.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot6.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot6.setRangeGridlineStroke(stroke18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.CrosshairState crosshairState24 = null;
        boolean boolean25 = xYPlot6.render(graphics2D20, rectangle2D21, 0, plotRenderingInfo23, crosshairState24);
        boolean boolean26 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color29, stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryMarker31.getLabelOffset();
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot6.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker31, layer33);
        java.awt.Paint paint35 = xYPlot6.getDomainGridlinePaint();
        xYPlot0.setRangeCrosshairPaint(paint35);
        java.awt.Paint paint37 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = null;
        try {
            xYPlot0.setOrientation(plotOrientation38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        try {
            dateAxis0.setRange(249.0d, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
    }
}

