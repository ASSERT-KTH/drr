import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight((double) 0.0f);
        double double7 = rectangleInsets4.getTop();
        numberAxis0.setTickLabelInsets(rectangleInsets4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setUpperMargin((double) 10L);
        java.awt.Color color12 = java.awt.Color.green;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = numberAxis9.hasListener((java.util.EventListener) categoryPlot20);
        double double22 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.Range range23 = numberAxis9.getDefaultAutoRange();
        numberAxis0.setRange(range23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) "GradientPaintTransformType.VERTICAL");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer3.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean8 = barRenderer3.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer3.getGradientPaintTransformer();
        barRenderer3.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        boolean boolean14 = barRenderer3.removeAnnotation(categoryAnnotation13);
        java.awt.Stroke stroke16 = barRenderer3.getSeriesStroke((int) (byte) -1);
        java.awt.Paint paint18 = barRenderer3.getSeriesFillPaint((int) ' ');
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setUpperMargin((double) 10L);
        java.awt.Color color23 = java.awt.Color.green;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        boolean boolean32 = numberAxis20.hasListener((java.util.EventListener) categoryPlot31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot31.getDataset();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot31);
        org.jfree.chart.title.LegendTitle legendTitle35 = jFreeChart34.getLegend();
        boolean boolean36 = jFreeChart34.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart34.setPadding(rectangleInsets37);
        java.awt.Paint paint39 = jFreeChart34.getBackgroundPaint();
        barRenderer3.setBasePaint(paint39);
        boolean boolean41 = categoryLabelPositions0.equals((java.lang.Object) paint39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertNotNull(legendTitle35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color4 = java.awt.Color.getColor("", (int) (short) 100);
        paintList0.setPaint(100, (java.awt.Paint) color4);
        java.lang.Object obj6 = null;
        boolean boolean7 = paintList0.equals(obj6);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset5);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset5, (java.lang.Comparable) 1L);
        double double10 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset9);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setUpperMargin((double) 10L);
        java.awt.Color color21 = java.awt.Color.green;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        int int23 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot15.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke37 = null;
        barRenderer35.setSeriesOutlineStroke(0, stroke37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        java.awt.Stroke stroke40 = categoryPlot39.getDomainGridlineStroke();
        numberAxis27.setTickMarkStroke(stroke40);
        categoryPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis27);
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setUpperMargin((double) 10L);
        java.awt.Color color47 = java.awt.Color.green;
        numberAxis44.setTickLabelPaint((java.awt.Paint) color47);
        numberAxis44.setAutoTickUnitSelection(true);
        java.awt.Paint paint51 = numberAxis44.getTickMarkPaint();
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList54 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint55 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean56 = objectList54.equals((java.lang.Object) paint55);
        org.jfree.chart.title.LegendGraphic legendGraphic57 = new org.jfree.chart.title.LegendGraphic(shape53, paint55);
        numberAxis44.setUpArrow(shape53);
        boolean boolean59 = color43.equals((java.lang.Object) shape53);
        numberAxis27.setLeftArrow(shape53);
        org.jfree.chart.entity.ChartEntity chartEntity63 = new org.jfree.chart.entity.ChartEntity(shape53, "UnitType.ABSOLUTE", "NOID");
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        java.awt.Paint paint12 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot6.setDomainAxis(1, categoryAxis14);
        java.awt.Stroke stroke16 = categoryPlot6.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        java.awt.Stroke stroke12 = numberAxis7.getAxisLineStroke();
        numberAxis0.setAxisLineStroke(stroke12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        double double2 = valueMarker1.getValue();
        java.awt.Paint paint3 = valueMarker1.getPaint();
        org.jfree.chart.util.ObjectList objectList5 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int7 = objectList5.indexOf((java.lang.Object) color6);
        valueMarker1.setLabelPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setNotify(false);
        boolean boolean11 = jFreeChart7.isBorderVisible();
        boolean boolean12 = jFreeChart7.getAntiAlias();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Stroke stroke14 = barRenderer0.lookupSeriesOutlineStroke(0);
        java.lang.Object obj15 = barRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Font font18 = legendTitle16.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        legendTitle16.setFrame((org.jfree.chart.block.BlockFrame) lineBorder19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle16.getLegendItemGraphicPadding();
        legendTitle16.setHeight((double) 500);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot16);
        barRenderer0.setPlot(categoryPlot16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer19.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        boolean boolean24 = barRenderer19.removeAnnotation(categoryAnnotation23);
        categoryPlot16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19, false);
        java.awt.Shape shape28 = barRenderer19.getSeriesShape(8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(shape28);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean(0, (java.lang.Boolean) false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Stroke stroke7 = null;
        barRenderer0.setSeriesOutlineStroke(8, stroke7, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator11);
        boolean boolean15 = barRenderer0.getItemCreateEntity(192, (int) (byte) 0);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 0);
        barRenderer0.setBaseShape(shape17, true);
        boolean boolean20 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        double double2 = size2D0.getWidth();
        size2D0.setHeight((double) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean9 = objectList7.equals((java.lang.Object) paint8);
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape6, paint8);
        boolean boolean11 = legendGraphic10.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic10.setMargin(rectangleInsets12);
        legendGraphic10.setPadding(2.0d, 0.0d, (double) (byte) 100, (double) 500);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendGraphic10.getShapeLocation();
        boolean boolean20 = size2D0.equals((java.lang.Object) legendGraphic10);
        size2D0.width = (-16777216);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) (-1), (double) 100L, rectangleAnchor8);
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D9);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets0.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType11, lengthAdjustmentType12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) lengthAdjustmentType11, jFreeChart14, 500, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 2.0f, (double) 1.0f);
        numberAxis2.setTickMarkOutsideLength((float) (-1L));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        numberAxis2.setTickMarkPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = numberAxis2.getUpArrow();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.equal(shape28, shape31);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(categoryAxis9);
        org.jfree.chart.plot.Plot plot11 = categoryPlot7.getParent();
        double[] doubleArray20 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray27 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray34 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray41 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray48 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray55 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray56 = new double[][] { doubleArray20, doubleArray27, doubleArray34, doubleArray41, doubleArray48, doubleArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset57);
        java.lang.Number number59 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset57);
        categoryPlot7.setDataset(categoryDataset57);
        java.lang.Comparable comparable61 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer62 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset57, comparable61);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-6.0d) + "'", number58.equals((-6.0d)));
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 600.0d + "'", number59.equals(600.0d));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot6.removeChangeListener(plotChangeListener11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis14.getCategoryLabelPositions();
        categoryAxis14.configure();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 3, font18);
        categoryAxis14.setCategoryMargin((double) 1);
        double double22 = categoryAxis14.getCategoryMargin();
        try {
            categoryPlot6.setDomainAxis((-1), categoryAxis14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle2.getPosition();
        axisState0.moveCursor((double) (-1), rectangleEdge6);
        axisState0.setMax((double) 0L);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        boolean boolean11 = barRenderer0.removeAnnotation(categoryAnnotation10);
        boolean boolean12 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Stroke stroke15 = barRenderer0.getSeriesOutlineStroke((-16711936));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(stroke15);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        java.awt.Image image11 = projectInfo7.getLogo();
        java.lang.String str12 = projectInfo7.getInfo();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        java.awt.Stroke stroke20 = barRenderer0.getSeriesOutlineStroke((int) (short) 0);
        java.lang.Object obj21 = barRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset5, 2);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset5, 16);
        java.lang.Comparable comparable10 = null;
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, comparable10, 3.0d, (int) '#');
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight((double) 0.0f);
        double double7 = rectangleInsets4.getTop();
        numberAxis0.setTickLabelInsets(rectangleInsets4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer9.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color14 = java.awt.Color.green;
        java.awt.Color color15 = color14.darker();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean18 = color15.equals((java.lang.Object) shape17);
        barRenderer9.setSeriesShape((int) '4', shape17);
        barRenderer9.setBaseCreateEntities(false, true);
        barRenderer9.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color29 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer9.setBasePaint((java.awt.Paint) color29, true);
        java.awt.Paint paint33 = barRenderer9.lookupSeriesPaint(8);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setUpperMargin((double) 10L);
        java.awt.Color color38 = java.awt.Color.green;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        numberAxis42.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer45);
        boolean boolean47 = numberAxis35.hasListener((java.util.EventListener) categoryPlot46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot46.getDataset();
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot46);
        org.jfree.chart.title.LegendTitle legendTitle50 = jFreeChart49.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer51 = legendTitle50.getItemContainer();
        java.awt.Font font52 = legendTitle50.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder53 = new org.jfree.chart.block.LineBorder();
        legendTitle50.setFrame((org.jfree.chart.block.BlockFrame) lineBorder53);
        java.awt.geom.Rectangle2D rectangle2D55 = legendTitle50.getBounds();
        barRenderer9.setBaseShape((java.awt.Shape) rectangle2D55);
        rectangleInsets4.trim(rectangle2D55);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(categoryDataset48);
        org.junit.Assert.assertNotNull(legendTitle50);
        org.junit.Assert.assertNotNull(blockContainer51);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_CENTER", font1, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textLine8);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        boolean boolean5 = textTitle0.getExpandToFitSpace();
        textTitle0.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        barRenderer0.notifyListeners(rendererChangeEvent19);
        java.awt.Paint paint22 = barRenderer0.lookupSeriesPaint(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot6.getRangeAxisEdge((int) ' ');
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 10, (int) (short) 100);
        double double21 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, (java.lang.Boolean) false);
        int int7 = barRenderer0.getRowCount();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        java.lang.String str12 = categoryPlot6.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        boolean boolean20 = categoryPlot19.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot19.getDomainAxisEdge(0);
        double double23 = categoryPlot19.getRangeCrosshairValue();
        boolean boolean24 = categoryPlot6.equals((java.lang.Object) categoryPlot19);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment28, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment26, verticalAlignment28, 0.0d, (double) (-1.0f));
        textTitle25.setTextAlignment(horizontalAlignment26);
        java.awt.Paint paint36 = textTitle25.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean38 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge37);
        textTitle25.setPosition(rectangleEdge37);
        textTitle25.setURLText("{0}");
        java.awt.Color color42 = java.awt.Color.lightGray;
        textTitle25.setBackgroundPaint((java.awt.Paint) color42);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color42);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setHeight((double) (-1L));
        java.awt.Paint paint9 = legendGraphic5.getOutlinePaint();
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = color10.darker();
        legendGraphic5.setLinePaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = legendGraphic5.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        textTitle20.draw(graphics2D21, rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle20.getPosition();
        axisState18.moveCursor((double) (-1), rectangleEdge24);
        axisCollection4.add((org.jfree.chart.axis.Axis) numberAxis5, rectangleEdge24);
        java.awt.Shape shape27 = numberAxis5.getRightArrow();
        java.awt.Color color28 = java.awt.Color.lightGray;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperMargin((double) 10L);
        java.awt.Color color32 = java.awt.Color.green;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke39 = null;
        barRenderer37.setSeriesOutlineStroke(0, stroke39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer37);
        java.awt.Stroke stroke42 = categoryPlot41.getDomainGridlineStroke();
        numberAxis29.setTickMarkStroke(stroke42);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean47 = barRenderer44.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color49 = java.awt.Color.green;
        java.awt.Color color50 = color49.darker();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean53 = color50.equals((java.lang.Object) shape52);
        barRenderer44.setSeriesShape((int) '4', shape52);
        barRenderer44.setBaseCreateEntities(false, true);
        barRenderer44.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color64 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer44.setBasePaint((java.awt.Paint) color64, true);
        java.awt.Paint paint68 = barRenderer44.lookupSeriesPaint(8);
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "HorizontalAlignment.CENTER", "RectangleEdge.TOP", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", shape27, (java.awt.Paint) color28, stroke42, paint68);
        int int70 = legendItem69.getSeriesIndex();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        java.lang.String str2 = datasetGroup0.getID();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setHorizontalAlignment(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        java.lang.Boolean boolean23 = barRenderer0.getSeriesVisible((int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(boolean23);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        numberAxis0.setVerticalTickLabels(true);
        try {
            numberAxis0.setAutoRangeMinimumSize((double) (-10420321));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean4 = categoryLabelWidthType2.equals((java.lang.Object) font3);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        int int7 = color6.getRed();
        int int8 = color6.getRGB();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", font3, (java.awt.Paint) color6);
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("RangeType.NEGATIVE", font3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16731648) + "'", int8 == (-16731648));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6, (float) '4');
        textLine3.addFragment(textFragment8);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean12 = categoryLabelWidthType10.equals((java.lang.Object) font11);
        boolean boolean13 = textFragment8.equals((java.lang.Object) font11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer15.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color20 = java.awt.Color.green;
        java.awt.Color color21 = color20.darker();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean24 = color21.equals((java.lang.Object) shape23);
        barRenderer15.setSeriesShape((int) '4', shape23);
        barRenderer15.setBaseCreateEntities(false, true);
        barRenderer15.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer15.setBasePaint((java.awt.Paint) color35, true);
        java.awt.Paint paint39 = barRenderer15.lookupSeriesPaint(8);
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("ThreadContext", font11, paint39);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Color color16 = java.awt.Color.green;
        jFreeChart15.setBorderPaint((java.awt.Paint) color16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart15.handleClick((-16731648), (-7839), chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot11.notifyListeners(plotChangeEvent13);
        boolean boolean15 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) (-1), (double) 100L, rectangleAnchor26);
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D27);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList31 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint32 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean33 = objectList31.equals((java.lang.Object) paint32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape30, paint32);
        boolean boolean35 = legendGraphic34.isLineVisible();
        java.awt.Paint paint36 = null;
        legendGraphic34.setFillPaint(paint36);
        java.awt.Shape shape38 = null;
        legendGraphic34.setLine(shape38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendGraphic34.getShapeLocation();
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor40);
        categoryPlot11.zoomDomainAxes((double) 2, plotRenderingInfo20, point2D41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo20.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = plotRenderingInfo20.getOwner();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNull(chartRenderingInfo44);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot6.getDataRange(valueAxis12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot6.setInsets(rectangleInsets14);
        categoryPlot6.setBackgroundAlpha((float) 0);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot6.getRangeAxis((-7839));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        boolean boolean7 = numberAxis0.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        boolean boolean10 = numberAxis0.isAutoRange();
        java.awt.Shape shape11 = numberAxis0.getLeftArrow();
        org.jfree.data.Range range12 = numberAxis0.getRange();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxis(0);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 0L);
        valueAxis10.setRightArrow(shape12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        boolean boolean20 = categoryPlot19.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        categoryPlot19.setFixedLegendItems(legendItemCollection21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot19.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot19.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot19.setDomainAxis(15, categoryAxis26, false);
        java.awt.Paint[] paintArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray32 = null;
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray29, paintArray30, paintArray31, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextOutlinePaint();
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = categoryPlot19.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot19.getFixedLegendItems();
        float float40 = categoryPlot19.getForegroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot19.getColumnRenderingOrder();
        categoryPlot6.setColumnRenderingOrder(sortOrder41);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(sortOrder41);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint5 = barRenderer0.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition(1, 2);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint10 = barRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape7, "TextBlockAnchor.TOP_CENTER");
        java.awt.Shape shape14 = chartEntity13.getArea();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint((-10420321), 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer0.getSeriesURLGenerator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryURLGenerator14);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot16.getDataset();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle20.getItemContainer();
        java.awt.Font font22 = legendTitle20.getItemFont();
        barRenderer0.setBaseItemLabelFont(font22, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator26 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        java.lang.Object obj27 = standardCategorySeriesLabelGenerator26.clone();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(192);
        java.lang.Object obj4 = keyedObjects0.getObject(0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj7 = textTitle6.clone();
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = color10.darker();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean14 = color11.equals((java.lang.Object) shape13);
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, (java.awt.Paint) color11, (float) (short) 0, 192, textMeasurer17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment21, verticalAlignment22, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment22, 0.0d, (double) (-1.0f));
        textTitle19.setTextAlignment(horizontalAlignment20);
        textBlock18.setLineAlignment(horizontalAlignment20);
        textTitle6.setTextAlignment(horizontalAlignment20);
        org.jfree.chart.util.ObjectList objectList33 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int35 = objectList33.indexOf((java.lang.Object) color34);
        textTitle6.setBackgroundPaint((java.awt.Paint) color34);
        keyedObjects0.addObject((java.lang.Comparable) (byte) 100, (java.lang.Object) color34);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean5 = objectList3.equals((java.lang.Object) axisSpace4);
        axisSpace4.setRight((double) 0.0f);
        axisSpace0.ensureAtLeast(axisSpace4);
        double double9 = axisSpace4.getLeft();
        axisSpace4.setBottom((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer19.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean23 = barRenderer19.isDrawBarOutline();
        boolean boolean24 = numberAxis14.equals((java.lang.Object) barRenderer19);
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) (-1), (double) 100L, rectangleAnchor29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis14.lengthToJava2D((double) 192, rectangle2D30, rectangleEdge31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = axisSpace4.reserved(rectangle2D30, rectangleEdge33);
        double double35 = axisSpace4.getBottom();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot6.removeChangeListener(plotChangeListener11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot6.setDomainAxis((int) 'a', categoryAxis14, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean14 = datasetRenderingOrder11.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setUpperMargin((double) 10L);
        java.awt.Paint paint18 = numberAxis15.getTickMarkPaint();
        boolean boolean19 = datasetRenderingOrder11.equals((java.lang.Object) paint18);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        barRenderer0.setItemMargin((double) 500);
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Color color23 = java.awt.Color.MAGENTA;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot16);
        barRenderer0.setPlot(categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        boolean boolean26 = categoryPlot25.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = null;
        categoryPlot25.setFixedLegendItems(legendItemCollection27);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot25.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot25.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke34 = null;
        barRenderer32.setSeriesOutlineStroke(0, stroke34);
        categoryPlot25.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer32, false);
        boolean boolean38 = categoryPlot25.isOutlineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder39);
        categoryPlot16.setDatasetRenderingOrder(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot6.getDomainAxisEdge(0);
        categoryPlot6.setAnchorValue((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart27.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer29 = legendTitle28.getItemContainer();
        java.awt.Font font30 = legendTitle28.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle28.getMargin();
        categoryPlot6.setInsets(rectangleInsets31, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNotNull(legendTitle28);
        org.junit.Assert.assertNotNull(blockContainer29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot6.axisChanged(axisChangeEvent19);
        org.jfree.chart.axis.Axis axis21 = axisChangeEvent19.getAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        axisChangeEvent19.setType(chartChangeEventType22);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(axis21);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle16.getItemContainer();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color23 = color22.darker();
        java.awt.Color color25 = java.awt.Color.green;
        java.awt.Color color26 = color25.darker();
        java.awt.Color color27 = java.awt.Color.getColor("hi!", color25);
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        float[] floatArray35 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray36 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray35);
        float[] floatArray37 = color23.getColorComponents(colorSpace28, floatArray35);
        legendTitle16.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = legendTitle16.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range14, (double) 100.0f);
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        double double18 = range17.getUpperBound();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        categoryPlot6.clearDomainAxes();
        categoryPlot6.mapDatasetToDomainAxis((int) '#', 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot11.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot11.getAxisOffset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        textTitle20.draw(graphics2D21, rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle20.getPosition();
        axisState18.moveCursor((double) (-1), rectangleEdge24);
        axisCollection4.add((org.jfree.chart.axis.Axis) numberAxis5, rectangleEdge24);
        java.awt.Shape shape27 = numberAxis5.getRightArrow();
        java.awt.Color color28 = java.awt.Color.lightGray;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperMargin((double) 10L);
        java.awt.Color color32 = java.awt.Color.green;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke39 = null;
        barRenderer37.setSeriesOutlineStroke(0, stroke39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer37);
        java.awt.Stroke stroke42 = categoryPlot41.getDomainGridlineStroke();
        numberAxis29.setTickMarkStroke(stroke42);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean47 = barRenderer44.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color49 = java.awt.Color.green;
        java.awt.Color color50 = color49.darker();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean53 = color50.equals((java.lang.Object) shape52);
        barRenderer44.setSeriesShape((int) '4', shape52);
        barRenderer44.setBaseCreateEntities(false, true);
        barRenderer44.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color64 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer44.setBasePaint((java.awt.Paint) color64, true);
        java.awt.Paint paint68 = barRenderer44.lookupSeriesPaint(8);
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "HorizontalAlignment.CENTER", "RectangleEdge.TOP", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", shape27, (java.awt.Paint) color28, stroke42, paint68);
        int int70 = legendItem69.getDatasetIndex();
        java.lang.Number[] numberArray73 = new java.lang.Number[] {};
        java.lang.Number[] numberArray74 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray73, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray75);
        org.jfree.data.general.PieDataset pieDataset78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset76, 2);
        legendItem69.setDataset((org.jfree.data.general.Dataset) categoryDataset76);
        org.jfree.data.general.Dataset dataset80 = legendItem69.getDataset();
        java.text.AttributedString attributedString81 = legendItem69.getAttributedLabel();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(pieDataset78);
        org.junit.Assert.assertNotNull(dataset80);
        org.junit.Assert.assertNull(attributedString81);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        double double13 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList16 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = objectList16.equals((java.lang.Object) paint17);
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape15, paint17);
        org.jfree.chart.block.BlockFrame blockFrame20 = legendGraphic19.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic19);
        legendGraphic19.setShapeOutlineVisible(true);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Color color29 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color30 = color29.darker();
        java.awt.Color color32 = java.awt.Color.green;
        java.awt.Color color33 = color32.darker();
        java.awt.Color color34 = java.awt.Color.getColor("hi!", color32);
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        float[] floatArray42 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray43 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray42);
        float[] floatArray44 = color30.getColorComponents(colorSpace35, floatArray42);
        java.awt.Color color45 = java.awt.Color.MAGENTA;
        float[] floatArray51 = new float[] { (short) 0, 2.0f, (short) 1, 500, 100 };
        float[] floatArray52 = color45.getColorComponents(floatArray51);
        float[] floatArray53 = color24.getComponents(colorSpace35, floatArray51);
        legendGraphic19.setFillPaint((java.awt.Paint) color24);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color24);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(blockFrame20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range27, 10.0d);
        double double33 = range32.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis34.setUpArrow(shape37);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape41, "", "hi!");
        numberAxis34.setDownArrow(shape41);
        numberAxis34.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.data.Range range49 = numberAxis34.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(range32, range49);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = rectangleConstraint50.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = rectangleConstraint51.toFixedHeight((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer3.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean12 = color9.equals((java.lang.Object) shape11);
        barRenderer3.setSeriesShape((int) '4', shape11);
        java.lang.Boolean boolean15 = barRenderer3.getSeriesCreateEntities(0);
        barRenderer3.setBaseSeriesVisible(false, false);
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color20 = color19.darker();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean23 = color20.equals((java.lang.Object) shape22);
        barRenderer3.setBaseFillPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot32.getRendererForDataset(categoryDataset36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot32.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke44 = null;
        barRenderer42.setSeriesOutlineStroke(0, stroke44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        java.awt.Stroke stroke47 = categoryPlot46.getDomainGridlineStroke();
        categoryPlot32.setDomainGridlineStroke(stroke47);
        barRenderer3.setSeriesOutlineStroke(10, stroke47);
        numberAxis0.setAxisLineStroke(stroke47);
        java.awt.Color color51 = java.awt.Color.BLUE;
        numberAxis0.setLabelPaint((java.awt.Paint) color51);
        try {
            numberAxis0.zoomRange((double) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer1.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean10 = color7.equals((java.lang.Object) shape9);
        barRenderer1.setSeriesShape((int) '4', shape9);
        barRenderer1.setBaseCreateEntities(false, true);
        barRenderer1.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer1.setBasePaint((java.awt.Paint) color21, true);
        java.awt.Paint paint25 = barRenderer1.lookupSeriesPaint(8);
        java.awt.Paint paint26 = barRenderer1.getBaseItemLabelPaint();
        boolean boolean27 = numberTickUnit0.equals((java.lang.Object) paint26);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis0.getTickLabelInsets();
        java.awt.Font font4 = null;
        try {
            numberAxis0.setLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        java.awt.Color color5 = color4.darker();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean8 = color5.equals((java.lang.Object) shape7);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color5, (float) (short) 0, 192, textMeasurer11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment16, 0.0d, (double) (-1.0f));
        textTitle13.setTextAlignment(horizontalAlignment14);
        textBlock12.setLineAlignment(horizontalAlignment14);
        textTitle0.setTextAlignment(horizontalAlignment14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer26.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color31 = java.awt.Color.green;
        java.awt.Color color32 = color31.darker();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean35 = color32.equals((java.lang.Object) shape34);
        barRenderer26.setSeriesShape((int) '4', shape34);
        java.lang.Boolean boolean38 = barRenderer26.getSeriesCreateEntities(0);
        barRenderer26.setBaseSeriesVisible(false, false);
        java.awt.Color color42 = java.awt.Color.green;
        java.awt.Color color43 = color42.darker();
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean46 = color43.equals((java.lang.Object) shape45);
        barRenderer26.setBaseFillPaint((java.awt.Paint) color43);
        textTitle0.setBackgroundPaint((java.awt.Paint) color43);
        java.awt.Graphics2D graphics2D49 = null;
        try {
            org.jfree.chart.util.Size2D size2D50 = textTitle0.arrange(graphics2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(boolean38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot6.getDataRange(valueAxis12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot6.setInsets(rectangleInsets14);
        categoryPlot6.setBackgroundAlpha((float) 0);
        java.awt.Paint paint18 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        double double2 = valueMarker1.getValue();
        java.awt.Paint paint3 = null;
        valueMarker1.setOutlinePaint(paint3);
        valueMarker1.setLabel("");
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.lang.Class<?> wildcardClass8 = font7.getClass();
        try {
            java.util.EventListener[] eventListenerArray9 = valueMarker1.getListeners((java.lang.Class) wildcardClass8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Font; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Font font18 = legendTitle16.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        legendTitle16.setFrame((org.jfree.chart.block.BlockFrame) lineBorder19);
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle16.getBounds();
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) (-1), (double) 100L, rectangleAnchor27);
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D28);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList32 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint33 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean34 = objectList32.equals((java.lang.Object) paint33);
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape31, paint33);
        boolean boolean36 = legendGraphic35.isLineVisible();
        java.awt.Paint paint37 = null;
        legendGraphic35.setFillPaint(paint37);
        java.awt.Shape shape39 = null;
        legendGraphic35.setLine(shape39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendGraphic35.getShapeLocation();
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor41);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot11.notifyListeners(plotChangeEvent13);
        boolean boolean15 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot11.getRenderer((int) (short) 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }
}

