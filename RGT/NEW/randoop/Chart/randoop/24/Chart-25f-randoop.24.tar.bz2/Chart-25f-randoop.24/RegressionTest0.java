import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke4, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (-1.0f), (float) (byte) 0, textAnchor4, (double) 10L, textAnchor6);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int3 = java.awt.Color.HSBtoRGB((float) '4', 100.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, 100.0f, (float) 1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Stroke stroke4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke4, rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        float[] floatArray4 = new float[] { 0.0f, 1.0f };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font1, (java.awt.Paint) color2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.CENTER" + "'", str1.equals("ItemLabelAnchor.CENTER"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.0d, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.CENTER", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            barRenderer0.setSeriesOutlinePaint((int) (short) -1, (java.awt.Paint) color2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        axisSpace0.setLeft((double) (short) 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.color.ColorSpace colorSpace4 = null;
        float[] floatArray8 = new float[] { (short) 1, (short) -1, (-1) };
        try {
            float[] floatArray9 = color3.getComponents(colorSpace4, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.green;
        float[] floatArray4 = new float[] { 100, (short) 0, 1L };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        float[] floatArray2 = new float[] { (byte) 100 };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) ' ');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 10, 1.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3, 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList8 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = objectList8.equals((java.lang.Object) paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape7, paint9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.trimHeight((double) 0.0f);
        try {
            org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("", font2, paint9, rectangleEdge12, horizontalAlignment13, verticalAlignment14, rectangleInsets15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (short) 10, (double) 2.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        categoryItemRendererState1.setBarWidth((double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isRangeCrosshairLockedOnData();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            barRenderer0.drawOutline(graphics2D6, categoryPlot13, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            categoryPlot6.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot6.handleClick((int) ' ', (int) 'a', plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) -1, 0.0f, (double) 10, (float) 100, 0.0f);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10, (float) (short) 100, textAnchor4, (double) (byte) 1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("hi!", (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setMaximumBarWidth((double) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.CENTER", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Shape shape14 = null;
        barRenderer0.setSeriesShape((int) (short) 1, shape14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer4.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean9 = barRenderer4.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape12 = barRenderer4.getItemShape((int) (short) 1, 100);
        java.awt.Stroke stroke13 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", "ItemLabelAnchor.CENTER", "", shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot6.getRenderer();
        try {
            categoryPlot6.mapDatasetToRangeAxis((-16777216), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer4.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = color9.darker();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean13 = color10.equals((java.lang.Object) shape12);
        barRenderer4.setSeriesShape((int) '4', shape12);
        java.awt.Stroke stroke15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color16);
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.CENTER", "hi!", "TextBlockAnchor.TOP_CENTER", shape12, stroke15, (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) boolean5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) (-1L), (float) '4', 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, (double) (-1), (double) 100L, rectangleAnchor20);
        try {
            jFreeChart15.draw(graphics2D16, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        try {
            barRenderer0.setSeriesItemLabelsVisible((-16777216), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = numberAxis2.getLabelURL();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.Plot plot9 = null;
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (-1), (double) 100L, rectangleAnchor13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        axisSpace16.setTop((double) 10);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace19 = numberAxis2.reserveSpace(graphics2D8, plot9, rectangle2D14, rectangleEdge15, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis4.setUpArrow(shape7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape11, "", "hi!");
        numberAxis4.setDownArrow(shape11);
        java.awt.Stroke stroke16 = null;
        java.awt.Color color17 = java.awt.Color.green;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "", "TextBlockAnchor.TOP_CENTER", "DatasetRenderingOrder.REVERSE", shape11, stroke16, (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2, (float) '4');
        java.awt.color.ColorSpace colorSpace5 = null;
        float[] floatArray10 = new float[] { 1.0f, (short) 1, 2.0f, 192 };
        try {
            float[] floatArray11 = color2.getColorComponents(colorSpace5, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray5 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        try {
            java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 2.0f, (double) 10, (double) 8, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot12.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer21.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean25 = barRenderer21.isDrawBarOutline();
        boolean boolean26 = numberAxis16.equals((java.lang.Object) barRenderer21);
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) (-1), (double) 100L, rectangleAnchor31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis16.lengthToJava2D((double) 192, rectangle2D32, rectangleEdge33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.axis.AxisSpace axisSpace36 = new org.jfree.chart.axis.AxisSpace();
        axisSpace36.setTop((double) 10);
        org.jfree.chart.util.ObjectList objectList39 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean41 = objectList39.equals((java.lang.Object) axisSpace40);
        axisSpace40.setRight((double) 0.0f);
        axisSpace36.ensureAtLeast(axisSpace40);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = numberAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot12, rectangle2D32, rectangleEdge35, axisSpace40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Stroke stroke11 = null;
        try {
            barRenderer0.setBaseStroke(stroke11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) (byte) 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) '4');
        textLine1.addFragment(textFragment6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Shape shape16 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D10, 1.0f, (float) '4', textAnchor13, (double) 0.0f, textAnchor15);
        try {
            float float17 = textFragment6.calculateBaselineOffset(graphics2D8, textAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.TOP_CENTER", graphics2D1, (double) 1, (float) (short) 100, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot15.getRangeMarkers(layer18);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Color color16 = java.awt.Color.green;
        jFreeChart15.setBorderPaint((java.awt.Paint) color16);
        java.awt.Paint paint18 = null;
        jFreeChart15.setBackgroundPaint(paint18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("DatasetRenderingOrder.REVERSE", graphics2D1, 100.0f, 0.0f, textAnchor4, (double) 100L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_CENTER", font1, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str12 = textBlockAnchor11.toString();
        java.lang.String str13 = textBlockAnchor11.toString();
        try {
            textBlock7.draw(graphics2D8, (float) 1, 1.0f, textBlockAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str12.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str13.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot6.addDomainMarker((-16777216), categoryMarker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean16 = jFreeChart15.isBorderVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        try {
            jFreeChart15.plotChanged(plotChangeEvent17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, (float) (byte) 0, (int) 'a', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) '4');
        textLine1.addFragment(textFragment6);
        java.lang.Object obj8 = null;
        boolean boolean9 = textFragment6.equals(obj8);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean28 = barRenderer25.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean30 = barRenderer25.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer31 = barRenderer25.getGradientPaintTransformer();
        barRenderer14.setGradientPaintTransformer(gradientPaintTransformer31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = null;
        try {
            barRenderer14.setSeriesURLGenerator((int) (short) -1, categoryURLGenerator34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer31);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean16 = jFreeChart15.isBorderVisible();
        boolean boolean17 = jFreeChart15.isNotify();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer26.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean30 = barRenderer26.isDrawBarOutline();
        boolean boolean31 = numberAxis21.equals((java.lang.Object) barRenderer26);
        org.jfree.chart.util.Size2D size2D33 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) (-1), (double) 100L, rectangleAnchor36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = numberAxis21.lengthToJava2D((double) 192, rectangle2D37, rectangleEdge38);
        java.awt.geom.Point2D point2D40 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        try {
            jFreeChart15.draw(graphics2D18, rectangle2D37, point2D40, chartRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot6.getRangeAxisLocation((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer16.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean20 = barRenderer16.isDrawBarOutline();
        boolean boolean21 = numberAxis11.equals((java.lang.Object) barRenderer16);
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) (-1), (double) 100L, rectangleAnchor26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis11.lengthToJava2D((double) 192, rectangle2D27, rectangleEdge28);
        try {
            categoryPlot6.drawOutline(graphics2D8, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = barRenderer14.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        numberAxis2.zoomRange((double) (-1.0f), (double) 100.0f);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("[size=1]", graphics2D1, (float) (byte) 100, (float) (short) 0, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3, 0.0f);
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Color color7 = java.awt.Color.green;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_CENTER", font3, (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer13 = new org.jfree.chart.text.G2TextMeasurer(graphics2D12);
        try {
            org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("DatasetRenderingOrder.REVERSE", font1, (java.awt.Paint) color7, 100.0f, 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        numberAxis0.configure();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer10.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color15 = java.awt.Color.green;
        java.awt.Color color16 = color15.darker();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean19 = color16.equals((java.lang.Object) shape18);
        barRenderer10.setSeriesShape((int) '4', shape18);
        java.lang.Boolean boolean22 = barRenderer10.getSeriesCreateEntities(0);
        barRenderer10.setBaseSeriesVisible(false, false);
        categoryPlot6.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets28);
        double double31 = rectangleInsets28.extendHeight((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 6.0d + "'", double31 == 6.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3, 0.0f);
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) font0, (java.lang.Object) "");
        org.junit.Assert.assertNotNull(font0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 10, 0.0f, textAnchor4, (double) 1L, 2.0f, 52.0f);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke14 = null;
        barRenderer12.setSeriesOutlineStroke(0, stroke14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        java.awt.Stroke stroke17 = categoryPlot16.getDomainGridlineStroke();
        legendGraphic5.setOutlineStroke(stroke17);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean2 = rangeType0.equals((java.lang.Object) rectangleInsets1);
        java.lang.String str3 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis5.setUpArrow(shape8);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "", "hi!");
        numberAxis5.setDownArrow(shape12);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer20.getItemLabelPaint((-1), (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        boolean boolean31 = categoryPlot30.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = null;
        categoryPlot30.setFixedLegendItems(legendItemCollection32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot30.getRendererForDataset(categoryDataset34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot30.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke42 = null;
        barRenderer40.setSeriesOutlineStroke(0, stroke42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer40);
        java.awt.Stroke stroke45 = categoryPlot44.getDomainGridlineStroke();
        categoryPlot30.setDomainGridlineStroke(stroke45);
        java.awt.Shape shape48 = null;
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        numberAxis51.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer54);
        boolean boolean56 = categoryPlot55.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = null;
        categoryPlot55.setFixedLegendItems(legendItemCollection57);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = categoryPlot55.getRendererForDataset(categoryDataset59);
        org.jfree.chart.axis.AxisLocation axisLocation61 = categoryPlot55.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke67 = null;
        barRenderer65.setSeriesOutlineStroke(0, stroke67);
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, valueAxis64, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer65);
        java.awt.Stroke stroke70 = categoryPlot69.getDomainGridlineStroke();
        categoryPlot55.setDomainGridlineStroke(stroke70);
        org.jfree.chart.renderer.category.BarRenderer barRenderer72 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean75 = barRenderer72.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean76 = barRenderer72.isDrawBarOutline();
        java.awt.Paint paint77 = barRenderer72.getBasePaint();
        try {
            org.jfree.chart.LegendItem legendItem78 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "{0}", "TextBlockAnchor.TOP_CENTER", false, shape12, true, (java.awt.Paint) color18, true, paint23, stroke45, true, shape48, stroke70, paint77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNull(categoryItemRenderer60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot11.getDataset();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            boolean boolean15 = categoryPlot11.removeAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean11 = categoryPlot6.equals((java.lang.Object) shape10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.RenderingHints renderingHints8 = null;
        try {
            jFreeChart7.setRenderingHints(renderingHints8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            java.awt.Color color1 = java.awt.Color.decode("[size=1]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"[size=1]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("[size=1]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setHeight((double) (-1L));
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedHeight((double) (short) -1);
        try {
            org.jfree.chart.util.Size2D size2D16 = legendGraphic5.arrange(graphics2D9, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer19.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean23 = barRenderer19.isDrawBarOutline();
        boolean boolean24 = numberAxis14.equals((java.lang.Object) barRenderer19);
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) (-1), (double) 100L, rectangleAnchor29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis14.lengthToJava2D((double) 192, rectangle2D30, rectangleEdge31);
        try {
            categoryPlot6.drawBackground(graphics2D11, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.TextTitle textTitle16 = null;
        jFreeChart15.setTitle(textTitle16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart15.createBufferedImage((-1), 0, (double) 15, (double) (byte) 10, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint12 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        java.lang.String str2 = numberTickUnit0.toString();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=1]" + "'", str2.equals("[size=1]"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean2 = axisLocation0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        barRenderer3.setBaseCreateEntities(false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_CENTER", font1, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        double double15 = range14.getUpperBound();
        try {
            org.jfree.data.Range range18 = org.jfree.data.Range.expand(range14, (double) 0, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.6777215E7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: AxisLocation.TOP_OR_LEFT incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        numberAxis14.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot27.getRenderer();
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) categoryPlot27);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) (-1), (double) 100L, rectangleAnchor34);
        categoryPlot27.drawBackgroundImage(graphics2D30, rectangle2D35);
        try {
            categoryPlot6.drawBackground(graphics2D11, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight((double) 0.0f);
        double double7 = rectangleInsets4.getTop();
        numberAxis0.setTickLabelInsets(rectangleInsets4);
        double double10 = rectangleInsets4.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        barRenderer0.setSeriesOutlineStroke(10, stroke44);
        double double47 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setTextAlignment(horizontalAlignment1);
        textTitle0.setNotify(false);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        numberAxis2.setAutoTickUnitSelection(false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryURLGenerator16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { (byte) 1, 2 };
        double[] doubleArray12 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray19 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray26 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray33 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray40 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray47 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray48 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray48);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray3, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        boolean boolean13 = numberAxis0.isVerticalTickLabels();
        java.awt.Stroke stroke14 = numberAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer10.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color15 = java.awt.Color.green;
        java.awt.Color color16 = color15.darker();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean19 = color16.equals((java.lang.Object) shape18);
        barRenderer10.setSeriesShape((int) '4', shape18);
        java.lang.Boolean boolean22 = barRenderer10.getSeriesCreateEntities(0);
        barRenderer10.setBaseSeriesVisible(false, false);
        categoryPlot6.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10, false);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke33 = null;
        barRenderer31.setSeriesOutlineStroke(0, stroke33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer31);
        java.awt.Stroke stroke36 = categoryPlot35.getDomainGridlineStroke();
        barRenderer10.setBaseStroke(stroke36, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean43 = barRenderer40.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color45 = java.awt.Color.green;
        java.awt.Color color46 = color45.darker();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean49 = color46.equals((java.lang.Object) shape48);
        barRenderer40.setSeriesShape((int) '4', shape48);
        java.lang.Boolean boolean52 = barRenderer40.getSeriesCreateEntities(0);
        barRenderer40.setBaseSeriesVisible(false, false);
        java.awt.Color color56 = java.awt.Color.green;
        java.awt.Color color57 = color56.darker();
        java.awt.Shape shape59 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean60 = color57.equals((java.lang.Object) shape59);
        barRenderer40.setBaseFillPaint((java.awt.Paint) color57);
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        numberAxis65.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, (org.jfree.chart.axis.ValueAxis) numberAxis65, categoryItemRenderer68);
        boolean boolean70 = categoryPlot69.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection71 = null;
        categoryPlot69.setFixedLegendItems(legendItemCollection71);
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = categoryPlot69.getRendererForDataset(categoryDataset73);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot69.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset76 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = null;
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer79 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke81 = null;
        barRenderer79.setSeriesOutlineStroke(0, stroke81);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset76, categoryAxis77, valueAxis78, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer79);
        java.awt.Stroke stroke84 = categoryPlot83.getDomainGridlineStroke();
        categoryPlot69.setDomainGridlineStroke(stroke84);
        barRenderer40.setSeriesOutlineStroke(10, stroke84);
        boolean boolean87 = barRenderer40.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer89 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean92 = barRenderer89.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean93 = barRenderer89.isDrawBarOutline();
        java.awt.Paint paint94 = barRenderer89.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition97 = barRenderer89.getNegativeItemLabelPosition(1, 2);
        barRenderer40.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition97);
        try {
            barRenderer10.setSeriesNegativeItemLabelPosition((-16777216), itemLabelPosition97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(boolean52);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(categoryItemRenderer74);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(paint94);
        org.junit.Assert.assertNotNull(itemLabelPosition97);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        categoryPlot6.setBackgroundAlpha((float) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1.0d, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        barRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        boolean boolean17 = barRenderer0.getBaseSeriesVisible();
        try {
            barRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString((double) 10L);
        java.lang.String str4 = numberTickUnit0.valueToString((double) (byte) 100);
        int int5 = numberTickUnit0.getMinorTickCount();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Color color2 = color1.darker();
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color1);
        int int4 = color1.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        boolean boolean13 = datasetRenderingOrder11.equals((java.lang.Object) color12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        double double10 = rectangleInsets7.calculateLeftOutset((-1.0d));
        double double12 = rectangleInsets7.calculateTopOutset((double) (short) 1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int3 = java.awt.Color.HSBtoRGB(0.5f, (float) 192, (float) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10420321) + "'", int3 == (-10420321));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        java.lang.String str12 = categoryPlot6.getNoDataMessage();
        categoryPlot6.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean2 = objectList0.equals((java.lang.Object) axisSpace1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            axisSpace1.add(0.0d, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Paint paint16 = jFreeChart15.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer4.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean9 = barRenderer4.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape12 = barRenderer4.getItemShape((int) (short) 1, 100);
        java.awt.Color color13 = java.awt.Color.PINK;
        try {
            org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.CENTER", "CategoryAnchor.MIDDLE", "10", shape12, (java.awt.Paint) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.TickType tickType4 = null;
        org.jfree.chart.axis.TickType tickType7 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick(tickType7, (double) (short) 0, "hi!", textAnchor10, textAnchor11, (double) (byte) 100);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D15, 1.0f, (float) '4', textAnchor18, (double) 0.0f, textAnchor20);
        org.jfree.chart.axis.NumberTick numberTick23 = new org.jfree.chart.axis.NumberTick(tickType4, (double) (short) 1, "ItemLabelAnchor.CENTER", textAnchor11, textAnchor20, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.Shape shape26 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("[size=1]", graphics2D1, 0.0f, (float) 15, textAnchor11, (double) 10L, textAnchor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle16.getItemContainer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setUpperMargin((double) 10L);
        java.awt.Color color24 = java.awt.Color.green;
        numberAxis21.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = numberAxis21.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot32.getDataset();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot32);
        java.awt.Color color36 = java.awt.Color.blue;
        categoryPlot32.setBackgroundPaint((java.awt.Paint) color36);
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textLine40.calculateDimensions(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 0.0f, rectangleAnchor45);
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color36.createContext(colorModel38, rectangle39, rectangle2D46, affineTransform47, renderingHints48);
        org.jfree.chart.util.ShapeList shapeList50 = new org.jfree.chart.util.ShapeList();
        try {
            java.lang.Object obj51 = blockContainer18.draw(graphics2D19, rectangle2D46, (java.lang.Object) shapeList50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(paintContext49);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(6.0d, (double) (-10420321));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.0) <= upper (-1.0420321E7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 192, 0.0d, 100.0d, (double) 'a');
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = numberAxis2.getLabelURL();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setUpperMargin((double) 10L);
        java.awt.Color color11 = java.awt.Color.green;
        numberAxis8.setTickLabelPaint((java.awt.Paint) color11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        boolean boolean20 = numberAxis8.hasListener((java.util.EventListener) categoryPlot19);
        double double21 = numberAxis8.getAutoRangeMinimumSize();
        org.jfree.data.Range range22 = numberAxis8.getDefaultAutoRange();
        numberAxis2.setRangeWithMargins(range22);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-8d + "'", double21 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        try {
            numberAxis0.setRange(3.0d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 10L);
        double double23 = numberAxis2.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-4.725d) + "'", double23 == (-4.725d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str16 = numberAxis0.getLabel();
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray19, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis24.setUpArrow(shape27);
        boolean boolean29 = numberAxis24.getAutoRangeIncludesZero();
        boolean boolean30 = numberAxis24.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean34 = barRenderer31.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean36 = barRenderer31.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = barRenderer31.getGradientPaintTransformer();
        barRenderer31.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer31);
        numberAxis24.setFixedDimension(0.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis24.setStandardTickUnits(tickUnitSource44);
        numberAxis0.setStandardTickUnits(tickUnitSource44);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(gradientPaintTransformer37);
        org.junit.Assert.assertNotNull(tickUnitSource44);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D7 = labelBlock1.arrange(graphics2D2, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        boolean boolean4 = blockBorder1.equals((java.lang.Object) itemLabelAnchor3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range27, 10.0d);
        java.lang.String str33 = range27.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Range[0.0,1.0]" + "'", str33.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.axis.TickType tickType1 = null;
        org.jfree.chart.axis.TickType tickType4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType4, (double) (short) 0, "hi!", textAnchor7, textAnchor8, (double) (byte) 100);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Shape shape18 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D12, 1.0f, (float) '4', textAnchor15, (double) 0.0f, textAnchor17);
        org.jfree.chart.axis.NumberTick numberTick20 = new org.jfree.chart.axis.NumberTick(tickType1, (double) (short) 1, "ItemLabelAnchor.CENTER", textAnchor8, textAnchor17, (double) 0.0f);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNull(shape18);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        float float4 = numberAxis0.getTickMarkOutsideLength();
        numberAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = null;
        barRenderer16.setSeriesOutlineStroke(0, stroke18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Stroke stroke21 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot6.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot6.isRangeZoomable();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot6.setRangeGridlineStroke(stroke24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot6.getRenderer(100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(categoryItemRenderer27);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) '4');
        textLine1.addFragment(textFragment6);
        java.awt.Font font8 = textFragment6.getFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor11);
        try {
            float float13 = textFragment6.calculateBaselineOffset(graphics2D9, textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Color color7 = java.awt.Color.green;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        boolean boolean16 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot15.getDataset();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Color color19 = java.awt.Color.blue;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = textLine23.calculateDimensions(graphics2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) '#', (double) 0.0f, rectangleAnchor28);
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color19.createContext(colorModel21, rectangle22, rectangle2D29, affineTransform30, renderingHints31);
        try {
            blockContainer1.draw(graphics2D2, (java.awt.geom.Rectangle2D) rectangle22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(paintContext32);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray5 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.blue;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color14);
        numberAxis9.setAutoRangeStickyZero(false);
        boolean boolean18 = defaultDrawingSupplier6.equals((java.lang.Object) false);
        try {
            java.awt.Stroke stroke19 = defaultDrawingSupplier6.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (-1.0f));
        org.jfree.chart.block.CenterArrangement centerArrangement9 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean28 = jFreeChart27.isBorderVisible();
        jFreeChart27.setTitle("10");
        textTitle11.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        columnArrangement8.add((org.jfree.chart.block.Block) blockContainer10, (java.lang.Object) jFreeChart27);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis36, categoryItemRenderer39);
        numberAxis36.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis45, categoryItemRenderer48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot49.getRenderer();
        numberAxis36.setPlot((org.jfree.chart.plot.Plot) categoryPlot49);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.util.Size2D size2D53 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D57 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, (double) (-1), (double) 100L, rectangleAnchor56);
        categoryPlot49.drawBackgroundImage(graphics2D52, rectangle2D57);
        java.awt.Color color62 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color63 = color62.darker();
        java.awt.Color color65 = java.awt.Color.green;
        java.awt.Color color66 = color65.darker();
        java.awt.Color color67 = java.awt.Color.getColor("hi!", color65);
        java.awt.color.ColorSpace colorSpace68 = color67.getColorSpace();
        float[] floatArray75 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray76 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray75);
        float[] floatArray77 = color63.getColorComponents(colorSpace68, floatArray75);
        try {
            java.lang.Object obj78 = blockContainer10.draw(graphics2D33, rectangle2D57, (java.lang.Object) floatArray75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(colorSpace68);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertNotNull(floatArray77);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        int int16 = barRenderer0.getPassCount();
        java.awt.Paint paint17 = barRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Font font12 = barRenderer0.getSeriesItemLabelFont((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color1 = java.awt.Color.getColor("TextBlockAnchor.TOP_CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        double double3 = numberAxis0.getLabelAngle();
        try {
            numberAxis0.setRange((double) 2.0f, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer7.getBaseItemLabelGenerator();
        boolean boolean16 = barRenderer7.getItemVisible(0, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) 10);
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.clone(shape1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 100, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        numberAxis12.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot25.getRenderer();
        numberAxis12.setPlot((org.jfree.chart.plot.Plot) categoryPlot25);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) (-1), (double) 100L, rectangleAnchor32);
        categoryPlot25.drawBackgroundImage(graphics2D28, rectangle2D33);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) (-1), (double) 100L, rectangleAnchor40);
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        try {
            jFreeChart7.draw(graphics2D9, rectangle2D33, point2D42, chartRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(point2D42);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        java.awt.Shape shape9 = null;
        legendGraphic5.setLine(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic5.getShapeLocation();
        boolean boolean12 = legendGraphic5.isLineVisible();
        boolean boolean13 = legendGraphic5.isShapeFilled();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        java.awt.Paint paint12 = barRenderer0.getItemPaint((int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer5.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = color10.darker();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean14 = color11.equals((java.lang.Object) shape13);
        barRenderer5.setSeriesShape((int) '4', shape13);
        java.lang.Boolean boolean17 = barRenderer5.getSeriesCreateEntities(0);
        java.awt.Stroke stroke19 = barRenderer5.lookupSeriesOutlineStroke((int) '#');
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RangeType.NEGATIVE", "100", shape4, stroke19, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean2 = objectList0.equals((java.lang.Object) paint1);
        java.awt.Image image6 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image6, "hi!", "", "hi!");
        projectInfo10.addOptionalLibrary("hi!");
        boolean boolean13 = objectList0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        double double2 = size2D0.getWidth();
        size2D0.setHeight((double) 10);
        double double5 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Color color7 = java.awt.Color.green;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        boolean boolean16 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot15.getDataset();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Color color19 = java.awt.Color.blue;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = textLine23.calculateDimensions(graphics2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) '#', (double) 0.0f, rectangleAnchor28);
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color19.createContext(colorModel21, rectangle22, rectangle2D29, affineTransform30, renderingHints31);
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = textLine33.calculateDimensions(graphics2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) '#', (double) 0.0f, rectangleAnchor38);
        try {
            java.awt.geom.Rectangle2D rectangle2D40 = axisSpace0.shrink((java.awt.geom.Rectangle2D) rectangle22, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot6.getRangeAxis();
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color28 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("", font27, (java.awt.Paint) color28, (float) '4');
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(valueAxis25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesStroke();
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        int int11 = barRenderer0.getPassCount();
        barRenderer0.setItemMargin((double) 0.5f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer3.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean12 = color9.equals((java.lang.Object) shape11);
        barRenderer3.setSeriesShape((int) '4', shape11);
        java.lang.Boolean boolean15 = barRenderer3.getSeriesCreateEntities(0);
        barRenderer3.setBaseSeriesVisible(false, false);
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color20 = color19.darker();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean23 = color20.equals((java.lang.Object) shape22);
        barRenderer3.setBaseFillPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot32.getRendererForDataset(categoryDataset36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot32.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke44 = null;
        barRenderer42.setSeriesOutlineStroke(0, stroke44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        java.awt.Stroke stroke47 = categoryPlot46.getDomainGridlineStroke();
        categoryPlot32.setDomainGridlineStroke(stroke47);
        barRenderer3.setSeriesOutlineStroke(10, stroke47);
        numberAxis0.setAxisLineStroke(stroke47);
        java.awt.Color color51 = java.awt.Color.BLUE;
        numberAxis0.setLabelPaint((java.awt.Paint) color51);
        java.lang.String str53 = numberAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 'a', (double) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color6 = java.awt.Color.MAGENTA;
        float[] floatArray12 = new float[] { (short) 0, 2.0f, (short) 1, 500, 100 };
        float[] floatArray13 = color6.getColorComponents(floatArray12);
        float[] floatArray14 = color0.getComponents(colorSpace5, floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        projectInfo7.setLicenceName("[size=1]");
        projectInfo7.setCopyright("TextBlockAnchor.TOP_CENTER");
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        java.awt.Shape shape9 = null;
        legendGraphic5.setLine(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic5.getShapeLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic5.getShapeLocation();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str14 = textBlockAnchor13.toString();
        java.lang.String str15 = textBlockAnchor13.toString();
        java.lang.String str16 = textBlockAnchor13.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        boolean boolean19 = textBlockAnchor13.equals((java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str14.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str15.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str16.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        java.lang.Object obj4 = null;
        boolean boolean5 = textLine1.equals(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("HorizontalAlignment.CENTER", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        boolean boolean14 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer13.getSeriesNegativeItemLabelPosition((-16777216));
        boolean boolean22 = barRenderer13.isSeriesItemLabelsVisible((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot6.zoomDomainAxes(1.0E-8d, (double) (-1L), plotRenderingInfo21, point2D22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) (-1), (double) 100L, rectangleAnchor28);
        try {
            categoryPlot6.drawOutline(graphics2D24, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textLine19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', (double) 0.0f, rectangleAnchor24);
        try {
            blockContainer17.draw(graphics2D18, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj1 = null;
        boolean boolean2 = chartChangeEventType0.equals(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        numberAxis0.setNegativeArrowVisible(false);
        java.awt.Stroke stroke16 = numberAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setHeight((double) (-1L));
        java.awt.Paint paint9 = legendGraphic5.getOutlinePaint();
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = color10.darker();
        legendGraphic5.setLinePaint((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendGraphic5.setShapeAnchor(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType1 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean3 = categoryLabelWidthType1.equals((java.lang.Object) font2);
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer8 = new org.jfree.chart.text.G2TextMeasurer(graphics2D7);
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("[size=1]", font2, (java.awt.Paint) color4, (float) '4', 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelWidthType1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer13.getSeriesNegativeItemLabelPosition((-16777216));
        barRenderer13.setItemMargin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleEdge.TOP");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge7);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge7);
        numberAxis2.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        boolean boolean3 = numberTickUnit0.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getToolTipText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer3.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Paint paint11 = barRenderer3.getItemPaint((int) (byte) 0, 192);
        labelBlock1.setPaint(paint11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Image image17 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo21 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image17, "hi!", "", "hi!");
        org.jfree.data.Range range23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint24.toUnconstrainedWidth();
        boolean boolean26 = projectInfo21.equals((java.lang.Object) rectangleConstraint24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer37);
        boolean boolean39 = numberAxis27.hasListener((java.util.EventListener) categoryPlot38);
        double double40 = numberAxis27.getAutoRangeMinimumSize();
        org.jfree.data.Range range41 = numberAxis27.getDefaultAutoRange();
        java.lang.Object obj42 = null;
        boolean boolean43 = range41.equals(obj42);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint24.toRangeHeight(range41);
        try {
            org.jfree.chart.util.Size2D size2D45 = labelBlock1.arrange(graphics2D13, rectangleConstraint44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0E-8d + "'", double40 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isRangeCrosshairLockedOnData();
        java.awt.Paint paint15 = categoryPlot13.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setUpperMargin((double) 10L);
        java.awt.Color color20 = java.awt.Color.green;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        boolean boolean29 = numberAxis17.hasListener((java.util.EventListener) categoryPlot28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot28.getDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot28);
        categoryPlot13.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        numberAxis37.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        numberAxis46.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis46, categoryItemRenderer49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot50.getRenderer();
        numberAxis37.setPlot((org.jfree.chart.plot.Plot) categoryPlot50);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.util.Size2D size2D54 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D54, (double) (-1), (double) 100L, rectangleAnchor57);
        categoryPlot50.drawBackgroundImage(graphics2D53, rectangle2D58);
        try {
            barRenderer0.drawDomainMarker(graphics2D6, categoryPlot13, categoryAxis33, categoryMarker34, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) "10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot21);
        boolean boolean23 = jFreeChart22.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = jFreeChart22.getCategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        categoryPlot24.configureDomainAxes();
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = textLine27.calculateDimensions(graphics2D28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) '#', (double) 0.0f, rectangleAnchor32);
        try {
            barRenderer0.drawOutline(graphics2D14, categoryPlot24, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(categoryPlot24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean2 = axisLocation0.equals((java.lang.Object) true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot6.getLegendItems();
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("100", "10");
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(192);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        axisState0.cursorDown((double) (-1));
        axisState0.cursorDown((double) 100);
        axisState0.cursorRight((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 2.0f, (double) 'a');
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.lang.Class<?> wildcardClass2 = font1.getClass();
        java.net.URL uRL3 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(uRL3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        categoryPlot6.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot6.getRangeMarkers(layer13);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6, (float) '4');
        textLine3.addFragment(textFragment8);
        java.awt.Font font10 = textFragment8.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        boolean boolean18 = categoryPlot17.isRangeCrosshairLockedOnData();
        java.awt.Paint paint19 = categoryPlot17.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font10, paint19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer21.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.darker();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean30 = color27.equals((java.lang.Object) shape29);
        barRenderer21.setSeriesShape((int) '4', shape29);
        java.lang.Boolean boolean33 = barRenderer21.getSeriesCreateEntities(0);
        barRenderer21.setBaseSeriesVisible(false, false);
        java.awt.Color color37 = java.awt.Color.green;
        java.awt.Color color38 = color37.darker();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean41 = color38.equals((java.lang.Object) shape40);
        barRenderer21.setBaseFillPaint((java.awt.Paint) color38);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer46 = new org.jfree.chart.text.G2TextMeasurer(graphics2D45);
        try {
            org.jfree.chart.text.TextBlock textBlock47 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", font10, (java.awt.Paint) color38, 0.95f, (int) (short) 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        int int9 = color7.getGreen();
        int int10 = color7.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(0.0d, 6.0d, 0.2d, (double) (byte) -1, (java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle0.getTextAlignment();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean18 = barRenderer14.isDrawBarOutline();
        boolean boolean19 = numberAxis9.equals((java.lang.Object) barRenderer14);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (-1), (double) 100L, rectangleAnchor24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis9.lengthToJava2D((double) 192, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis28.setUpArrow(shape31);
        numberAxis28.setFixedDimension((double) '#');
        java.lang.Object obj35 = textTitle0.draw(graphics2D6, rectangle2D25, (java.lang.Object) numberAxis28);
        java.lang.String str36 = textTitle0.getText();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        axisSpace2.setTop((double) 10);
        java.lang.String str5 = axisSpace2.toString();
        boolean boolean6 = blockContainer1.equals((java.lang.Object) axisSpace2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot16.getDataset();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle20.getItemContainer();
        java.awt.Font font22 = legendTitle20.getItemFont();
        barRenderer0.setBaseItemLabelFont(font22, true);
        barRenderer0.setItemMargin((double) 0L);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator27, false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        categoryPlot7.setForegroundAlpha((float) (short) -1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10.0f, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.lang.Class<?> wildcardClass2 = font1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("TextBlockAnchor.TOP_CENTER", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 10L);
        numberAxis2.setRangeAboutValue((double) '#', (double) 192);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot32.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot32.getDatasetRenderingOrder();
        java.awt.Stroke stroke38 = categoryPlot32.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot32.getFixedLegendItems();
        numberAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot32);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(legendItemCollection39);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.CENTER", graphics2D1, 0.0f, (float) 10, (double) (short) 0, (float) 100L, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray5 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextOutlinePaint();
        try {
            java.awt.Stroke stroke8 = defaultDrawingSupplier6.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot6.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        float[] floatArray4 = new float[] { 2.0f };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (short) 1, 255, (int) (byte) 1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        java.awt.Paint paint3 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        projectInfo7.setLicenceName("[size=1]");
        projectInfo7.setLicenceText("ItemLabelAnchor.CENTER");
        java.lang.String str15 = projectInfo7.getInfo();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.TickType tickType4 = null;
        org.jfree.chart.axis.TickType tickType7 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick(tickType7, (double) (short) 0, "hi!", textAnchor10, textAnchor11, (double) (byte) 100);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D15, 1.0f, (float) '4', textAnchor18, (double) 0.0f, textAnchor20);
        org.jfree.chart.axis.NumberTick numberTick23 = new org.jfree.chart.axis.NumberTick(tickType4, (double) (short) 1, "ItemLabelAnchor.CENTER", textAnchor11, textAnchor20, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor24 = numberTick23.getTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("100", graphics2D1, (float) (byte) 0, (float) 15, textAnchor24, 0.0d, (float) '#', (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean5 = objectList3.equals((java.lang.Object) axisSpace4);
        axisSpace4.setRight((double) 0.0f);
        axisSpace0.ensureAtLeast(axisSpace4);
        double double9 = axisSpace4.getLeft();
        axisSpace4.setRight((double) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            axisSpace4.ensureAtLeast(10.0d, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: AxisSpace.ensureAtLeast(): unrecognised AxisLocation.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        int int16 = barRenderer0.getPassCount();
        java.awt.Paint paint17 = null;
        try {
            barRenderer0.setBaseFillPaint(paint17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        boolean boolean11 = barRenderer0.removeAnnotation(categoryAnnotation10);
        boolean boolean12 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(drawingSupplier14);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.jfree.data.RangeType rangeType2 = org.jfree.data.RangeType.FULL;
        java.lang.Class<?> wildcardClass3 = rangeType2.getClass();
        boolean boolean4 = horizontalAlignment0.equals((java.lang.Object) rangeType2);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Paint paint5 = barRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) 'a', 10);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer10.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color15 = java.awt.Color.green;
        java.awt.Color color16 = color15.darker();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean19 = color16.equals((java.lang.Object) shape18);
        barRenderer10.setSeriesShape((int) '4', shape18);
        java.lang.Boolean boolean22 = barRenderer10.getSeriesCreateEntities(0);
        barRenderer10.setBaseSeriesVisible(false, false);
        categoryPlot6.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10, false);
        java.lang.Boolean boolean29 = barRenderer10.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNull(boolean29);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxis(0);
        valueAxis10.resizeRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(valueAxis10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        java.lang.String str2 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MINOR" + "'", str2.equals("MINOR"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis5, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot9.getDomainAxisEdge(0);
        axisState0.moveCursor(0.0d, rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.text.AttributedString attributedString0 = null;
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Color color13 = java.awt.Color.green;
        java.awt.Color color14 = color13.darker();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean17 = color14.equals((java.lang.Object) shape16);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setUpperMargin((double) 10L);
        java.awt.Color color23 = java.awt.Color.green;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color23);
        numberAxis20.setAutoTickUnitSelection(true);
        java.awt.Paint paint27 = numberAxis20.getTickMarkPaint();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList30 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint31 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean32 = objectList30.equals((java.lang.Object) paint31);
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape29, paint31);
        numberAxis20.setUpArrow(shape29);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        boolean boolean42 = categoryPlot41.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = null;
        categoryPlot41.setFixedLegendItems(legendItemCollection43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot41.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder46 = categoryPlot41.getDatasetRenderingOrder();
        java.awt.Stroke stroke47 = categoryPlot41.getOutlineStroke();
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "RectangleEdge.TOP", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", false, shape8, true, paint11, false, (java.awt.Paint) color14, stroke18, false, shape29, stroke47, (java.awt.Paint) color48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge7);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        categoryPlot6.setWeight((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5, (float) '4');
        textLine2.addFragment(textFragment7);
        java.awt.Font font9 = textFragment7.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = categoryPlot16.isRangeCrosshairLockedOnData();
        java.awt.Paint paint18 = categoryPlot16.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("", font9, paint18);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font23 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color24 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("", font23, (java.awt.Paint) color24, (float) '4');
        textLine21.addFragment(textFragment26);
        textLine19.addFragment(textFragment26);
        java.awt.Paint paint29 = textFragment26.getPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        double double7 = legendGraphic5.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            legendGraphic5.setPadding(rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setNotify(false);
        jFreeChart7.setTextAntiAlias(true);
        jFreeChart7.setAntiAlias(false);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        java.awt.Shape shape8 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) '4');
        textLine1.addFragment(textFragment6);
        java.awt.Font font8 = textFragment6.getFont();
        java.lang.String str9 = textFragment6.getText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj1 = axisSpace0.clone();
        axisSpace0.setRight((double) 192);
        axisSpace0.setBottom((double) 255);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        projectInfo7.addOptionalLibrary("hi!");
        java.util.List list13 = null;
        projectInfo7.setContributors(list13);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset5, (double) 'a');
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset5, false);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset5);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNull(range29);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.RangeType rangeType2 = org.jfree.data.RangeType.FULL;
        java.lang.Class<?> wildcardClass3 = rangeType2.getClass();
        java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("10", (java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(uRL5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.lang.Object obj3 = keyedObjects0.getObject((-10420321));
        java.lang.Object obj4 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint30.toUnconstrainedHeight();
        java.lang.String str33 = rectangleConstraint30.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]" + "'", str33.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setTickMarkInsideLength((float) 15);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.AxisCollection axisCollection12 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        org.jfree.chart.axis.AxisState axisState26 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle28.draw(graphics2D29, rectangle2D30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = textTitle28.getPosition();
        axisState26.moveCursor((double) (-1), rectangleEdge32);
        axisCollection12.add((org.jfree.chart.axis.Axis) numberAxis13, rectangleEdge32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisCollection12.add((org.jfree.chart.axis.Axis) numberAxis35, rectangleEdge36);
        try {
            java.util.List list38 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        boolean boolean5 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer7);
        boolean boolean9 = categoryPlot8.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot8.setFixedLegendItems(legendItemCollection10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot8.getRendererForDataset(categoryDataset12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke20 = null;
        barRenderer18.setSeriesOutlineStroke(0, stroke20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.awt.Stroke stroke23 = categoryPlot22.getDomainGridlineStroke();
        categoryPlot8.setDomainGridlineStroke(stroke23);
        boolean boolean25 = categoryPlot8.isRangeZoomable();
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot8.setRangeGridlineStroke(stroke26);
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke26);
        boolean boolean29 = barRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 0, "hi!", textAnchor3, textAnchor4, (double) (byte) 100);
        double double7 = numberTick6.getValue();
        java.lang.String str8 = numberTick6.toString();
        double double9 = numberTick6.getAngle();
        java.lang.Object obj10 = numberTick6.clone();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        numberAxis11.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot24.getRenderer();
        numberAxis11.setPlot((org.jfree.chart.plot.Plot) categoryPlot24);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) (-1), (double) 100L, rectangleAnchor31);
        categoryPlot24.drawBackgroundImage(graphics2D27, rectangle2D32);
        try {
            categoryPlot6.drawBackground(graphics2D8, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) '#', (double) 0.0f, rectangleAnchor5);
        double double7 = size2D2.getHeight();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        int int3 = keyedObjects0.getIndex((java.lang.Comparable) (-1L));
        int int4 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        double double14 = numberAxis0.getFixedDimension();
        float float15 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString((double) 10L);
        double double3 = numberTickUnit0.getSize();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.lang.String str9 = chartEntity8.getToolTipText();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = chartEntity8.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        boolean boolean13 = color0.equals((java.lang.Object) str12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.green;
        java.awt.Color color4 = color3.darker();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean7 = color4.equals((java.lang.Object) shape6);
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color4, (float) (short) 0, 192, textMeasurer10);
        org.jfree.chart.plot.Plot plot12 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font2, plot12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlock11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Stroke stroke5 = numberAxis0.getAxisLineStroke();
        double double6 = numberAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot6.axisChanged(axisChangeEvent19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot6.getRenderer(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryItemRenderer22);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        double double14 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range15 = numberAxis1.getDefaultAutoRange();
        java.lang.Object obj16 = null;
        boolean boolean17 = range15.equals(obj16);
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) "ItemLabelAnchor.CENTER", (java.lang.Object) boolean17);
        java.lang.Object obj19 = keyedObject18.getObject();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + obj19 + "' != '" + false + "'", obj19.equals(false));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isRangeCrosshairLockedOnData();
        boolean boolean9 = categoryPlot7.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setUpperMargin((double) 10L);
        java.awt.Color color14 = java.awt.Color.green;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer21);
        boolean boolean23 = numberAxis11.hasListener((java.util.EventListener) categoryPlot22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Color color26 = java.awt.Color.green;
        jFreeChart25.setBorderPaint((java.awt.Paint) color26);
        categoryPlot7.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color32);
        boolean boolean34 = plotOrientation0.equals((java.lang.Object) categoryPlot7);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        boolean boolean11 = barRenderer0.removeAnnotation(categoryAnnotation10);
        java.awt.Stroke stroke13 = barRenderer0.getSeriesStroke((int) (byte) -1);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        boolean boolean22 = categoryPlot21.isRangeCrosshairLockedOnData();
        java.awt.Paint paint23 = categoryPlot21.getBackgroundPaint();
        categoryPlot21.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer37);
        boolean boolean39 = numberAxis27.hasListener((java.util.EventListener) categoryPlot38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot38.getDataset();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot38);
        java.awt.Color color42 = java.awt.Color.blue;
        categoryPlot38.setBackgroundPaint((java.awt.Paint) color42);
        java.awt.image.ColorModel colorModel44 = null;
        java.awt.Rectangle rectangle45 = null;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.util.Size2D size2D48 = textLine46.calculateDimensions(graphics2D47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D52 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, (double) '#', (double) 0.0f, rectangleAnchor51);
        java.awt.geom.AffineTransform affineTransform53 = null;
        java.awt.RenderingHints renderingHints54 = null;
        java.awt.PaintContext paintContext55 = color42.createContext(colorModel44, rectangle45, rectangle2D52, affineTransform53, renderingHints54);
        try {
            barRenderer0.drawOutline(graphics2D14, categoryPlot21, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(paintContext55);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        java.lang.Object obj9 = legendGraphic5.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendGraphic5.getShapeAnchor();
        legendGraphic5.setShapeOutlineVisible(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setName("Category Plot");
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RangeType.NEGATIVE");
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic5);
        legendGraphic5.setShapeOutlineVisible(true);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = org.jfree.chart.block.LengthConstraintType.FIXED;
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) legendGraphic5, (java.lang.Object) lengthConstraintType10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        java.lang.Object obj3 = size2D2.clone();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        java.awt.Stroke stroke9 = categoryPlot6.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        java.lang.String str2 = textBlockAnchor0.toString();
        java.lang.String str3 = textBlockAnchor0.toString();
        java.lang.String str4 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str1.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str2.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str3.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str4.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str3 = gradientPaintTransformType0.toString();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = null;
        categoryPlot11.setFixedLegendItems(legendItemCollection13);
        boolean boolean15 = categoryLabelPositions4.equals((java.lang.Object) legendItemCollection13);
        boolean boolean16 = gradientPaintTransformType0.equals((java.lang.Object) legendItemCollection13);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str3.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        numberAxis0.setNegativeArrowVisible(false);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle18.draw(graphics2D19, rectangle2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle18.getPosition();
        try {
            double double23 = numberAxis0.lengthToJava2D((double) 52.0f, rectangle2D17, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        legendGraphic5.setShapeVisible(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.lang.String str9 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = new org.jfree.chart.axis.CategoryLabelPositions();
        boolean boolean2 = categoryLabelWidthType0.equals((java.lang.Object) categoryLabelPositions1);
        java.lang.String str3 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str3.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        double double3 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = objectList4.equals((java.lang.Object) paint5);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape3, paint5);
        org.jfree.chart.block.BlockFrame blockFrame8 = legendGraphic7.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic7);
        legendGraphic7.setShapeOutlineVisible(true);
        java.lang.Object obj12 = null;
        centerArrangement0.add((org.jfree.chart.block.Block) legendGraphic7, obj12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(blockFrame8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (short) 100);
        int int3 = color2.getBlue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        java.awt.Paint paint14 = numberAxis0.getLabelPaint();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(paint14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint((-10420321), 100);
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = barRenderer0.getGradientPaintTransformer();
        double double16 = barRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer8.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color13 = java.awt.Color.green;
        java.awt.Color color14 = color13.darker();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean17 = color14.equals((java.lang.Object) shape16);
        barRenderer8.setSeriesShape((int) '4', shape16);
        barRenderer8.setBaseCreateEntities(false, true);
        barRenderer8.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color28 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer8.setBasePaint((java.awt.Paint) color28, true);
        boolean boolean31 = projectInfo7.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        numberAxis0.configure();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Stroke stroke5 = numberAxis0.getAxisLineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot23.getRenderer();
        numberAxis10.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) (-1), (double) 100L, rectangleAnchor30);
        categoryPlot23.drawBackgroundImage(graphics2D26, rectangle2D31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D38 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, (double) (-1), (double) 100L, rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D42);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets33.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType44, lengthAdjustmentType45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        try {
            org.jfree.chart.axis.AxisState axisState50 = numberAxis0.draw(graphics2D6, (double) (short) -1, rectangle2D31, rectangle2D46, rectangleEdge47, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.0d + "'", double35 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart7.removeProgressListener(chartProgressListener10);
        jFreeChart7.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot6.setDomainAxis((int) (byte) 0, categoryAxis10, false);
        double double13 = categoryPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot6.handleClick(192, 1, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset5, (double) (byte) 1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) (byte) 1);
        boolean boolean11 = valueAxis10.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis3.setUpArrow(shape6);
        try {
            java.awt.GradientPaint gradientPaint8 = standardGradientPaintTransformer0.transform(gradientPaint2, shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot6.getLegendItems();
        int int26 = legendItemCollection25.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Category Plot", graphics2D1, (float) (byte) 10, (float) (byte) 1, (double) 1.0f, (float) 255, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        java.awt.Paint paint2 = lineBorder0.getPaint();
        java.awt.Paint paint3 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isRangeCrosshairLockedOnData();
        boolean boolean15 = categoryPlot13.isRangeZoomable();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer17.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color22 = java.awt.Color.green;
        java.awt.Color color23 = color22.darker();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean26 = color23.equals((java.lang.Object) shape25);
        barRenderer17.setSeriesShape((int) '4', shape25);
        java.lang.Boolean boolean29 = barRenderer17.getSeriesCreateEntities(0);
        barRenderer17.setBaseSeriesVisible(false, false);
        categoryPlot13.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17, false);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke40 = null;
        barRenderer38.setSeriesOutlineStroke(0, stroke40);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer38);
        java.awt.Stroke stroke43 = categoryPlot42.getDomainGridlineStroke();
        barRenderer17.setBaseStroke(stroke43, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder47 = new org.jfree.chart.block.LineBorder(paint6, stroke43, rectangleInsets46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = categoryItemRendererState1.getEntityCollection();
        double double3 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6, (float) '4');
        textLine3.addFragment(textFragment8);
        java.awt.Font font10 = textFragment8.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        boolean boolean18 = categoryPlot17.isRangeCrosshairLockedOnData();
        java.awt.Paint paint19 = categoryPlot17.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font10, paint19);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font24 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("", font24, (java.awt.Paint) color25, (float) '4');
        textLine22.addFragment(textFragment27);
        textLine20.addFragment(textFragment27);
        boolean boolean30 = lineBorder0.equals((java.lang.Object) textFragment27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean34 = barRenderer31.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color36 = java.awt.Color.green;
        java.awt.Color color37 = color36.darker();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean40 = color37.equals((java.lang.Object) shape39);
        barRenderer31.setSeriesShape((int) '4', shape39);
        java.awt.Paint paint43 = barRenderer31.lookupSeriesPaint(0);
        barRenderer31.setIncludeBaseInRange(false);
        java.awt.Paint paint46 = barRenderer31.getBasePaint();
        int int47 = barRenderer31.getPassCount();
        boolean boolean48 = lineBorder0.equals((java.lang.Object) barRenderer31);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot6.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot6.getFixedLegendItems();
        float float27 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot6.getColumnRenderingOrder();
        java.awt.Image image32 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo36 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image32, "", "hi!", "hi!");
        java.awt.Image image37 = projectInfo36.getLogo();
        java.lang.String str38 = projectInfo36.getVersion();
        java.lang.String str39 = projectInfo36.getVersion();
        boolean boolean40 = sortOrder28.equals((java.lang.Object) str39);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNull(image37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = null;
        categoryPlot14.setFixedLegendItems(legendItemCollection16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRendererForDataset(categoryDataset18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot14.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke26 = null;
        barRenderer24.setSeriesOutlineStroke(0, stroke26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer24);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke29);
        boolean boolean31 = categoryPlot14.isRangeZoomable();
        boolean boolean32 = categoryPlot14.isRangeCrosshairVisible();
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) boolean32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        boolean boolean21 = numberAxis2.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        numberAxis2.setTickLabelInsets(rectangleInsets22);
        numberAxis2.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setItemMargin((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        java.awt.Color color3 = color2.brighter();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("100", font1, (java.awt.Paint) color3, (float) (-1), (int) (byte) 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer10.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color15 = java.awt.Color.green;
        java.awt.Color color16 = color15.darker();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean19 = color16.equals((java.lang.Object) shape18);
        barRenderer10.setSeriesShape((int) '4', shape18);
        java.lang.Boolean boolean22 = barRenderer10.getSeriesCreateEntities(0);
        barRenderer10.setBaseSeriesVisible(false, false);
        categoryPlot6.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10, false);
        try {
            barRenderer10.setSeriesVisible((-1), (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(boolean22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle0.getTextAlignment();
        double double6 = textTitle0.getHeight();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle0.setHorizontalAlignment(horizontalAlignment7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle0.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        int int16 = barRenderer0.getPassCount();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Font font18 = legendTitle16.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle16.getMargin();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle21.draw(graphics2D22, rectangle2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = textTitle21.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle21.getTextAlignment();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean38 = barRenderer35.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean39 = barRenderer35.isDrawBarOutline();
        boolean boolean40 = numberAxis30.equals((java.lang.Object) barRenderer35);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) (-1), (double) 100L, rectangleAnchor45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis30.lengthToJava2D((double) 192, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis49.setUpArrow(shape52);
        numberAxis49.setFixedDimension((double) '#');
        java.lang.Object obj56 = textTitle21.draw(graphics2D27, rectangle2D46, (java.lang.Object) numberAxis49);
        try {
            legendTitle16.draw(graphics2D20, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(obj56);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) (-1), (double) 100L, rectangleAnchor8);
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D9);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets0.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType11, lengthAdjustmentType12);
        double double15 = rectangleInsets0.calculateTopOutset((double) ' ');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2, (float) '4');
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textFragment4.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelWidthType.CATEGORY", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        double double15 = range14.getUpperBound();
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range14, 0.0d);
        try {
            org.jfree.data.Range range20 = org.jfree.data.Range.expand(range14, (double) (byte) 0, (-6.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-5.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (-1), (double) 100L, rectangleAnchor18);
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D19);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList23 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean25 = objectList23.equals((java.lang.Object) paint24);
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape22, paint24);
        boolean boolean27 = legendGraphic26.isLineVisible();
        java.awt.Paint paint28 = null;
        legendGraphic26.setFillPaint(paint28);
        java.awt.Shape shape30 = null;
        legendGraphic26.setLine(shape30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendGraphic26.getShapeLocation();
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D19, rectangleAnchor32);
        categoryPlot6.zoomDomainAxes((-1.0d), plotRenderingInfo12, point2D33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        try {
            categoryPlot6.drawOutline(graphics2D35, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(point2D33);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        java.awt.Paint paint2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean3 = size2D0.equals((java.lang.Object) paint2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (-1.0f));
        org.jfree.chart.block.CenterArrangement centerArrangement9 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean28 = jFreeChart27.isBorderVisible();
        jFreeChart27.setTitle("10");
        textTitle11.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        columnArrangement8.add((org.jfree.chart.block.Block) blockContainer10, (java.lang.Object) jFreeChart27);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = null;
        try {
            jFreeChart27.titleChanged(titleChangeEvent33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic5);
        legendGraphic5.setShapeOutlineVisible(true);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape12, "");
        legendGraphic5.setLine(shape12);
        java.awt.Color color19 = java.awt.Color.red;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) 10);
        double double3 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Image image7 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image7, "hi!", "", "hi!");
        org.jfree.data.Range range13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        boolean boolean16 = projectInfo11.equals((java.lang.Object) rectangleConstraint14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setUpperMargin((double) 10L);
        java.awt.Color color20 = java.awt.Color.green;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        boolean boolean29 = numberAxis17.hasListener((java.util.EventListener) categoryPlot28);
        double double30 = numberAxis17.getAutoRangeMinimumSize();
        org.jfree.data.Range range31 = numberAxis17.getDefaultAutoRange();
        java.lang.Object obj32 = null;
        boolean boolean33 = range31.equals(obj32);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint14.toRangeHeight(range31);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType35 = rectangleConstraint34.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D37 = centerArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint36);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0E-8d + "'", double30 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(lengthConstraintType35);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot11.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent14);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        barRenderer0.setSeriesOutlineStroke(10, stroke44);
        boolean boolean47 = barRenderer0.getAutoPopulateSeriesFillPaint();
        barRenderer0.setSeriesItemLabelsVisible(2, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator52);
        try {
            barRenderer0.setSeriesVisibleInLegend((-16731648), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setLabel("{0}");
        numberAxis0.setFixedAutoRange((double) 52.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ChartChangeEventType.GENERAL", "", "hi!", "");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.Object obj8 = null;
        boolean boolean9 = chartEntity7.equals(obj8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot6.axisChanged(axisChangeEvent19);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        axisChangeEvent19.setType(chartChangeEventType21);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.FULL;
        java.lang.Class<?> wildcardClass2 = rangeType1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(inputStream3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis((int) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot6.getLegendItems();
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = valueMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean2 = objectList0.equals((java.lang.Object) axisSpace1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = null;
        barRenderer6.setSeriesOutlineStroke(0, stroke8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        java.awt.Stroke stroke11 = categoryPlot10.getDomainGridlineStroke();
        categoryPlot10.clearDomainMarkers(8);
        java.util.List list14 = categoryPlot10.getAnnotations();
        int int15 = objectList0.indexOf((java.lang.Object) categoryPlot10);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        java.util.List list17 = categoryPlot10.getCategoriesForAxis(categoryAxis16);
        java.util.Collection collection18 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getVersion();
        java.lang.String str10 = projectInfo7.getVersion();
        projectInfo7.setLicenceName("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.lang.String str12 = datasetRenderingOrder11.toString();
        java.lang.String str13 = datasetRenderingOrder11.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str12.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str13.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 0.0f);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) (-1), (double) 100L, rectangleAnchor8);
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets0.createInsetRectangle(rectangle2D9, false, false);
        double double15 = rectangleInsets0.calculateLeftInset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        categoryPlot6.mapDatasetToRangeAxis(500, (int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis(15);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        categoryPlot6.mapDatasetToRangeAxis(500, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot6.setDomainAxis(categoryAxis11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getDomainAxisLocation();
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        numberAxis0.setAutoRangeMinimumSize((double) 100L);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.String str8 = chartEntity7.getToolTipText();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setUpperMargin((double) 10L);
        java.awt.Color color12 = java.awt.Color.green;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = numberAxis9.hasListener((java.util.EventListener) categoryPlot20);
        double double22 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.Range range23 = numberAxis9.getDefaultAutoRange();
        boolean boolean24 = chartEntity7.equals((java.lang.Object) range23);
        java.awt.Shape shape25 = chartEntity7.getArea();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        jFreeChart7.setBorderPaint(paint9);
        java.lang.Object obj11 = jFreeChart7.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setLabel("{0}");
        numberAxis0.setFixedDimension((double) 2);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 10L);
        java.awt.Color color13 = java.awt.Color.green;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        boolean boolean22 = numberAxis10.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        categoryPlot21.notifyListeners(plotChangeEvent23);
        boolean boolean25 = categoryPlot21.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) (-1), (double) 100L, rectangleAnchor34);
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D35);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets26.createAdjustedRectangle(rectangle2D35, lengthAdjustmentType37, lengthAdjustmentType38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = new org.jfree.chart.axis.AxisSpace();
        axisSpace41.setTop((double) 10);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace44 = numberAxis0.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) categoryPlot21, rectangle2D35, rectangleEdge40, axisSpace41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: AxisSpace.ensureAtLeast(): unrecognised AxisLocation.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        java.awt.Shape shape9 = null;
        legendGraphic5.setLine(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setUpperMargin((double) 10L);
        java.awt.Color color14 = java.awt.Color.green;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        double double16 = numberAxis11.getLowerBound();
        boolean boolean17 = legendGraphic5.equals((java.lang.Object) double16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = categoryPlot24.getDomainGridlinePosition();
        boolean boolean27 = legendGraphic5.equals((java.lang.Object) categoryPlot24);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, 0.0d);
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image11, "hi!", "", "hi!");
        org.jfree.data.Range range17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint18.toUnconstrainedWidth();
        boolean boolean20 = projectInfo15.equals((java.lang.Object) rectangleConstraint18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setUpperMargin((double) 10L);
        java.awt.Color color24 = java.awt.Color.green;
        numberAxis21.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = numberAxis21.hasListener((java.util.EventListener) categoryPlot32);
        double double34 = numberAxis21.getAutoRangeMinimumSize();
        org.jfree.data.Range range35 = numberAxis21.getDefaultAutoRange();
        java.lang.Object obj36 = null;
        boolean boolean37 = range35.equals(obj36);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint18.toRangeHeight(range35);
        try {
            org.jfree.chart.util.Size2D size2D39 = flowArrangement4.arrange(blockContainer6, graphics2D7, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-8d + "'", double34 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        java.awt.Paint paint19 = categoryPlot6.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer1.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean6 = barRenderer1.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = barRenderer1.getGradientPaintTransformer();
        barRenderer1.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer1.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font19 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("", font19, (java.awt.Paint) color20, (float) '4');
        textLine17.addFragment(textFragment22);
        java.awt.Font font24 = textFragment22.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        boolean boolean32 = categoryPlot31.isRangeCrosshairLockedOnData();
        java.awt.Paint paint33 = categoryPlot31.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("", font24, paint33);
        barRenderer1.setBaseItemLabelFont(font24);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setUpperMargin((double) 10L);
        java.awt.Color color40 = java.awt.Color.green;
        numberAxis37.setTickLabelPaint((java.awt.Paint) color40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer47);
        boolean boolean49 = numberAxis37.hasListener((java.util.EventListener) categoryPlot48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = categoryPlot48.getDataset();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot48);
        java.awt.Color color52 = java.awt.Color.blue;
        categoryPlot48.setBackgroundPaint((java.awt.Paint) color52);
        java.awt.image.ColorModel colorModel54 = null;
        java.awt.Rectangle rectangle55 = null;
        org.jfree.chart.text.TextLine textLine56 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.util.Size2D size2D58 = textLine56.calculateDimensions(graphics2D57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D62 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D58, (double) '#', (double) 0.0f, rectangleAnchor61);
        java.awt.geom.AffineTransform affineTransform63 = null;
        java.awt.RenderingHints renderingHints64 = null;
        java.awt.PaintContext paintContext65 = color52.createContext(colorModel54, rectangle55, rectangle2D62, affineTransform63, renderingHints64);
        org.jfree.chart.text.TextBlock textBlock66 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelWidthType.CATEGORY", font24, (java.awt.Paint) color52);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(categoryDataset50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(size2D58);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(paintContext65);
        org.junit.Assert.assertNotNull(textBlock66);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 100, (float) 10);
        numberAxis2.setRightArrow(shape9);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle16.getPosition();
        axisState14.moveCursor((double) (-1), rectangleEdge20);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis23, rectangleEdge24);
        boolean boolean26 = numberAxis23.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart7.getLegend();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
        org.junit.Assert.assertNotNull(legendTitle10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight((double) 0.0f);
        double double7 = rectangleInsets4.getTop();
        numberAxis0.setTickLabelInsets(rectangleInsets4);
        double double10 = rectangleInsets4.extendHeight((double) 2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, (double) ' ');
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        barRenderer0.setDrawBarOutline(false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        java.awt.Shape shape9 = null;
        legendGraphic5.setLine(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic5.getShapeLocation();
        java.lang.Object obj12 = legendGraphic5.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 0, "hi!", textAnchor3, textAnchor4, (double) (byte) 100);
        java.lang.String str7 = numberTick6.toString();
        java.lang.String str8 = numberTick6.toString();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RectangleEdge.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Color color7 = java.awt.Color.green;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        boolean boolean16 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot15.notifyListeners(plotChangeEvent17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot15.getDataset((int) ' ');
        keyedObjects0.setObject((java.lang.Comparable) 10.0d, (java.lang.Object) categoryPlot15);
        java.lang.Object obj23 = keyedObjects0.getObject((int) (short) 1);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image12, "hi!", "", "hi!");
        org.jfree.data.Range range18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint19.toUnconstrainedWidth();
        boolean boolean21 = projectInfo16.equals((java.lang.Object) rectangleConstraint19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setUpperMargin((double) 10L);
        java.awt.Color color25 = java.awt.Color.green;
        numberAxis22.setTickLabelPaint((java.awt.Paint) color25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer32);
        boolean boolean34 = numberAxis22.hasListener((java.util.EventListener) categoryPlot33);
        double double35 = numberAxis22.getAutoRangeMinimumSize();
        org.jfree.data.Range range36 = numberAxis22.getDefaultAutoRange();
        java.lang.Object obj37 = null;
        boolean boolean38 = range36.equals(obj37);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint19.toRangeHeight(range36);
        try {
            org.jfree.chart.util.Size2D size2D40 = legendGraphic5.arrange(graphics2D8, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) 100, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis7.setStandardTickUnits(tickUnitSource27);
        numberAxis7.setTickMarkInsideLength(1.0f);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(tickUnitSource27);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        java.lang.String str3 = textBlockAnchor1.toString();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor4, (double) (-16731648), categoryLabelWidthType6, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str2.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str3.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            jFreeChart7.handleClick(0, (-1), chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setHeight((double) (-1L));
        java.awt.Paint paint9 = legendGraphic5.getOutlinePaint();
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Color color11 = color10.darker();
        legendGraphic5.setLinePaint((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendGraphic5.getPadding();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (-1), (double) 100L, rectangleAnchor18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setUpperMargin((double) 10L);
        java.awt.Color color24 = java.awt.Color.green;
        numberAxis21.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = numberAxis21.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot32.getDataset();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot32);
        org.jfree.chart.title.LegendTitle legendTitle36 = jFreeChart35.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer37 = legendTitle36.getItemContainer();
        java.awt.Font font38 = legendTitle36.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder();
        legendTitle36.setFrame((org.jfree.chart.block.BlockFrame) lineBorder39);
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle36.getBounds();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D19, rectangle2D41);
        try {
            legendGraphic5.draw(graphics2D14, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertNotNull(legendTitle36);
        org.junit.Assert.assertNotNull(blockContainer37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        double double3 = axisSpace0.getRight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        numberAxis0.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis0.getTickUnit();
        java.lang.String str17 = numberTickUnit15.valueToString((double) '4');
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52" + "'", str17.equals("52"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic5);
        java.lang.Object obj8 = chartChangeEvent7.getSource();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        projectInfo7.setName("TextBlockAnchor.TOP_CENTER");
        java.lang.String str13 = projectInfo7.getInfo();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot6.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot6.getFixedLegendItems();
        int int27 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) (short) 1, 100);
        java.awt.Stroke stroke10 = barRenderer0.getSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = null;
        barRenderer16.setSeriesOutlineStroke(0, stroke18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Stroke stroke21 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot6.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot6.isRangeZoomable();
        try {
            categoryPlot6.mapDatasetToRangeAxis((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot6.getDataRange(valueAxis12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot6.setInsets(rectangleInsets14);
        boolean boolean16 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1), (double) 100L, rectangleAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        java.lang.String str7 = textBlockAnchor5.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor5, categoryLabelWidthType8, (float) (short) 100);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str6.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str7.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean5 = objectList3.equals((java.lang.Object) axisSpace4);
        axisSpace4.setRight((double) 0.0f);
        axisSpace0.ensureAtLeast(axisSpace4);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace0.add((double) 52.0f, rectangleEdge10);
        java.lang.Object obj12 = axisSpace0.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        numberAxis2.setAutoTickUnitSelection(true);
        java.awt.Paint paint9 = numberAxis2.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = textLine11.calculateDimensions(graphics2D12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) '#', (double) 0.0f, rectangleAnchor16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle18.draw(graphics2D19, rectangle2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle18.getPosition();
        double double23 = numberAxis2.lengthToJava2D((double) 1, rectangle2D17, rectangleEdge22);
        try {
            shapeList0.setShape((int) (byte) -1, (java.awt.Shape) rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = objectList3.equals((java.lang.Object) paint4);
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape2, paint4);
        boolean boolean7 = legendGraphic6.isLineVisible();
        java.awt.Paint paint8 = null;
        legendGraphic6.setFillPaint(paint8);
        java.awt.Shape shape10 = null;
        legendGraphic6.setLine(shape10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic6.getShapeLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic6.getShapeLocation();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str15 = textBlockAnchor14.toString();
        java.lang.String str16 = textBlockAnchor14.toString();
        java.lang.String str17 = textBlockAnchor14.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14);
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType21 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor14, textAnchor19, (double) 2.0f, categoryLabelWidthType21, (float) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str15.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str16.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str17.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.CENTER", graphics2D1, 0.0f, (float) 10L, (double) 0.0f, (float) (-16777216), (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        java.awt.Paint paint6 = null;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("GradientPaintTransformType.VERTICAL", "ThreadContext", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]", "10", shape5, paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }
}

