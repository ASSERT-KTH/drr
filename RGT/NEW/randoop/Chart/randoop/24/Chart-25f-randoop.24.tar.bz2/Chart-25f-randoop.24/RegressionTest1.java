import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot16.getDataset();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle20.getItemContainer();
        java.awt.Font font22 = legendTitle20.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder();
        legendTitle20.setFrame((org.jfree.chart.block.BlockFrame) lineBorder23);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle20.getBounds();
        java.awt.Stroke stroke26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean30 = barRenderer27.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color32 = java.awt.Color.green;
        java.awt.Color color33 = color32.darker();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean36 = color33.equals((java.lang.Object) shape35);
        barRenderer27.setSeriesShape((int) '4', shape35);
        java.lang.Boolean boolean39 = barRenderer27.getSeriesCreateEntities(0);
        barRenderer27.setBaseSeriesVisible(false, false);
        java.awt.Color color43 = java.awt.Color.green;
        java.awt.Color color44 = color43.darker();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean47 = color44.equals((java.lang.Object) shape46);
        barRenderer27.setBaseFillPaint((java.awt.Paint) color44);
        try {
            org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "HorizontalAlignment.CENTER", "", "10", (java.awt.Shape) rectangle2D25, stroke26, (java.awt.Paint) color44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        java.lang.Object obj9 = legendGraphic5.clone();
        double double10 = legendGraphic5.getWidth();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        legendGraphic5.setPadding(2.0d, 0.0d, (double) (byte) 100, (double) 500);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendGraphic5.getShapeLocation();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setUpperMargin((double) 10L);
        java.awt.Paint paint18 = numberAxis15.getTickMarkPaint();
        legendGraphic5.setLinePaint(paint18);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.String str8 = chartEntity7.getToolTipText();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setUpperMargin((double) 10L);
        java.awt.Color color12 = java.awt.Color.green;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = numberAxis9.hasListener((java.util.EventListener) categoryPlot20);
        double double22 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.Range range23 = numberAxis9.getDefaultAutoRange();
        boolean boolean24 = chartEntity7.equals((java.lang.Object) range23);
        java.lang.String str25 = chartEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        numberAxis0.resizeRange(1.0d, (double) 15);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        boolean boolean11 = barRenderer0.removeAnnotation(categoryAnnotation10);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5, (float) '4');
        textLine2.addFragment(textFragment7);
        java.awt.Font font9 = textFragment7.getFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("MINOR", font9);
        java.awt.Font font11 = labelBlock10.getFont();
        double double12 = labelBlock10.getContentXOffset();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setUpperMargin((double) 10L);
        java.awt.Color color23 = java.awt.Color.green;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        boolean boolean32 = numberAxis20.hasListener((java.util.EventListener) categoryPlot31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot31.getDataset();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot31);
        org.jfree.chart.title.LegendTitle legendTitle35 = jFreeChart34.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer36 = legendTitle35.getItemContainer();
        java.awt.Font font37 = legendTitle35.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder38 = new org.jfree.chart.block.LineBorder();
        legendTitle35.setFrame((org.jfree.chart.block.BlockFrame) lineBorder38);
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle35.getBounds();
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D18, rectangle2D40);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        numberAxis42.setUpperMargin((double) 10L);
        java.awt.Color color45 = java.awt.Color.green;
        numberAxis42.setTickLabelPaint((java.awt.Paint) color45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke52 = null;
        barRenderer50.setSeriesOutlineStroke(0, stroke52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.awt.Stroke stroke55 = categoryPlot54.getDomainGridlineStroke();
        numberAxis42.setTickMarkStroke(stroke55);
        try {
            java.lang.Object obj57 = labelBlock10.draw(graphics2D13, rectangle2D40, (java.lang.Object) numberAxis42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertNotNull(legendTitle35);
        org.junit.Assert.assertNotNull(blockContainer36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.awt.Color color7 = java.awt.Color.blue;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color7);
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        barRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Paint paint17 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer0.getSeriesNegativeItemLabelPosition(100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1.0d + "'", number3.equals(1.0d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        java.awt.Color color11 = java.awt.Color.white;
        barRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = null;
        barRenderer17.setSeriesOutlineStroke(0, stroke19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Stroke stroke22 = categoryPlot21.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean26 = barRenderer23.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation27 = null;
        boolean boolean28 = barRenderer23.removeAnnotation(categoryAnnotation27);
        barRenderer23.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        barRenderer23.setPositiveItemLabelPositionFallback(itemLabelPosition30);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = barRenderer23.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer38);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot39);
        barRenderer23.setPlot(categoryPlot39);
        java.awt.Paint paint42 = barRenderer23.getBaseOutlinePaint();
        categoryPlot21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator32);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart7.removeProgressListener(chartProgressListener10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        try {
            jFreeChart7.plotChanged(plotChangeEvent12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        double double15 = range14.getUpperBound();
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement16);
        boolean boolean18 = range14.equals((java.lang.Object) blockContainer17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setUpperMargin((double) 10L);
        java.awt.Color color24 = java.awt.Color.green;
        numberAxis21.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = numberAxis21.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot32.getDataset();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot32);
        java.awt.Color color36 = java.awt.Color.blue;
        categoryPlot32.setBackgroundPaint((java.awt.Paint) color36);
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textLine40.calculateDimensions(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 0.0f, rectangleAnchor45);
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color36.createContext(colorModel38, rectangle39, rectangle2D46, affineTransform47, renderingHints48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace51 = color50.getColorSpace();
        try {
            java.lang.Object obj52 = blockContainer17.draw(graphics2D19, (java.awt.geom.Rectangle2D) rectangle39, (java.lang.Object) color50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(paintContext49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(colorSpace51);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.Object obj8 = chartEntity7.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        categoryAxis0.setCategoryMargin((double) 'a');
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        double double3 = categoryItemRendererState1.getSeriesRunningTotal();
        double double4 = categoryItemRendererState1.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        boolean boolean19 = categoryPlot6.isOutlineVisible();
        categoryPlot6.clearRangeMarkers();
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setTextAlignment(horizontalAlignment1);
        java.awt.Paint paint11 = textTitle0.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        textTitle0.setPosition(rectangleEdge12);
        textTitle0.setURLText("{0}");
        java.awt.Color color17 = java.awt.Color.lightGray;
        textTitle0.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 0, "hi!", textAnchor3, textAnchor4, (double) (byte) 100);
        double double7 = numberTick6.getValue();
        java.lang.String str8 = numberTick6.getText();
        java.lang.Object obj9 = numberTick6.clone();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color18 = java.awt.Color.green;
        java.awt.Color color19 = color18.darker();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean22 = color19.equals((java.lang.Object) shape21);
        barRenderer0.setSeriesShape(1, shape21, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = null;
        barRenderer16.setSeriesOutlineStroke(0, stroke18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Stroke stroke21 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot6.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot6.isRangeZoomable();
        boolean boolean24 = categoryPlot6.isRangeCrosshairVisible();
        double double25 = categoryPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean2 = rangeType0.equals((java.lang.Object) rectangleInsets1);
        double double4 = rectangleInsets1.calculateLeftOutset((double) 3);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) (short) 0, 6.0d);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, 0.0d, (double) '#');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        boolean boolean21 = numberAxis2.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        numberAxis2.setTickLabelInsets(rectangleInsets22);
        org.jfree.data.Range range24 = numberAxis2.getRange();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        double double2 = size2D0.getWidth();
        size2D0.width = (short) 10;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        float float4 = numberAxis0.getTickMarkOutsideLength();
        boolean boolean5 = numberAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setTextAlignment(horizontalAlignment1);
        java.awt.Paint paint11 = textTitle0.getPaint();
        double double12 = textTitle0.getContentXOffset();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setID("");
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setUpperMargin((double) 10L);
        java.awt.Paint paint12 = numberAxis9.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets13.trimHeight((double) 0.0f);
        double double16 = rectangleInsets13.getTop();
        numberAxis9.setTickLabelInsets(rectangleInsets13);
        double double19 = rectangleInsets13.calculateRightInset(10.0d);
        legendGraphic5.setPadding(rectangleInsets13);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.extendHeight(10.0d);
        valueMarker1.setLabelOffset(rectangleInsets2);
        org.jfree.chart.axis.TickType tickType6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick(tickType6, (double) (short) 0, "hi!", textAnchor9, textAnchor10, (double) (byte) 100);
        valueMarker1.setLabelTextAnchor(textAnchor9);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        java.lang.Object obj9 = legendGraphic5.clone();
        boolean boolean10 = legendGraphic5.isShapeFilled();
        java.lang.Object obj11 = legendGraphic5.clone();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        categoryPlot18.setFixedLegendItems(legendItemCollection20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRendererForDataset(categoryDataset22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot18.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke30 = null;
        barRenderer28.setSeriesOutlineStroke(0, stroke30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer28);
        java.awt.Stroke stroke33 = categoryPlot32.getDomainGridlineStroke();
        categoryPlot18.setDomainGridlineStroke(stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double37 = rectangleInsets35.trimHeight((double) 0.0f);
        double double38 = rectangleInsets35.getTop();
        org.jfree.chart.util.UnitType unitType39 = rectangleInsets35.getUnitType();
        categoryPlot18.setAxisOffset(rectangleInsets35);
        legendGraphic5.setPadding(rectangleInsets35);
        double double42 = legendGraphic5.getWidth();
        java.awt.Paint paint43 = legendGraphic5.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer7);
        java.lang.String str9 = numberAxis4.getLabelURL();
        boolean boolean10 = tickType0.equals((java.lang.Object) numberAxis4);
        boolean boolean11 = numberAxis4.isInverted();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Color color1 = java.awt.Color.decode("52");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RectangleEdge.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Color color7 = java.awt.Color.green;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        boolean boolean16 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot15.notifyListeners(plotChangeEvent17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot15.getDataset((int) ' ');
        keyedObjects0.setObject((java.lang.Comparable) 10.0d, (java.lang.Object) categoryPlot15);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot11.notifyListeners(plotChangeEvent13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        org.jfree.data.Range range22 = categoryPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis17);
        categoryPlot11.setWeight((int) '#');
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setTextAlignment(horizontalAlignment1);
        java.awt.Paint paint11 = textTitle0.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        textTitle0.setPosition(rectangleEdge12);
        textTitle0.setURLText("{0}");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        boolean boolean19 = horizontalAlignment17.equals((java.lang.Object) paint18);
        textTitle0.setTextAlignment(horizontalAlignment17);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle0.getPadding();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getVersion();
        java.lang.String str10 = projectInfo7.getVersion();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer11.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        boolean boolean16 = barRenderer11.removeAnnotation(categoryAnnotation15);
        java.awt.Paint paint17 = barRenderer11.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer11.setBaseItemLabelGenerator(categoryItemLabelGenerator18, false);
        barRenderer11.setItemLabelAnchorOffset((double) (short) 0);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer11.setBaseStroke(stroke23);
        boolean boolean25 = projectInfo7.equals((java.lang.Object) barRenderer11);
        java.lang.Boolean boolean27 = barRenderer11.getSeriesVisibleInLegend((int) '#');
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(boolean27);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer0.getItemLabelPaint((-1), (int) 'a');
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisibleInLegend((int) (byte) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        categoryPlot7.setRangeCrosshairValue((double) 10.0f, true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot6.removeChangeListener(plotChangeListener11);
        java.awt.Stroke stroke13 = categoryPlot6.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.lang.Object obj3 = keyedObjects0.getObject((-10420321));
        int int4 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 0, true);
        java.awt.Paint paint12 = barRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset5);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset5, false);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        java.awt.Paint paint17 = null;
        jFreeChart15.setBorderPaint(paint17);
        org.jfree.chart.event.ChartProgressListener chartProgressListener19 = null;
        jFreeChart15.addProgressListener(chartProgressListener19);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean2 = objectList0.equals((java.lang.Object) axisSpace1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = null;
        barRenderer6.setSeriesOutlineStroke(0, stroke8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        java.awt.Stroke stroke11 = categoryPlot10.getDomainGridlineStroke();
        categoryPlot10.clearDomainMarkers(8);
        java.util.List list14 = categoryPlot10.getAnnotations();
        int int15 = objectList0.indexOf((java.lang.Object) categoryPlot10);
        java.awt.Paint paint16 = categoryPlot10.getDomainGridlinePaint();
        int int17 = categoryPlot10.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot6.getDomainAxisEdge(0);
        double double10 = categoryPlot6.getRangeCrosshairValue();
        float float11 = categoryPlot6.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean2 = objectList0.equals((java.lang.Object) axisSpace1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = null;
        barRenderer6.setSeriesOutlineStroke(0, stroke8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        java.awt.Stroke stroke11 = categoryPlot10.getDomainGridlineStroke();
        categoryPlot10.clearDomainMarkers(8);
        java.util.List list14 = categoryPlot10.getAnnotations();
        int int15 = objectList0.indexOf((java.lang.Object) categoryPlot10);
        java.awt.Paint paint16 = categoryPlot10.getDomainGridlinePaint();
        int int17 = categoryPlot10.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        size2D2.width = 2;
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        barRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator17);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((-16777216));
        java.awt.Stroke stroke22 = barRenderer0.getSeriesStroke(16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNull(stroke22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        java.lang.Object obj3 = textTitle1.clone();
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        int int9 = color7.getGreen();
        int int10 = color7.getAlpha();
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.util.StrokeList strokeList12 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = null;
        barRenderer17.setSeriesOutlineStroke(0, stroke19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Stroke stroke22 = categoryPlot21.getDomainGridlineStroke();
        strokeList12.setStroke(1, stroke22);
        java.awt.Paint paint24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setUpperMargin((double) 10L);
        java.awt.Color color28 = java.awt.Color.green;
        numberAxis25.setTickLabelPaint((java.awt.Paint) color28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke35 = null;
        barRenderer33.setSeriesOutlineStroke(0, stroke35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer33);
        java.awt.Stroke stroke38 = categoryPlot37.getDomainGridlineStroke();
        numberAxis25.setTickMarkStroke(stroke38);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) '4', (java.awt.Paint) color7, stroke22, paint24, stroke38, 52.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getRangeAxisEdge(0);
        java.util.List list27 = categoryPlot6.getAnnotations();
        java.util.Collection collection28 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list27);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(collection28);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.Image image6 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image6, "hi!", "", "hi!");
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        boolean boolean15 = projectInfo10.equals((java.lang.Object) rectangleConstraint13);
        org.jfree.data.Range range16 = rectangleConstraint13.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D17 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart7.setBorderVisible(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        numberAxis13.setAutoTickUnitSelection(true);
        java.awt.Paint paint20 = numberAxis13.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textLine22.calculateDimensions(graphics2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', (double) 0.0f, rectangleAnchor27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        textTitle29.draw(graphics2D30, rectangle2D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = textTitle29.getPosition();
        double double34 = numberAxis13.lengthToJava2D((double) 1, rectangle2D28, rectangleEdge33);
        plotRenderingInfo12.setDataArea(rectangle2D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        try {
            jFreeChart7.draw(graphics2D10, rectangle2D28, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        org.jfree.chart.event.ChartChangeListener chartChangeListener10 = null;
        try {
            jFreeChart7.addChangeListener(chartChangeListener10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation16 = axisLocation15.getOpposite();
        categoryPlot6.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot6.getRenderer((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = objectList10.equals((java.lang.Object) paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape9, paint11);
        numberAxis0.setUpArrow(shape9);
        java.awt.Paint paint15 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) (-1));
        axisState0.cursorDown((double) 10.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot12.getDomainAxisLocation((int) (byte) 0);
        categoryPlot12.clearAnnotations();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint5 = barRenderer0.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition(1, 2);
        double double9 = itemLabelPosition8.getAngle();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = numberAxis2.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle17.getPosition();
        axisState15.moveCursor((double) (-1), rectangleEdge21);
        axisCollection1.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge21);
        java.awt.Shape shape24 = numberAxis2.getRightArrow();
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape24, (double) 100L, (float) (short) 100, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot12.getDomainAxisLocation((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        categoryPlot27.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot27.getRowRenderingOrder();
        categoryPlot12.setColumnRenderingOrder(sortOrder31);
        categoryPlot12.setBackgroundImageAlignment(10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(sortOrder31);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setID("");
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets10.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (-1), (double) 100L, rectangleAnchor18);
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets10.createAdjustedRectangle(rectangle2D19, lengthAdjustmentType21, lengthAdjustmentType22);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D19, (double) 8, 0.0f, 100.0f);
        java.awt.Color color28 = java.awt.Color.MAGENTA;
        java.awt.Color color29 = color28.brighter();
        try {
            java.lang.Object obj30 = legendGraphic5.draw(graphics2D9, rectangle2D19, (java.lang.Object) color28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        float[] floatArray9 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray10 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray9);
        float[] floatArray11 = java.awt.Color.RGBtoHSB(500, 0, (int) (short) 100, floatArray10);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Font font18 = legendTitle16.getItemFont();
        java.awt.Font font19 = null;
        try {
            legendTitle16.setItemFont(font19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle16.getItemContainer();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color23 = color22.darker();
        java.awt.Color color25 = java.awt.Color.green;
        java.awt.Color color26 = color25.darker();
        java.awt.Color color27 = java.awt.Color.getColor("hi!", color25);
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        float[] floatArray35 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray36 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray35);
        float[] floatArray37 = color23.getColorComponents(colorSpace28, floatArray35);
        legendTitle16.setBackgroundPaint((java.awt.Paint) color23);
        java.lang.String str39 = legendTitle16.getID();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer47);
        boolean boolean49 = categoryPlot48.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection50 = null;
        categoryPlot48.setFixedLegendItems(legendItemCollection50);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = categoryPlot48.getRendererForDataset(categoryDataset52);
        java.awt.Paint paint54 = categoryPlot48.getRangeCrosshairPaint();
        try {
            java.lang.Object obj55 = legendTitle16.draw(graphics2D40, rectangle2D41, (java.lang.Object) categoryPlot48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(categoryItemRenderer53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        barRenderer0.setSeriesOutlineStroke(10, stroke44);
        boolean boolean47 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(drawingSupplier48);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        java.lang.String str2 = textBlockAnchor0.toString();
        java.lang.String str3 = textBlockAnchor0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        categoryPlot10.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot10.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot10.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = null;
        barRenderer17.setSeriesOutlineStroke(0, stroke19);
        categoryPlot10.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17, false);
        boolean boolean23 = categoryPlot10.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot10.getLegendItems();
        java.lang.Object obj25 = legendItemCollection24.clone();
        boolean boolean26 = textBlockAnchor0.equals((java.lang.Object) legendItemCollection24);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str1.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str2.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str3.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = numberAxis2.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot13.getDataset();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot13);
        boolean boolean17 = jFreeChart16.isBorderVisible();
        jFreeChart16.setTitle("10");
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.lang.String str21 = textTitle0.getToolTipText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 10L);
        java.awt.Color color13 = java.awt.Color.green;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color13);
        numberAxis10.setAutoTickUnitSelection(true);
        java.awt.Paint paint17 = numberAxis10.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textLine19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', (double) 0.0f, rectangleAnchor24);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        textTitle26.draw(graphics2D27, rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = textTitle26.getPosition();
        double double31 = numberAxis10.lengthToJava2D((double) 1, rectangle2D25, rectangleEdge30);
        plotRenderingInfo9.setDataArea(rectangle2D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double34 = categoryAxis0.getCategoryEnd((-16777216), 500, rectangle2D25, rectangleEdge33);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = new org.jfree.chart.axis.CategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        double double15 = range14.getUpperBound();
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement16);
        boolean boolean18 = range14.equals((java.lang.Object) blockContainer17);
        blockContainer17.clear();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeCrosshairLockedOnData();
        java.awt.Paint paint12 = categoryPlot10.getBackgroundPaint();
        categoryPlot10.setRangeCrosshairVisible(false);
        java.lang.String str15 = categoryPlot10.getNoDataMessage();
        boolean boolean16 = legendItemEntity3.equals((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean9 = objectList7.equals((java.lang.Object) paint8);
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape6, paint8);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape6, "AxisLocation.TOP_OR_LEFT", "Range[0.0,1.0]");
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.extendHeight(10.0d);
        valueMarker22.setLabelOffset(rectangleInsets23);
        float float27 = valueMarker22.getAlpha();
        double double28 = valueMarker22.getValue();
        java.awt.Stroke stroke29 = valueMarker22.getStroke();
        java.awt.Shape shape31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer37);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot38);
        boolean boolean40 = jFreeChart39.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = jFreeChart39.getCategoryPlot();
        boolean boolean42 = categoryPlot41.isDomainGridlinesVisible();
        java.awt.Stroke stroke43 = categoryPlot41.getOutlineStroke();
        java.awt.Paint paint44 = null;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]", "", "AxisLocation.TOP_OR_LEFT", "HorizontalAlignment.CENTER", false, shape6, false, (java.awt.Paint) color16, false, (java.awt.Paint) color20, stroke29, false, shape31, stroke43, paint44);
        boolean boolean46 = legendItem45.isShapeFilled();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.8f + "'", float27 == 0.8f);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(categoryPlot41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 10, (double) 0L, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        java.lang.String str31 = rectangleConstraint10.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str31.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range14, (double) 100.0f);
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        java.lang.String str18 = rectangleConstraint16.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]" + "'", str18.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.configure();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 3, font5);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        boolean boolean16 = categoryPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = null;
        categoryPlot15.setFixedLegendItems(legendItemCollection17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRendererForDataset(categoryDataset19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot15.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke27 = null;
        barRenderer25.setSeriesOutlineStroke(0, stroke27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer25);
        java.awt.Stroke stroke30 = categoryPlot29.getDomainGridlineStroke();
        categoryPlot15.setDomainGridlineStroke(stroke30);
        boolean boolean32 = categoryPlot15.isRangeZoomable();
        boolean boolean33 = categoryPlot15.isRangeCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder34 = categoryPlot15.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font8, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier37);
        java.awt.Paint paint39 = defaultDrawingSupplier37.getNextOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment40 = new org.jfree.chart.text.TextFragment("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", font5, paint39);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder34);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str1.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.Object obj2 = null;
        boolean boolean3 = lengthConstraintType1.equals(obj2);
        org.jfree.data.KeyedObject keyedObject4 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0.0d, (java.lang.Object) lengthConstraintType1);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        double double18 = numberAxis5.getAutoRangeMinimumSize();
        org.jfree.data.Range range19 = numberAxis5.getDefaultAutoRange();
        double double20 = range19.getUpperBound();
        numberAxis0.setRangeWithMargins(range19, true, false);
        org.jfree.data.RangeType rangeType24 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str25 = rangeType24.toString();
        numberAxis0.setRangeType(rangeType24);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rangeType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RangeType.NEGATIVE" + "'", str25.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot12.getDomainAxisLocation((int) (byte) 0);
        java.awt.Image image21 = categoryPlot12.getBackgroundImage();
        double[] doubleArray30 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray37 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray44 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray51 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray58 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray65 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray66 = new double[][] { doubleArray30, doubleArray37, doubleArray44, doubleArray51, doubleArray58, doubleArray65 };
        org.jfree.data.category.CategoryDataset categoryDataset67 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray66);
        categoryPlot12.setDataset(categoryDataset67);
        org.jfree.data.KeyToGroupMap keyToGroupMap69 = null;
        try {
            org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset67, keyToGroupMap69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(image21);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(categoryDataset67);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        double double5 = numberAxis0.getLowerBound();
        java.awt.Stroke stroke6 = numberAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        java.lang.String str22 = color17.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=0,g=178,b=0]" + "'", str22.equals("java.awt.Color[r=0,g=178,b=0]"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        java.lang.String str9 = categoryAnchor8.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str9.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryPlot6.setNoDataMessagePaint(paint10);
        categoryPlot6.clearRangeMarkers((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(192, 1);
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color21 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("", font20, (java.awt.Paint) color21, (float) '4');
        textLine18.addFragment(textFragment23);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean27 = categoryLabelWidthType25.equals((java.lang.Object) font26);
        boolean boolean28 = textFragment23.equals((java.lang.Object) font26);
        barRenderer0.setBaseItemLabelFont(font26, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator31 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator31);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) '#', (double) 100L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot6.getRangeAxisEdge((int) ' ');
        boolean boolean18 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        java.lang.String str3 = plotOrientation1.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.VERTICAL" + "'", str3.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        boolean boolean5 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) 100L, 0.0d);
        textTitle0.setVerticalAlignment(verticalAlignment7);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_RED;
        textTitle0.setPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeGridlineStroke();
        float float13 = categoryPlot6.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis1.setUpArrow(shape4);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "", "hi!");
        numberAxis1.setDownArrow(shape8);
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis1.setLabelFont(font13);
        org.jfree.chart.plot.Plot plot15 = numberAxis1.getPlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean20 = objectList18.equals((java.lang.Object) paint19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape17, paint19);
        boolean boolean22 = legendGraphic21.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic21.setMargin(rectangleInsets23);
        double double26 = rectangleInsets23.calculateLeftOutset((-1.0d));
        numberAxis1.setLabelInsets(rectangleInsets23);
        boolean boolean28 = strokeList0.equals((java.lang.Object) rectangleInsets23);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("HorizontalAlignment.CENTER", 16, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean5 = objectList3.equals((java.lang.Object) axisSpace4);
        axisSpace4.setRight((double) 0.0f);
        axisSpace0.ensureAtLeast(axisSpace4);
        double double9 = axisSpace4.getLeft();
        double double10 = axisSpace4.getLeft();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer19.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean23 = barRenderer19.isDrawBarOutline();
        boolean boolean24 = numberAxis14.equals((java.lang.Object) barRenderer19);
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) (-1), (double) 100L, rectangleAnchor29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis14.lengthToJava2D((double) 192, rectangle2D30, rectangleEdge31);
        try {
            java.awt.geom.Rectangle2D rectangle2D33 = axisSpace4.expand(rectangle2D11, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = null;
        barRenderer10.setSeriesOutlineStroke(0, stroke12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.awt.Stroke stroke15 = categoryPlot14.getDomainGridlineStroke();
        barRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(itemLabelPosition17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        java.util.List list9 = categoryPlot7.getAnnotations();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart7.removeProgressListener(chartProgressListener10);
        try {
            org.jfree.chart.plot.XYPlot xYPlot12 = jFreeChart7.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (-1.0f));
        org.jfree.chart.block.CenterArrangement centerArrangement9 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean28 = jFreeChart27.isBorderVisible();
        jFreeChart27.setTitle("10");
        textTitle11.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        columnArrangement8.add((org.jfree.chart.block.Block) blockContainer10, (java.lang.Object) jFreeChart27);
        org.jfree.chart.block.Block block33 = null;
        blockContainer10.add(block33);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        categoryPlot7.clearDomainMarkers(8);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot7.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.String str8 = chartEntity7.getToolTipText();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator9 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator10 = null;
        java.lang.String str11 = chartEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator9, uRLTagFragmentGenerator10);
        chartEntity7.setURLText("");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(categoryAxis8);
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, paintArray12, strokeArray13, strokeArray14, shapeArray15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        java.awt.Color color24 = java.awt.Color.blue;
        numberAxis19.setTickLabelPaint((java.awt.Paint) color24);
        numberAxis19.setAutoRangeStickyZero(false);
        boolean boolean28 = defaultDrawingSupplier16.equals((java.lang.Object) false);
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6, (float) '4');
        textLine3.addFragment(textFragment8);
        java.awt.Font font10 = textFragment8.getFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("MINOR", font10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke17 = null;
        barRenderer15.setSeriesOutlineStroke(0, stroke17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        java.awt.Stroke stroke20 = categoryPlot19.getDomainGridlineStroke();
        categoryPlot19.clearDomainMarkers(8);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("MINOR", font10, (org.jfree.chart.plot.Plot) categoryPlot19, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            java.awt.image.BufferedImage bufferedImage29 = jFreeChart24.createBufferedImage((-16777216), (-1), (int) '#', chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Paint paint6 = barRenderer0.getBaseFillPaint();
        boolean boolean7 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.TextTitle textTitle16 = null;
        jFreeChart15.setTitle(textTitle16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        boolean boolean20 = jFreeChart15.isNotify();
        java.lang.Class<?> wildcardClass21 = jFreeChart15.getClass();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        numberAxis0.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis0.getTickUnit();
        numberAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(numberTickUnit15);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        double double6 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 0.0f, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str3 = gradientPaintTransformType0.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str3.equals("GradientPaintTransformType.VERTICAL"));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("{0}", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getToolTipText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer3.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Paint paint11 = barRenderer3.getItemPaint((int) (byte) 0, 192);
        labelBlock1.setPaint(paint11);
        java.awt.Font font13 = labelBlock1.getFont();
        labelBlock1.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        java.awt.Stroke stroke14 = barRenderer0.lookupSeriesOutlineStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5, (float) '4');
        textLine2.addFragment(textFragment7);
        java.awt.Font font9 = textFragment7.getFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("MINOR", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Shape shape0 = null;
        double[] doubleArray11 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray18 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray25 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray32 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray39 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray46 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray47);
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity51 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "{0}", "Layer.BACKGROUND", categoryDataset48, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(192, 1);
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color21 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("", font20, (java.awt.Paint) color21, (float) '4');
        textLine18.addFragment(textFragment23);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean27 = categoryLabelWidthType25.equals((java.lang.Object) font26);
        boolean boolean28 = textFragment23.equals((java.lang.Object) font26);
        barRenderer0.setBaseItemLabelFont(font26, true);
        barRenderer0.setSeriesItemLabelsVisible(255, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle2.getPosition();
        axisState0.moveCursor((double) (-1), rectangleEdge6);
        axisState0.cursorDown((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        axisState0.moveCursor(1.0d, rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(192, 1);
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color21 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("", font20, (java.awt.Paint) color21, (float) '4');
        textLine18.addFragment(textFragment23);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean27 = categoryLabelWidthType25.equals((java.lang.Object) font26);
        boolean boolean28 = textFragment23.equals((java.lang.Object) font26);
        barRenderer0.setBaseItemLabelFont(font26, true);
        boolean boolean33 = barRenderer0.getItemCreateEntity(192, (int) (byte) 0);
        java.awt.Paint paint34 = barRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        barRenderer0.setSeriesOutlineStroke(10, stroke44);
        boolean boolean47 = barRenderer0.getAutoPopulateSeriesFillPaint();
        barRenderer0.setSeriesItemLabelsVisible(2, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator52);
        java.awt.Stroke stroke55 = barRenderer0.lookupSeriesOutlineStroke(255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Stroke stroke5 = numberAxis0.getAxisLineStroke();
        org.jfree.data.Range range6 = null;
        try {
            numberAxis0.setRangeWithMargins(range6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean9 = objectList7.equals((java.lang.Object) paint8);
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape6, paint8);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape6, "AxisLocation.TOP_OR_LEFT", "Range[0.0,1.0]");
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.extendHeight(10.0d);
        valueMarker22.setLabelOffset(rectangleInsets23);
        float float27 = valueMarker22.getAlpha();
        double double28 = valueMarker22.getValue();
        java.awt.Stroke stroke29 = valueMarker22.getStroke();
        java.awt.Shape shape31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer37);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot38);
        boolean boolean40 = jFreeChart39.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = jFreeChart39.getCategoryPlot();
        boolean boolean42 = categoryPlot41.isDomainGridlinesVisible();
        java.awt.Stroke stroke43 = categoryPlot41.getOutlineStroke();
        java.awt.Paint paint44 = null;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]", "", "AxisLocation.TOP_OR_LEFT", "HorizontalAlignment.CENTER", false, shape6, false, (java.awt.Paint) color16, false, (java.awt.Paint) color20, stroke29, false, shape31, stroke43, paint44);
        java.awt.Stroke stroke46 = legendItem45.getOutlineStroke();
        int int47 = legendItem45.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.8f + "'", float27 == 0.8f);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(categoryPlot41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        float float1 = numberAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        java.util.List list2 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        boolean boolean11 = barRenderer0.removeAnnotation(categoryAnnotation10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition(100, itemLabelPosition13, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setNotify(false);
        java.awt.Paint paint11 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart7.setBackgroundPaint(paint11);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot19.getRenderer();
        numberAxis6.setPlot((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setUpperMargin((double) 10L);
        java.awt.Color color25 = java.awt.Color.green;
        numberAxis22.setTickLabelPaint((java.awt.Paint) color25);
        int int27 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot19.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setUpperMargin((double) 10L);
        java.awt.Color color34 = java.awt.Color.green;
        numberAxis31.setTickLabelPaint((java.awt.Paint) color34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        numberAxis31.setTickMarkStroke(stroke44);
        categoryPlot19.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.axis.AxisState axisState48 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        textTitle50.draw(graphics2D51, rectangle2D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = textTitle50.getPosition();
        axisState48.moveCursor((double) (-1), rectangleEdge54);
        java.lang.String str56 = rectangleEdge54.toString();
        java.lang.String str57 = rectangleEdge54.toString();
        org.jfree.chart.axis.AxisSpace axisSpace58 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace59 = categoryAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D47, rectangleEdge54, axisSpace58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "RectangleEdge.TOP" + "'", str56.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleEdge.TOP" + "'", str57.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        java.lang.Object obj9 = legendGraphic5.clone();
        boolean boolean10 = legendGraphic5.isShapeFilled();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            legendGraphic5.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getRangeAxisEdge(0);
        java.util.List list27 = categoryPlot6.getAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperMargin((double) 10L);
        java.awt.Color color32 = java.awt.Color.green;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis36, categoryItemRenderer39);
        boolean boolean41 = numberAxis29.hasListener((java.util.EventListener) categoryPlot40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot40.getDataset();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot40);
        java.awt.Color color44 = java.awt.Color.green;
        jFreeChart43.setBorderPaint((java.awt.Paint) color44);
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color44);
        boolean boolean47 = categoryPlot6.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        numberAxis0.setNegativeArrowVisible(false);
        double double16 = numberAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) 500);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean5 = textLine1.equals((java.lang.Object) rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryPlot6.getInsets();
        categoryPlot6.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 2.0f, (double) 1.0f);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot6.getRangeAxis();
        valueAxis25.setVerticalTickLabels(false);
        java.awt.Font font28 = valueAxis25.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(valueAxis25);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 15);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart15.getTitle();
        java.util.List list19 = jFreeChart15.getSubtitles();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) (-1), (double) 100L, rectangleAnchor8);
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D9);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets0.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType11, lengthAdjustmentType12);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D9, (double) 8, 0.0f, 100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape17, "HorizontalAlignment.CENTER", "AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setUpperMargin((double) 10L);
        java.awt.Color color12 = java.awt.Color.green;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = numberAxis9.hasListener((java.util.EventListener) categoryPlot20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot20.getDataset();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot20);
        boolean boolean24 = jFreeChart23.isBorderVisible();
        jFreeChart23.setTitle("10");
        chartChangeEvent7.setChart(jFreeChart23);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        chartChangeEvent7.setChart(jFreeChart28);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart15.setPadding(rectangleInsets18);
        java.awt.Paint paint20 = jFreeChart15.getBackgroundPaint();
        boolean boolean21 = jFreeChart15.isNotify();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        boolean boolean46 = categoryPlot29.isRangeZoomable();
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot29.setRangeGridlineStroke(stroke47);
        boolean boolean49 = color22.equals((java.lang.Object) stroke47);
        jFreeChart15.setBorderStroke(stroke47);
        try {
            org.jfree.chart.plot.XYPlot xYPlot51 = jFreeChart15.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle16.getPosition();
        axisState14.moveCursor((double) (-1), rectangleEdge20);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis23, rectangleEdge24);
        java.lang.String str26 = rectangleEdge24.toString();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleEdge.TOP" + "'", str26.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        projectInfo7.setName("LegendItemEntity: seriesKey=null, dataset=null");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.title.Title title5 = titleChangeEvent4.getTitle();
        org.junit.Assert.assertNotNull(title5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setUpperMargin((double) 10L);
        java.awt.Color color21 = java.awt.Color.green;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        int int23 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        categoryPlot15.clearRangeAxes();
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Font font18 = legendTitle16.getItemFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = legendTitle16.getVerticalAlignment();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString((double) 10L);
        java.lang.String str4 = numberTickUnit0.valueToString((double) (byte) 100);
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color9 = color8.darker();
        java.awt.Color color11 = java.awt.Color.green;
        java.awt.Color color12 = color11.darker();
        java.awt.Color color13 = java.awt.Color.getColor("hi!", color11);
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        float[] floatArray21 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray22 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray21);
        float[] floatArray23 = color9.getColorComponents(colorSpace14, floatArray21);
        boolean boolean24 = numberTickUnit0.equals((java.lang.Object) colorSpace14);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        legendGraphic5.setHeight((double) (-1L));
        java.awt.Paint paint9 = legendGraphic5.getOutlinePaint();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            legendGraphic5.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 0.0f);
        double double3 = rectangleInsets0.getTop();
        double double5 = rectangleInsets0.calculateBottomInset(100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        barRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        barRenderer0.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("MINOR");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key MINOR");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 10L);
        java.awt.Color color13 = java.awt.Color.green;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color13);
        numberAxis10.setAutoTickUnitSelection(true);
        java.awt.Paint paint17 = numberAxis10.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textLine19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', (double) 0.0f, rectangleAnchor24);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        textTitle26.draw(graphics2D27, rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = textTitle26.getPosition();
        double double31 = numberAxis10.lengthToJava2D((double) 1, rectangle2D25, rectangleEdge30);
        plotRenderingInfo9.setDataArea(rectangle2D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double34 = categoryAxis0.getCategoryEnd((-16777216), 500, rectangle2D25, rectangleEdge33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor35);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(point2D36);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart15.setPadding(rectangleInsets18);
        java.awt.Paint paint20 = jFreeChart15.getBackgroundPaint();
        jFreeChart15.setAntiAlias(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot12.getRenderer();
        try {
            categoryPlot12.setBackgroundImageAlpha((float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RectangleEdge.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Color color7 = java.awt.Color.green;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        boolean boolean16 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot15.notifyListeners(plotChangeEvent17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot15.getDataset((int) ' ');
        keyedObjects0.setObject((java.lang.Comparable) 10.0d, (java.lang.Object) categoryPlot15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean26 = barRenderer23.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean28 = barRenderer23.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape31 = barRenderer23.getItemShape((int) (short) 1, 100);
        keyedObjects0.setObject((java.lang.Comparable) "AxisLocation.TOP_OR_LEFT", (java.lang.Object) 100);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range14, (double) 100.0f);
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range14, (double) (short) 10);
        double double19 = range18.getLowerBound();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        java.awt.Color color11 = java.awt.Color.white;
        barRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color11, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke20 = null;
        barRenderer18.setSeriesOutlineStroke(0, stroke20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        barRenderer18.notifyListeners(rendererChangeEvent23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean28 = barRenderer25.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color30 = java.awt.Color.green;
        java.awt.Color color31 = color30.darker();
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean34 = color31.equals((java.lang.Object) shape33);
        barRenderer25.setSeriesShape((int) '4', shape33);
        java.lang.Boolean boolean37 = barRenderer25.getSeriesCreateEntities(0);
        barRenderer25.setBaseSeriesVisible(false, false);
        java.awt.Color color41 = java.awt.Color.green;
        java.awt.Color color42 = color41.darker();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean45 = color42.equals((java.lang.Object) shape44);
        barRenderer25.setBaseFillPaint((java.awt.Paint) color42);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        boolean boolean55 = categoryPlot54.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection56 = null;
        categoryPlot54.setFixedLegendItems(legendItemCollection56);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = categoryPlot54.getRendererForDataset(categoryDataset58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot54.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke66 = null;
        barRenderer64.setSeriesOutlineStroke(0, stroke66);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer64);
        java.awt.Stroke stroke69 = categoryPlot68.getDomainGridlineStroke();
        categoryPlot54.setDomainGridlineStroke(stroke69);
        barRenderer25.setSeriesOutlineStroke(10, stroke69);
        boolean boolean72 = barRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer74 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean77 = barRenderer74.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean78 = barRenderer74.isDrawBarOutline();
        java.awt.Paint paint79 = barRenderer74.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition82 = barRenderer74.getNegativeItemLabelPosition(1, 2);
        barRenderer25.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition82);
        barRenderer18.setNegativeItemLabelPositionFallback(itemLabelPosition82);
        barRenderer0.setSeriesNegativeItemLabelPosition(1, itemLabelPosition82, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(categoryItemRenderer59);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(itemLabelPosition82);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart15.setPadding(rectangleInsets18);
        java.awt.Paint paint20 = jFreeChart15.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer21.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        boolean boolean26 = barRenderer21.removeAnnotation(categoryAnnotation25);
        java.awt.Paint paint27 = barRenderer21.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        barRenderer21.setBaseItemLabelGenerator(categoryItemLabelGenerator28, false);
        barRenderer21.setItemLabelAnchorOffset((double) (short) 0);
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer21.setBaseStroke(stroke33);
        jFreeChart15.setBorderStroke(stroke33);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "ItemLabelAnchor.CENTER", "hi!", "");
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list6 = axisCollection5.getAxesAtRight();
        java.util.List list7 = axisCollection5.getAxesAtRight();
        boolean boolean8 = library4.equals((java.lang.Object) axisCollection5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList5 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint6 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean7 = objectList5.equals((java.lang.Object) paint6);
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape4, paint6);
        boolean boolean9 = legendGraphic8.isLineVisible();
        java.awt.Paint paint10 = null;
        legendGraphic8.setFillPaint(paint10);
        java.awt.Shape shape12 = null;
        legendGraphic8.setLine(shape12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendGraphic8.getShapeLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendGraphic8.getShapeLocation();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str17 = textBlockAnchor16.toString();
        java.lang.String str18 = textBlockAnchor16.toString();
        java.lang.String str19 = textBlockAnchor16.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str17.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str18.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str19.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setTextAlignment(horizontalAlignment1);
        java.awt.Paint paint11 = textTitle0.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        textTitle0.setPosition(rectangleEdge12);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textTitle0.arrange(graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot6.getRangeAxisEdge((int) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = null;
        categoryPlot24.setFixedLegendItems(legendItemCollection26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRendererForDataset(categoryDataset28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot24.getRangeAxisLocation();
        java.lang.String str31 = axisLocation30.toString();
        categoryPlot6.setDomainAxisLocation(axisLocation30, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str31.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        java.awt.Paint paint2 = lineBorder0.getPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            lineBorder0.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RectangleEdge.TOP");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType3);
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) standardGradientPaintTransformer4);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range27, 10.0d);
        double double33 = range32.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis34.setUpArrow(shape37);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape41, "", "hi!");
        numberAxis34.setDownArrow(shape41);
        numberAxis34.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.data.Range range49 = numberAxis34.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(range32, range49);
        try {
            org.jfree.data.Range range53 = org.jfree.data.Range.expand(range32, (double) 1L, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-10.0) <= upper (-1.6777215E8).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) (-1), (double) 100L, rectangleAnchor8);
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D9);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList13 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean15 = objectList13.equals((java.lang.Object) paint14);
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape12, paint14);
        boolean boolean17 = legendGraphic16.isLineVisible();
        java.awt.Paint paint18 = null;
        legendGraphic16.setFillPaint(paint18);
        java.awt.Shape shape20 = null;
        legendGraphic16.setLine(shape20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendGraphic16.getShapeLocation();
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor22);
        java.awt.geom.AffineTransform affineTransform24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot31);
        java.awt.RenderingHints renderingHints33 = jFreeChart32.getRenderingHints();
        java.awt.PaintContext paintContext34 = color0.createContext(colorModel1, rectangle2, rectangle2D9, affineTransform24, renderingHints33);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(renderingHints33);
        org.junit.Assert.assertNotNull(paintContext34);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(categoryAxis8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot6.getParent();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot6.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot11.notifyListeners(plotChangeEvent13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot11.getDatasetGroup();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(datasetGroup15);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        boolean boolean7 = numberAxis0.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        boolean boolean10 = numberAxis0.isAutoRange();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape13, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape13, "");
        numberAxis0.setUpArrow(shape13);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        java.lang.Object obj21 = legendItemEntity20.clone();
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        legendItemEntity20.setArea(shape22);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5, (float) '4');
        textLine2.addFragment(textFragment7);
        java.awt.Font font9 = textFragment7.getFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("MINOR", font9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean12 = labelBlock10.equals((java.lang.Object) axisLocation11);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (-6.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean16 = jFreeChart15.isBorderVisible();
        jFreeChart15.setTitle("10");
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart15.getLegend(0);
        java.awt.Paint paint21 = jFreeChart15.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(192, 1);
        barRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer3.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean12 = color9.equals((java.lang.Object) shape11);
        barRenderer3.setSeriesShape((int) '4', shape11);
        java.lang.Boolean boolean15 = barRenderer3.getSeriesCreateEntities(0);
        barRenderer3.setBaseSeriesVisible(false, false);
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color20 = color19.darker();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean23 = color20.equals((java.lang.Object) shape22);
        barRenderer3.setBaseFillPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot32.getRendererForDataset(categoryDataset36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot32.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke44 = null;
        barRenderer42.setSeriesOutlineStroke(0, stroke44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        java.awt.Stroke stroke47 = categoryPlot46.getDomainGridlineStroke();
        categoryPlot32.setDomainGridlineStroke(stroke47);
        barRenderer3.setSeriesOutlineStroke(10, stroke47);
        numberAxis0.setAxisLineStroke(stroke47);
        java.awt.Color color51 = java.awt.Color.BLUE;
        numberAxis0.setLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis0.isAutoRange();
        org.jfree.data.RangeType rangeType54 = numberAxis0.getRangeType();
        boolean boolean55 = numberAxis0.isTickMarksVisible();
        try {
            numberAxis0.setRangeAboutValue((double) 100.0f, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.5) <= upper (99.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        double double2 = size2D0.getWidth();
        size2D0.setHeight((double) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean9 = objectList7.equals((java.lang.Object) paint8);
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape6, paint8);
        boolean boolean11 = legendGraphic10.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic10.setMargin(rectangleInsets12);
        legendGraphic10.setPadding(2.0d, 0.0d, (double) (byte) 100, (double) 500);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendGraphic10.getShapeLocation();
        boolean boolean20 = size2D0.equals((java.lang.Object) legendGraphic10);
        java.lang.Object obj21 = size2D0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis1.setUpArrow(shape4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setUpperMargin((double) 10L);
        java.awt.Color color9 = java.awt.Color.green;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        boolean boolean18 = numberAxis6.hasListener((java.util.EventListener) categoryPlot17);
        double double19 = numberAxis6.getAutoRangeMinimumSize();
        org.jfree.data.Range range20 = numberAxis6.getDefaultAutoRange();
        double double21 = range20.getUpperBound();
        numberAxis1.setRangeWithMargins(range20, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range20);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-8d + "'", double19 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = barRenderer0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 10);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean5 = objectList3.equals((java.lang.Object) axisSpace4);
        axisSpace4.setRight((double) 0.0f);
        axisSpace0.ensureAtLeast(axisSpace4);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace0.add((double) 52.0f, rectangleEdge10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot18);
        boolean boolean20 = jFreeChart19.getAntiAlias();
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        jFreeChart19.setBorderPaint(paint21);
        boolean boolean23 = axisSpace0.equals((java.lang.Object) paint21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot12.getRenderer();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.extendHeight(10.0d);
        valueMarker18.setLabelOffset(rectangleInsets19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18, layer23);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(layer23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        barRenderer0.setItemMargin((double) 500);
        java.awt.Font font21 = barRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, (double) (short) 0, 6.0d);
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean13 = objectList11.equals((java.lang.Object) axisSpace12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = null;
        barRenderer17.setSeriesOutlineStroke(0, stroke19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Stroke stroke22 = categoryPlot21.getDomainGridlineStroke();
        categoryPlot21.clearDomainMarkers(8);
        java.util.List list25 = categoryPlot21.getAnnotations();
        int int26 = objectList11.indexOf((java.lang.Object) categoryPlot21);
        java.awt.Paint paint27 = categoryPlot21.getDomainGridlinePaint();
        java.awt.Font font30 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color31 = java.awt.Color.green;
        java.awt.Color color32 = color31.darker();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean35 = color32.equals((java.lang.Object) shape34);
        org.jfree.chart.text.TextMeasurer textMeasurer38 = null;
        org.jfree.chart.text.TextBlock textBlock39 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color32, (float) (short) 0, 192, textMeasurer38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setUpperMargin((double) 10L);
        java.awt.Color color47 = java.awt.Color.green;
        numberAxis44.setTickLabelPaint((java.awt.Paint) color47);
        numberAxis44.setAutoTickUnitSelection(true);
        java.awt.Paint paint51 = numberAxis44.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine53 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.util.Size2D size2D55 = textLine53.calculateDimensions(graphics2D54);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D59 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D55, (double) '#', (double) 0.0f, rectangleAnchor58);
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        textTitle60.draw(graphics2D61, rectangle2D62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = textTitle60.getPosition();
        double double65 = numberAxis44.lengthToJava2D((double) 1, rectangle2D59, rectangleEdge64);
        plotRenderingInfo43.setDataArea(rectangle2D59);
        java.awt.Stroke stroke67 = null;
        java.awt.Color color68 = org.jfree.chart.ChartColor.DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem(attributedString0, "CategoryLabelWidthType.CATEGORY", "LegendItemEntity: seriesKey=null, dataset=null", "AxisLocation.BOTTOM_OR_LEFT", false, shape9, false, paint27, false, (java.awt.Paint) color32, stroke40, true, (java.awt.Shape) rectangle2D59, stroke67, (java.awt.Paint) color68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(textBlock39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(size2D55);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(color68);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart15.setPadding(rectangleInsets18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        textTitle20.draw(graphics2D21, rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle20.getPosition();
        boolean boolean25 = rectangleInsets18.equals((java.lang.Object) textTitle20);
        java.awt.Paint paint26 = textTitle20.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = null;
        barRenderer16.setSeriesOutlineStroke(0, stroke18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Stroke stroke21 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot6.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot6.isRangeZoomable();
        boolean boolean24 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot6.getDomainAxisForDataset((-10420321));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(categoryAxis26);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.chart.ui.Library library12 = new org.jfree.chart.ui.Library("hi!", "ItemLabelAnchor.CENTER", "hi!", "");
        projectInfo7.addLibrary(library12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.data.Range range13 = rectangleConstraint10.getWidthRange();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        boolean boolean26 = numberAxis14.hasListener((java.util.EventListener) categoryPlot25);
        double double27 = numberAxis14.getAutoRangeMinimumSize();
        org.jfree.data.Range range28 = numberAxis14.getDefaultAutoRange();
        double double29 = range28.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range28);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint10.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E-8d + "'", double27 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = color2.darker();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean6 = color3.equals((java.lang.Object) shape5);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color3, (float) (short) 0, 192, textMeasurer9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment13, verticalAlignment14, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment14, 0.0d, (double) (-1.0f));
        textTitle11.setTextAlignment(horizontalAlignment12);
        textBlock10.setLineAlignment(horizontalAlignment12);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textBlock10.calculateDimensions(graphics2D23);
        double double25 = size2D24.width;
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Color color16 = java.awt.Color.blue;
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        java.awt.RenderingHints renderingHints30 = jFreeChart29.getRenderingHints();
        java.awt.PaintContext paintContext31 = color16.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints30);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(renderingHints30);
        org.junit.Assert.assertNotNull(paintContext31);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList13 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean15 = objectList13.equals((java.lang.Object) paint14);
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape12, paint14);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape12, "AxisLocation.TOP_OR_LEFT", "Range[0.0,1.0]");
        java.awt.Color color22 = java.awt.Color.green;
        java.awt.Color color23 = color22.darker();
        java.awt.Color color24 = java.awt.Color.getColor("hi!", color22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double31 = rectangleInsets29.extendHeight(10.0d);
        valueMarker28.setLabelOffset(rectangleInsets29);
        float float33 = valueMarker28.getAlpha();
        double double34 = valueMarker28.getValue();
        java.awt.Stroke stroke35 = valueMarker28.getStroke();
        java.awt.Shape shape37 = null;
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis40, categoryItemRenderer43);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot44);
        boolean boolean46 = jFreeChart45.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = jFreeChart45.getCategoryPlot();
        boolean boolean48 = categoryPlot47.isDomainGridlinesVisible();
        java.awt.Stroke stroke49 = categoryPlot47.getOutlineStroke();
        java.awt.Paint paint50 = null;
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]", "", "AxisLocation.TOP_OR_LEFT", "HorizontalAlignment.CENTER", false, shape12, false, (java.awt.Paint) color22, false, (java.awt.Paint) color26, stroke35, false, shape37, stroke49, paint50);
        barRenderer0.setSeriesPaint(3, (java.awt.Paint) color26, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.8f + "'", float33 == 0.8f);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-1.0d) + "'", double34 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(categoryPlot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = barRenderer0.getBasePaint();
        boolean boolean16 = barRenderer0.isDrawBarOutline();
        barRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) true);
        barRenderer0.setSeriesVisible((int) (byte) 10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("DatasetRenderingOrder.REVERSE", "Category Plot", "PlotOrientation.VERTICAL", "VerticalAlignment.TOP", "CategoryLabelWidthType.CATEGORY");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot6.getRangeAxisLocation((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        barRenderer0.setSeriesOutlineStroke(10, stroke44);
        boolean boolean47 = barRenderer0.getAutoPopulateSeriesFillPaint();
        barRenderer0.setSeriesItemLabelsVisible(2, (java.lang.Boolean) true, false);
        java.awt.Font font53 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color54 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("", font53, (java.awt.Paint) color54, 0.0f);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color54, true);
        barRenderer0.setItemLabelAnchorOffset((double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle16.getItemContainer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setBaseSeriesVisible(true, false);
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block25 = null;
        java.lang.Object obj26 = null;
        columnArrangement24.add(block25, obj26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer19, (org.jfree.chart.block.Arrangement) columnArrangement23, (org.jfree.chart.block.Arrangement) columnArrangement24);
        boolean boolean29 = blockContainer18.equals((java.lang.Object) columnArrangement24);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis5, categoryItemRenderer8);
        numberAxis5.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot18.getRenderer();
        numberAxis5.setPlot((org.jfree.chart.plot.Plot) categoryPlot18);
        boolean boolean21 = lineBorder1.equals((java.lang.Object) categoryPlot18);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.awt.Shape shape27 = barRenderer14.getItemShape((int) (byte) 0, (int) (byte) 100);
        boolean boolean28 = barRenderer14.isDrawBarOutline();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset5, 2);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset5, 16);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset5);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 10L);
        java.awt.Color color13 = java.awt.Color.green;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        boolean boolean22 = numberAxis10.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = categoryPlot21.getDataset();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot21);
        categoryPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot6.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem28 = legendItemCollection26.get((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(categoryDataset23);
        org.junit.Assert.assertNotNull(legendItemCollection26);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryAxis0.equals(obj1);
        double double3 = categoryAxis0.getLowerMargin();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer6.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color11 = java.awt.Color.green;
        java.awt.Color color12 = color11.darker();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean15 = color12.equals((java.lang.Object) shape14);
        barRenderer6.setSeriesShape((int) '4', shape14);
        barRenderer6.setBaseCreateEntities(false, true);
        barRenderer6.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer6.setBasePaint((java.awt.Paint) color26, true);
        java.awt.Paint paint30 = barRenderer6.lookupSeriesPaint(8);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setUpperMargin((double) 10L);
        java.awt.Color color35 = java.awt.Color.green;
        numberAxis32.setTickLabelPaint((java.awt.Paint) color35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer42);
        boolean boolean44 = numberAxis32.hasListener((java.util.EventListener) categoryPlot43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot43.getDataset();
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot43);
        org.jfree.chart.title.LegendTitle legendTitle47 = jFreeChart46.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer48 = legendTitle47.getItemContainer();
        java.awt.Font font49 = legendTitle47.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder();
        legendTitle47.setFrame((org.jfree.chart.block.BlockFrame) lineBorder50);
        java.awt.geom.Rectangle2D rectangle2D52 = legendTitle47.getBounds();
        barRenderer6.setBaseShape((java.awt.Shape) rectangle2D52);
        org.jfree.chart.util.Size2D size2D54 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D54, (double) (-1), (double) 100L, rectangleAnchor57);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement65 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment61, verticalAlignment62, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement68 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment60, verticalAlignment62, 0.0d, (double) (-1.0f));
        textTitle59.setTextAlignment(horizontalAlignment60);
        java.awt.Paint paint70 = textTitle59.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean72 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge71);
        textTitle59.setPosition(rectangleEdge71);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo74);
        try {
            org.jfree.chart.axis.AxisState axisState76 = categoryAxis0.draw(graphics2D4, (double) 2, rectangle2D52, rectangle2D58, rectangleEdge71, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertNotNull(legendTitle47);
        org.junit.Assert.assertNotNull(blockContainer48);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(horizontalAlignment61);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image4, "hi!", "", "hi!");
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint11.toUnconstrainedWidth();
        boolean boolean13 = projectInfo8.equals((java.lang.Object) rectangleConstraint11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        boolean boolean26 = numberAxis14.hasListener((java.util.EventListener) categoryPlot25);
        double double27 = numberAxis14.getAutoRangeMinimumSize();
        org.jfree.data.Range range28 = numberAxis14.getDefaultAutoRange();
        java.lang.Object obj29 = null;
        boolean boolean30 = range28.equals(obj29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint11.toRangeHeight(range28);
        boolean boolean32 = textAnchor0.equals((java.lang.Object) rectangleConstraint31);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E-8d + "'", double27 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font22 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color23 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("", font22, (java.awt.Paint) color23, (float) '4');
        textLine20.addFragment(textFragment25);
        java.awt.Font font27 = textFragment25.getFont();
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("MINOR", font27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis29.setUpArrow(shape32);
        boolean boolean34 = numberAxis29.getAutoRangeIncludesZero();
        boolean boolean35 = numberAxis29.isPositiveArrowVisible();
        boolean boolean36 = numberAxis29.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis29.setMarkerBand(markerAxisBand37);
        boolean boolean39 = numberAxis29.isAutoRange();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity(shape42, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape42, "");
        numberAxis29.setUpArrow(shape42);
        java.awt.Shape shape49 = numberAxis29.getLeftArrow();
        blockContainer17.add((org.jfree.chart.block.Block) labelBlock28, (java.lang.Object) shape49);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double55 = rectangleInsets53.extendHeight(10.0d);
        valueMarker52.setLabelOffset(rectangleInsets53);
        labelBlock28.setMargin(rectangleInsets53);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 10.0d + "'", double55 == 10.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = plotRenderingInfo1.getSubplotInfo((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot6.getRangeAxisEdge((int) ' ');
        boolean boolean18 = categoryPlot6.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("AxisLocation.BOTTOM_OR_LEFT");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines(15);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=0,g=178,b=0]", (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        double double15 = range14.getUpperBound();
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement16);
        boolean boolean18 = range14.equals((java.lang.Object) blockContainer17);
        java.util.List list19 = blockContainer17.getBlocks();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        int int5 = color3.getRGB();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-16777216) + "'", int5 == (-16777216));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        boolean boolean33 = range27.intersects((double) 500, (double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setUpperMargin((double) 10L);
        java.awt.Color color21 = java.awt.Color.green;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        int int23 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot15.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke37 = null;
        barRenderer35.setSeriesOutlineStroke(0, stroke37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        java.awt.Stroke stroke40 = categoryPlot39.getDomainGridlineStroke();
        numberAxis27.setTickMarkStroke(stroke40);
        categoryPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis27);
        boolean boolean43 = numberAxis27.isPositiveArrowVisible();
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        double double14 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range15 = numberAxis1.getDefaultAutoRange();
        java.lang.Object obj16 = null;
        boolean boolean17 = range15.equals(obj16);
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) "ItemLabelAnchor.CENTER", (java.lang.Object) boolean17);
        java.lang.Object obj19 = keyedObject18.clone();
        java.lang.Comparable comparable20 = keyedObject18.getKey();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + "ItemLabelAnchor.CENTER" + "'", comparable20.equals("ItemLabelAnchor.CENTER"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        barRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer0.setBasePaint((java.awt.Paint) color20, true);
        java.awt.Paint paint24 = barRenderer0.lookupSeriesPaint(8);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setUpperMargin((double) 10L);
        java.awt.Color color29 = java.awt.Color.green;
        numberAxis26.setTickLabelPaint((java.awt.Paint) color29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        boolean boolean38 = numberAxis26.hasListener((java.util.EventListener) categoryPlot37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot37.getDataset();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot37);
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart40.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer42 = legendTitle41.getItemContainer();
        java.awt.Font font43 = legendTitle41.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder44 = new org.jfree.chart.block.LineBorder();
        legendTitle41.setFrame((org.jfree.chart.block.BlockFrame) lineBorder44);
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle41.getBounds();
        barRenderer0.setBaseShape((java.awt.Shape) rectangle2D46);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = barRenderer0.getURLGenerator(0, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(blockContainer42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNull(categoryURLGenerator50);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = legendGraphic5.arrange(graphics2D6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic5.getShapeLocation();
        java.lang.Object obj9 = null;
        boolean boolean10 = rectangleAnchor8.equals(obj9);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) (short) 1, 100);
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesStroke();
        double double10 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = null;
        barRenderer0.setSeriesStroke((int) (byte) 10, stroke12, false);
        java.awt.Paint paint16 = barRenderer0.getSeriesPaint(8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) '4');
        textLine1.addFragment(textFragment6);
        float float8 = textFragment6.getBaselineOffset();
        java.awt.Paint paint9 = textFragment6.getPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation16 = axisLocation15.getOpposite();
        categoryPlot6.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        numberAxis0.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.data.Range range15 = numberAxis0.getRange();
        boolean boolean16 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isRangeCrosshairLockedOnData();
        boolean boolean9 = categoryPlot7.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setUpperMargin((double) 10L);
        java.awt.Color color14 = java.awt.Color.green;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer21);
        boolean boolean23 = numberAxis11.hasListener((java.util.EventListener) categoryPlot22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot22.getDataset();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Color color26 = java.awt.Color.green;
        jFreeChart25.setBorderPaint((java.awt.Paint) color26);
        categoryPlot7.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        boolean boolean29 = plotOrientation0.equals((java.lang.Object) categoryPlot7);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.extendHeight(10.0d);
        valueMarker1.setLabelOffset(rectangleInsets2);
        float float6 = valueMarker1.getAlpha();
        double double7 = valueMarker1.getValue();
        java.lang.Object obj8 = valueMarker1.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        valueMarker1.setOutlinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.8f + "'", float6 == 0.8f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle0.getTextAlignment();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean18 = barRenderer14.isDrawBarOutline();
        boolean boolean19 = numberAxis9.equals((java.lang.Object) barRenderer14);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (-1), (double) 100L, rectangleAnchor24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis9.lengthToJava2D((double) 192, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis28.setUpArrow(shape31);
        numberAxis28.setFixedDimension((double) '#');
        java.lang.Object obj35 = textTitle0.draw(graphics2D6, rectangle2D25, (java.lang.Object) numberAxis28);
        boolean boolean36 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        boolean boolean10 = categoryPlot9.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj12 = axisSpace11.clone();
        categoryPlot9.setFixedRangeAxisSpace(axisSpace11);
        double double14 = axisSpace11.getBottom();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) '#', (double) 0.0f, rectangleAnchor5);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D6);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        int int3 = keyedObjects0.getIndex((java.lang.Comparable) (-1L));
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer12.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean16 = barRenderer12.isDrawBarOutline();
        boolean boolean17 = numberAxis7.equals((java.lang.Object) barRenderer12);
        keyedObjects0.addObject((java.lang.Comparable) (short) 100, (java.lang.Object) numberAxis7);
        java.lang.Object obj19 = null;
        boolean boolean20 = keyedObjects0.equals(obj19);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (-1), (double) 100L, rectangleAnchor11);
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets3.createAdjustedRectangle(rectangle2D12, lengthAdjustmentType14, lengthAdjustmentType15);
        try {
            labelBlock1.draw(graphics2D2, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = null;
        barRenderer10.setSeriesOutlineStroke(0, stroke12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.awt.Stroke stroke15 = categoryPlot14.getDomainGridlineStroke();
        barRenderer0.setBaseStroke(stroke15);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setUpperMargin((double) 10L);
        java.awt.Color color22 = java.awt.Color.green;
        numberAxis19.setTickLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_CENTER", font18, (java.awt.Paint) color22);
        boolean boolean25 = barRenderer0.equals((java.lang.Object) color22);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 0.0f);
        double double3 = rectangleInsets0.getTop();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets0.getUnitType();
        java.lang.String str5 = unitType4.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UnitType.ABSOLUTE" + "'", str5.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        java.lang.Class<?> wildcardClass2 = categoryLabelPositions1.getClass();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 3, (double) 16, (int) (short) 100, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 0, "hi!", textAnchor3, textAnchor4, (double) (byte) 100);
        double double7 = numberTick6.getValue();
        java.lang.String str8 = numberTick6.getText();
        double double9 = numberTick6.getAngle();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setUpperMargin((double) 10L);
        java.awt.Color color9 = java.awt.Color.green;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        boolean boolean18 = numberAxis6.hasListener((java.util.EventListener) categoryPlot17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot17.getDataset();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot17);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart20.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame22 = legendTitle21.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer23 = legendTitle21.getItemContainer();
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color28 = color27.darker();
        java.awt.Color color30 = java.awt.Color.green;
        java.awt.Color color31 = color30.darker();
        java.awt.Color color32 = java.awt.Color.getColor("hi!", color30);
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        float[] floatArray40 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray41 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray40);
        float[] floatArray42 = color28.getColorComponents(colorSpace33, floatArray40);
        legendTitle21.setBackgroundPaint((java.awt.Paint) color28);
        java.lang.String str44 = legendTitle21.getID();
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) "NOID");
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryDataset19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockFrame22);
        org.junit.Assert.assertNotNull(blockContainer23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setUpperMargin((double) 10L);
        java.awt.Paint paint19 = numberAxis16.getTickMarkPaint();
        float float20 = numberAxis16.getTickMarkOutsideLength();
        java.awt.Paint paint21 = numberAxis16.getTickLabelPaint();
        try {
            barRenderer0.setSeriesItemLabelPaint((-16777216), paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle16.getPosition();
        axisState14.moveCursor((double) (-1), rectangleEdge20);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge20);
        java.awt.Shape shape23 = numberAxis1.getRightArrow();
        java.awt.Font font24 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean10 = projectInfo7.equals((java.lang.Object) blockBorder9);
        projectInfo7.setLicenceName("[size=1]");
        projectInfo7.setLicenceName("52");
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block6 = null;
        java.lang.Object obj7 = null;
        columnArrangement5.add(block6, obj7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.extendHeight(10.0d);
        valueMarker11.setLabelOffset(rectangleInsets12);
        float float16 = valueMarker11.getAlpha();
        double double17 = valueMarker11.getValue();
        java.lang.Object obj18 = valueMarker11.clone();
        boolean boolean19 = columnArrangement4.equals(obj18);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis((int) 'a');
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer13);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.BACKGROUND" + "'", str14.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        boolean boolean7 = numberAxis0.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.setRangeAboutValue((double) (short) 0, (double) 0);
        java.awt.Shape shape15 = numberAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(categoryAxis8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot6.getParent();
        double[] doubleArray19 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray26 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray33 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray40 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray47 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray54 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray55);
        java.lang.Number number57 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset56);
        categoryPlot6.setDataset(categoryDataset56);
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset56);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-6.0d) + "'", number57.equals((-6.0d)));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 600.0d + "'", number58.equals(600.0d));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (-6.0d) + "'", number60.equals((-6.0d)));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        boolean boolean18 = categoryPlot17.isRangeCrosshairLockedOnData();
        boolean boolean19 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot17.getRangeAxisForDataset((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot17.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot17.getDomainAxisEdge((-16777216));
        org.jfree.chart.axis.AxisCollection axisCollection25 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list26 = axisCollection25.getAxesAtRight();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        axisCollection25.add((org.jfree.chart.axis.Axis) numberAxis27, rectangleEdge32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setUpperMargin((double) 10L);
        java.awt.Color color38 = java.awt.Color.green;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color38);
        numberAxis35.setAutoTickUnitSelection(true);
        java.awt.Paint paint42 = numberAxis35.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textLine44.calculateDimensions(graphics2D45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, (double) '#', (double) 0.0f, rectangleAnchor49);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        textTitle51.draw(graphics2D52, rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = textTitle51.getPosition();
        double double56 = numberAxis35.lengthToJava2D((double) 1, rectangle2D50, rectangleEdge55);
        barRenderer0.drawRangeGridline(graphics2D10, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis27, rectangle2D50, (double) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(valueAxis21);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(10, 1, (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection26 = categoryPlot24.getRangeMarkers(layer25);
        java.awt.Paint paint27 = categoryPlot24.getBackgroundPaint();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Stroke stroke7 = null;
        barRenderer0.setSeriesOutlineStroke(8, stroke7, false);
        barRenderer0.setMaximumBarWidth((double) 8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        numberAxis1.setAutoTickUnitSelection(true);
        java.awt.Paint paint8 = numberAxis1.getTickMarkPaint();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean13 = objectList11.equals((java.lang.Object) paint12);
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape10, paint12);
        numberAxis1.setUpArrow(shape10);
        boolean boolean16 = color0.equals((java.lang.Object) shape10);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape10, "MINOR");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        barRenderer0.setSeriesVisible(192, (java.lang.Boolean) false, true);
        barRenderer0.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer5.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean9 = barRenderer5.isDrawBarOutline();
        java.awt.Paint paint10 = barRenderer5.getBasePaint();
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[size=1]", "hi!", "Range[0.0,1.0]", shape4, paint10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double15 = rectangleInsets13.calculateLeftInset((double) 192);
        categoryPlot6.setInsets(rectangleInsets13);
        int int17 = categoryPlot6.getRangeAxisCount();
        java.awt.Paint paint18 = null;
        try {
            categoryPlot6.setRangeCrosshairPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color4 = color3.darker();
        java.lang.String str5 = color3.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str5.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList32 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint33 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean34 = objectList32.equals((java.lang.Object) paint33);
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape31, paint33);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape31, "AxisLocation.TOP_OR_LEFT", "Range[0.0,1.0]");
        java.awt.Color color41 = java.awt.Color.green;
        java.awt.Color color42 = color41.darker();
        java.awt.Color color43 = java.awt.Color.getColor("hi!", color41);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double50 = rectangleInsets48.extendHeight(10.0d);
        valueMarker47.setLabelOffset(rectangleInsets48);
        float float52 = valueMarker47.getAlpha();
        double double53 = valueMarker47.getValue();
        java.awt.Stroke stroke54 = valueMarker47.getStroke();
        java.awt.Shape shape56 = null;
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        numberAxis59.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer62);
        org.jfree.chart.JFreeChart jFreeChart64 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot63);
        boolean boolean65 = jFreeChart64.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = jFreeChart64.getCategoryPlot();
        boolean boolean67 = categoryPlot66.isDomainGridlinesVisible();
        java.awt.Stroke stroke68 = categoryPlot66.getOutlineStroke();
        java.awt.Paint paint69 = null;
        org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]", "", "AxisLocation.TOP_OR_LEFT", "HorizontalAlignment.CENTER", false, shape31, false, (java.awt.Paint) color41, false, (java.awt.Paint) color45, stroke54, false, shape56, stroke68, paint69);
        numberAxis7.setAxisLinePaint((java.awt.Paint) color45);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 10.0d + "'", double50 == 10.0d);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.8f + "'", float52 == 0.8f);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-1.0d) + "'", double53 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(categoryPlot66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart15.setPadding(rectangleInsets18);
        java.awt.Paint paint20 = jFreeChart15.getBackgroundPaint();
        boolean boolean21 = jFreeChart15.isNotify();
        int int22 = jFreeChart15.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        double double2 = valueMarker1.getValue();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer3.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean12 = color9.equals((java.lang.Object) shape11);
        barRenderer3.setSeriesShape((int) '4', shape11);
        java.lang.Boolean boolean15 = barRenderer3.getSeriesCreateEntities(0);
        barRenderer3.setBaseSeriesVisible(false, false);
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color20 = color19.darker();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean23 = color20.equals((java.lang.Object) shape22);
        barRenderer3.setBaseFillPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot32.getRendererForDataset(categoryDataset36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot32.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke44 = null;
        barRenderer42.setSeriesOutlineStroke(0, stroke44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        java.awt.Stroke stroke47 = categoryPlot46.getDomainGridlineStroke();
        categoryPlot32.setDomainGridlineStroke(stroke47);
        barRenderer3.setSeriesOutlineStroke(10, stroke47);
        boolean boolean50 = barRenderer3.getAutoPopulateSeriesFillPaint();
        barRenderer3.setSeriesItemLabelsVisible(2, (java.lang.Boolean) true, false);
        java.awt.Font font56 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color57 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment59 = new org.jfree.chart.text.TextFragment("", font56, (java.awt.Paint) color57, 0.0f);
        barRenderer3.setBaseItemLabelPaint((java.awt.Paint) color57, true);
        valueMarker1.setPaint((java.awt.Paint) color57);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color4 = java.awt.Color.getColor("", (int) (short) 100);
        paintList0.setPaint(100, (java.awt.Paint) color4);
        java.awt.Paint paint7 = paintList0.getPaint(255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getToolTipText();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle3.draw(graphics2D4, rectangle2D5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle3.getPosition();
        boolean boolean8 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) 100L, 0.0d);
        textTitle3.setVerticalAlignment(verticalAlignment10);
        boolean boolean15 = labelBlock1.equals((java.lang.Object) textTitle3);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        barRenderer0.setSeriesVisibleInLegend(16, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        boolean boolean7 = numberAxis0.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        numberAxis0.setPositiveArrowVisible(true);
        org.jfree.data.KeyedObjects keyedObjects12 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj14 = keyedObjects12.getObject((java.lang.Comparable) "RectangleEdge.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setUpperMargin((double) 10L);
        java.awt.Color color19 = java.awt.Color.green;
        numberAxis16.setTickLabelPaint((java.awt.Paint) color19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        boolean boolean28 = numberAxis16.hasListener((java.util.EventListener) categoryPlot27);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        categoryPlot27.notifyListeners(plotChangeEvent29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot27.getDataset((int) ' ');
        keyedObjects12.setObject((java.lang.Comparable) 10.0d, (java.lang.Object) categoryPlot27);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryDataset32);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("NOID", graphics2D1, (float) (short) 0, (float) 8, (double) (-10420321), (float) 100, (float) (-16731648));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        barRenderer0.setSeriesVisible(192, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition(15, itemLabelPosition9, false);
        java.awt.Paint paint12 = null;
        try {
            barRenderer0.setBaseItemLabelPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer7);
        boolean boolean9 = categoryPlot8.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot8.setFixedLegendItems(legendItemCollection10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot8.getRendererForDataset(categoryDataset12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke20 = null;
        barRenderer18.setSeriesOutlineStroke(0, stroke20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.awt.Stroke stroke23 = categoryPlot22.getDomainGridlineStroke();
        categoryPlot8.setDomainGridlineStroke(stroke23);
        boolean boolean25 = categoryPlot8.isRangeZoomable();
        boolean boolean26 = categoryPlot8.isRangeCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot8.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font1, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextOutlinePaint();
        java.awt.Shape shape33 = defaultDrawingSupplier30.getNextShape();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = null;
        categoryPlot11.setFixedLegendItems(legendItemCollection13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot11.getRendererForDataset(categoryDataset15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke23 = null;
        barRenderer21.setSeriesOutlineStroke(0, stroke23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer21);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        categoryPlot11.setDomainGridlineStroke(stroke26);
        boolean boolean28 = categoryPlot11.isRangeZoomable();
        boolean boolean29 = categoryPlot11.isRangeCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font4, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        java.awt.Stroke stroke35 = defaultDrawingSupplier33.getNextStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color1, stroke35);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.TextTitle textTitle16 = null;
        jFreeChart15.setTitle(textTitle16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        boolean boolean20 = jFreeChart15.isNotify();
        float float21 = jFreeChart15.getBackgroundImageAlpha();
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart15.addProgressListener(chartProgressListener22);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        textLine4.draw(graphics2D5, (float) (byte) 1, (float) (short) 10, textAnchor8, (float) 2, (float) 100, 100.0d);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.VERTICAL", graphics2D1, 0.8f, (float) 0L, textAnchor8, (double) (short) 1, textAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot6.axisChanged(axisChangeEvent19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = null;
        try {
            categoryPlot6.setInsets(rectangleInsets21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) '#');
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setUpperMargin((double) 10L);
        java.awt.Color color6 = java.awt.Color.green;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        boolean boolean15 = numberAxis3.hasListener((java.util.EventListener) categoryPlot14);
        double double16 = numberAxis3.getAutoRangeMinimumSize();
        org.jfree.data.Range range17 = numberAxis3.getDefaultAutoRange();
        double double18 = range17.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint2.toRangeWidth(range17);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        java.awt.Paint paint14 = numberAxis0.getLabelPaint();
        numberAxis0.centerRange((double) 255);
        boolean boolean17 = numberAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        barRenderer7.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RectangleEdge.TOP");
        java.lang.Object obj4 = keyedObjects0.getObject((int) (byte) -1);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.JFreeChart jFreeChart5 = titleChangeEvent4.getChart();
        java.lang.Object obj6 = titleChangeEvent4.getSource();
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color19 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font18, (java.awt.Paint) color19, (float) '4');
        textLine16.addFragment(textFragment21);
        java.awt.Font font23 = textFragment21.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        boolean boolean31 = categoryPlot30.isRangeCrosshairLockedOnData();
        java.awt.Paint paint32 = categoryPlot30.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("", font23, paint32);
        barRenderer0.setBaseItemLabelFont(font23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(itemLabelPosition35);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getVersion();
        java.lang.String str10 = projectInfo7.getVersion();
        projectInfo7.setLicenceName("[size=1]");
        org.jfree.chart.ui.Library[] libraryArray13 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray13);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean7 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic5);
        legendGraphic5.setShapeOutlineVisible(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setUpperMargin((double) 10L);
        java.awt.Color color14 = java.awt.Color.green;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer21);
        boolean boolean23 = numberAxis11.hasListener((java.util.EventListener) categoryPlot22);
        double double24 = numberAxis11.getAutoRangeMinimumSize();
        org.jfree.data.Range range25 = numberAxis11.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range25, (double) 100.0f);
        org.jfree.data.Range range28 = rectangleConstraint27.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint27.toFixedHeight((double) 10L);
        try {
            org.jfree.chart.util.Size2D size2D31 = legendGraphic5.arrange(graphics2D10, rectangleConstraint27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = null;
        barRenderer16.setSeriesOutlineStroke(0, stroke18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Stroke stroke21 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot6.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot6.isRangeZoomable();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot6.setRangeGridlineStroke(stroke24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot6.getDomainMarkers((-1), layer29);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(collection30);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        projectInfo7.addOptionalLibrary("hi!");
        projectInfo7.setVersion("UnitType.ABSOLUTE");
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        boolean boolean7 = numberAxis0.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        boolean boolean10 = numberAxis0.isAutoRange();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape13, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape13, "");
        numberAxis0.setUpArrow(shape13);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        java.lang.String str21 = legendItemEntity20.toString();
        java.lang.String str22 = legendItemEntity20.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str21.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str22.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setNotify(false);
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean13 = objectList11.equals((java.lang.Object) axisSpace12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = null;
        barRenderer17.setSeriesOutlineStroke(0, stroke19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Stroke stroke22 = categoryPlot21.getDomainGridlineStroke();
        categoryPlot21.clearDomainMarkers(8);
        java.util.List list25 = categoryPlot21.getAnnotations();
        int int26 = objectList11.indexOf((java.lang.Object) categoryPlot21);
        java.awt.Paint paint27 = categoryPlot21.getDomainGridlinePaint();
        jFreeChart7.setBorderPaint(paint27);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart7.getPadding();
        java.lang.Object obj10 = jFreeChart7.clone();
        java.awt.Image image11 = null;
        jFreeChart7.setBackgroundImage(image11);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setMaximumBarWidth((double) (byte) 1);
        barRenderer0.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            boolean boolean14 = categoryPlot6.removeAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        java.awt.Stroke stroke20 = barRenderer0.getSeriesOutlineStroke((int) (short) 0);
        barRenderer0.setBaseSeriesVisible(false, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(stroke20);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        java.awt.Shape shape9 = null;
        legendGraphic5.setLine(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic5.getShapeLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic5.getShapeLocation();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str14 = textBlockAnchor13.toString();
        java.lang.String str15 = textBlockAnchor13.toString();
        java.lang.String str16 = textBlockAnchor13.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = categoryLabelPosition17.getWidthType();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = categoryLabelPosition17.getLabelAnchor();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str14.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str15.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str16.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString((double) 10L);
        java.lang.String str4 = numberTickUnit0.valueToString((double) (byte) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer5.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean10 = barRenderer5.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer5.getGradientPaintTransformer();
        barRenderer5.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer5.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        int int19 = numberTickUnit0.compareTo((java.lang.Object) 500);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.fireChartChanged();
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=0,b=0]", "MINOR", "", "java.awt.Color[r=0,g=0,b=0]");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray4, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ItemLabelAnchor.CENTER", numberArray6);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset8, (java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        double[] doubleArray17 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray24 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray31 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray38 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray45 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray52 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray53 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot6.getRendererForDataset(categoryDataset54);
        categoryPlot6.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNull(categoryItemRenderer55);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color19 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font18, (java.awt.Paint) color19, (float) '4');
        textLine16.addFragment(textFragment21);
        java.awt.Font font23 = textFragment21.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        boolean boolean31 = categoryPlot30.isRangeCrosshairLockedOnData();
        java.awt.Paint paint32 = categoryPlot30.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("", font23, paint32);
        barRenderer0.setBaseItemLabelFont(font23);
        java.awt.Color color36 = java.awt.Color.RED;
        barRenderer0.setSeriesPaint((int) (short) 1, (java.awt.Paint) color36);
        java.awt.Paint paint40 = barRenderer0.getItemLabelPaint((int) ' ', 15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = objectList10.equals((java.lang.Object) paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape9, paint11);
        numberAxis0.setUpArrow(shape9);
        numberAxis0.setVerticalTickLabels(false);
        org.jfree.data.RangeType rangeType17 = org.jfree.data.RangeType.FULL;
        java.lang.Class<?> wildcardClass18 = rangeType17.getClass();
        numberAxis0.setRangeType(rangeType17);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle16.getItemContainer();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color23 = color22.darker();
        java.awt.Color color25 = java.awt.Color.green;
        java.awt.Color color26 = color25.darker();
        java.awt.Color color27 = java.awt.Color.getColor("hi!", color25);
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        float[] floatArray35 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray36 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray35);
        float[] floatArray37 = color23.getColorComponents(colorSpace28, floatArray35);
        legendTitle16.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList41 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint42 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean43 = objectList41.equals((java.lang.Object) paint42);
        org.jfree.chart.title.LegendGraphic legendGraphic44 = new org.jfree.chart.title.LegendGraphic(shape40, paint42);
        org.jfree.chart.block.BlockFrame blockFrame45 = legendGraphic44.getFrame();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendGraphic44);
        boolean boolean47 = legendGraphic44.isShapeOutlineVisible();
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        legendGraphic44.setLinePaint(paint48);
        legendTitle16.setBackgroundPaint(paint48);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(blockFrame45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot6.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot6.getFixedLegendItems();
        float float27 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot6.getColumnRenderingOrder();
        java.awt.Paint paint29 = categoryPlot6.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        textTitle0.setNotify(false);
        double double4 = textTitle0.getWidth();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (-1), (double) 100L, rectangleAnchor12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setUpperMargin((double) 10L);
        java.awt.Color color18 = java.awt.Color.green;
        numberAxis15.setTickLabelPaint((java.awt.Paint) color18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        boolean boolean27 = numberAxis15.hasListener((java.util.EventListener) categoryPlot26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot26.getDataset();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.title.LegendTitle legendTitle30 = jFreeChart29.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer31 = legendTitle30.getItemContainer();
        java.awt.Font font32 = legendTitle30.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder();
        legendTitle30.setFrame((org.jfree.chart.block.BlockFrame) lineBorder33);
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle30.getBounds();
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D13, rectangle2D35);
        barRenderer0.setSeriesShape((int) (short) 0, (java.awt.Shape) rectangle2D35, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(legendTitle30);
        org.junit.Assert.assertNotNull(blockContainer31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 10L);
        java.awt.Color color13 = java.awt.Color.green;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        boolean boolean22 = numberAxis10.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = categoryPlot21.getDataset();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot21);
        java.awt.Color color25 = java.awt.Color.green;
        jFreeChart24.setBorderPaint((java.awt.Paint) color25);
        categoryPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot6.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(categoryDataset23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNull(axisSpace29);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        categoryPlot6.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) (short) 1, 100);
        java.awt.Stroke stroke10 = barRenderer0.getSeriesOutlineStroke((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        boolean boolean18 = categoryPlot17.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        categoryPlot17.setFixedLegendItems(legendItemCollection19);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot17.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot17.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke26 = null;
        barRenderer24.setSeriesOutlineStroke(0, stroke26);
        categoryPlot17.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer24, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = barRenderer24.getSeriesNegativeItemLabelPosition((-16777216));
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator33);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        boolean boolean21 = numberAxis2.isTickLabelsVisible();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.Plot plot23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot30.getRenderer();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = textLine33.calculateDimensions(graphics2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) '#', (double) 0.0f, rectangleAnchor38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = plotRenderingInfo42.getOwner();
        boolean boolean44 = categoryPlot30.render(graphics2D32, rectangle2D39, (int) (byte) -1, plotRenderingInfo42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        numberAxis47.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis47, categoryItemRenderer50);
        boolean boolean52 = categoryPlot51.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot51.getDomainAxisEdge(0);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        numberAxis57.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) numberAxis57, categoryItemRenderer60);
        boolean boolean62 = categoryPlot61.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection63 = null;
        categoryPlot61.setFixedLegendItems(legendItemCollection63);
        org.jfree.chart.util.SortOrder sortOrder65 = categoryPlot61.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder66 = categoryPlot61.getDatasetRenderingOrder();
        java.awt.Stroke stroke67 = categoryPlot61.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection68 = categoryPlot61.getFixedLegendItems();
        org.jfree.chart.util.ObjectList objectList69 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisSpace axisSpace70 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean71 = objectList69.equals((java.lang.Object) axisSpace70);
        axisSpace70.setLeft((double) 'a');
        categoryPlot61.setFixedRangeAxisSpace(axisSpace70);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace75 = numberAxis2.reserveSpace(graphics2D22, plot23, rectangle2D39, rectangleEdge54, axisSpace70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNull(chartRenderingInfo43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(sortOrder65);
        org.junit.Assert.assertNotNull(datasetRenderingOrder66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNull(legendItemCollection68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setUpperMargin((double) 10L);
        java.awt.Color color26 = java.awt.Color.green;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer33);
        boolean boolean35 = numberAxis23.hasListener((java.util.EventListener) categoryPlot34);
        double double36 = numberAxis23.getAutoRangeMinimumSize();
        org.jfree.data.Range range37 = numberAxis23.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(range37, (double) 100.0f);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude(range37, (double) (short) 10);
        numberAxis2.setRangeWithMargins(range37);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0E-8d + "'", double36 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.8f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot6.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot6.setDomainAxes(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        boolean boolean26 = categoryPlot25.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = null;
        categoryPlot25.setFixedLegendItems(legendItemCollection27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot25.getRendererForDataset(categoryDataset29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot25.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke37 = null;
        barRenderer35.setSeriesOutlineStroke(0, stroke37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        java.awt.Stroke stroke40 = categoryPlot39.getDomainGridlineStroke();
        categoryPlot25.setDomainGridlineStroke(stroke40);
        boolean boolean42 = categoryPlot25.isRangeZoomable();
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot25.setRangeGridlineStroke(stroke43);
        boolean boolean45 = color18.equals((java.lang.Object) stroke43);
        legendTitle16.setItemPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        java.awt.Color color8 = java.awt.Color.blue;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color8);
        numberAxis3.setAutoRangeStickyZero(false);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList14 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = objectList14.equals((java.lang.Object) paint15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape13, paint15);
        numberAxis3.setRightArrow(shape13);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape13, (double) (-16731648), 2.0f, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.extendHeight(10.0d);
        valueMarker14.setLabelOffset(rectangleInsets15);
        float float19 = valueMarker14.getAlpha();
        double double20 = valueMarker14.getValue();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        java.awt.Stroke stroke22 = valueMarker14.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.8f + "'", float19 == 0.8f);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "CategoryLabelWidthType.CATEGORY", "RangeType.NEGATIVE");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        double double3 = categoryItemRendererState1.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.String str8 = chartEntity7.getToolTipText();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setUpperMargin((double) 10L);
        java.awt.Color color12 = java.awt.Color.green;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = numberAxis9.hasListener((java.util.EventListener) categoryPlot20);
        double double22 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.Range range23 = numberAxis9.getDefaultAutoRange();
        boolean boolean24 = chartEntity7.equals((java.lang.Object) range23);
        java.lang.String str25 = range23.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Range[0.0,1.0]" + "'", str25.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart15.getTitle();
        org.jfree.chart.plot.Plot plot19 = jFreeChart15.getPlot();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(plot19);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1), (double) 100L, rectangleAnchor3);
        double double5 = size2D0.getWidth();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = objectList10.equals((java.lang.Object) paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape9, paint11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendGraphic13.arrange(graphics2D14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendGraphic13.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) -1, 600.0d, rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        int int13 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        categoryPlot13.setFixedLegendItems(legendItemCollection15);
        java.awt.Paint paint17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryPlot13.setNoDataMessagePaint(paint17);
        barRenderer0.setSeriesPaint(15, paint17);
        double double20 = barRenderer0.getMaximumBarWidth();
        java.awt.Paint paint23 = barRenderer0.getItemLabelPaint((-16777216), 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(categoryAxis8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot6.getParent();
        double[] doubleArray19 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray26 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray33 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray40 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray47 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray54 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray55);
        java.lang.Number number57 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset56);
        categoryPlot6.setDataset(categoryDataset56);
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset56);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-6.0d) + "'", number57.equals((-6.0d)));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 600.0d + "'", number58.equals(600.0d));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (-1.0d) + "'", number60.equals((-1.0d)));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getRangeAxisEdge(0);
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint11 = lineBorder10.getPaint();
        java.awt.Paint paint12 = lineBorder10.getPaint();
        barRenderer0.setBaseItemLabelPaint(paint12, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font12);
        org.jfree.chart.plot.Plot plot14 = numberAxis0.getPlot();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList17 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = objectList17.equals((java.lang.Object) paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape16, paint18);
        boolean boolean21 = legendGraphic20.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic20.setMargin(rectangleInsets22);
        double double25 = rectangleInsets22.calculateLeftOutset((-1.0d));
        numberAxis0.setLabelInsets(rectangleInsets22);
        try {
            numberAxis0.setRange((double) 10L, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5, (float) '4');
        textLine2.addFragment(textFragment7);
        java.awt.Font font9 = textFragment7.getFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("MINOR", font9);
        java.awt.Font font11 = labelBlock10.getFont();
        double double12 = labelBlock10.getContentXOffset();
        java.awt.Color color13 = java.awt.Color.green;
        java.awt.Color color14 = color13.darker();
        labelBlock10.setPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint5 = barRenderer0.getBasePaint();
        barRenderer0.setSeriesVisible(192, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.extendHeight(10.0d);
        valueMarker27.setLabelOffset(rectangleInsets28);
        java.lang.Number[] numberArray34 = new java.lang.Number[] {};
        java.lang.Number[] numberArray35 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray34, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis39.setUpArrow(shape42);
        boolean boolean44 = numberAxis39.getAutoRangeIncludesZero();
        boolean boolean45 = numberAxis39.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean49 = barRenderer46.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean51 = barRenderer46.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer52 = barRenderer46.getGradientPaintTransformer();
        barRenderer46.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer46);
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection58 = categoryPlot56.getRangeMarkers(layer57);
        categoryPlot6.addRangeMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker27, layer57);
        java.lang.String str60 = valueMarker27.getLabel();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 10.0d + "'", double30 == 10.0d);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(boolean51);
        org.junit.Assert.assertNotNull(gradientPaintTransformer52);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNull(str60);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "CategoryLabelWidthType.CATEGORY", (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        boolean boolean19 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot6.getLegendItems();
        int int21 = legendItemCollection20.getItemCount();
        java.util.Iterator iterator22 = legendItemCollection20.iterator();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(iterator22);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean20 = color17.equals((java.lang.Object) shape19);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke41 = null;
        barRenderer39.setSeriesOutlineStroke(0, stroke41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Stroke stroke44 = categoryPlot43.getDomainGridlineStroke();
        categoryPlot29.setDomainGridlineStroke(stroke44);
        barRenderer0.setSeriesOutlineStroke(10, stroke44);
        boolean boolean47 = barRenderer0.getAutoPopulateSeriesFillPaint();
        barRenderer0.setSeriesItemLabelsVisible(2, (java.lang.Boolean) true, false);
        java.awt.Font font53 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color54 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("", font53, (java.awt.Paint) color54, 0.0f);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color54, true);
        java.awt.Stroke stroke60 = barRenderer0.getSeriesStroke(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNull(stroke60);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle16.getItemContainer();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color23 = color22.darker();
        java.awt.Color color25 = java.awt.Color.green;
        java.awt.Color color26 = color25.darker();
        java.awt.Color color27 = java.awt.Color.getColor("hi!", color25);
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        float[] floatArray35 = new float[] { '#', 1.0f, 1.0f };
        float[] floatArray36 = java.awt.Color.RGBtoHSB(1, (-16777216), (int) (byte) 0, floatArray35);
        float[] floatArray37 = color23.getColorComponents(colorSpace28, floatArray35);
        legendTitle16.setBackgroundPaint((java.awt.Paint) color23);
        java.lang.String str39 = legendTitle16.getID();
        org.jfree.chart.block.BlockContainer blockContainer40 = legendTitle16.getItemContainer();
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.util.Size2D size2D43 = textLine41.calculateDimensions(graphics2D42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, (double) '#', (double) 0.0f, rectangleAnchor46);
        legendTitle16.setLegendItemGraphicLocation(rectangleAnchor46);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(blockContainer40);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis7.setStandardTickUnits(tickUnitSource27);
        java.awt.Shape shape29 = numberAxis7.getRightArrow();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        try {
            numberAxis0.setRange((double) (short) 100, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot11.notifyListeners(plotChangeEvent13);
        boolean boolean15 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) (-1), (double) 100L, rectangleAnchor26);
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D27);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList31 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint32 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean33 = objectList31.equals((java.lang.Object) paint32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape30, paint32);
        boolean boolean35 = legendGraphic34.isLineVisible();
        java.awt.Paint paint36 = null;
        legendGraphic34.setFillPaint(paint36);
        java.awt.Shape shape38 = null;
        legendGraphic34.setLine(shape38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendGraphic34.getShapeLocation();
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor40);
        categoryPlot11.zoomDomainAxes((double) 2, plotRenderingInfo20, point2D41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo20.getPlotArea();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNull(rectangle2D43);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        java.awt.Paint paint7 = null;
        legendGraphic5.setFillPaint(paint7);
        legendGraphic5.setLineVisible(false);
        boolean boolean11 = legendGraphic5.isLineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = objectList10.equals((java.lang.Object) paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape9, paint11);
        numberAxis0.setUpArrow(shape9);
        numberAxis0.setUpperBound(600.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.awt.Shape shape27 = barRenderer14.getItemShape((int) (byte) 0, (int) (byte) 100);
        double double28 = barRenderer14.getItemMargin();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer3.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean12 = color9.equals((java.lang.Object) shape11);
        barRenderer3.setSeriesShape((int) '4', shape11);
        java.lang.Boolean boolean15 = barRenderer3.getSeriesCreateEntities(0);
        barRenderer3.setBaseSeriesVisible(false, false);
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color20 = color19.darker();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean23 = color20.equals((java.lang.Object) shape22);
        barRenderer3.setBaseFillPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot32.getRendererForDataset(categoryDataset36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot32.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke44 = null;
        barRenderer42.setSeriesOutlineStroke(0, stroke44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        java.awt.Stroke stroke47 = categoryPlot46.getDomainGridlineStroke();
        categoryPlot32.setDomainGridlineStroke(stroke47);
        barRenderer3.setSeriesOutlineStroke(10, stroke47);
        numberAxis0.setAxisLineStroke(stroke47);
        numberAxis0.setTickMarkOutsideLength(100.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setUpperMargin((double) 10L);
        java.awt.Color color21 = java.awt.Color.green;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        int int23 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot15.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke37 = null;
        barRenderer35.setSeriesOutlineStroke(0, stroke37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        java.awt.Stroke stroke40 = categoryPlot39.getDomainGridlineStroke();
        numberAxis27.setTickMarkStroke(stroke40);
        categoryPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis27);
        java.awt.Font font43 = numberAxis27.getLabelFont();
        java.awt.Font font44 = numberAxis27.getTickLabelFont();
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        java.awt.Color color5 = color4.darker();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean8 = color5.equals((java.lang.Object) shape7);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color5, (float) (short) 0, 192, textMeasurer11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment16, 0.0d, (double) (-1.0f));
        textTitle13.setTextAlignment(horizontalAlignment14);
        textBlock12.setLineAlignment(horizontalAlignment14);
        textTitle0.setTextAlignment(horizontalAlignment14);
        org.jfree.chart.util.ObjectList objectList27 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int29 = objectList27.indexOf((java.lang.Object) color28);
        textTitle0.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj32 = textTitle31.clone();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer38);
        boolean boolean40 = categoryPlot39.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = null;
        categoryPlot39.setFixedLegendItems(legendItemCollection41);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot39.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot39.getRangeAxis((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double48 = rectangleInsets46.calculateLeftInset((double) 192);
        categoryPlot39.setInsets(rectangleInsets46);
        textTitle31.setMargin(rectangleInsets46);
        textTitle0.setMargin(rectangleInsets46);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 3.0d + "'", double48 == 3.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        boolean boolean18 = barRenderer0.hasListener((java.util.EventListener) categoryPlot12);
        barRenderer0.setItemMargin((double) 500);
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesFillPaint();
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Stroke stroke8 = barRenderer0.getItemOutlineStroke((int) 'a', 8);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset5, 2);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset5, (double) (short) 0);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        textTitle20.draw(graphics2D21, rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle20.getPosition();
        axisState18.moveCursor((double) (-1), rectangleEdge24);
        axisCollection4.add((org.jfree.chart.axis.Axis) numberAxis5, rectangleEdge24);
        java.awt.Shape shape27 = numberAxis5.getRightArrow();
        java.awt.Color color28 = java.awt.Color.lightGray;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperMargin((double) 10L);
        java.awt.Color color32 = java.awt.Color.green;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke39 = null;
        barRenderer37.setSeriesOutlineStroke(0, stroke39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer37);
        java.awt.Stroke stroke42 = categoryPlot41.getDomainGridlineStroke();
        numberAxis29.setTickMarkStroke(stroke42);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean47 = barRenderer44.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color49 = java.awt.Color.green;
        java.awt.Color color50 = color49.darker();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean53 = color50.equals((java.lang.Object) shape52);
        barRenderer44.setSeriesShape((int) '4', shape52);
        barRenderer44.setBaseCreateEntities(false, true);
        barRenderer44.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color64 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer44.setBasePaint((java.awt.Paint) color64, true);
        java.awt.Paint paint68 = barRenderer44.lookupSeriesPaint(8);
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "HorizontalAlignment.CENTER", "RectangleEdge.TOP", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", shape27, (java.awt.Paint) color28, stroke42, paint68);
        java.awt.Paint paint70 = legendItem69.getOutlinePaint();
        java.awt.Stroke stroke71 = legendItem69.getOutlineStroke();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot7.setDomainAxisLocation(16, axisLocation10);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle16.getFrame();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle16.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (-1.0f));
        org.jfree.chart.block.CenterArrangement centerArrangement9 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean28 = jFreeChart27.isBorderVisible();
        jFreeChart27.setTitle("10");
        textTitle11.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        columnArrangement8.add((org.jfree.chart.block.Block) blockContainer10, (java.lang.Object) jFreeChart27);
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList35 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint36 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean37 = objectList35.equals((java.lang.Object) paint36);
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape34, paint36);
        boolean boolean39 = legendGraphic38.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic38.setMargin(rectangleInsets40);
        legendGraphic38.setPadding(2.0d, 0.0d, (double) (byte) 100, (double) 500);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendGraphic38.getShapeLocation();
        blockContainer10.add((org.jfree.chart.block.Block) legendGraphic38, (java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 2.0f, (double) 1.0f);
        double double24 = numberAxis2.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "UnitType.ABSOLUTE", "Category Plot");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint6 = barRenderer0.getBaseFillPaint();
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = null;
        categoryPlot14.setFixedLegendItems(legendItemCollection16);
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = categoryPlot14.getDatasetRenderingOrder();
        java.awt.Stroke stroke20 = categoryPlot14.getOutlineStroke();
        barRenderer0.setBaseStroke(stroke20);
        java.awt.Shape shape23 = null;
        barRenderer0.setSeriesShape(16, shape23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot15.getRenderer();
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setUpperMargin((double) 10L);
        java.awt.Color color21 = java.awt.Color.green;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        int int23 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot15.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperMargin((double) 10L);
        java.awt.Color color30 = java.awt.Color.green;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke37 = null;
        barRenderer35.setSeriesOutlineStroke(0, stroke37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        java.awt.Stroke stroke40 = categoryPlot39.getDomainGridlineStroke();
        numberAxis27.setTickMarkStroke(stroke40);
        categoryPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis27);
        java.awt.Font font43 = numberAxis27.getLabelFont();
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 0);
        numberAxis27.setDownArrow(shape45);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot12.getRenderer();
        categoryPlot12.setOutlineVisible(true);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setUpperMargin((double) 10L);
        java.awt.Color color25 = java.awt.Color.green;
        numberAxis22.setTickLabelPaint((java.awt.Paint) color25);
        numberAxis22.setAutoTickUnitSelection(true);
        java.awt.Paint paint29 = numberAxis22.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.Size2D size2D33 = textLine31.calculateDimensions(graphics2D32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) '#', (double) 0.0f, rectangleAnchor36);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        textTitle38.draw(graphics2D39, rectangle2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = textTitle38.getPosition();
        double double43 = numberAxis22.lengthToJava2D((double) 1, rectangle2D37, rectangleEdge42);
        plotRenderingInfo21.setDataArea(rectangle2D37);
        categoryPlot12.drawBackgroundImage(graphics2D19, rectangle2D37);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setNotify(false);
        jFreeChart7.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            jFreeChart7.handleClick((int) (short) 10, 192, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean6 = numberAxis0.isPositiveArrowVisible();
        boolean boolean7 = numberAxis0.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        numberAxis0.setAutoRangeIncludesZero(false);
        java.awt.Paint paint12 = numberAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, 0.0d);
        java.lang.String str5 = verticalAlignment1.toString();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        categoryPlot12.setFixedLegendItems(legendItemCollection14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRendererForDataset(categoryDataset16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = null;
        barRenderer22.setSeriesOutlineStroke(0, stroke24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer22);
        java.awt.Stroke stroke27 = categoryPlot26.getDomainGridlineStroke();
        categoryPlot12.setDomainGridlineStroke(stroke27);
        boolean boolean29 = categoryPlot12.isRangeZoomable();
        org.jfree.chart.plot.Plot plot30 = categoryPlot12.getParent();
        java.lang.Object obj31 = categoryPlot12.clone();
        boolean boolean32 = verticalAlignment1.equals(obj31);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.TOP" + "'", str5.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setPositiveArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setUpperMargin((double) 10L);
        java.awt.Color color6 = java.awt.Color.green;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        numberAxis3.setAutoTickUnitSelection(true);
        java.awt.Paint paint10 = numberAxis3.getTickMarkPaint();
        numberAxis0.setTickLabelPaint(paint10);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        legendGraphic5.setPadding(2.0d, 0.0d, (double) (byte) 100, (double) 500);
        legendGraphic5.setShapeFilled(true);
        java.lang.Object obj16 = null;
        boolean boolean17 = legendGraphic5.equals(obj16);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean4 = barRenderer0.isDrawBarOutline();
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint6 = barRenderer0.getBaseFillPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = null;
        categoryPlot14.setFixedLegendItems(legendItemCollection16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRendererForDataset(categoryDataset18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot14.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke26 = null;
        barRenderer24.setSeriesOutlineStroke(0, stroke26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer24);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke29);
        boolean boolean31 = categoryPlot14.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setUpperMargin((double) 10L);
        numberAxis32.setVerticalTickLabels(true);
        numberAxis32.setLabel("{0}");
        numberAxis32.setFixedDimension((double) 2);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) (-1), (double) 100L, rectangleAnchor45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer52);
        boolean boolean54 = categoryPlot53.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection55 = null;
        categoryPlot53.setFixedLegendItems(legendItemCollection55);
        org.jfree.chart.util.SortOrder sortOrder57 = categoryPlot53.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup58 = categoryPlot53.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        categoryPlot53.setDomainAxis(15, categoryAxis60, false);
        java.awt.Paint[] paintArray63 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray64 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray65 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray66 = null;
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray68 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier69 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray63, paintArray64, paintArray65, strokeArray66, strokeArray67, shapeArray68);
        java.awt.Paint paint70 = defaultDrawingSupplier69.getNextOutlinePaint();
        categoryPlot53.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier69);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot53.getRangeAxisEdge(0);
        double double74 = numberAxis32.java2DToValue((double) ' ', rectangle2D46, rectangleEdge73);
        try {
            barRenderer0.drawBackground(graphics2D7, categoryPlot14, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(sortOrder57);
        org.junit.Assert.assertNull(datasetGroup58);
        org.junit.Assert.assertNotNull(paintArray63);
        org.junit.Assert.assertNotNull(paintArray64);
        org.junit.Assert.assertNotNull(paintArray65);
        org.junit.Assert.assertNotNull(strokeArray67);
        org.junit.Assert.assertNotNull(shapeArray68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.NEGATIVE_INFINITY + "'", double74 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        double[] doubleArray17 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray24 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray31 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray38 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray45 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray52 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray53 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot6.getRendererForDataset(categoryDataset54);
        org.jfree.chart.LegendItemCollection legendItemCollection56 = categoryPlot6.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        numberAxis59.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer62);
        boolean boolean64 = categoryPlot63.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection65 = null;
        categoryPlot63.setFixedLegendItems(legendItemCollection65);
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = categoryPlot63.getRendererForDataset(categoryDataset67);
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot63.getRangeAxisLocation();
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot63);
        org.jfree.chart.plot.ValueMarker valueMarker72 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double75 = rectangleInsets73.extendHeight(10.0d);
        valueMarker72.setLabelOffset(rectangleInsets73);
        float float77 = valueMarker72.getAlpha();
        org.jfree.chart.util.Layer layer78 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker72, layer78);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNull(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(legendItemCollection56);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNull(categoryItemRenderer68);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 10.0d + "'", double75 == 10.0d);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.8f + "'", float77 == 0.8f);
        org.junit.Assert.assertNotNull(layer78);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.setAutoTickUnitSelection(true);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = numberAxis0.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis9.setUpArrow(shape12);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "", "hi!");
        numberAxis9.setDownArrow(shape16);
        numberAxis9.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.data.Range range24 = numberAxis9.getRange();
        numberAxis0.setRangeWithMargins(range24);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        double double2 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        java.lang.Object obj9 = legendGraphic5.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendGraphic5.getShapeAnchor();
        legendGraphic5.setPadding((double) 0L, (double) (byte) -1, (double) 0.95f, (double) 100);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        double double18 = numberAxis5.getAutoRangeMinimumSize();
        org.jfree.data.Range range19 = numberAxis5.getDefaultAutoRange();
        double double20 = range19.getUpperBound();
        numberAxis0.setRangeWithMargins(range19, true, false);
        java.awt.Font font24 = numberAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        numberAxis7.setFixedDimension(0.0d);
        boolean boolean27 = numberAxis7.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = legendGraphic5.arrange(graphics2D6);
        double double8 = size2D7.getHeight();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.0d + "'", double8 == 6.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        java.lang.Object obj3 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        java.awt.Paint paint8 = null;
        try {
            categoryPlot6.setRangeGridlinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer9.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        boolean boolean14 = barRenderer9.removeAnnotation(categoryAnnotation13);
        barRenderer9.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer9.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer9.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot25);
        barRenderer9.setPlot(categoryPlot25);
        java.awt.Paint paint28 = barRenderer9.getBaseOutlinePaint();
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer9);
        int int30 = barRenderer9.getColumnCount();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset5, 2);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset5, 16);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset5);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Font font18 = legendTitle16.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        legendTitle16.setFrame((org.jfree.chart.block.BlockFrame) lineBorder19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer21.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.darker();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean30 = color27.equals((java.lang.Object) shape29);
        barRenderer21.setSeriesShape((int) '4', shape29);
        java.awt.Paint paint33 = barRenderer21.lookupSeriesPaint(0);
        barRenderer21.setIncludeBaseInRange(false);
        java.awt.Paint paint36 = barRenderer21.getBasePaint();
        legendTitle16.setItemPaint(paint36);
        org.jfree.chart.axis.AxisState axisState38 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        textTitle40.draw(graphics2D41, rectangle2D42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = textTitle40.getPosition();
        axisState38.moveCursor((double) (-1), rectangleEdge44);
        java.lang.String str46 = rectangleEdge44.toString();
        legendTitle16.setPosition(rectangleEdge44);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "RectangleEdge.TOP" + "'", str46.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = numberAxis2.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot13.getDataset();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot13);
        boolean boolean17 = jFreeChart16.isBorderVisible();
        jFreeChart16.setTitle("10");
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        categoryPlot27.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot27.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot27.getRangeAxis((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double36 = rectangleInsets34.calculateLeftInset((double) 192);
        categoryPlot27.setInsets(rectangleInsets34);
        jFreeChart16.setPadding(rectangleInsets34);
        double double40 = rectangleInsets34.extendWidth((-1.0d));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 5.0d + "'", double40 == 5.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot16.getDataset();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle20.getItemContainer();
        java.awt.Font font22 = legendTitle20.getItemFont();
        barRenderer0.setBaseItemLabelFont(font22, true);
        barRenderer0.setItemMargin((double) 0L);
        barRenderer0.setSeriesVisibleInLegend(500, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int3 = java.awt.Color.HSBtoRGB((float) 192, (float) 'a', (float) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-7839) + "'", int3 == (-7839));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        double double18 = legendTitle16.getHeight();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) (short) 1, 100);
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesStroke();
        double double10 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = null;
        barRenderer0.setSeriesStroke((int) (byte) 10, stroke12, false);
        boolean boolean16 = barRenderer0.isSeriesVisible((int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "Layer.BACKGROUND", 500, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", 0.0f, "Range[0.0,1.0]" };
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { (-10420321), 3.0d, "AxisLocation.BOTTOM_OR_LEFT" };
        double[] doubleArray18 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray25 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray32 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray39 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray46 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[] doubleArray53 = new double[] { 2.0f, 2.0f, (byte) -1, (-1.0d), 100L, (short) 100 };
        double[][] doubleArray54 = new double[][] { doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "DatasetRenderingOrder.REVERSE", doubleArray54);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray9, doubleArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Color color16 = java.awt.Color.green;
        jFreeChart15.setBorderPaint((java.awt.Paint) color16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart15.handleClick(0, 255, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer7);
        java.lang.String str9 = numberAxis4.getLabelURL();
        boolean boolean10 = tickType0.equals((java.lang.Object) numberAxis4);
        java.lang.String str11 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "MINOR" + "'", str11.equals("MINOR"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset5);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset5, false);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset5);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0d + "'", number9.equals(0.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray17, paintArray18, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot6.getRangeAxisEdge(0);
        java.util.List list27 = categoryPlot6.getAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperMargin((double) 10L);
        java.awt.Color color32 = java.awt.Color.green;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis36, categoryItemRenderer39);
        boolean boolean41 = numberAxis29.hasListener((java.util.EventListener) categoryPlot40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot40.getDataset();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot40);
        java.awt.Color color44 = java.awt.Color.green;
        jFreeChart43.setBorderPaint((java.awt.Paint) color44);
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color44);
        int int47 = color44.getRGB();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-16711936) + "'", int47 == (-16711936));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = null;
        barRenderer13.setSeriesOutlineStroke(0, stroke15);
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13, false);
        barRenderer13.setBaseCreateEntities(true, true);
        barRenderer13.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean4 = objectList2.equals((java.lang.Object) paint3);
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, paint3);
        boolean boolean6 = legendGraphic5.isLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendGraphic5.setMargin(rectangleInsets7);
        legendGraphic5.setPadding(2.0d, 0.0d, (double) (byte) 100, (double) 500);
        legendGraphic5.setShapeFilled(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer16.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer16.removeAnnotation(categoryAnnotation20);
        java.awt.Paint paint22 = barRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        barRenderer16.setBaseItemLabelGenerator(categoryItemLabelGenerator23, false);
        barRenderer16.setItemLabelAnchorOffset((double) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer33);
        boolean boolean35 = categoryPlot34.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = null;
        categoryPlot34.setFixedLegendItems(legendItemCollection36);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot34.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup39 = categoryPlot34.getDatasetGroup();
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke43 = null;
        barRenderer41.setSeriesOutlineStroke(0, stroke43);
        categoryPlot34.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer41, false);
        boolean boolean47 = categoryPlot34.isOutlineVisible();
        categoryPlot34.clearRangeMarkers();
        java.awt.Stroke stroke49 = categoryPlot34.getOutlineStroke();
        barRenderer16.setBaseStroke(stroke49, false);
        legendGraphic5.setOutlineStroke(stroke49);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNull(datasetGroup39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        boolean boolean17 = jFreeChart15.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart15.setPadding(rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = jFreeChart15.getPadding();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.extendHeight(10.0d);
        valueMarker1.setLabelOffset(rectangleInsets2);
        float float6 = valueMarker1.getAlpha();
        double double7 = valueMarker1.getValue();
        java.awt.Stroke stroke8 = valueMarker1.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean17 = jFreeChart16.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = jFreeChart16.getCategoryPlot();
        boolean boolean19 = categoryPlot18.isDomainGridlinesVisible();
        java.awt.Stroke stroke20 = categoryPlot18.getOutlineStroke();
        valueMarker1.setOutlineStroke(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.8f + "'", float6 == 0.8f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(categoryPlot18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        centerArrangement0.clear();
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font22 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color23 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("", font22, (java.awt.Paint) color23, (float) '4');
        textLine20.addFragment(textFragment25);
        java.awt.Font font27 = textFragment25.getFont();
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("MINOR", font27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis29.setUpArrow(shape32);
        boolean boolean34 = numberAxis29.getAutoRangeIncludesZero();
        boolean boolean35 = numberAxis29.isPositiveArrowVisible();
        boolean boolean36 = numberAxis29.isVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis29.setMarkerBand(markerAxisBand37);
        boolean boolean39 = numberAxis29.isAutoRange();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity(shape42, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape42, "");
        numberAxis29.setUpArrow(shape42);
        java.awt.Shape shape49 = numberAxis29.getLeftArrow();
        blockContainer17.add((org.jfree.chart.block.Block) labelBlock28, (java.lang.Object) shape49);
        labelBlock28.setURLText("ItemLabelAnchor.CENTER");
        java.lang.Object obj53 = null;
        boolean boolean54 = labelBlock28.equals(obj53);
        java.lang.Object obj55 = labelBlock28.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(obj55);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test426");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RangeType.NEGATIVE", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer12.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean16 = barRenderer12.isDrawBarOutline();
        boolean boolean17 = barRenderer12.getAutoPopulateSeriesStroke();
        java.awt.Paint paint18 = barRenderer12.getBaseFillPaint();
        barRenderer0.setSeriesOutlinePaint(100, paint18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot6.axisChanged(axisChangeEvent19);
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis0.setUpArrow(shape3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "", "hi!");
        numberAxis0.setDownArrow(shape7);
        numberAxis0.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis0.getTickUnit();
        int int16 = numberTickUnit15.getMinorTickCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean16 = jFreeChart15.isBorderVisible();
        boolean boolean17 = jFreeChart15.isNotify();
        jFreeChart15.setAntiAlias(false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot20 = jFreeChart15.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Image image9 = jFreeChart8.getBackgroundImage();
        boolean boolean10 = rectangleAnchor0.equals((java.lang.Object) image9);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, 1.0f, (float) '4', textAnchor4, (double) 0.0f, textAnchor6);
        java.lang.String str8 = textAnchor6.toString();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str8.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Paint paint6 = barRenderer0.getBaseFillPaint();
        java.awt.Paint paint7 = barRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "", "LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle16.getPosition();
        axisState14.moveCursor((double) (-1), rectangleEdge20);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge20);
        double double23 = numberAxis1.getFixedAutoRange();
        numberAxis1.setLabel("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("java.awt.Color[r=0,g=178,b=0]");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot16);
        barRenderer0.setPlot(categoryPlot16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        int int20 = categoryPlot16.getDomainAxisIndex(categoryAxis19);
        boolean boolean21 = categoryPlot16.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        java.awt.Color color29 = java.awt.Color.blue;
        numberAxis24.setTickLabelPaint((java.awt.Paint) color29);
        java.awt.color.ColorSpace colorSpace31 = color29.getColorSpace();
        categoryPlot16.setRangeGridlinePaint((java.awt.Paint) color29);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot16.setRangeAxisLocation(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer7.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean11 = barRenderer7.isDrawBarOutline();
        boolean boolean12 = numberAxis2.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis2.lengthToJava2D((double) 192, rectangle2D18, rectangleEdge19);
        numberAxis2.resizeRange((double) 2.0f, (double) 1.0f);
        numberAxis2.setTickMarkOutsideLength((float) (-1L));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        numberAxis2.setTickMarkPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.Plot plot28 = null;
        numberAxis2.setPlot(plot28);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = color2.darker();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean6 = color3.equals((java.lang.Object) shape5);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color3, (float) (short) 0, 192, textMeasurer9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment13, verticalAlignment14, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment14, 0.0d, (double) (-1.0f));
        textTitle11.setTextAlignment(horizontalAlignment12);
        textBlock10.setLineAlignment(horizontalAlignment12);
        java.util.List list23 = textBlock10.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textBlock10.getLineAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot31);
        boolean boolean33 = jFreeChart32.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = jFreeChart32.getCategoryPlot();
        org.jfree.chart.event.ChartProgressListener chartProgressListener35 = null;
        jFreeChart32.removeProgressListener(chartProgressListener35);
        boolean boolean37 = textBlock10.equals((java.lang.Object) chartProgressListener35);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(categoryPlot34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setUpperMargin((double) 10L);
        java.awt.Color color17 = java.awt.Color.green;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot6.axisChanged(axisChangeEvent19);
        org.jfree.chart.axis.Axis axis21 = axisChangeEvent19.getAxis();
        org.jfree.chart.axis.Axis axis22 = axisChangeEvent19.getAxis();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(axis21);
        org.junit.Assert.assertNotNull(axis22);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("java.awt.Color[r=0,g=178,b=0]");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) (short) 1, 100);
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesStroke();
        double double10 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setUpperMargin((double) 10L);
        java.awt.Color color15 = java.awt.Color.green;
        numberAxis12.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        boolean boolean24 = numberAxis12.hasListener((java.util.EventListener) categoryPlot23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot23.getDataset();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.title.LegendTitle legendTitle27 = jFreeChart26.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer28 = legendTitle27.getItemContainer();
        java.awt.Font font29 = legendTitle27.getItemFont();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder();
        legendTitle27.setFrame((org.jfree.chart.block.BlockFrame) lineBorder30);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle27.getBounds();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray33 = legendTitle27.getSources();
        java.awt.Paint paint34 = legendTitle27.getBackgroundPaint();
        barRenderer0.setBaseOutlinePaint(paint34, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(legendTitle27);
        org.junit.Assert.assertNotNull(blockContainer28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(legendItemSourceArray33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", image3, "", "hi!", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getVersion();
        java.lang.String str10 = projectInfo7.getVersion();
        projectInfo7.setLicenceName("[size=1]");
        java.lang.String str13 = projectInfo7.getLicenceName();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[size=1]" + "'", str13.equals("[size=1]"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle16.getPosition();
        axisState14.moveCursor((double) (-1), rectangleEdge20);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis23, rectangleEdge24);
        java.util.List list26 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_CENTER", font1, (java.awt.Paint) color5);
        java.util.List list8 = textBlock7.getLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot7);
        categoryPlot7.mapDatasetToRangeAxis(500, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot7.setDomainAxis(categoryAxis12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot7.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("CategoryLabelWidthType.CATEGORY", (org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.title.TextTitle textTitle16 = null;
        jFreeChart15.setTitle(textTitle16);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, 0.0f);
        java.lang.String str7 = textFragment6.getText();
        textLine1.addFragment(textFragment6);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1), (double) 100L, rectangleAnchor3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation5, plotOrientation6);
        double double8 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D4, rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setRangeWithMargins((-6.0d), (double) '4');
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer0.removeAnnotation(categoryAnnotation4);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getBaseItemLabelGenerator();
        java.awt.Color color11 = java.awt.Color.white;
        barRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color11, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator15, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer0.getPositiveItemLabelPosition((int) 'a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float1 = categoryLabelPosition0.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        float float3 = categoryLabelPosition0.getWidthRatio();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.95f + "'", float1 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.95f + "'", float3 == 0.95f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RangeType.NEGATIVE", "PlotOrientation.VERTICAL", "TextAnchor.HALF_ASCENT_RIGHT", "PlotOrientation.VERTICAL");
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.trimHeight((double) 0.0f);
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, (double) (-1), (double) 100L, rectangleAnchor10);
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D11);
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets2.createInsetRectangle(rectangle2D11, false, false);
        plotRenderingInfo1.setDataArea(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setInverted(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.extendHeight(10.0d);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (-1), (double) 100L, rectangleAnchor17);
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets9.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D18, (double) 8, 0.0f, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis2, shape26, "", "ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 100L, 0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) (-1.0f));
        textTitle0.setTextAlignment(horizontalAlignment1);
        java.awt.Paint paint11 = textTitle0.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        textTitle0.setPosition(rectangleEdge12);
        textTitle0.setURLText("{0}");
        java.lang.Object obj17 = textTitle0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList6 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint7 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean8 = objectList6.equals((java.lang.Object) paint7);
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape5, paint7);
        boolean boolean10 = legendGraphic9.isLineVisible();
        java.awt.Paint paint11 = null;
        legendGraphic9.setFillPaint(paint11);
        java.awt.Shape shape13 = null;
        legendGraphic9.setLine(shape13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendGraphic9.getShapeLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendGraphic9.getShapeLocation();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str18 = textBlockAnchor17.toString();
        java.lang.String str19 = textBlockAnchor17.toString();
        java.lang.String str20 = textBlockAnchor17.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions3, categoryLabelPosition21);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        boolean boolean31 = categoryPlot30.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = null;
        categoryPlot30.setFixedLegendItems(legendItemCollection32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot30.getRendererForDataset(categoryDataset34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot30.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke42 = null;
        barRenderer40.setSeriesOutlineStroke(0, stroke42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer40);
        java.awt.Stroke stroke45 = categoryPlot44.getDomainGridlineStroke();
        categoryPlot30.setDomainGridlineStroke(stroke45);
        boolean boolean47 = categoryPlot30.isRangeZoomable();
        boolean boolean48 = categoryPlot30.isRangeCrosshairVisible();
        boolean boolean49 = categoryLabelPosition21.equals((java.lang.Object) boolean48);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str18.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str19.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str20.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.FULL;
        java.lang.Class<?> wildcardClass2 = rangeType1.getClass();
        org.jfree.data.KeyedObject keyedObject3 = new org.jfree.data.KeyedObject((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=1.0]", (java.lang.Object) rangeType1);
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 100, (float) 0L);
        java.awt.Color color8 = color7.darker();
        keyedObject3.setObject((java.lang.Object) color7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = categoryPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = null;
        categoryPlot16.setFixedLegendItems(legendItemCollection18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot16.getRendererForDataset(categoryDataset20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot16.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot16.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setUpperMargin((double) 10L);
        java.awt.Color color27 = java.awt.Color.green;
        numberAxis24.setTickLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis24);
        categoryPlot16.axisChanged(axisChangeEvent29);
        keyedObject3.setObject((java.lang.Object) categoryPlot16);
        categoryPlot16.clearDomainAxes();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Color color2 = java.awt.Color.getColor("ChartChangeEventType.GENERAL", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle2.getPosition();
        axisState0.moveCursor((double) (-1), rectangleEdge6);
        java.util.List list8 = axisState0.getTicks();
        axisState0.setMax((double) 0.5f);
        double double11 = axisState0.getMax();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        categoryPlot6.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setBaseSeriesVisible(true, false);
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.Block block19 = null;
        java.lang.Object obj20 = null;
        columnArrangement18.add(block19, obj20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer13, (org.jfree.chart.block.Arrangement) columnArrangement17, (org.jfree.chart.block.Arrangement) columnArrangement18);
        org.jfree.chart.block.CenterArrangement centerArrangement23 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6, (org.jfree.chart.block.Arrangement) columnArrangement18, (org.jfree.chart.block.Arrangement) centerArrangement23);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setUpperMargin((double) 10L);
        java.awt.Color color28 = java.awt.Color.green;
        numberAxis25.setTickLabelPaint((java.awt.Paint) color28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis32, categoryItemRenderer35);
        boolean boolean37 = numberAxis25.hasListener((java.util.EventListener) categoryPlot36);
        double double38 = numberAxis25.getAutoRangeMinimumSize();
        org.jfree.data.Range range39 = numberAxis25.getDefaultAutoRange();
        double double40 = range39.getUpperBound();
        org.jfree.chart.block.CenterArrangement centerArrangement41 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement41);
        boolean boolean43 = range39.equals((java.lang.Object) blockContainer42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.Image image48 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo52 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image48, "hi!", "", "hi!");
        org.jfree.data.Range range54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range54);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = rectangleConstraint55.toUnconstrainedWidth();
        boolean boolean57 = projectInfo52.equals((java.lang.Object) rectangleConstraint55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        numberAxis58.setUpperMargin((double) 10L);
        java.awt.Color color61 = java.awt.Color.green;
        numberAxis58.setTickLabelPaint((java.awt.Paint) color61);
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        numberAxis65.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, (org.jfree.chart.axis.ValueAxis) numberAxis65, categoryItemRenderer68);
        boolean boolean70 = numberAxis58.hasListener((java.util.EventListener) categoryPlot69);
        double double71 = numberAxis58.getAutoRangeMinimumSize();
        org.jfree.data.Range range72 = numberAxis58.getDefaultAutoRange();
        java.lang.Object obj73 = null;
        boolean boolean74 = range72.equals(obj73);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint75 = rectangleConstraint55.toRangeHeight(range72);
        org.jfree.data.Range range77 = org.jfree.data.Range.expandToInclude(range72, 10.0d);
        double double78 = range77.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis79.setUpArrow(shape82);
        java.awt.Shape shape86 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity89 = new org.jfree.chart.entity.ChartEntity(shape86, "", "hi!");
        numberAxis79.setDownArrow(shape86);
        numberAxis79.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.data.Range range94 = numberAxis79.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint95 = new org.jfree.chart.block.RectangleConstraint(range77, range94);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType96 = rectangleConstraint95.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D97 = centerArrangement23.arrange(blockContainer42, graphics2D44, rectangleConstraint95);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0E-8d + "'", double38 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0E-8d + "'", double71 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint75);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.0d + "'", double78 == 10.0d);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertNotNull(range94);
        org.junit.Assert.assertNotNull(lengthConstraintType96);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setIncludeBaseInRange(false);
        barRenderer0.setBaseCreateEntities(true, true);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = barRenderer0.getLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNull(drawingSupplier19);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart7.getCategoryPlot();
        boolean boolean10 = categoryPlot9.isDomainGridlinesVisible();
        java.awt.Stroke stroke11 = categoryPlot9.getOutlineStroke();
        java.util.List list12 = categoryPlot9.getCategories();
        categoryPlot9.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = categoryPlot9.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(categoryPlot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(list12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        java.util.List list2 = axisState0.getTicks();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        textTitle20.draw(graphics2D21, rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle20.getPosition();
        axisState18.moveCursor((double) (-1), rectangleEdge24);
        axisCollection4.add((org.jfree.chart.axis.Axis) numberAxis5, rectangleEdge24);
        java.awt.Shape shape27 = numberAxis5.getRightArrow();
        java.awt.Color color28 = java.awt.Color.lightGray;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperMargin((double) 10L);
        java.awt.Color color32 = java.awt.Color.green;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke39 = null;
        barRenderer37.setSeriesOutlineStroke(0, stroke39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer37);
        java.awt.Stroke stroke42 = categoryPlot41.getDomainGridlineStroke();
        numberAxis29.setTickMarkStroke(stroke42);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean47 = barRenderer44.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color49 = java.awt.Color.green;
        java.awt.Color color50 = color49.darker();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean53 = color50.equals((java.lang.Object) shape52);
        barRenderer44.setSeriesShape((int) '4', shape52);
        barRenderer44.setBaseCreateEntities(false, true);
        barRenderer44.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) false);
        java.awt.Color color64 = java.awt.Color.getHSBColor((float) 1, (float) (-1L), 10.0f);
        barRenderer44.setBasePaint((java.awt.Paint) color64, true);
        java.awt.Paint paint68 = barRenderer44.lookupSeriesPaint(8);
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "HorizontalAlignment.CENTER", "RectangleEdge.TOP", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", shape27, (java.awt.Paint) color28, stroke42, paint68);
        int int70 = legendItem69.getDatasetIndex();
        java.lang.Number[] numberArray73 = new java.lang.Number[] {};
        java.lang.Number[] numberArray74 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray73, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray75);
        org.jfree.data.general.PieDataset pieDataset78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset76, 2);
        legendItem69.setDataset((org.jfree.data.general.Dataset) categoryDataset76);
        java.lang.String str80 = legendItem69.getToolTipText();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(pieDataset78);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "RectangleEdge.TOP" + "'", str80.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean8 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxisForDataset(16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis10);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = null;
        barRenderer16.setSeriesOutlineStroke(0, stroke18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Stroke stroke21 = categoryPlot20.getDomainGridlineStroke();
        categoryPlot6.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot6.isRangeZoomable();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot6.setRangeGridlineStroke(stroke24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setUpperMargin((double) 10L);
        java.awt.Paint paint31 = numberAxis28.getTickMarkPaint();
        categoryPlot6.setNoDataMessagePaint(paint31);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", "TextBlockAnchor.TOP_CENTER", "NOID", "", " version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!");
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = color5.darker();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean9 = color6.equals((java.lang.Object) shape8);
        barRenderer0.setSeriesShape((int) '4', shape8);
        barRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer16.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean21 = barRenderer16.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = barRenderer16.getGradientPaintTransformer();
        barRenderer16.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer16.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Paint paint32 = barRenderer16.getItemLabelPaint(192, 1);
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font36 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color37 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("", font36, (java.awt.Paint) color37, (float) '4');
        textLine34.addFragment(textFragment39);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType41 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean43 = categoryLabelWidthType41.equals((java.lang.Object) font42);
        boolean boolean44 = textFragment39.equals((java.lang.Object) font42);
        barRenderer16.setBaseItemLabelFont(font42, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer16.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator47);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator47);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(gradientPaintTransformer22);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(categoryLabelWidthType41);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setLabel("{0}");
        numberAxis0.setFixedDimension((double) 2);
        numberAxis0.centerRange((double) (short) 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4, (float) '4');
        textLine1.addFragment(textFragment6);
        float float8 = textFragment6.getBaselineOffset();
        java.lang.String str9 = textFragment6.getText();
        float float10 = textFragment6.getBaselineOffset();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("java.awt.Color[r=0,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=0,g=0,b=0]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setUpperMargin((double) 10L);
        java.awt.Color color6 = java.awt.Color.green;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        boolean boolean15 = numberAxis3.hasListener((java.util.EventListener) categoryPlot14);
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        textTitle18.draw(graphics2D19, rectangle2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle18.getPosition();
        axisState16.moveCursor((double) (-1), rectangleEdge22);
        axisCollection2.add((org.jfree.chart.axis.Axis) numberAxis3, rectangleEdge22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisCollection2.add((org.jfree.chart.axis.Axis) numberAxis25, rectangleEdge26);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition28 = categoryLabelPositions1.getLabelPosition(rectangleEdge26);
        float float29 = categoryLabelPosition28.getWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(categoryLabelPosition28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.95f + "'", float29 == 0.95f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getBlue();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        float[] floatArray10 = new float[] { (short) 0, 2.0f, (short) 1, 500, 100 };
        float[] floatArray11 = color4.getColorComponents(floatArray10);
        float[] floatArray12 = color3.getComponents(floatArray10);
        float[] floatArray13 = color1.getRGBColorComponents(floatArray12);
        java.awt.Color color14 = java.awt.Color.getColor(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot6.setDomainAxis(15, categoryAxis13, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot6.getRangeAxisEdge((int) ' ');
        categoryPlot6.mapDatasetToRangeAxis(2, (int) (short) 100);
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 0.0f, dataset22);
        categoryPlot6.datasetChanged(datasetChangeEvent23);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setUpperMargin((double) 10L);
        java.awt.Paint paint7 = numberAxis4.getTickMarkPaint();
        float float8 = numberAxis4.getTickMarkOutsideLength();
        java.awt.Paint paint9 = numberAxis4.getTickLabelPaint();
        java.awt.Paint paint10 = numberAxis4.getTickMarkPaint();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (short) 1, (double) 500, 0.0d, paint10);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperMargin((double) 10L);
        java.awt.Color color4 = java.awt.Color.green;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        boolean boolean13 = numberAxis1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot12.getDataset();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart15.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList20 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean22 = objectList20.equals((java.lang.Object) paint21);
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape19, paint21);
        boolean boolean24 = legendGraphic23.isLineVisible();
        legendGraphic23.setHeight((double) (-1L));
        java.awt.Paint paint27 = legendGraphic23.getOutlinePaint();
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = color28.darker();
        legendGraphic23.setLinePaint((java.awt.Paint) color28);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendGraphic23.getPadding();
        double double32 = rectangleInsets31.getTop();
        legendTitle16.setItemLabelPadding(rectangleInsets31);
        double double35 = rectangleInsets31.calculateTopOutset((double) (-1.0f));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(legendTitle16);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.0d + "'", double35 == 2.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        java.lang.String str9 = categoryPlot6.getPlotType();
        java.awt.Paint paint10 = categoryPlot6.getNoDataMessagePaint();
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getDomainAxisLocation(500);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(192, 1);
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("");
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color21 = java.awt.Color.green;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("", font20, (java.awt.Paint) color21, (float) '4');
        textLine18.addFragment(textFragment23);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean27 = categoryLabelWidthType25.equals((java.lang.Object) font26);
        boolean boolean28 = textFragment23.equals((java.lang.Object) font26);
        barRenderer0.setBaseItemLabelFont(font26, true);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        boolean boolean38 = categoryPlot37.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot37.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot37.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup42 = categoryPlot37.getDatasetGroup();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.Range range44 = categoryPlot37.getDataRange(valueAxis43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot37.setInsets(rectangleInsets45);
        barRenderer0.setPlot(categoryPlot37);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(sortOrder41);
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint12 = categoryPlot6.getRangeCrosshairPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) (-1), (double) 100L, rectangleAnchor19);
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-4.725d), (double) (short) 10, rectangle2D20);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint25 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean26 = objectList24.equals((java.lang.Object) paint25);
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape23, paint25);
        boolean boolean28 = legendGraphic27.isLineVisible();
        java.awt.Paint paint29 = null;
        legendGraphic27.setFillPaint(paint29);
        java.awt.Shape shape31 = null;
        legendGraphic27.setLine(shape31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = legendGraphic27.getShapeLocation();
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor33);
        try {
            categoryPlot6.drawBackground(graphics2D13, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        java.lang.String str9 = categoryPlot6.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot6.getInsets();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle2.getPosition();
        axisState0.moveCursor((double) (-1), rectangleEdge6);
        java.util.List list8 = axisState0.getTicks();
        axisState0.setMax((double) 0.5f);
        axisState0.cursorDown(10.0d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        double double2 = valueMarker1.getValue();
        java.awt.Paint paint3 = valueMarker1.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeCrosshairLockedOnData();
        java.awt.Paint paint12 = categoryPlot10.getBackgroundPaint();
        valueMarker1.setOutlinePaint(paint12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.axis.TickType tickType3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick(tickType3, (double) (short) 0, "hi!", textAnchor6, textAnchor7, (double) (byte) 100);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Shape shape17 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D11, 1.0f, (float) '4', textAnchor14, (double) 0.0f, textAnchor16);
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 1, "ItemLabelAnchor.CENTER", textAnchor7, textAnchor16, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor20 = numberTick19.getTextAnchor();
        java.lang.Number number21 = numberTick19.getNumber();
        double double22 = numberTick19.getAngle();
        double double23 = numberTick19.getAngle();
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.0d + "'", number21.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer7);
        boolean boolean9 = categoryPlot8.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot8.setFixedLegendItems(legendItemCollection10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot8.getRendererForDataset(categoryDataset12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke20 = null;
        barRenderer18.setSeriesOutlineStroke(0, stroke20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.awt.Stroke stroke23 = categoryPlot22.getDomainGridlineStroke();
        categoryPlot8.setDomainGridlineStroke(stroke23);
        boolean boolean25 = categoryPlot8.isRangeZoomable();
        boolean boolean26 = categoryPlot8.isRangeCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot8.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font1, (org.jfree.chart.plot.Plot) categoryPlot8, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = null;
        try {
            categoryPlot8.addDomainMarker(categoryMarker30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setUpperMargin((double) 10L);
        java.awt.Color color5 = java.awt.Color.green;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        boolean boolean14 = numberAxis2.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot13.getDataset();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot13);
        boolean boolean17 = jFreeChart16.isBorderVisible();
        jFreeChart16.setTitle("10");
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.awt.Graphics2D graphics2D21 = null;
        try {
            org.jfree.chart.util.Size2D size2D22 = textTitle0.arrange(graphics2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer8.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean12 = barRenderer8.isDrawBarOutline();
        java.awt.Paint paint13 = barRenderer8.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer8.getNegativeItemLabelPosition(1, 2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition16.getItemLabelAnchor();
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition16, true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = objectList4.equals((java.lang.Object) paint5);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape3, paint5);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape3, "AxisLocation.TOP_OR_LEFT", "Range[0.0,1.0]");
        boolean boolean11 = color0.equals((java.lang.Object) "Range[0.0,1.0]");
        int int12 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis7.setUpArrow(shape10);
        boolean boolean12 = numberAxis7.getAutoRangeIncludesZero();
        boolean boolean13 = numberAxis7.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer14.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean19 = barRenderer14.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = barRenderer14.getGradientPaintTransformer();
        barRenderer14.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset5);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset5);
        org.jfree.data.general.PieDataset pieDataset28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset5, (java.lang.Comparable) 0.5f);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset5, (double) (byte) 0);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset28);
        org.junit.Assert.assertNull(range30);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) (short) 1, 100);
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesStroke();
        double double10 = barRenderer0.getLowerClip();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        java.lang.String str13 = projectInfo7.toString();
        java.lang.String str14 = projectInfo7.getInfo();
        java.awt.Image image18 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo22 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image18, "hi!", "", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo22);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!" + "'", str13.equals(" version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot6.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        categoryPlot18.setFixedLegendItems(legendItemCollection20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot18.getRowRenderingOrder();
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot18.setDomainAxis(15, categoryAxis25, false);
        java.awt.Paint[] paintArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray31 = null;
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray29, paintArray30, strokeArray31, strokeArray32, shapeArray33);
        java.awt.Paint paint35 = defaultDrawingSupplier34.getNextOutlinePaint();
        categoryPlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double42 = rectangleInsets40.extendHeight(10.0d);
        valueMarker39.setLabelOffset(rectangleInsets40);
        java.lang.Number[] numberArray46 = new java.lang.Number[] {};
        java.lang.Number[] numberArray47 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray46, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis51.setUpArrow(shape54);
        boolean boolean56 = numberAxis51.getAutoRangeIncludesZero();
        boolean boolean57 = numberAxis51.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean61 = barRenderer58.getItemCreateEntity((int) (short) -1, 0);
        java.lang.Boolean boolean63 = barRenderer58.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = barRenderer58.getGradientPaintTransformer();
        barRenderer58.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer58);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection70 = categoryPlot68.getRangeMarkers(layer69);
        categoryPlot18.addRangeMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker39, layer69);
        java.util.Collection collection72 = categoryPlot6.getDomainMarkers(layer69);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10.0d + "'", double42 == 10.0d);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(boolean63);
        org.junit.Assert.assertNotNull(gradientPaintTransformer64);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNotNull(collection70);
        org.junit.Assert.assertNull(collection72);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        barRenderer3.notifyListeners(rendererChangeEvent8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer10.getItemCreateEntity((int) (short) -1, 0);
        java.awt.Color color15 = java.awt.Color.green;
        java.awt.Color color16 = color15.darker();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean19 = color16.equals((java.lang.Object) shape18);
        barRenderer10.setSeriesShape((int) '4', shape18);
        java.lang.Boolean boolean22 = barRenderer10.getSeriesCreateEntities(0);
        barRenderer10.setBaseSeriesVisible(false, false);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.darker();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        boolean boolean30 = color27.equals((java.lang.Object) shape29);
        barRenderer10.setBaseFillPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer38);
        boolean boolean40 = categoryPlot39.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = null;
        categoryPlot39.setFixedLegendItems(legendItemCollection41);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot39.getRendererForDataset(categoryDataset43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot39.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke51 = null;
        barRenderer49.setSeriesOutlineStroke(0, stroke51);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer49);
        java.awt.Stroke stroke54 = categoryPlot53.getDomainGridlineStroke();
        categoryPlot39.setDomainGridlineStroke(stroke54);
        barRenderer10.setSeriesOutlineStroke(10, stroke54);
        boolean boolean57 = barRenderer10.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean62 = barRenderer59.getItemCreateEntity((int) (short) -1, 0);
        boolean boolean63 = barRenderer59.isDrawBarOutline();
        java.awt.Paint paint64 = barRenderer59.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition67 = barRenderer59.getNegativeItemLabelPosition(1, 2);
        barRenderer10.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition67);
        barRenderer3.setNegativeItemLabelPositionFallback(itemLabelPosition67);
        java.awt.Paint paint70 = barRenderer3.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(categoryItemRenderer44);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(itemLabelPosition67);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setUpperMargin((double) 10L);
        java.awt.Color color8 = java.awt.Color.green;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        boolean boolean17 = numberAxis5.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot16.getDataset();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        boolean boolean21 = jFreeChart19.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart19.setPadding(rectangleInsets22);
        java.awt.Paint paint24 = jFreeChart19.getBackgroundPaint();
        boolean boolean25 = jFreeChart19.isNotify();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer32);
        boolean boolean34 = categoryPlot33.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = null;
        categoryPlot33.setFixedLegendItems(legendItemCollection35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot33.getRendererForDataset(categoryDataset37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot33.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke45 = null;
        barRenderer43.setSeriesOutlineStroke(0, stroke45);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer43);
        java.awt.Stroke stroke48 = categoryPlot47.getDomainGridlineStroke();
        categoryPlot33.setDomainGridlineStroke(stroke48);
        boolean boolean50 = categoryPlot33.isRangeZoomable();
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot33.setRangeGridlineStroke(stroke51);
        boolean boolean53 = color26.equals((java.lang.Object) stroke51);
        jFreeChart19.setBorderStroke(stroke51);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "hi!", "", "hi!");
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        boolean boolean12 = projectInfo7.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperMargin((double) 10L);
        java.awt.Color color16 = java.awt.Color.green;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        boolean boolean25 = numberAxis13.hasListener((java.util.EventListener) categoryPlot24);
        double double26 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.Range range27 = numberAxis13.getDefaultAutoRange();
        java.lang.Object obj28 = null;
        boolean boolean29 = range27.equals(obj28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint10.toRangeHeight(range27);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range27, 10.0d);
        double double33 = range32.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        numberAxis34.setUpArrow(shape37);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape41, "", "hi!");
        numberAxis34.setDownArrow(shape41);
        numberAxis34.setRangeWithMargins((double) (byte) -1, 0.0d);
        org.jfree.data.Range range49 = numberAxis34.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(range32, range49);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = rectangleConstraint50.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape2, " version .\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", "DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot6.getBackgroundPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot6.setDomainAxis((int) (short) 1, categoryAxis10, false);
        boolean boolean13 = categoryPlot6.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.configure();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 10L);
        java.awt.Color color13 = java.awt.Color.green;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color13);
        numberAxis10.setAutoTickUnitSelection(true);
        java.awt.Paint paint17 = numberAxis10.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textLine19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', (double) 0.0f, rectangleAnchor24);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        textTitle26.draw(graphics2D27, rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = textTitle26.getPosition();
        double double31 = numberAxis10.lengthToJava2D((double) 1, rectangle2D25, rectangleEdge30);
        plotRenderingInfo9.setDataArea(rectangle2D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double34 = categoryAxis0.getCategoryEnd((-16777216), 500, rectangle2D25, rectangleEdge33);
        categoryAxis0.setMaximumCategoryLabelLines(8);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10L);
        java.awt.Color color3 = java.awt.Color.green;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelAngle((double) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        boolean boolean12 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        double double13 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range14, (double) 100.0f);
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range17, (double) (byte) 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
    }
}

